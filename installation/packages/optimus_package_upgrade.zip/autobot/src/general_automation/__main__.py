#!/usr/bin/env python
# coding: utf-8

if __name__ == "__main__":    
    from prefect import tags
    import config # call config upon startup - required to get background argument to modify flow name before calling run flow
    import core.initialize

    if 'arguments' in config.program_args:
        config.constants['arg'] = config.program_args['arguments']

    if config.program_args['flowrun']==3: # DEBUG
        config.variables['break point'] = config.program_args['arguments'].split(' , ')[1]
        config.variables['window position'] = eval(config.program_args['arguments'].split(' , ')[0])
        #print('####### arg' , config.program_args)
        #print('####### cont' , config.constants)    
        #print('####### var' , config.variables)        

    if '4' in str(config.program_args['background']):
        deploymentname = config.program_args['startfile'] + "_TRIGGER"
    else:
        deploymentname = config.program_args['startfile']

    #timeout = 60*50 #3 * 60  # 1 hour = 60 min x 60 sec
    retries = int(config.program_args['retries'])
    tag = config.program_args['tag']

    print(deploymentname, config.program_args['startsheet'], config.program_args['startcode'])

    if config.program_args['startsheet']!="main": deploymentname=deploymentname+'_'+config.program_args['startsheet']
    if config.program_args['startcode']!="main": deploymentname=deploymentname+'_'+config.program_args['startcode']

    with tags(tag):   #("production", "test"):
        #run()  # has tags: a, b
        from run import run
        result = run.with_options(name=deploymentname, description=deploymentname, retries=retries)(flowrun=config.program_args['flowrun']) #, timeout_seconds=timeout)()

