_A=None
from pathlib import Path,PureWindowsPath
import sys,os
from datetime import datetime
from prefect import task,flow,get_run_logger,context
from config import log_space,codeVersion,startTime
from auto_utility_file import killprocess
from job_monitor import touchFile,stateChange,write_yaml,read_yaml,triggerRPA
@flow(name='launch-autobot',description='launch autobot rpa flow',version=codeVersion,retries=0)
def run(file='',flowrun=1,deploymentname='',PROGRAM_DIR='',update='',retries='',startcode='',startsheet='',background='',retry_delay_seconds=30,**y):
	l='%m/%d/%Y, %H:%M:%S';k='======================== TEARDOWN ========================';j='OPEN_CLOSE';i='PROGRAM_DIR';h='error';g='arguments';Y=deploymentname;P=flowrun;O=True;M=update;J=startsheet;I=startcode;F=background;E=PROGRAM_DIR;B=file;import initialize;C=get_run_logger();C.debug(f"Run started ... ");from pathlib import Path as D;Z=D('.').resolve().absolute().__str__()
	if E=='':E=D(Z).parents[0].resolve().absolute().__str__()
	a=D(__file__).parents[0].resolve().absolute().__str__();b=D(f"{E}/autobot/venv/Lib/site-packages").resolve().absolute().__str__();m=D(f"{E}/autobot/src/general_automation").resolve().absolute().__str__();c=D(f"{E}/autobot/src/general_automation/libraries").resolve().absolute().__str__();sys.path.append(a);sys.path.append(b);sys.path.append(m);sys.path.append(c);C.debug(f"Flow Run Parameters: \n         {log_space}PROGRAM_DIR={E}, \n         {log_space}current_DIR={Z} | \n         {log_space}Module path:{a} and {b} and {c} | \n         {log_space}__file__={__file__} | flowExecute file={B}, flowrun={P}, deploymentname={Y} ");from config import configuResultMsg as n;from config import isDeploymentFlowRun;import config as A
	if context.get_run_context().flow_run.deployment_id==_A:
		import config as A
		if B=='':B=A.STARTFILE
		if J=='':J=A.STARTSHEET
		if I=='':I=A.STARTCODE
		if F=='':F=A.BACKGROUND
		if M=='':M=A.UPDATE
		if E=='':E=A.PROGRAM_DIR
		Q=D(A.STARTFILE).stem.__str__()+'-'+A.STARTSHEET+'-'+A.STARTCODE
	else:Q=Y;A.STARTFILE=B;A.UPDATE=M;A.RETRIES=retries;A.BACKGROUND=F
	from config import variables as o
	if'3'in str(F):o['headless_mode']=O
	if'4'in str(F)or'5'in str(F):print(f"background:{F} | Trigger script: {triggerRPA(B,memoryPath=MEMORYPATH)}");return
	A.flow_run_name=context.get_run_context().flow_run.dict()['name'];C.debug(f"RUN Settngs ... \n{n()}");A.variables['flowrun']=A.flow_run_name;A.variables[g]=A.program_args[g].split('  ,  ');A.variables[h]=''
	try:
		from auto_helper_lib import try_catch as K;from core.auto_core_lib import runCodelist as L;from auto_initialize import changeWorkingDirectory as p;from config import ASSETS_DIR as q,CWD_DIR as r,program_args;r=p(q)
		if P==1:
			from libraries.Windows import _runRPAscript;G=context.get_run_context().flow_run.parameters;s=f"-sc {G['startcode']} -sh {G['startsheet']} -b {G['background']} -r {G['retries']} -u {G['update']}";from pathlib import Path as D;d=D(G[i]).resolve()/'runRPA.bat';R=D(G[i]).resolve()/'scripts'/f"{G['file']}";S=f"{str(d)} -f {R.stem} {s}";C.warning(S)
			if d.exists()and R.exists():import subprocess as t;z=t.Popen(S,shell=O);C.warning(f"*** LAUNCH: {R.stem} | {S}")
			return O
		u,T,H,v,e,N=optimus_open.with_options(name='OPEN',tags=[j])(startfile=B,startsheet=J,startcode=I,background=F,program_dir=E,update=M)
		if P==2:K(L(H,['Deploy:'],file=B))
		else:
			if e!=_A:C.info('======================== SETUP ========================');K(L(H,e,file=B))
			C.info(f"============ RUN SCRIPT: {B} ============");K(L(H,v,file=B))
			if N!=_A:C.info(k);K(L(H,N,file=B))
		optimus_close.with_options(name='CLOSE',tags=[j])(u,T,H,B)
	except Exception as U:
		if U.__str__()=='Excel.Application.Workbooks':C.critical(f"kiil process: {killprocess('excel')}")
		try:A.variables[h]=U.__str__();raise ValueError(f"Software Error: {U}")
		finally:
			f=f".\\{A.startTime.strftime('%Y%m%d_%H%M%S')}_{A.flow_run_name}_ERROR.jpg";C.warning(f"======================== EXCEPTION ERROR ======================== Screenshot: {f}");from auto_utility_file import printscreen as w;w(f)
			if N!=_A:C.info(k);K(L(H,N,file=B))
			from config import RPABROWSER as V
			if V==0:import rpa as x;T=x.close();print('Close finally',T);selectedWindows.getNew();selectedWindows.closeNew()
			from auto_utility_dates import getDuration as W;X=W(startTime,datetime.now());C.info(f"Completed RPA flow. File: {B} | {Q} | Sheet: {J} {I} | Time: {datetime.now().strftime(l)} | {X}")
	from config import RPABROWSER as V
	if V==0:selectedWindows.getNew();selectedWindows.closeNew()
	from auto_utility_dates import getDuration as W;X=W(startTime,datetime.now());C.info(f"Completed RPA flow. File: {B} | {Q} | Sheet: {J} {I} | Time: {datetime.now().strftime(l)} | {X}");return O
@task(name='OPEN')
def optimus_open(startfile,startsheet,startcode,background,program_dir,update):
	L='RPABROWSER';K='browserDisable';I=startfile;F=False;D=program_dir;C=startsheet;M=get_run_logger();from auto_utility_file import runInBackground as N
	if'1'in str(background):N(D)
	from utility_excel import isFileNewer,pickle_storeData,pickle_loadData,cacheScripts as G;from auto_helper_lib import try_catch,readExcelConfig,dfKey_value as E,dfObjList as H;from core.auto_core_lib import runCodelist;import pandas as O;A,B=G(script=Path(I).name,df=O.DataFrame(),program_dir=D,startsheet=C,refresh=bool(update),msgStr='');A,B=G(script='OptimusLib.xlsm',df=A,program_dir=D,startsheet=C,refresh=F,msgStr=B);A,B=G(script='OptimusLibPublic.xlsm',df=A,program_dir=D,startsheet=C,refresh=F,msgStr=B);P=F if E(A,K)==_A else E(A,K);Q=F;import config as J;J.RPABROWSER=0 if E(A,L)==_A else int(E(A,L));B=f"Start file:{Path(I).name}, sheet:{C}, RPA Browser:{J.RPABROWSER}\n {log_space}Scripts files loaded:\n"+B;M.debug(f"{B}");R=H(A,startcode);S=H(A,'[Setup]');T=H(A,'[Teardown]');return P,Q,A,R,S,T
@task
def optimus_close(browserDisable,instantiatedRPA,dfmain,file):
	A=instantiatedRPA;import rpa as B;from auto_helper_lib import try_catch,dfObjList;from core.auto_core_lib import runCodelist
	if not browserDisable and not A:A=B.close()
	from auto_helper_lib import Window,process_list;return