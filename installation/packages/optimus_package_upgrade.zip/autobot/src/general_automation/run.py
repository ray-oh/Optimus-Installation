
from pathlib import Path, PureWindowsPath
import sys, os
from datetime import datetime
from prefect import task, flow, get_run_logger, context
from config import log_space, codeVersion, startTime  
from core.files import killprocess
from job_monitor import touchFile, stateChange, write_yaml, read_yaml, triggerRPA 
@flow(name='launch-autobot', 
      description='launch autobot rpa flow', version=codeVersion, retries=0)
def run(file = '', flowrun = 1, deploymentname = '', PROGRAM_DIR = '', update = '', retries = '',
            startcode = '', startsheet = '', background = '', retry_delay_seconds=30, **kwargs):
    import core.initialize
    logger = get_run_logger()
    logger.debug(f"Run started ... ") 
    from pathlib import Path
    current_DIR = Path('.').resolve().absolute().__str__()
    if PROGRAM_DIR == '': PROGRAM_DIR = Path(current_DIR).parents[0].resolve().absolute().__str__()
    MODULE_PATH_file = Path(__file__).parents[0].resolve().absolute().__str__()
    MODULE_PATH_lib = Path(f"{PROGRAM_DIR}/autobot/venv/Lib/site-packages").resolve().absolute().__str__()  
    MODULE_PATH_src = Path(f"{PROGRAM_DIR}/autobot/src/general_automation").resolve().absolute().__str__()
    MODULE_PATH_libraries = Path(f"{PROGRAM_DIR}/autobot/src/general_automation/libraries").resolve().absolute().__str__()  
    sys.path.append(MODULE_PATH_file)
    sys.path.append(MODULE_PATH_lib)
    sys.path.append(MODULE_PATH_src)    
    sys.path.append(MODULE_PATH_libraries)
    logger.debug(f"Flow Run Parameters: \n \
        {log_space}PROGRAM_DIR={PROGRAM_DIR}, \n \
        {log_space}current_DIR={current_DIR} | \n \
        {log_space}Module path:{MODULE_PATH_file} and {MODULE_PATH_lib} and {MODULE_PATH_libraries} | \n \
        {log_space}__file__={__file__} | flowExecute file={file}, flowrun={flowrun}, deploymentname={deploymentname} ")  
    from config import configuResultMsg
    from config import isDeploymentFlowRun
    
    
    import config
    if context.get_run_context().flow_run.deployment_id == None:
        import config
        if file == '': file = config.STARTFILE 
        if startsheet == '': startsheet = config.STARTSHEET
        if startcode == '': startcode=config.STARTCODE
        if background == '': background=config.BACKGROUND
        if update == '': update=config.UPDATE
        if PROGRAM_DIR == '': PROGRAM_DIR = config.PROGRAM_DIR
        
        flowname = Path(config.STARTFILE).stem.__str__() + "-" + config.STARTSHEET + "-" + config.STARTCODE
    else:
        flowname = deploymentname         
        config.STARTFILE = file
        config.UPDATE = update
        config.RETRIES = retries
        config.BACKGROUND = background
    
    
    from config import variables 
    if '3' in str(background): variables['headless_mode']=True  
    if '4' in str(background) or '5' in str(background):
        print(f"background:{background} | Trigger script: {triggerRPA(file, memoryPath=MEMORYPATH)}")        
        
        return
    config.flow_run_name = context.get_run_context().flow_run.dict()['name']
    logger.debug(f"RUN Settngs ... \n{configuResultMsg()}") 
    
    config.variables['flowrun']=config.flow_run_name
    config.variables['arguments']=config.program_args['arguments'].split('  ,  ')
    config.variables['error'] = ''
    config.variables['debug']=False
    try:
        
        
        from core.core import try_catch
        from core.auto_core_lib import runCodelist
        from core.files import changeWorkingDirectory
        from config import ASSETS_DIR, CWD_DIR, program_args
        CWD_DIR = changeWorkingDirectory(ASSETS_DIR)
        notification_cfg = f"{PROGRAM_DIR}\\autobot\\_cache\\notifications.pickle"
        from pathlib import Path
        if Path(notification_cfg).exists():
            from core.files import pickleRead
            notifications = pickleRead(filename_pickle=notification_cfg)
            id = notifications['id']
            activate = notifications['activate']
        else:
            id = ''
            activate = False
        recording_cfg = f"{PROGRAM_DIR}\\autobot\\_cache\\recording.pickle"
        if Path(recording_cfg).exists():
            from core.files import pickleRead
            recording = pickleRead(filename_pickle=recording_cfg)
            recording_file = recording['file']
            recording_folder = recording['folder']            
            recording_activate = recording['activate']
            if Path(recording_folder).exists():
                recording_path = (Path(recording_folder) / Path(recording_file)).absolute().__str__()
            else:
                recording_path = ''
        else:
            recording_activate = False
            recording_path = ''
        log_settings_cfg = f"{PROGRAM_DIR}\\autobot\\_cache\\log_settings.pickle"
        if Path(log_settings_cfg).exists():
            from core.files import pickleRead
            log_settings = pickleRead(filename_pickle=log_settings_cfg)
            log_settings_beta = log_settings['beta']
        else:
            log_settings_beta = False
        config.variables['debug_log']=log_settings_beta
        if config.variables['debug_log']: print('Debug_log:', config.variables['debug_log'])
        if flowrun==1: 
            from libraries.Windows import _runRPAscript
            param = context.get_run_context().flow_run.parameters            
            flags = f"-sc {param['startcode']} -sh {param['startsheet']} -b {param['background']} -r {param['retries']} -u {param['update']}"
            from pathlib import Path
            currentPath = Path(param['PROGRAM_DIR']).resolve() / "runRPA.bat"   
            scriptFile = Path(param['PROGRAM_DIR']).resolve() / "scripts" / f"{param['file']}"
            runBatchCommand = rf'{str(currentPath)} -f {scriptFile.stem} {flags}'
            logger.warning(runBatchCommand)
            if currentPath.exists() and scriptFile.exists(): 
                import subprocess
                proc = subprocess.Popen(runBatchCommand, shell=True)  
                logger.warning(f"*** LAUNCH: {scriptFile.stem} | {runBatchCommand}")
            return True
        browserDisable, instantiatedRPA, dfmain, main_code, setup_code, teardown_code, df_list, df_main_code, df_setup_code, df_teardown_code = \
            optimus_open.with_options(name='OPEN', tags=['OPEN_CLOSE'])(startfile=file, startsheet=startsheet, 
            startcode=startcode, background=background, program_dir=PROGRAM_DIR, update=update)
        config.variables['script file'] = file
        if flowrun==2: 
            try_catch(runCodelist(dfmain, ['Deploy:'], file=file))
        elif flowrun==0 or flowrun==3:          
            if flowrun==3: config.variables['debug']=True
            from libraries.Browser_tagui import telegram
            if not id == '' and activate: telegram(id, f'{Path(file).stem.split(".")[0]}:⚡️', bypass=True)
            from libraries.Image import start_recording
            if not recording_path == '' and recording_activate: start_recording(file_to_save = f"{recording_path}", fps = 10, bypass=True)
            if setup_code != None:
                logger.info("======================== SETUP ========================")
                try_catch(runCodelist(dfmain, setup_code, file=file, df_list=df_setup_code))
            logger.info(f"============ RUN SCRIPT: {file} ============")
            try_catch(runCodelist(dfmain, main_code, file=file, df_list=df_main_code))
            if teardown_code != None: 
                logger.info("======================== TEARDOWN ========================")            
                try_catch(runCodelist(dfmain, teardown_code, file=file, df_list=df_teardown_code))        
        optimus_close.with_options(name='CLOSE', tags=['OPEN_CLOSE'])(browserDisable, instantiatedRPA, dfmain, file, id, activate, recording_path, recording_activate)
        
    except Exception as e: 
        if e.__str__() == "Excel.Application.Workbooks":
            logger.critical(f"kiil process: {killprocess('excel')}")  
        try:
            config.variables['error']=e.__str__()
            raise ValueError(f"Software Error: {e}")
        finally:
            screenshot_filename = f".\{config.startTime.strftime('%Y%m%d_%H%M%S')}_{config.flow_run_name}_ERROR.jpg"
            logger.error(f"======================== EXCEPTION ERROR ========================")
            logger.error(f"ERROR {config.variables['codeID']}: {config.variables['error']}")
            logger.error(f"Screenshot: {screenshot_filename}")            
            logger.error(f"Excel: {config.variables['Excel']} Sheet: {config.variables['Sheet']} Row: {config.variables['Row']}")
            from core.files import printscreen
            printscreen(screenshot_filename)
            if teardown_code != None: 
                logger.info("======================== TEARDOWN ========================")            
                try_catch(runCodelist(dfmain, teardown_code, file=file))        
            from libraries.Browser_tagui import telegram
            if not id == '' and activate: telegram(id, f'{config.variables["error"]}:❌', bypass=True) 
            from config import RPABROWSER
            if RPABROWSER == 0:
                import rpa as r
                instantiatedRPA = r.close()
                print('Close finally', instantiatedRPA)
            from core.dates import getDuration
            endTime = getDuration(startTime, datetime.now())
            logger.info(f"Completed RPA flow. File: {file} | {flowname} | Sheet: {startsheet} {startcode} | Time: {datetime.now().strftime('%m/%d/%Y, %H:%M:%S')} | {endTime}")
    from config import RPABROWSER
    if RPABROWSER == 0:
        pass
    from studio.xpath import saveToExcel
    if config.variables['Auto save activate']: saveToExcel(dataframe=config.variables['recorded_df_list'], excel=config.variables['script file'], worksheet='Recorded', mode='w')       
    from core.dates import getDuration
    endTime = getDuration(startTime, datetime.now())
    logger.info(f"Completed RPA flow. File: {file} | {flowname} | Sheet: {startsheet} {startcode} | Time: {datetime.now().strftime('%m/%d/%Y, %H:%M:%S')} | {endTime}")
    return True 
@task(name="OPEN")
def optimus_open(startfile, startsheet, startcode, background, program_dir, update):
    
    logger = get_run_logger()
    from core.files import runInBackground
    if '1' in str(background) : runInBackground(program_dir)
    from core.files import isFileNewer, cacheScripts
    from core.core import dfKey_value, dfObjList
    from core.auto_core_lib import runCodelist 
    import pandas as pd
    displayMsg = ''
    dfmain, msgStr = cacheScripts(script=Path(startfile).name,df=pd.DataFrame(),program_dir=program_dir, startsheet=startsheet, refresh=bool(update)) 
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*5}{msgStr}'
    dfmain, msgStr = cacheScripts(script='OptimusLib.xlsm',df=dfmain,program_dir=program_dir, startsheet='main', refresh=False)  
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*5}{msgStr}'
    dfmain, msgStr = cacheScripts(script='OptimusLibPublic.xlsm',df=dfmain,program_dir=program_dir, startsheet='main', refresh=False)  
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*5}{msgStr}'
    browserDisable = False if dfKey_value(dfmain, 'browserDisable') == None else dfKey_value(dfmain, 'browserDisable')
    instantiatedRPA = False
    import config
    config.RPABROWSER = 0 if dfKey_value(dfmain, 'RPABROWSER') == None else int(dfKey_value(dfmain, 'RPABROWSER'))    
    msgStr = f"Start file:{Path(startfile).name}, sheet:{startsheet}, RPA Browser:{config.RPABROWSER}\n{log_space*5}Scripts files loaded:" + displayMsg
    logger.debug(f"{msgStr}")
    main_code = dfObjList(dfmain, startcode)
    df_main_code = dfObjList(dfmain, startcode, df_list=True)
    df_list = dfObjList(dfmain, startcode, df_list=True)
    setup_code = dfObjList(dfmain, '[Setup]')
    df_setup_code = dfObjList(dfmain, '[Setup]', df_list=True)
    teardown_code = dfObjList(dfmain, '[Teardown]')
    df_teardown_code = dfObjList(dfmain, '[Teardown]', df_list=True)    
    return browserDisable, instantiatedRPA, dfmain, main_code, setup_code, teardown_code, df_list, df_main_code, df_setup_code, df_teardown_code
@task
def optimus_close(browserDisable, instantiatedRPA, dfmain, file, id='', activate=False, recording_path='', recording_activate=False):
    import rpa as r
    if not browserDisable and not instantiatedRPA:
        instantiatedRPA = r.close()    
    
    from libraries.Browser_tagui import telegram
    if not id == '' and activate: telegram(id, f'{Path(file).stem.split(".")[0]}:✅', bypass=True)
    from libraries.Image import stop_recording
    if not recording_path == '' and recording_activate: stop_recording(bypass=True)
    return
