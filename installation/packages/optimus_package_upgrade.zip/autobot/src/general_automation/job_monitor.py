_H='startfile'
_G='process'
_F='start'
_E='pending'
_D='background'
_C='update'
_B=False
_A=True
def touchFile(filename):from pathlib import Path;Path(filename).touch();return _A
import yaml
def write_yaml(py_obj,filename):
	with open(f"{filename}",'w')as A:yaml.dump(py_obj,A,sort_keys=_B)
	return _A
def read_yaml(filename):
	with open(f"{filename}",'r')as A:B=yaml.safe_load(A)
	return B
import os,time
def file_age(filepath):A=time.time()-os.path.getmtime(filepath);return int(A)
def timestamp():import calendar as A,time;from datetime import datetime as B;C=time.gmtime();D=A.timegm(C);E=B.fromtimestamp(D);return E.strftime('%y%m%d_%H%M%S')
import os
def getfiles(dirpath,reverse=_B):A=dirpath;B=[B for B in os.listdir(A)if os.path.isfile(os.path.join(A,B))];B.sort(key=lambda s:os.path.getmtime(os.path.join(A,s)),reverse=reverse);return B
def stateChange(token='test.txt',statefrom=_F,stateto='stop',changeName='',memoryPath=''):
	E=changeName;D=statefrom;C=memoryPath;B=stateto;A=token
	try:
		import os,shutil as G;from pathlib import Path as F
		if not F(f"{C}\\{D}\\{F(A).stem}.txt").exists():H=tokenCreate();tokenSave(H,B,A)
		if B==_G:touchFile(f"{C}\\{B}\\{F(A).stem}.txt")
		if E=='':E=A
		I=f"{C}\\{D}\\{A}";J=f"{C}\\{B}\\{E}";K=G.move(I,J)
	except FileNotFoundError:print(f"StateChange from {D} to {B}: Token {A} not found");return _B
	return _A
from pathlib import Path
def runRPAscript(script='test',flags=''):
	A=script;B=Path().resolve().parent/'runRPA.bat';D=Path().resolve().parent/'scripts'/f"{A}.xlsm";C=f"{str(B)} -f {A} {flags}"
	if B.exists()and D.exists():import subprocess as E;F=E.Popen(C,shell=_A);print('*** LAUNCH:',A,' | ',C);return _A
	return _B
def tokenCreate():from config import STARTFILE as B,STARTSHEET as C,STARTCODE as D,PROGRAM_DIR as E,UPDATE as F,BACKGROUND as G;A={};A[_C]=F;A[_H]=B;A['startsheet']=C;A['startcode']=D;A[_D]=G;A['program_dir']=E;print('Token',A);return A
def tokenSave(token,state,file='',memoryPath=''):
	B=token;A=file;from pathlib import Path
	if A=='':A=B[_H]
	return write_yaml(B,f"{memoryPath}\\{state}\\{Path(A).stem}.txt")
def triggerRPA(file,memoryPath=''):
	B=memoryPath;A=file
	if A=='':return _B
	from pathlib import Path as C,PureWindowsPath;D=_E
	if B=='':return _B
	E=tokenCreate();print('LAUNCH RPA SCRIPT:',C(A).stem,tokenSave(E,D,A));F=read_yaml(f"{B}\\{D}\\{C(A).stem}.txt");print(F);return _A
def monitor(memoryPath=''):
	b='fail';a='-----------------------------------------------------------------------------------------------------------------';Q='=';N=None;I='=============================================================================';F=memoryPath;import time;print('\n    ##################################################\n            OPTIMUS JOB MONITOR AND QUEUE\n    ##################################################\n    ');R=[];S=[];T=[];U=[];V=[];W=[]
	while _A:
		import time;c=time.strftime('%H:%M:%S',time.localtime());G=[];H=[];C=getfiles(F+'\\pending');J=getfiles(F+'\\start');E=getfiles(F+'\\process');X=getfiles(F+'\\complete')
		if len(E)>0:
			for D in E:
				B=_G;A=read_yaml(f"{F}\\{B}\\{D}")
				if not A==N:
					if _D in A:
						if'5'in A[_D]:
							G=G+[D];E=E.remove(D)
							if E==N:E=[]
		if len(C)>0:
			for D in C:
				B=_E;A=read_yaml(f"{F}\\{B}\\{D}")
				if not A==N:
					if _D in A:
						if'5'in A[_D]:
							H=H+[D];C=C.remove(D)
							if C==N:C=[]
		C=C[:1]+H
		if R==G and S==H and T==C and U==J and V==E and W==X:0
		else:print(a);print(c,': pending:',C,'start:',J,'process:',E,'nonBlockingPendingTokens:',H,'nonBlockingProcessTokens',G);print(a)
		if len(C)>0 and len(J)==0 and len(E)==0:
			print(I);from pathlib import Path as K;B=_E
			for D in C:
				A=read_yaml(f"{F}\\{B}\\{D}");print(A);from pathlib import Path as K;L=D
				if len(K(L).stem.split(Q))>1:Y=K(L).stem.split(Q)[1]
				else:Y='None'
				A['flow_run_name']=Y;write_yaml(A,f"{F}\\{B}\\{D}");L=K(L).stem.split(Q)[0];print('PENDING -> START:',stateChange(D,_E,_F));Z=''
				if not A==N:
					if _C in A:
						if str(A[_C]).strip()in'01234'and not str(A[_C]).strip()=='':Z=f"-u {A[_C]}"
				runRPAscript(script=K(f"{L}").stem,flags=Z);print(I)
		for A in E:
			if not A in G:
				B=_G;O=f"{F}\\{B}\\{A}";M=file_age(O);P=60*5
				if M>P:print(I);print(f"FAIL <- {timestamp()}_{B} {A} {int(M/60)}min:",stateChange(A,B,b,f"{timestamp()}_{B}_{A}"));print(I)
		for A in J:
			B=_F;O=f"{F}\\{B}\\{A}";M=file_age(O);P=60*2
			if M>P:print(I);print(f"FAIL <- {timestamp()}_{B} {A} {int(M/60)}min:",stateChange(A,B,b,f"{timestamp()}_{B}_{A}"));print(I)
		R=G;S=H;T=C;U=J;V=E;W=X;time.sleep(15)
if __name__=='__main__':monitor()