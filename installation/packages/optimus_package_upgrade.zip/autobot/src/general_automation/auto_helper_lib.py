#!/usr/bin/env python
_H='table'
_G='Object'
_F='Key'
_E='iterationCount'
_D=False
_C=True
_B=None
_A='key'
from logging import raiseExceptions
from prefect import task,flow,get_run_logger
from prefect.task_runners import SequentialTaskRunner
import config
from auto_utility_PDF_Image import *
from auto_utility_file import *
from auto_utility_browser import *
from auto_utility_parsers import *
import rpa as r,traceback,os.path
from os import path
from ctypes import windll
from datetime import date,datetime,timedelta
import time,pygetwindow as gw
class Window:
	def __init__(self):self.title=[];self.new=[];self.win=[];self.snap()
	def get(self,name=''):return gw.getWindowsWithTitle(name)
	def getTitles(self,name=''):return gw.getWindowsWithTitle(name)
	def snap(self,name=''):
		logger=get_run_logger();selectedWindows=gw.getWindowsWithTitle(name);win_list=[];title_list=[];titles_str=f"{log_space}List of open windows:"
		for win in selectedWindows:
			win_list=win_list+[win];title_list=title_list+[win.title]
			if not win.title=='':titles_str=titles_str+'\n'+f"     {log_space}"+win.title
		logger.debug(f"{titles_str}");self.win=win_list;self.title=title_list
	def getNew(self):new_set=self.get();prev_set=self.win;new=Diff(new_set,prev_set);self.new=new;return new
	def getTitles(self,selection):
		titles=[]
		for item in selection:titles=titles+[item.title]
		return titles
	def closeNew(self):
		logger=get_run_logger()
		try:
			logger.debug(f"{log_space}Closed:{self.getTitles(self.new)}")
			for win in self.new:win.close()
			self.new=[]
		except Exception as e:logger.debug('none closed');logger.debug(str(e));pass
	def focus(self,name=''):
		logger=get_run_logger()
		try:
			print('Focus *******',name.lower());self.snap()
			for win in self.win:
				if name.lower()in str(win.title).lower():print('selected ****',str(win.title).lower());logger.debug(f"{log_space}Focus:{win.title}");win.minimize();win.restore()
		except Exception as e:logger.debug('error');logger.debug(str(e))
def Diff(li1,li2):li_dif=[i for i in li1 if i not in li2];return li_dif
def process_kill(process=[]):
	import psutil,time
	for proc in psutil.process_iter():
		if proc.name()in process:
			try:
				processName=proc.name();processID=proc.pid;processUser=psutil.Process(processID).username();etime=(time.time()-proc.create_time())/60/60;print(processName,' ::: ',processID,etime,processUser)
				if not'SYSTEM'in processUser:proc.kill()
			except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.ZombieProcess):print('error');pass
def process_list(name='',minutes=30):
	C='name';B='pid';A='etime';logger=get_run_logger();import psutil,time;result=[];targetedList=['chrome.exe','python.exe'];exclusionList_system=['svchost.exe','LogonUI.exe','winlogon.exe','ctfmon.exe','smartscreen.exe','SearchFilterHost.exe','SearchProtocolHost.exe','dwm.exe','msiexec.exe','TabTip.exe','rdpclip.exe','fontdrvhost.exe','csrss.exe','WUDFHost.exe','WmiPrvSE.exe','conhost.exe'];exclusionList_security=['TaniumCX.exe','TaniumClient.exe','vm3dservice.exe','rdpinput.exe'];exclusionList_others=['Code.exe','msedge.exe'];exclusionList=exclusionList_system+exclusionList_security+exclusionList_others
	def getListOfProcessSortedByCreateTime():
		result=[];listOfProcObjects=[]
		for proc in psutil.process_iter():
			try:
				processName=proc.name();etime=round((time.time()-proc.create_time())/60,1)
				if name in processName and etime<minutes:
					if not processName in exclusionList:result=result+[proc];pinfo=proc.as_dict(attrs=[B,C,'username']);pinfo['vms']=proc.memory_info().vms/(1024*1024);pinfo[A]=etime;listOfProcObjects.append(pinfo)
			except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.ZombieProcess):pass
		listOfProcObjects=sorted(listOfProcObjects,key=lambda procObj:procObj[A],reverse=_C);return listOfProcObjects,result
	listOfProcObjects,result=getListOfProcessSortedByCreateTime();log_str=f"{log_space}Running Process of last {minutes} min:\n"
	for proc in listOfProcObjects:log_str=log_str+f"     {log_space}{proc[C]} ::: ID {proc[B]} ::: {proc[A]} min\n"
	logger.debug(log_str);return result
import pandas as pd
def readExcelConfig(sheet,excel=config.STARTFILE,refresh=_C):
	B='Type';A='ASCII';logger=get_run_logger();from config import PROGRAM_DIR,STARTFILE;excel=getFullPath(excel);logger.debug(f"refreshExcel {sheet} {excel} {PROGRAM_DIR} {STARTFILE}")
	if refresh:
		from pathlib import Path,PureWindowsPath;import pythoncom;pythoncom.CoInitialize();logger.warning(f"{log_space}Coinitialized");from config import CWD_DIR;from pathlib import Path;logger.warning(f"CWD {Path('.').resolve().absolute().__str__()}");logger.warning(f"CWD_DIR {CWD_DIR}");import xlwings as xw
		with xw.App(visible=_D)as app:wb=app.books.open(Path(excel).absolute().__str__());wb.api.RefreshAll();logger.debug(f"{log_space}Excel refreshed: {excel}");wb.save(Path(excel).absolute().__str__())
		processName='Excel';import subprocess;command="Get-Process | Where-Object {{$_.Name -Like '{}'}} ".format(processName);result=subprocess.run(['powershell.exe',command],capture_output=_C)
		if len(result.stdout.decode(A))>0:logger.warning('process killed'+result.stdout.decode(A))
	df=pd.read_excel(excel,sheet_name=sheet);df=df[df.Key.notna()];df[[B,_G]]=df[[B,_G]].fillna(method='ffill');constants[_E]=0;return df
from pathlib import Path,PureWindowsPath
def refreshExcel(excel=''):
	if excel=='':return _D
	workBookName=Path(excel).name;fileIsOpen=checkIfFileOpen(excel);excel=Path(excel).absolute();import pythoncom,win32com.client;office=win32com.client.Dispatch('Excel.Application',pythoncom.CoInitialize());excelQuit=_C;wbClose=_C
	if office.Workbooks.Count>0:
		excelQuit=_D
		for i in office.Workbooks:
			if i.Name==workBookName:wb=i;wbClose=_D
		wb=office.Workbooks.Open(excel.__str__())
	else:
		import os;f=excel
		if os.path.exists(f):
			try:os.rename(f,f);logger.debug(f'{log_space}Access on file "'+f.name+'" is available!')
			except OSError as e:logger.critical('Access-error on file "'+f.name+'"! \n'+str(e))
		wb=office.Workbooks.Open(excel.__str__())
	logger.debug(f"{log_space}Refreshing workbook");wb.RefreshAll();office.CalculateUntilAsyncQueriesDone();wb.Save()
	if wbClose:wb.Close(SaveChanges=_D)
	if excelQuit:office.Quit()
	return _C
def dfKey_value(df,key,offset=1):
	try:df=df[df.Type==_A].reset_index(drop=_C);x=df.index[df[_F]==key].tolist()[0];y=df.columns.get_loc(_F)+offset;result=df.iloc[x,y];return result
	except KeyError:print('Key does not exist - key error:',key);return _B
	except IndexError:print('Key does not exist - index error:',key);return _B
def dfObjList(df,object_value,withHeader=0):
	try:
		if object_value in df[_G].unique().tolist():
			list=df[df.Object==object_value][_F].values.tolist()
			if withHeader:list=list[1:]
			return list
		else:
			result=df[df.Type==_H].groupby(_G,as_index=_D);final=result.nth(0)
			for i in range(len(final)):
				if object_value in final.iloc[i].values.tolist():objTable=final.iloc[i].values.tolist()[1];objTableSet=df[(df.Type==_H)&(df.Object==objTable)];new_header=objTableSet.iloc[0];objTableSet=objTableSet[1:];objTableSet.columns=new_header;list=objTableSet[object_value].values.tolist();print(objTableSet);print(list);return list
			return _B
	except:return _B
def updateConstants(df,code):
	H='@(.*?)\\((.*?)\\)';G='variables';F='constants';E=':';D='}}';C='{{';B='>';A='<';logger=get_run_logger();import re;matchConstants=re.findall('<(.*?)>',code)+re.findall('{{(.*?)}}',code)
	if not matchConstants:return code
	for item in matchConstants:
		evalValue=re.findall('[eE][vV][aA][lL]\\((.*)\\)',item.strip());itemIndex=_B
		if item[-1:]==']':
			vlist=item.strip(']').strip().rsplit('[',1)
			if len(vlist)==2:
				if str(vlist[1]).isdigit():itemIndex=int(vlist[1]);originalItem=item;item=vlist[0];logger.error(log_space+'Argument list. index:'+str(itemIndex)+' argument: '+item)
		if len(evalValue)>0:from datetime import datetime;evalStr=str(evalValue[0]);print('evalValue:',evalValue,evalStr);value=eval(evalStr);code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
		elif item in df[df.Object==F][_F].values.tolist():
			value=dfKey_value(df[df.Object==F],item)
			if value!=value:logger.error(f"{log_space}Updating constants:{item} ->  {value}  isNaN {value!=value}  ");value=''
			code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
		elif item in constants:
			if item==_E:value=constants[_E];code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
			else:value=constants[item];code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
		elif item in variables or item in df[df.Object==G][_F].values.tolist():
			if item in variables:
				value=variables[item]
				if isinstance(value,list):
					if itemIndex==_B:value=value[0]
					elif len(value)>itemIndex:value=value[itemIndex];item=originalItem
					else:continue
				code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
			else:
				value=dfKey_value(df[df.Object==G],item);import math
				if math.isnan(value):value=''
				code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
		elif len(re.findall(H,item))>=1:
			value='';formula=re.findall(H,item);import traceback
			try:name=formula[0][0].strip();parameters=formula[0][1].strip();value=_formula(name,parameters);logger.info(f"   match formula >>> item: {item} formula: {name}, parameters: {parameters}, result: {value}");code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
			except Exception as e:logger.info(traceback.format_exc())
		elif len(item.split(E))==2:
			obj=item.split(E)[0].strip();attribute=item.split(E)[1].strip()
			if obj[:4]=='tbl@':obj=obj[4:];withHeader=1
			else:withHeader=0
			if obj in df[df.Type==_A][_G].dropna().values.tolist():
				if withHeader==1:custom_header_field=attribute;objTableSet=df[(df.Type==_A)&(df.Object==obj)];new_header=objTableSet.iloc[0];objTableSet=objTableSet[1:];objTableSet.columns=new_header;objLists=objTableSet[custom_header_field].values.tolist()
				elif attribute.lower()==_A:objLists=df[(df.Type==_A)&(df.Object==obj)][_F].values.tolist()
				elif attribute.lower()=='value':objLists=df[(df.Type==_A)&(df.Object==obj)]['Value'].values.tolist()
				elif attribute.lower()in['0','1','2','3','4','5','6','7','8','9','10','11']:offset=int(attribute.lower());columnIndex=df.columns.get_loc(_F)+offset;objLists=df[(df.Type==_A)&(df.Object==obj)].iloc[:,columnIndex].values.tolist()
				elif attribute.lower()[:1]=='@':custom_header=attribute[1:];objTableSet=df[(df.Type==_A)&(df.Object==obj)];new_header=objTableSet.iloc[0];objTableSet=objTableSet[1:];objTableSet.columns=new_header;objLists=objTableSet[custom_header].values.tolist()
				if _E in constants:value=objLists[constants[_E]];code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
			elif obj in df[df.Type==_H][_G].dropna().values.tolist():
				custom_header_field=attribute;objTableSet=df[(df.Type==_H)&(df.Object==obj)];new_header=objTableSet.iloc[0];objTableSet=objTableSet[1:];objTableSet.columns=new_header;objLists=objTableSet[custom_header_field].values.tolist()
				if _E in constants:value=objLists[constants[_E]];code=code.replace(A+item+B,str(value));code=code.replace(C+item+D,str(value))
	return code
def _formula(name,code=''):
	logger=get_run_logger()
	if name.lower()=='fileuptodate':
		try:param1=code.split(',')[0].strip();date_string=code.split(',')[1].strip();logger.info(param1+' | '+date_string);param2=datetime.strptime(date_string,'%Y-%m-%d %H:%M:%S');logger.info(f"formula .... name {name} param1 {param1} param2 {param2}");return _fileuptodate(param1,param2)
		except Exception as e:logger.info(traceback.format_exc());return _B
	elif _D:0
	return _B
def _fileuptodate(path_to_file,date):import datetime;serial=date;seconds=(serial-25569)*86400.0;comparetime=datetime.datetime.utcfromtimestamp(seconds);return datetime.datetime.fromtimestamp(file_date(path_to_file))>=comparetime
import os,platform
def file_date(path_to_file,type='m'):
	if platform.system()=='Windows':
		if type=='m':return os.path.getmtime(path_to_file)
		elif type=='c':return os.path.getctime(path_to_file)
		elif type=='a':return os.path.getatime(path_to_file)
	else:
		stat=os.stat(path_to_file)
		try:
			if type=='m':return stat.st_mtime
			elif type=='c'or type=='a':return stat.st_birthtime
		except AttributeError:return stat.st_mtime
class CriticalAccessFailure(Exception):
	def __init__(self,err):print('a: critical');Exception.__init__(self);self.error=err
	def __str__(self):print('b: critical');return'%r'%self.error
def try_catch(func,comment=''):
	try:result=func
	except CriticalAccessFailure as caf:print('Critical Error');logger.info(f"'Critical failure', level = 'critical', caf = {caf}");logging.critical(caf);r.close();sys.exit(3)
	except Exception as e:print('Exception error');logger.info(f"'exception', e = {e}, level = 'error'");r.close();sys.exit(4);pass
	except:print('Except error');logger.info(f"'except', level = 'error'");r.close();sys.exit(5);pass
	finally:return result