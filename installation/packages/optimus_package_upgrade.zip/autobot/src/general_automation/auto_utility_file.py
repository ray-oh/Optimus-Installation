#!/usr/bin/env python
_B=None
_A=True
from prefect import task,flow,get_run_logger,context
from prefect.task_runners import SequentialTaskRunner
import os
def renameFile(sourceFilePath,targetFilePath):
	A=targetFilePath
	if os.path.exists(A):os.remove(A)
	os.rename(sourceFilePath,A)
def getFullPath(path):return os.path.abspath(path)
import time,glob,os
from pathlib import Path,PureWindowsPath
def GetRecentCreatedFile(filepath,filetype,inLastNumOfSec):
	C=filepath;B=inLastNumOfSec;C=Path(C);E=C/filetype;D=glob.glob(str(E))
	if D:
		A=max(D,key=os.path.getctime);print('Latest file',A,'create',time.ctime(os.path.getctime(A)),'>',time.ctime(time.time()-B),os.path.getctime(A)>time.time()-B)
		if os.path.getctime(A)>time.time()-B:print('Time',time.time()-B,'|',A);return A
		else:return _B
	else:return _B
import json
def jsonWrite(obj,file):
	with open(file,'w')as A:json.dump(obj,A,indent=4);print(file,obj,' : Write successful');A.close()
	return _A
def jsonRead(file):
	with open(file,'r')as A:B=json.load(A);print(file,' : Read successful');A.close()
	return B
def runInBackground(prog_path):E='      ';B=prog_path;from subprocess import Popen;from pathlib import Path as C,PureWindowsPath;import subprocess as D,sys;A=D.run(C(B+'\\autobot\\src\\console.bat').absolute(),capture_output=_A,text=_A);print(E,'Activate remote console session. Return code:',A.returncode,A.stderr);A=D.run(str(C(B+'\\autobot\\src\\Qres\\Qres.exe').absolute())+' /x:1920 /y:1080',capture_output=_A,text=_A);print(E,'Set screen resolution 1920 x 1080.',A.stderr);return
def killprocess(processName):
	F='process killed';E='powershell.exe';B='ASCII';G=get_run_logger();import subprocess as C;D="Get-Process | Where-Object {{$_.Name -Like '{}'}} ".format(processName);A=C.run([E,D],capture_output=_A)
	if len(A.stdout.decode(B))>0:G.info(F+A.stdout.decode(B));print(F+A.stdout.decode(B));A=C.run([E,D+' | Stop-Process -force '],capture_output=_A);return _A
	else:return False
def checkIfFileOpen(FILENAME):
	import os,pythoncom as A,win32api,win32com.client;C=A.CreateBindCtx(0)
	for D in A.GetRunningObjectTable():
		B=D.GetDisplayName(C,_B)
		if B.endswith(FILENAME):print('Found',B);return _A
		else:0
	return False
def printscreen(file='.\\screen.jpg'):from PIL import Image,ImageGrab as B;A=B.grab(bbox=_B);A=A.save(file)