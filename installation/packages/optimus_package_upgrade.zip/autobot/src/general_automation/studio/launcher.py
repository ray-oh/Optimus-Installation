#!/usr/bin/env python
"""
    Application launcher for Optimus.
    Allows following actions:
        Run RPA scripts
        Settings
        And more!

    Copyright 2021, 2022, 2023 Optimus
"""
# default program path
from pathlib import Path
prog_path = Path.cwd().parent.__str__() # d:\optimus
scriptKeywordsDefn = f'{prog_path}/autobot/assets/studio/studio.xlsx' #f'D:\Optimus\docs\scriptKeywordsDefn.xlsx'

# Utility libraries
import PySimpleGUI as sg

# Resize image
from io import BytesIO
from pathlib import Path
from PIL import Image, UnidentifiedImageError
def resize(image_file, new_size, encode_format='PNG'):
    im = Image.open(image_file)
    #new_im = im.resize(new_size, Image.ANTIALIAS)
    #new_im = im.resize((128, 128), Image.Resampling.LANCZOS)
    new_im = im.resize(new_size, Image.Resampling.LANCZOS)    
    with BytesIO() as buffer:
        new_im.save(buffer, format=encode_format)
        data = buffer.getvalue()
    return data

# Optimus keyword command definition library and other utility

import pandas as pd
# read optimus script keyword definitions
def readfile(filepath = scriptKeywordsDefn, sheet_name=0):
    df = pd.read_excel(filepath, sheet_name) # can also index sheet by name or fetch all sheets
    if sheet_name=="Commands":
        df['Type']=df['Type'].fillna(method="ffill")
        df['Description']=df['Description'].astype(str)
        df['Command']=df['Command'].astype(str)
    if sheet_name=="Apps":
        df['Description']=df['Description'].astype(str)
        df['Label']=df['Label'].astype(str)        
    return df


# enhance to read from cache if cache file exist
# else read file from excel source and generate a cache
from pathlib import Path
def get_filename_without_extension(file_path:str) -> str:
    path = Path(file_path)
    filename_without_extension = path.stem
    full_path = path.parent
    return str (full_path / filename_without_extension)
    return filename_without_extension

# Is file1 newer, return True or False
import os.path
import datetime
import time
def isFileNewer(file1: str, file2: str, type="m") -> bool:
    # m = modified, c = creation date
    if type == "m":
        #local_time_file1 = time.ctime(os.path.getmtime(file1))
        #local_time_file2 = time.ctime(os.path.getmtime(file2))            
        #print("mtime (Local time):", local_time_file1, local_time_file2)
        return os.path.getmtime(file1) > os.path.getmtime(file2)
    elif type == "c":
        #local_time_file1 = time.ctime(os.path.getctime(file1))
        #local_time_file2 = time.ctime(os.path.getctime(file2))            
        #print("ctime (Local time):", local_time_file1, local_time_file2)
        return os.path.getctime(file1) > os.path.getctime(file2)
    else:
        return

scriptKeywordsDefnCache = get_filename_without_extension(scriptKeywordsDefn)+".pickle"
if Path(scriptKeywordsDefnCache).exists():
    if isFileNewer(scriptKeywordsDefnCache, scriptKeywordsDefn):
        df = pd.read_pickle(scriptKeywordsDefnCache)
    else:
        df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
        pd.to_pickle(df, scriptKeywordsDefnCache) # generate cache
else:
    df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
    pd.to_pickle(df, scriptKeywordsDefnCache) # generate cache


# returns field values of specified command key, and prefix token
def data_desc(key='rem:', field='Description', token=""):
    x = df[df.Command==key][field]
    if len(x)==0: return ""
    result = str(x.iloc[0])
    if result =="nan": 
        result=""
    else:
        result=token+result
    return result

# returns JSON object from string - else None
def readJSON(json_str):
    import json
    try:
        return json.loads(json_str)
    except:
        return None

#__version__, __description__, __date__, __updated__
def launcher_window(version="x.x.x", description="", date="", updated="", author=""):
    # PARAMETERS    
    menu_def = [['&Application', ['E&xit']],
                ['&Help', ['&About']] ]
    right_click_menu_def = [[], ['Edit Me', 'Versions', 'Nothing','More Nothing','Exit']]
    fcolor = 'dark slate gray'

    # LAYOUT COMPONENTS
    menu_bar = [ [sg.MenubarCustom(menu_def, key='-MENU-', tearoff=False)] ] #font='Courier 15',tearoff=True
    
    banner_textblock = [ [sg.Text('OPTIMUS RPA',background_color='white', text_color=fcolor, font=("Helvetica", 12, "bold"))],
            [sg.Text('Select required action ...',background_color='white', text_color=fcolor, font=("Helvetica", 11))] ]
    top_bar_banner = [[sg.Column(banner_textblock, background_color='white'), sg.Push(background_color='white'), 
                  sg.Image(data=resize('./assets/studio/program_icon.png', (150,60)), background_color='white')]]
    top_bar = [[sg.Frame('', top_bar_banner, background_color='white', size=(480,70) )]]
    
    # tab1 layout
    button_bar = [[]]
    tab = 'tab1'
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab1_layout =  button_bar
    
    # tab2 layout
    button2_bar = [[]]
    tab = 'tab2'    
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button2_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab2_layout =  button2_bar

    # tab3 layout
    button3_bar = [[]]
    tab = 'tab3'    
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button3_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab3_layout =  button3_bar
    
    #logging_layout = [[sg.Text("Anything printed will display here!")],
    #                  [sg.Multiline(size=(60,15), font='Courier 8', expand_x=True, expand_y=True, write_only=True,
    #                                reroute_stdout=True, reroute_stderr=True, echo_stdout_stderr=True, autoscroll=True, auto_refresh=True)]
    #                  ]

    # LAYOUT
    layout = menu_bar + top_bar                
    layout +=[[sg.TabGroup([[  sg.Tab('OPTIMUS CORE', tab1_layout),
                               sg.Tab('SETTINGS', tab2_layout),
                               sg.Tab('AGENTS', tab3_layout),
                            ]], key='-TAB GROUP-', expand_x=True, expand_y=True),
               ]]
    layout[-1].append(sg.Sizegrip())
    
    # WINDOW CREATE / BINDINGS    
    win_title = f'OPTIMUS - Do more with less'
    window = sg.Window(win_title, layout, right_click_menu=right_click_menu_def, right_click_menu_tearoff=True, grab_anywhere=True, 
                       resizable=True, margins=(0,0), use_custom_titlebar=True, finalize=True)
                       # , keep_on_top=True)right_click_menu_tearoff=True, 
    window.set_min_size(window.size)
    window.bind("<Escape>", "_Escape")    
    #return window

    # window = make_window() # sg.theme() 
    
    # EVENT ACTIONS    
    while True: # Event Loop
        event, values = window.read()

        if event in ("-EXIT-", sg.WIN_CLOSED, "_Escape"):
            break

        if '-BUTTON' in event:
            print(event, str(event)[7:]) #, df[df['Label']==str(event)[7:]]['Description'][0])
            # depending on label_str event, choose action - either call python function directly or indirectly via windows command batch
            label_str = str(event)[7:]            
            program = df[df['Label']==label_str]['Launcher'].tolist()[0]            
            type = df[df['Label']==label_str]['Type'].tolist()[0]
            if label_str=='STUDIO':
                from studio.studio import search_rpa_commands_window
                #studio.
                search_rpa_commands_window()
            elif label_str=='HELP':
                from libraries.BuiltIn import help
                #help("all , ../autobot/assets/studio/help.xlsx")
                if help("all , ./assets/studio/help.xlsx"):
                    from pathlib import Path
                    helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                    sg.popup(f"Help documentation refreshed for new libraries.\nFile:{helpFile}\nAccess from Studio.", title='Help Documentation')
                else:
                    sg.popup("Help documentation refresh failed.", title='Help Documentation')
            elif label_str=='UPGRADE':
                upgrade_sub_window(f'{prog_path}\{program}', version)

            elif label_str=='UPGRADE3':
                #upgrade_sub_window(f'{prog_path}\{program}')

                # This function does the actual "running" of the command.  Also watches for any output. If found output is printed
                def runCommand(cmd, timeout=None, window=None):
                    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    output = ''
                    for line in p.stdout:
                        line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                        output += line
                        print(line)
                        window.Refresh() if window else None        # yes, a 1-line if, so shoot me
                    retval = p.wait(timeout)
                    return (retval, output)                         # also return the output just for fun

                layout = [  [sg.Text('Enter a command to execute (e.g. dir or ls)')],
                        [sg.Input(key='_IN_')],             # input field where you'll type command
                        [sg.Output(size=(60,15))],          # an output area where all print output will go
                        [sg.Button('Run'), sg.Button('Exit')] ]     # a couple of buttons

                window = sg.Window('Realtime Shell Command Output', layout)
                while True:             # Event Loop
                    event, values = window.Read()
                    if event in (None, 'Exit'):         # checks if user wants to 
                        exit
                        break

                    if event == 'Run':                  # the two lines of code needed to get button and run command
                        runCommand(cmd=values['_IN_'], window=window)

                window.Close()



            elif label_str=='UPGRADE2':

                command = program.split(" ")
                shell=True
                print(program, "|", shell, "|", command)
                markdown_text = \
f"""============= UPGRADE =============
Upgrading in progress ...
"""               
                import subprocess
                proc = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   # non blocking
                output, error = proc.communicate()
                sg.popup(output.decode(), title='Upgrade Package')

            else:
                if type in ('win'): 
                    command = program.split(" ")
                    shell=True
                else: 
                    command = f'{prog_path}\{program}'.split(" ")
                    shell=False
                print(program, "|", shell, "|", command)
                import subprocess
                #if len(program.split(" "))>1:
                #    #subprocess.call([program.split(" ")[0], program.split(" ")[1], program.split(" ")[2] ])
                #    subprocess.call(program.split(" "))                
                #elif len(program.split(" "))==1:
                #subprocess.call(["D:\\optimus\\" + program])
                proc = subprocess.Popen(command, shell=shell)   # non blocking

        if event in ("About"):#event == 'About':
            markdown_text = \
f"""============= OPTIMUS =============
Version {version} | {date}
{author}

{description}
"""
            markdown_text = \
f"""Version: {version}
Release: {date}
Contact: {author}

Desciption:{description}
"""
            sg.popup(markdown_text, title='OPTIMUS RPA')                        
            #sg.popup_scrolled(markdown_text, title='My Popup')
            #gui(window, key)
            #print("MENU Clicked", event)
            
    window.close()


def dsupgrade_sub_window(program:str = ""):
    import subprocess
    import sys
    import PySimpleGUI as sg

    layout = [
        [sg.Text('Enter a command to execute (e.g. dir or ls)')],
        [sg.Input(key='_IN_', size=(80,5), default_text=program)],  # input field where you'll type command
        [sg.Output(size=(80,15), background_color='black', text_color='white')],  # an output area where all print output will go
        [sg.Button('Run'), sg.Button('Exit')]  # a couple of buttons
    ]

    window = sg.Window('Realtime Shell Command Output', layout, finalize=True)

    print('Default text to display in the output area')

    while True:  # Event Loop
        event, values = window.Read()

        if event in (None, 'Exit'):  # checks if user wants to exit
            break

        if event == 'Run':  # the two lines of code needed to get button and run command
            runCommand(cmd=values['_IN_'], window=window)

    window.Close()

    # This function does the actual "running" of the command. Also watches for any output. If found output is printed
    def runCommand(cmd, timeout=None, window=None):
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output = ''
        for line in p.stdout:
            #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
            line = line.decode("utf-8")
            output += line + '\n'
            #print(line)
            print("test")
            #window.Refresh() if window else None  # yes, a 1-line if, so shoot me
        retval = p.wait(timeout)
        return (retval, output)  # also return the output just for fun



def upgrade_sub_window(program:str = "", version:str = ""):
    import subprocess
    import PySimpleGUI as sg

    #command = program.split(" ")

    layout = [[sg.Text('Enter a command to execute:')],
            [sg.Input(key='-IN-', size=(80,5), default_text=program)],
            [sg.Button('Run'), sg.Button('Exit')],
            [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')]]

    window = sg.Window('Upgrade OPTIMUS Packages', layout, finalize=True)  #'Realtime Shell Command Output'

    # print default starting text
    from libraries.Github import github_repo_latest_release, is_internet_available
    if is_internet_available():
        latest_version = github_repo_latest_release("ray-oh", "Optimus-Installation")
    else:
        latest_version = "Internet or package is not available. Check again later."

    def returnVers(text):
        import re
        #text = '10.2.4-test org'
        match = re.search(r'\d+\.\d+\.\d+', text)
        if match:
            #print(match.group())
            return match.group()
        else:
            #print('No match')
            return None

    try:
        from packaging.version import parse
        v2 = parse(returnVers(version))
        v1 = parse(returnVers(latest_version))

        if v1 > v2:
            #print(f'{v1} is greater than {v2}')
            upgrade_available = "Upgrade available"
        elif v1 < v2:
            #print(f'{v1} is less than {v2}')
            upgrade_available = "OPTIMUS newer than available upgrade"
        else:
            #print(f'{v1} is equal to {v2}')
            upgrade_available = "OPTIMUS up to date"
        print(f"{upgrade_available} .... Current OPTIMUS is {version} ... Latest release is {latest_version} ...")

    except:
        pass


    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit':
            break
        if event == 'Run':
            print('RUNNING ....')

            command = values['-IN-'].split(" ")
            #print(program, "|", command)

            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            #output = subprocess.check_output(cmd, shell=True, universal_newlines=True)
            #output, error = process.communicate()

            for line in process.stdout:
                line = line.decode('utf-8')
                import re
                # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                line = re.sub(r"[^\x00-\x7F]+", "", line)
                line = re.sub(r"[\r\n]+", "", line.rstrip())                
                print(line)
                window.Refresh() if window else None  # yes, a 1-line if, so shoot me
                #output += line + '\n'
            # Wait for the process to exit
            process.wait()
            print('Process completed: ', not process.poll()==None)

        if False:
            # Poll the process for new output
            while True:
                #output = process.stdout.readline()
                import re
                # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                output = re.sub(r"[^\x00-\x7F]+", "", process.stdout.readline().decode('utf-8'))
                output = re.sub(r"[\r\n]+", "", output.strip())                
                if  process.poll() is not None:
                    break
                else:
                    #window['-OUTPUT-'].update(output.strip())
                    print(output)
                window.Refresh() if window else None  # yes, a 1-line if, so shoot me                    

            # Wait for the process to exit
            process.wait()
            #print(str(process.poll()))
            print('Process completed: ', not process.poll()==None)

        if False:
            output = ""            
            while True:
                output = output + process.stdout.readline()
                if output == b'' and process.poll() is not None:
                    break
                if output:
                    window['-OUTPUT-'].update(output.decode())
            process.poll()

    window.close()

if __name__ == '__main__':
    launcher_window()


