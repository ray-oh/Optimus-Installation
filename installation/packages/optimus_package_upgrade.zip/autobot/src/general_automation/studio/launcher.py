
from pathlib import Path
import FreeSimpleGUI as sg
from core.dates import localTime
from core.files import _getProgPath
from libraries.Image import resize
help_text = 
prog_path = _getProgPath().__str__() 
def get_asset_file(scriptKeywordsDefn:str = f"{prog_path}/autobot/assets/studio/studio.xlsx"):
    
    import pandas as pd
    from core.files import isFileNewer, get_filename_without_extension, readfile
    scriptKeywordsDefnCache = get_filename_without_extension(scriptKeywordsDefn)+".pickle"
    if Path(scriptKeywordsDefnCache).exists():
        if isFileNewer(scriptKeywordsDefnCache, scriptKeywordsDefn): 
            df = pd.read_pickle(scriptKeywordsDefnCache)
        else:
            df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
            pd.to_pickle(df, scriptKeywordsDefnCache) 
    else:
        df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
        pd.to_pickle(df, scriptKeywordsDefnCache) 
    return df
def launcher_window(version="x.x.x", description="", date="", updated="", author="", asset_file=f"{prog_path}/autobot/assets/studio/studio.xlsx"):
    import numpy as np
    markdown_text = \
f
    markdown_text = \
f
    df = get_asset_file(asset_file)
    df['Label'].replace('', np.nan, inplace=True)
    df['Label'].replace('nan', np.nan, inplace=True)    
    df = df.dropna(subset=['Label'])    
    menu_def = [['&Application', ['E&xit']],
                ['&Help', ['&About']] ]
    right_click_menu_def = [[], ['Edit Me', 'Versions', 'Nothing','More Nothing','Exit']]
    fcolor = 'dark slate gray'
    menu_bar = [ [sg.Menu(menu_def, key='-MENU-', tearoff=False)] ] 
    banner_textblock = [ [sg.Text('OPTIMUS RPA',background_color='white', text_color=fcolor, font=("Helvetica", 12, "bold"))],
            [sg.Text('Select required action ...',background_color='white', text_color=fcolor, font=("Helvetica", 11))] ]
    top_bar_banner = [[sg.Column(banner_textblock, background_color='white'), sg.Push(background_color='white'), 
                  sg.Image(data=resize('./assets/studio/program_icon.png', (150,60)), background_color='white')]]
    top_bar = [[sg.Frame('', top_bar_banner, background_color='white', size=(480,70) )]]
    bottom_bar = [[sg.Text('Select command ...', key='-TASKBAR-')]]
    button_bar = {}
    tabs = df['Tab'].unique()
    tab_group = []
    for idx_bar, tab in enumerate(tabs):
        button_bar[idx_bar] = [[]]
        for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
            button_bar[idx_bar] +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                                k=f"-BUTTON{i}", enable_events=True),
                    sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                                justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                    ]] 
        tab_group += [sg.Tab(tab.split(' , ')[1], button_bar[idx_bar])]
    
    layout = menu_bar + top_bar
    layout +=[[sg.TabGroup([tab_group], key='-TAB GROUP-', expand_x=True, expand_y=True),
               ]]
    layout += bottom_bar
    layout[-1].append(sg.Sizegrip())
    win_title = f'OPTIMUS - Do more with less'
    window = sg.Window(win_title, layout, right_click_menu=right_click_menu_def, right_click_menu_tearoff=True, grab_anywhere=True, 
                       resizable=False, margins=(0,0), finalize=True, icon = r"./assets/shortcuts/rocket.ico")
    window.set_min_size(window.size)
    window.bind("<Escape>", "_Escape")    
    while True: 
        event, values = window.read()
        if event in ("-EXIT-", sg.WIN_CLOSED, "_Escape", "Exit"):
            break
        if event in ("About"):
            sg.popup(markdown_text, title='OPTIMUS RPA')                        
        if '-BUTTON' in event:
            print(event, str(event)[7:]) 
            try:
                label_str = str(event)[7:]            
                program = df[df['Label']==label_str]['Launcher'].tolist()[0]            
                type = df[df['Label']==label_str]['Type'].tolist()[0]
                window['-TASKBAR-'].update(f"{label_str} : {program}")
                if label_str=='CLOSE':
                    break
                elif label_str=='RUN SCRIPT':
                    from studio.sub_windows import sub_windows_run_script
                    sub_windows_run_script(prog_path, label_str, version, window)
                elif label_str=='STUDIO':
                    from studio.studio import search_rpa_commands_window
                    search_rpa_commands_window(location=window.current_location())
                elif label_str=='INSPECT':
                    from studio.py_inspect import main
                    main()
                elif label_str=='HELP':
                    from libraries.BuiltIn import help
                    from pathlib import Path
                    helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                    popup(help("all , ./assets/studio/help.xlsx"), 'Help Documentation', 
                        f"Help documentation refreshed for new libraries.\n\nFile:\n{helpFile}\n\nAccess from Studio.", 
                        "Help documentation refresh failed.")
                elif label_str=='SHORTCUT':
                    from libraries.FileSystem import _setup_shortcuts
                    popup(_setup_shortcuts(), 'Setup', 'Shortcuts created on desktop', 'Shortcuts creation failed')
                elif label_str=='UPGRADE':
                    from libraries.Github import checkOptimusReleases
                    sub_window(program=f'{prog_path}\{program}', version=version, title=program, run=False, starting_msg=checkOptimusReleases(version))
                elif label_str in ("PACKAGE", "CLEAN"):
                    sub_window(program=f'{prog_path}\{program}', title=program, run=False)
                elif label_str in ("LOGGING"):
                    from studio.sub_windows import sub_window_log_level
                    sub_window_log_level(window=window)
                elif label_str in ("INFO LEVEL", "DEBUG LEVEL"):
                    sub_window(program=f'{prog_path}\{program}', title=program, run=True)
                    
                elif label_str in ("NOTIFICATIONS"):
                    from studio.sub_windows import sub_window_notifications
                    sub_window_notifications(window=window)
                elif label_str in ("RECORDING"):
                    from studio.sub_windows import sub_window_screen_recording
                    sub_window_screen_recording(window=window)
                elif label_str in ('WORKFLOW'):
                    from studio.sub_windows import sub_windows_prefect
                    sub_windows_prefect(window)
                elif label_str in ("AGENT", "ORION SERVER", "SERVICES"):
                    from studio.sub_windows import sub_window_task_scheduler
                    sub_window_task_scheduler(prog_path=prog_path, runrpa_script="", window=window, values=values, 
                                            task_path = 'Optimus\\', script_list = ['Optimus Agent', 'Optimus Orion'])
                    continue
                    if label_str == "AGENT":
                        action='CREATE' 
                        program=f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}' 
                        start_time='06:00' 
                        freq='DAILY /mo 1' 
                        task_path='optimus\\'
                        task='Optimus_Agent_test' 
                    elif label_str == "ORION SERVER":
                        action='CREATE' 
                        from pathlib import Path
                        program= Path(f'{prog_path}\\autobot\\startOrion.bat').absolute().__str__() 
                        start_time='' 
                        import os
                        freq=f'ONSTART /ru "{os.environ.get("USERNAME")}" ' 
                        task_path='optimus\\'
                        task='Optimus_Orion_test' 
                    from libraries.Windows import _schedule
                    result = _schedule(action=action, program=program, start_time=start_time, freq=freq, task_path = task_path, task=task)
                    window['-TASKBAR-'].update(f"{label_str} : {program}")
                    sub_window(program=f'{prog_path}\{program}', title=program, run=False)
                elif True:
                    runProgram(type, program, prog_path)
            except Exception as e:
                print(e)
                window['-TASKBAR-'].update(f"{label_str} : ERROR {e}")
    window.close()
def sub_window(program:str = "", title:str = "", version:str = "", disabled:bool = True, run:bool = False, starting_msg:str = "", variable = None,
               insertWindow:list=[], window_buttons:list=[[]], replace_window_buttons:bool = False, location:tuple = (0,0), 
               message:str='', visible:bool=True, task_path=None):
    
    import subprocess
    import FreeSimpleGUI as sg
    if run:
        default_buttons = [[sg.Button('Exit', disabled=True)]]
    else:
        default_buttons = [[sg.Button('Run'), sg.Button('Exit')]]
    if replace_window_buttons:
        window_buttons = window_buttons
    else:
        window_buttons = [default_buttons[0] + window_buttons[0]]
    layout = [insertWindow, 
            [sg.Text('Enter or modify command to execute', key='-MESSAGE-', visible=visible)],
            [sg.Input(key='-IN-', size=(80,5), default_text=program, disabled=disabled, visible=visible)]] + window_buttons
    layout = layout + [[sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')],
            [sg.Text('STATUS: Running ...', key='-ALERT-', visible=True)],
            ]
    if not location == (0,0):
        window = sg.Window(title, layout, finalize=True, location=location)  
    else:
        window = sg.Window(title, layout, finalize=True)  
    window.TKroot.focus_force()         
    if run:
        run = True
        print(f'{starting_msg}')
        window.write_event_value('Run', '')        
    elif starting_msg != "":
        print(starting_msg)
    firstRun = True
    runrpa_script = ""
    alert = "Ready"
    sub_window_result = ''
    import config
    if not 'record' in config.variables: config.variables['record'] = False
    if config.variables['record']: 
        prev_input = program 
        window['-IN-'].update('')  
        window.Refresh() if window else None
    if program == 'RUN SCRIPT' and firstRun==True:
        window.Refresh() if window else None
        print(help_text)
        command = f'{prog_path}\\runrpa -h'
        window['-IN-'].update(disabled=False)
        firstRun = False
    window.bind("<Escape>", "_Escape")    
    window[f"-IN-"].bind("<Return>", "_Enter")
    window['-IN-'].set_focus()
    while True:
        window['-ALERT-'].update(f'STATUS: {alert}')
        if not message=='': window['-MESSAGE-'].update(message)
        window.Refresh()
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit' or '_Escape' in event:
            break
        if 'INTERACTIVE' in event or ('INTERACTIVE' in title and "_Enter" in event):
            if 'Continue' in event:
                import config
                config.variables['break point'] = values['INTERACTIVE -BREAK POINT']
                if config.variables['break point'] == '':
                    config.variables['break point'] = 'CONTINUE TO END AS THIS WILL NOT MATCH'
                sub_window_result = values['-IN-']
                break
            elif 'Step' in event or "_Enter" in event:
                import config
                config.variables['break point'] = ''
                sub_window_result = values['-IN-']
                break
            elif 'Terminate' in event:
                raise ValueError('Terminate Run')
            elif 'Record' in event:
                if config.variables['record']:  
                    window['INTERACTIVE - Record'].update(button_color=('white','
                    config.variables['record'] = False
                    window['-IN-'].update(prev_input)  
                else:
                    window['INTERACTIVE - Record'].update(button_color=('white','red'))
                    prev_input = values['-IN-']
                    window['-IN-'].update('')  
                    config.variables['record'] = True
                pass
            elif '- Save' in event:
                from studio.xpath import saveToExcel
                print(config.variables['script file'])
                from pathlib import Path             
                saveToExcel(dataframe=config.variables['recorded_df_list'], excel=config.variables['script file'], worksheet='Recorded', mode='w')                                
            elif 'Auto Save' in event:
                config.variables['Auto save activate'] = values['INTERACTIVE - Auto Save']
            if 'Studio' in event:
                from studio.studio import search_rpa_commands_window, formula_window
                if ':' in values['-IN-']:
                    codeID = values['-IN-'].split(':', 1)[0].strip()
                    codeParameterList = values['-IN-'].split(':', 1)[1].strip().split(' , ')
                    print('codeID', codeID, 'codeParameterList', codeParameterList)
                current_location = window.current_location()
                if 'codeID' in locals() and len(values['-IN-'].strip())>0: inputText = formula_window(codeID, codeParameterList, location=current_location)
                else: inputText = search_rpa_commands_window(location=current_location)
                if not inputText=='': window['-IN-'].update(inputText)
                window.Refresh()
            elif 'Edit' in event:
                from pathlib import Path
                script_file = str(Path(config.variables['script file']).name)
                runProgram('std', f'start excel.exe "{prog_path}/scripts/{script_file}"', prog_path)
            if 'Variablelist' in event:
                window['INTERACTIVE -Variables'].update(values['INTERACTIVE - Variablelist'])
            if 'VariableType' in event:
                from config import variables, constants
                df = variable[1]
                if 'Script constants' == values['INTERACTIVE - VariableType']:
                    variableList = df[(df.Object == 'constants')]['Key'].values.tolist()
                elif 'Script variables' == values['INTERACTIVE - VariableType']:                    
                    variableList = df[(df.Object == 'variables')]['Key'].values.tolist()
                elif 'Optimus constants' == values['INTERACTIVE - VariableType']:
                    variableList = list(constants.keys())
                elif 'Optimus variables' == values['INTERACTIVE - VariableType']:
                    variableList = list(variables.keys())
                elif 'Optimus globals' == values['INTERACTIVE - VariableType']:
                    variableList = list(globals().keys())
                elif 'Optimus locals' == values['INTERACTIVE - VariableType']:
                    variableList = list(locals().keys())
                window['INTERACTIVE - Variablelist'].update(value='', values=variableList)
            if 'Resolve' in event:
                from auto_helper_lib import updateConstants
                checkcode = values['INTERACTIVE -Variables']
                from config import variables
                try:
                    if 'Optimus globals' == values['INTERACTIVE - VariableType']:
                        result = globals()[checkcode]
                    elif 'Optimus locals' == values['INTERACTIVE - VariableType']:
                        result = locals()[checkcode]
                    else:
                        result = updateConstants(df=variables['optimusDF'], code='{{'+checkcode+'}}')
                    print('Variable value:', result)
                except Exception as e:
                    print('Error', e)
                pass
        if 'SCRIPT LIST' in event:
            if '_' in event:
                if len(values["SCRIPT LIST_"]) != 0:
                    runrpa_script = f'runRPA.bat -f {values["SCRIPT LIST_"][0]} -sh {values["SCRIPT LIST_worksheet"]} -sc {values["SCRIPT LIST_objectStep"]}'
                    window['-IN-'].update(runrpa_script)  
                    alert = 'Ready'
            elif 'Refresh' in event:
                from core.files import list_of_files
                script_list = list_of_files(f'{prog_path}\scripts', '*.xlsm')
                window['SCRIPT LIST_'].update(script_list)  
                alert = 'Refreshed'
            elif 'Edit' in event:
                if len(values["SCRIPT LIST_"]) != 0:
                    script_file = values["SCRIPT LIST_"][0]
                    runProgram('std', f'cd ..\scripts && start excel.exe "{script_file}"', prog_path)
                    alert = 'Ready'
                else:
                    alert = 'Please select a script first'
            elif 'Debug activate' in event:
                pass
        if 'Notifications' in event:
            if 'Save' in event:
                activate = values['Notifications activate']
                id = values['Notifications ID']
                print('Notifications', activate, id)
                from core.files import pickleWrite, pickleRead
                pickleWrite(obj={'activate':activate, 'id':id}, filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle")
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle")
                print(obj)
            if 'activate' in event:
                pass
        if 'Recording' in event:
            if 'Save' in event:
                activate = values['Recording activate']
                file = values['Recording file']
                folder = values['Recording folder']
                print('Recording', activate, folder, file)
                from core.files import pickleWrite, pickleRead
                pickleWrite(obj={'activate':activate, 'file':file, 'folder':folder}, filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle")
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle")
                print(obj)
            if 'activate' in event:
                pass
        if event == 'SCRIPT LIST beta logging':
            beta = values['SCRIPT LIST beta logging']
            filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle"
            from pathlib import Path
            from core.files import pickleWrite, pickleRead
            if Path(filename_pickle).exists():
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
                print(obj)
            else:
                obj = {}
            obj['beta'] = beta
            pickleWrite(obj=obj, filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
        if 'Log Settings' in event:
            if 'Save' in event:
                beta = values['Log Settings beta']
                log_level = values['Log Settings log_level']
                print('Log Settings', log_level, beta)
                from core.files import pickleWrite, pickleRead
                pickleWrite(obj={'beta':beta, 'log_level':log_level}, filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
                print(obj)
                print(prog_path)
                if log_level == 'DEBUG LEVEL':
                    cmd = f'{prog_path}\\autobot\\setLogLevelDEBUG.bat'
                elif log_level == 'INFO LEVEL':
                    cmd = f'{prog_path}\\autobot\\setLogLevelINFO.bat'
                import subprocess
                process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                for line in process.stdout:
                    line = line.decode('utf-8')
                    import re
                    line = re.sub(r"[^\x00-\x7F]+", "", line)
                    line = re.sub(r"[\r\n]+", "", line.rstrip())                
                    print(line)
                    window.Refresh() if window else None  
                process.wait()
        if 'Prefect' in event:
            if event == 'Prefect':
                from studio.sub_windows import sub_windows_prefect
                sub_windows_prefect(window)
                alert = 'Ready'
            elif 'Run' in event:
                alert = 'Running ...'
                window['-ALERT-'].update(f'STATUS: {alert}')
                window.Refresh() if window else None
                action = values['action']
                status_list = values["-STATUS LIST-"]
                period_num  = values["period_num"]
                period  = values["period"]
                if period.lower()=='hours': factor = 1
                elif period.lower()=='days': factor = 24
                elif period.lower()=='weeks': factor = 24*7
                elif period.lower()=='months': factor = 24*30
                hours = int(period_num) * factor
                import asyncio
                from libraries.Prefect import bulk_delete_flow_runs, query_flow_runs
                try:
                    if action.lower() == 'query':
                        msg = asyncio.run(query_flow_runs(state=status_list, hours=hours))
                        print(msg)
                        alert = 'Ready'
                    elif action.lower() == 'delete':
                        asyncio.run(bulk_delete_flow_runs(state=status_list, hours=hours, prompt=False))
                        alert = 'Ready'
                except Exception as e:
                    alert = str(e)
            elif 'Monitor' in event:
                runProgram('std', f'start http://127.0.0.1:4200/flow-runs', prog_path)
                alert = 'Ready'
            elif 'Deployments' in event:
                runProgram('std', f'start http://127.0.0.1:4200/deployments', prog_path)
                alert = 'Ready'
        if 'Task Scheduler' in event:
            try:
                if event == 'Task Scheduler': 
                    if len(values["SCRIPT LIST_"]) == 0:
                        alert = 'Please select a script first'
                        continue
                    else:
                        if 'runRPA.bat' in runrpa_script:
                            from studio.sub_windows import sub_window_task_scheduler
                            sub_window_task_scheduler(prog_path, runrpa_script, window, values)
                        alert = 'Ready'
                elif event == 'Task Scheduler Run': 
                    action=values["action"]
                    program=values["-IN-"]
                    if values["freq"] == "ONSTART":
                        start_time=""
                        freq=values["freq"] + ' ' + values["modifier"]
                    else:
                        start_time=values["start_hr"] + ':' + values["start_min"]
                        freq=values["freq"] + ' ' + values["modifier"] + ' /mo ' + values["freq_mod"]
                    task=values["Task Scheduler tasklist"]
                    from libraries.Windows import _schedule
                    result = _schedule(action=action, program=program, start_time=start_time, freq=freq, task_path = task_path, task=task)
                    alert = 'Ready'
                elif 'Windows' in event:
                    runProgram('std', f'start taskschd.msc', prog_path)
                    alert = 'Ready'
                elif 'Query' in event: 
                    cmd = 'schtasks /query /tn \Optimus\ /nh'
                    import subprocess
                    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    for line in process.stdout:
                        line = line.decode('utf-8')
                        import re
                        line = re.sub(r"[^\x00-\x7F]+", "", line)
                        line = re.sub(r"[\r\n]+", "", line.rstrip())                
                        print(line)
                        window.Refresh() if window else None  
                    process.wait()
                    alert = 'Ready'
                    if False:
                        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                        if result.returncode == 0:
                            output = result.stdout.decode('utf-8')
                            print(output)
                        else:
                            error = result.stderr.decode('utf-8')
                            print(f'Error: {error}')
                elif 'tasklist' in event:  
                    from studio.sub_windows import tasks
                    if "Optimus Agent" in values["Task Scheduler tasklist"]:
                        item = 'Optimus Agent'
                        program = tasks[item]['program']
                        start_time = tasks[item]['start_time']
                        freq = tasks[item]['freq']
                        freq_mod = tasks[item]['freq_mod']
                        task = tasks[item]['task']
                        modifier = tasks[item]['modifier']
                        description = tasks[item]['description']
                    elif "Optimus Orion" in values["Task Scheduler tasklist"]:
                        item = 'Optimus Orion'
                        program = tasks[item]['program']
                        start_time = tasks[item]['start_time']
                        freq = tasks[item]['freq']
                        freq_mod = tasks[item]['freq_mod']
                        task = tasks[item]['task']
                        modifier = tasks[item]['modifier']
                        description = tasks[item]['description']
                    else:
                        program = f'runRPA.bat -f {values["Task Scheduler tasklist"]} -sh main -sc main'
                    window['-IN-'].update(program)  
                    if 'modifier' in locals(): window['modifier'].update(modifier)
                    if 'description' in locals(): window['description'].update(description)
                    if 'freq' in locals(): window['freq'].update(freq)                    
                    if 'freq_mod' in locals(): window['freq_mod'].update(freq_mod)                   
                    if 'start_time' in locals(): window["start_hr"].update(start_time[:2])
                    if 'start_time' in locals(): window["start_min"].update(start_time[-2:])
                    alert = 'Ready'
            except Exception as e:
                print("ERROR: Tasklist", str(e))
        if event in ('Run', 'SCRIPT LIST Debug', 'SCRIPT LIST Deploy'):
            run = False
            command = values['-IN-'].split(" ")
            if 'RUN SCRIPT' in program:
                additional_args = ''
                import config
                config.variables['window position']=window.current_location()
                if len(values["SCRIPT LIST_"])==0: 
                    alert = 'Please select a script first'
                    continue
                if 'SCRIPT LIST Debug activate' in values.keys() or event == 'SCRIPT LIST Debug':
                    if values['SCRIPT LIST Debug activate'] or event == 'SCRIPT LIST Debug':  
                        additional_args = ' -o 3'
                        additional_args = additional_args + ' -a ' + f'"{config.variables["window position"]} , {values["-BREAK POINT-"]}"'
                elif event == 'SCRIPT LIST Deploy': 
                    additional_args = ' -o 2'
                if 'runRPA.bat' in runrpa_script:
                    print(runrpa_script, prog_path)
                    runProgram('std', f'cd .. && start {runrpa_script}{additional_args}', prog_path)                    
                    alert = 'Ready'
                continue
            alert = 'Running ...'
            window['-ALERT-'].update(f'STATUS: {alert}')
            window.Refresh() if window else None
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            for line in process.stdout:
                line = line.decode('utf-8')
                import re
                line = re.sub(r"[^\x00-\x7F]+", "", line)
                line = re.sub(r"[\r\n]+", "", line.rstrip())                
                print(line)
                window.Refresh() if window else None  
            process.wait()
            print('Process completed: ', not process.poll()==None)
            window["Exit"].update(disabled=False)
            alert = 'Ready'
    window.close()
    return sub_window_result
def popup(function:bool=True, title='', ifTrue:str='True result', ifFalse:str='False', location:tuple = (0,0)):
    
    import FreeSimpleGUI as sg                
    if function:
        text = ifTrue
    else:
        text = ifFalse
    if location==(0,0):
        sg.popup(text, title=title)
    else:
        sg.popup(text, title=title, location=location)
def runProgram(type, program, prog_path):
    
    print(type, program, prog_path)
    try:
        if type in ('win'): 
            command = program.split(" ")
            shell=True
        elif  type in ('std'):
            command = program 
            shell=True
        else: 
            command = f'{prog_path}\{program}'.split(" ")
            shell=False
        print(program)
        import subprocess
        process = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   
        result = process.stdout.decode('utf-8')
        return result
    except Exception as e:
        return "" 
if __name__ == '__main__':
    launcher_window()
