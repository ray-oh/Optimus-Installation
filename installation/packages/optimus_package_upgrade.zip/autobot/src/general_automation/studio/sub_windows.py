#!/usr/bin/env python
"""
    Application launcher for Optimus.
    Allows following actions:
        Run RPA scripts
        Settings
        And more!

    Copyright 2021, 2022, 2023 Optimus
"""
from pathlib import Path
import os

import FreeSimpleGUI as sg

from core.dates import localTime
from studio.launcher import sub_window, prog_path

# set pre defined settings for these items - program, strt_time, freq, modifier
tasks = {}
tasks['Optimus Agent'] = {
    'program':f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}',
    'start_time':'06:30',
    'freq':'DAILY',
    'freq_mod':'1',
    'task_path':'Optimus\\',
    'task':'Optimus Agent',
    'modifier':'/ri 180 /du 0010:00',
    'description':'Agent responsible for checking for flow runs that are ready to run and starting their execution.  Lightweight polling service that gets scheduled work from a work pool and deploy corresponding flow runs.'
} #180 /i 3
tasks['Optimus Orion'] = {
    'program':Path(f'{prog_path}\\autobot\\startOrion.bat').absolute().__str__(),
    'start_time':'',
    'freq':'ONSTART',
    'freq_mod':'',
    'task_path':'Optimus\\',
    'task':'Optimus Orion',
    'modifier':f' /ru "{os.environ.get("USERNAME")}" /delay 0015:00',
    'description':'Enables flow run monitoring dashboard.  Track and manage your flows, runs, and deployments and additionally filter by names, tags, and other metadata.  Check out the dashboard at http://127.0.0.1:4200'
}
tasks['Default'] = {
    'program':f'runRPA.bat -f {""} -sh main -sc main',
    'start_time':'09:00',
    'freq':'DAILY',
    'freq_mod':'1',
    'task_path':'Optimus\\Scripts\\',
    'task':'',
    'modifier':'/ri 180 /du 0010:00',
    'description':'Schedule Optimus automation scripts.'    
}


def sub_window_task_scheduler(prog_path, runrpa_script, window, values,
    task_path = 'Optimus\\Scripts\\', script_list = None, action_list = ['CREATE', 'DELETE', 'RUN', 'QUERY', 'QUERY ALL']):
    """Sub window for windows task scheduler  
    """
    from core.files import list_of_files

    # setup task scheduler for optimus services or script tasks
    if script_list == None: # script tasks
        item = 'Default'
        start_time = tasks[item]['start_time']
        freq = tasks[item]['freq']
        freq_mod = tasks[item]['freq_mod']
        task_path = tasks[item]['task_path']
        modifier = tasks[item]['modifier']
        description = tasks[item]['description']
        #task = tasks[item]['task']
        #program = tasks[item]['program']

        script_list = list_of_files(f'{prog_path}\scripts', '*.xlsm')
        if "SCRIPT LIST_" in values:
            task = os.path.splitext(values["SCRIPT LIST_"][0])[0]
        else:
            task = script_list[0]
        program = f'{prog_path}\\{runrpa_script}'
        action = 'CREATE'

    else: # optimus services
        item = 'Optimus Agent'
        program = tasks[item]['program']
        start_time = tasks[item]['start_time']
        freq = tasks[item]['freq']
        freq_mod = tasks[item]['freq_mod']
        task_path = tasks[item]['task_path']
        task = tasks[item]['task']
        modifier = tasks[item]['modifier']
        description = tasks[item]['description']

        action='RUN' #values["action"]
        #freq = f'{freq} {"" if freq_mod=="" else " /mo " + freq_mod}'

        #task = script_list[0] # optimus agent
        #task='Optimus_Agent_test' #values["task"]
        #program=f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}' #values["-IN-"]
        #start_time='06:00' #values["start_hr"] + ':' + values["start_min"]
        #freq='DAILY /mo 1' #values["freq"] + ' /mo ' + values["freq_mod"] + ' ' + values["modifier"]
        #task_path='optimus\\'
        #modifier = '' #/mo 3 

    initial_hrs = start_time[:2]
    initial_mins= start_time[-2:]

    left_part = [
        [sg.Text("Task")],
        [sg.Text("Action")],                        
        [sg.Text("Start Time")],
        [sg.Text("Frequency")],
    ]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    mins = [f'{i:02d}' for i in range(0, 60)]
    freq_mod = [f'{i:02d}' for i in range(1, 61)]                    
    freq_list = ['MINUTE', 'HOURLY', 'DAILY', 'WEEKLY', 'MONTHLY', 'ONCE', 'ONSTART']
    middle_part = [
        #[sg.Input(task, size=(37, 1), key="Task Scheduler tasklist", disabled=True)],
        [sg.Combo(script_list, size=(37, 1), default_value=task, key='Task Scheduler tasklist', readonly=True, enable_events=True)],        
        [sg.Combo(action_list, size=(37, 1), default_value=action, key='action', readonly=True, enable_events=True)],
        [sg.Spin([i for i in hrs], initial_value=initial_hrs, readonly=True, key='start_hr', enable_events=True), sg.Text(':'), sg.Spin([i for i in mins], initial_value=initial_mins, readonly=True, key='start_min', enable_events=True)],
        [sg.Combo(freq_list, size=(25, 1), default_value=freq, key='freq', readonly=True, enable_events=True), sg.Spin([i for i in freq_mod], initial_value='01', readonly=True, key='freq_mod', enable_events=True)],
        [sg.Input(modifier, size=(37, 1), key="modifier", enable_events=True)],
    ]
    #[sg.Input(action, size=(37, 1), key="action")],
    #[sg.Input(start_time, size=(37, 1), key="start_time")],
    #[sg.CalendarButton('Calendar', key="start_date")],
    right_part = [
        [sg.Text(description, size=(20, 8), key='description')],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(middle_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Run', key='Task Scheduler Run'), sg.Button('Exit'), sg.VSeparator(), sg.Button('Query All', key='Task Scheduler Query'), sg.Button('Task Scheduler', key='Windows Task Scheduler')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title='Task Scheduler', run=False, location=current_location, disabled=False,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, task_path=task_path)

    """
    if False:
        #_schedule(action='create', program='D:\Optimus\runrpa.bat -f Cognos-weekly5 -b 1 -u 1 -r 2', start_time='09:00', freq='HOURLY /mo 3 /du 0010:00', 
        #            task_path = 'optimus\\scripts\\', task='Cognos-weekly5')

        script_file = values["-SCRIPT LIST-"][0]
        sub_window(program=f'{prog_path}\{program}', title=program, run=False, starting_msg=checkOptimusReleases(version))
        script_buttons = [sg.VSeparator(), sg.Button('Task Scheduler'), sg.Button('Monitor')]
        sub_window(program=f'{label_str}', version=version, title=label_str, run=False, insertWindow=script_Window, window_buttons=script_buttons)
        
        from libraries.Windows import _schedule
        sub_window(program=f'{label_str}', version=version, title=label_str, run=False, insertWindow=script_Window, window_buttons=script_buttons)


        runProgram('std', f'cd ..\scripts && start excel.exe "{script_file}"', prog_path)
    """


def sub_windows_prefect(window):
    """ Sub window for managing prefect flows
    Actions: Query, Delete, Run?
    Select: status - Running, Completed, Failed, Crashed
    Select: flow runs, flows
    Select: time period back
    """
    status_list = ['Completed', 'Failed', 'Crashed', 'Running', 'Pending', 'Scheduled', 'Late']
    action_list = ['Query', 'Delete']
    days = [f'{i:03d}' for i in range(0, 365)]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    period = ['hours', 'days', 'weeks', 'months']
    program = 'Prog'

    left_part = [
        [sg.Text("Status")],
        [sg.Listbox(status_list, size=(22, 5), expand_y=True, enable_events=True, key='-STATUS LIST-', select_mode='multiple', default_values=('Completed', 'Failed', 'Crashed'))], #font=('Arial Bold', 14),
    ]

    right_part = [
        [sg.Text("Action")],        
        [sg.Combo(action_list, size=(10, 1), default_value='Query', key='action', readonly=True)],
        [sg.Text("")],
        [sg.Text("Period")],
        [sg.Text("Past"), sg.Spin([i for i in days], initial_value='001', readonly=True, size=(3, 1), key='period_num'), sg.Combo(period, size=(8, 1), default_value='days', key='period', readonly=True)],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Run', key='Prefect Run'), sg.Button('Exit'), sg.VSeparator(), 
                      sg.Text("Dashboard: "), sg.Button('Monitor Flows', key='Prefect Monitor'), sg.Button('Deployments', key='Prefect Deployments')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title='Workflow Management', run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)

    return

def sub_windows_run_script(prog_path, label_str, version, window):                   
    from core.files import list_of_files
    script_list = list_of_files(f'{prog_path}\scripts', '*.xls*')

    left_part = [
        [sg.Text("Select your script")],
        [sg.Listbox(script_list, size=(22, 5), expand_y=True, enable_events=True, key='SCRIPT LIST_')] #font=('Arial Bold', 14),
    ]
    """
        [sg.Input(size=(25, 1), key="path")],
        [sg.FileBrowse(key="fav"), sg.Button("Submit")],
        [sg.Image(key="img1")],
        [sg.Text("Pick your favorite number")],
        [sg.Input(key="num", size=(10, 10))],
        [sg.Button("Submit")],
        [sg.Button("Show image of animal")],
        [sg.Image(key="img2")],

    """    
    middle_part = [
        [sg.Button('Refresh', size=(8, 1), key = 'SCRIPT LIST Refresh')],
        [sg.Button('Edit', size=(8, 1), key = 'SCRIPT LIST Edit')],
        [sg.Button('Deploy', size=(8, 1), key = 'SCRIPT LIST Deploy')],
        [sg.Button('Debug', size=(8, 1), key = 'SCRIPT LIST Debug')],
    ]

    #from config import variables
    #beta_logging = variables['debug_log']
    #print('beta_logging', beta_logging)

    filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle"
    from pathlib import Path
    from core.files import pickleWrite, pickleRead
    if Path(filename_pickle).exists():
        obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
        print(obj)
        beta_logging = obj['beta']
    else:
        beta_logging = False

    right_part = [
        [sg.Text("Starting Worksheet")],
        [sg.Input('main', size=(37, 1), enable_events=True, key="SCRIPT LIST_worksheet")],
        [sg.Text("Starting Step / Object")],
        [sg.Input('main', size=(37, 1), enable_events=True, key="SCRIPT LIST_objectStep")],
        [sg.Checkbox("Debug", default=False, enable_events=True, key='SCRIPT LIST Debug activate'), 
         sg.Checkbox("Log", default=beta_logging, enable_events=True, key='SCRIPT LIST beta logging'),
         sg.Text("Break"), sg.Input('', size=(11, 1), key="-BREAK POINT-")],                        
    ] #SCRIPT LIST Debug Log activate 17

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(middle_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.VSeparator(), sg.Button('Task Scheduler', key='Task Scheduler'), sg.Button('Query', key='Task Scheduler Query'), sg.VSeparator(),
                        sg.Button('Prefect', key='Prefect'), sg.Button('Deployments', key='Prefect Deployments')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=f'{label_str}', version=version, title=label_str, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons]) #checkOptimusReleases(version)) starting_msg= script_list, 


def sub_window_notifications(window):
    """ Sub window for managing notifications
    Activate: Notifications on start and end
    Configure: Telegram ID
    Save.
    Run telegram bot service.  Configure telegram bot ID.
    """
    title = 'Notifications Management'
    description = 'Enable telegram notifications for RPA runs.  Setup default telegram ID. Check your telegram ID from @userinfobot.'
    program = 'Prog'
    activate = True
    id = ''
    file = f"{prog_path}\\autobot\\_cache\\notifications.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        notifications = pickleRead(filename_pickle=file)
        id = notifications['id']
        activate = notifications['activate']

    left_part = [
        [sg.Text("Activate", size=(12, 1)), sg.Checkbox("", default=activate, enable_events=True, key='Notifications activate')],
        [sg.Text("Telegram ID", size=(12, 1)), sg.Input(id, size=(12, 1), key="Notifications ID")],                        
    ]

    right_part = [
        [sg.Text(description, size=(40, 3), key='description')],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Save', key='Notifications Save'), sg.Button('Exit')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)

    return

def sub_window_screen_recording(window):
    """ Sub window for managing screen recording
    """
    title = 'Screen recording'
    description = 'Enable recording of RPA run.'
    program = 'Prog'
    activate = True
    id = 'recording.mp4'
    folder = prog_path
    file = f"{prog_path}\\autobot\\_cache\\recording.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        recording = pickleRead(filename_pickle=file)
        id = recording['file']
        activate = recording['activate']

    left_part = [
        [sg.Text("Activate", size=(12, 1)), sg.Checkbox("", default=activate, enable_events=True, key='Recording activate')],
        [sg.Text("Recording file", size=(12, 1)), sg.Input(id, size=(20, 1), key="Recording file")],
        [sg.Text("Folder", size=(12, 1)), sg.Input(prog_path, size=(20, 1), key='Recording folder'), sg.FolderBrowse(target='Recording folder', initial_folder=folder)],
    ]

    right_part = [
        [sg.Text(description, size=(25, 3), key='description')],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Save', key='Recording Save'), sg.Button('Exit')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)

    return

def sub_window_log_level(window):
    """ Sub window for managing logging
    Log Level: DEBUG LEVEL INFO LEVEL
    Activate BETA logs: Used mainly for interative mode debugging

    Activate: Notifications on start and end
    Configure: Telegram ID
    Save.
    Run telegram bot service.  Configure telegram bot ID.
    """
    title = 'Logging Management'
    description = 'Enable various level of logging for RPA runs.'
    program = 'Prog'
    log_level_options = ['DEBUG LEVEL', 'INFO LEVEL']
    log_level = 'INFO LEVEL'
    beta = True
    file = f"{prog_path}\\autobot\\_cache\\log_settings.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        log_settings = pickleRead(filename_pickle=file)
        log_level = log_settings['log_level']
        beta = log_settings['beta']

    left_part = [
        [sg.Combo(log_level_options, size=(20, 1), default_value=log_level, key='Log Settings log_level', readonly=True, enable_events=True)],
        [sg.Text("Activate beta logging", size=(15, 1)), sg.Checkbox("", default=beta, enable_events=True, key='Log Settings beta')],
    ]

    right_part = [
        [sg.Text(description, size=(40, 3), key='description')],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Save', key='Log Settings Save'), sg.Button('Exit')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)

    return

######################## NOT USED BELOW ######################


def sub_windows_agents(window):
    """ Sub window for managing Optimus Services - Prefect Agent, Orion Server
    Actions: Query, Delete, Register, Run
    Select: status - Running, Completed, Failed, Crashed
    Select: flow runs, flows
    Select: time period back
    """
    status_list = ['Completed', 'Failed', 'Crashed', 'Running', 'Pending', 'Scheduled', 'Late']
    action_list = ['Query', 'Delete']
    days = [f'{i:03d}' for i in range(0, 365)]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    period = ['hours', 'days', 'weeks', 'months']
    program = 'Prog'

    left_part = [
        [sg.Text("Status")],
        [sg.Listbox(status_list, size=(22, 5), expand_y=True, enable_events=True, key='-STATUS LIST-', select_mode='multiple', default_values=('Completed', 'Failed', 'Crashed'))], #font=('Arial Bold', 14),
    ]

    right_part = [
        [sg.Text("Action")],        
        [sg.Combo(action_list, size=(10, 1), default_value='Query', key='action', readonly=True)],
        [sg.Text("")],
        [sg.Text("Period")],
        [sg.Text("Past"), sg.Spin([i for i in days], initial_value='001', readonly=True, size=(3, 1), key='period_num'), sg.Combo(period, size=(8, 1), default_value='days', key='period', readonly=True)],
    ]

    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]

    script_buttons = [sg.Button('Run', key='Agent Run'), sg.Button('Register', key='Agent Register'), sg.Button('Exit')]
    current_location = window.current_location()
    #print(current_location)
    sub_window(program=program, title='Optimus Services', run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)

    return


def ___upgrade_sub_window(program:str = "", version:str = ""):
    import subprocess
    import FreeSimpleGUI as sg

    #command = program.split(" ")

    layout = [[sg.Text('Enter a command to execute:')],
            [sg.Input(key='-IN-', size=(80,5), default_text=program)],
            [sg.Button('Run'), sg.Button('Exit')],
            [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')]]

    window = sg.Window('Upgrade OPTIMUS Packages', layout, finalize=True)  #'Realtime Shell Command Output'

    # print default starting text
    from libraries.Github import github_repo_latest_release, is_internet_available
    if is_internet_available():
        latest_version = github_repo_latest_release("ray-oh", "Optimus-Installation")
    else:
        latest_version = "Internet or package is not available. Check again later."

    def returnVers(text):
        import re
        #text = '10.2.4-test org'
        match = re.search(r'\d+\.\d+\.\d+', text)
        if match:
            #print(match.group())
            return match.group()
        else:
            #print('No match')
            return None

    try:
        from packaging.version import parse
        v2 = parse(returnVers(version))
        v1 = parse(returnVers(latest_version))

        if v1 > v2:
            #print(f'{v1} is greater than {v2}')
            upgrade_available = "Upgrade available"
        elif v1 < v2:
            #print(f'{v1} is less than {v2}')
            upgrade_available = "OPTIMUS newer than available upgrade"
        else:
            #print(f'{v1} is equal to {v2}')
            upgrade_available = "OPTIMUS up to date"
        print(f"{upgrade_available} .... Current OPTIMUS is {version} ... Latest release is {latest_version} ...")

    except:
        pass


    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit':
            break
        if event == 'Run':
            print('RUNNING ....')

            command = values['-IN-'].split(" ")
            #print(program, "|", command)

            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            #output = subprocess.check_output(cmd, shell=True, universal_newlines=True)
            #output, error = process.communicate()

            for line in process.stdout:
                line = line.decode('utf-8')
                import re
                # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                line = re.sub(r"[^\x00-\x7F]+", "", line)
                line = re.sub(r"[\r\n]+", "", line.rstrip())                
                print(line)
                window.Refresh() if window else None  # yes, a 1-line if, so shoot me
                #output += line + '\n'
            # Wait for the process to exit
            process.wait()
            print('Process completed: ', not process.poll()==None)

        if False:
            # Poll the process for new output
            while True:
                #output = process.stdout.readline()
                import re
                # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                output = re.sub(r"[^\x00-\x7F]+", "", process.stdout.readline().decode('utf-8'))
                output = re.sub(r"[\r\n]+", "", output.strip())                
                if  process.poll() is not None:
                    break
                else:
                    #window['-OUTPUT-'].update(output.strip())
                    print(output)
                window.Refresh() if window else None  # yes, a 1-line if, so shoot me                    

            # Wait for the process to exit
            process.wait()
            #print(str(process.poll()))
            print('Process completed: ', not process.poll()==None)

        if False:
            output = ""            
            while True:
                output = output + process.stdout.readline()
                if output == b'' and process.poll() is not None:
                    break
                if output:
                    window['-OUTPUT-'].update(output.decode())
            process.poll()

    window.close()


def ____dsupgrade_sub_window(program:str = ""):
    import subprocess
    import sys
    import FreeSimpleGUI as sg

    layout = [
        [sg.Text('Enter or modify command to execute')],
        [sg.Input(key='_IN_', size=(80,5), default_text=program)],  # input field where you'll type command
        [sg.Output(size=(80,15), background_color='black', text_color='white')],  # an output area where all print output will go
        [sg.Button('Run'), sg.Button('Exit')]  # a couple of buttons
    ]

    window = sg.Window('Realtime Shell Command Output', layout, finalize=True)

    print('Default text to display in the output area')

    while True:  # Event Loop
        event, values = window.Read()

        if event in (None, 'Exit'):  # checks if user wants to exit
            break

        if event == 'Run':  # the two lines of code needed to get button and run command
            runCommand(cmd=values['_IN_'], window=window)

    window.Close()

    # This function does the actual "running" of the command. Also watches for any output. If found output is printed
    def runCommand(cmd, timeout=None, window=None):
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output = ''
        for line in p.stdout:
            #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
            line = line.decode("utf-8")
            output += line + '\n'
            #print(line)
            print("test")
            #window.Refresh() if window else None  # yes, a 1-line if, so shoot me
        retval = p.wait(timeout)
        return (retval, output)  # also return the output just for fun

def temp_from_launch_window():
    if False: 
        if True:
            if True:                
                if True: pass                
                elif '1DEBUG LEVEL' in label_str or 'INFO LEVEL' in label_str:
                    #for i in range(1,100):
                    #    sg.one_line_progress_meter('My Meter', i+1, 100, 
                    #        'key','Optional message', key = "OK for 1 meter", orientation = "h",)
                    def generateHelp(window):
                        import FreeSimpleGUI as sg
                        from libraries.BuiltIn import help
                        if help("all , ./assets/studio/help.xlsx"): # ../autobot/assets/studio/help.xlsx
                            from pathlib import Path
                            helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                            #sg.popup(f"Help documentation refreshed for new libraries.\nFile:{helpFile}\nAccess from Studio.", title='Help Documentation')
                        else:
                            #sg.popup("Help documentation refresh failed.", title='Help Documentation')
                            pass
                        window.write_event_value('Complete', '')

                    def animation(function, title, size, animated_gif, msg):
                        import threading
                        import FreeSimpleGUI as sg
    
                        layout = [[sg.Text(msg, key='-OUTPUT-')],
                                [sg.Image(animated_gif, key="-IMAGE-")],
                                [sg.Button("Ok", key="-OK-", disabled=True), sg.Button('Cancel', visible=False)]]

                        window = sg.Window(title, layout, size=size, disable_minimize=True, disable_close=True)
                        animate = True

                        threading.Thread(target=function, args=(window, ),
                                        daemon=True).start()

                        while True:
                            event, values = window.read(timeout=100)
                            if event == sg.WIN_CLOSED or event == 'Cancel' or event == '-OK-':
                                break
                            if event == 'Complete':
                                window["-OUTPUT-"].update('Help generated')
                                window["-OK-"].update(disabled=False)
                                animate = False
                            if animate:
                                window["-IMAGE-"].update_animation(animated_gif, time_between_frames=100)

                        window.close()

                    animation(generateHelp, 'Generate Help Documentation', (200,100), r"./assets/shortcuts/progressbar2.gif", 'A custom progress meter')

                elif '1DEBUG LEVEL' in label_str or '1INFO LEVEL' in label_str:
                    #sub_window(program=f'{prog_path}\{program}', title=program)
                    def progressBar():
                        import FreeSimpleGUI as sg

                        # layout the window
                        layout = [[sg.Text('A custom progress meter')],
                                [sg.ProgressBar(1000, orientation='h', size=(20, 20), key='progressbar')],
                                [sg.Button('Ok'), sg.Button('Cancel')]]
                        #        [sg.Cancel()]]

                        # create the window`
                        window = sg.Window('Custom Progress Meter', layout)
                        progress_bar = window['progressbar']
                        # loop that would normally do something useful
                        for i in range(1000):
                            # check to see if the cancel button was clicked and exit loop if clicked
                            event, values = window.read(timeout=10)
                            if event == 'Cancel'  or event == sg.WIN_CLOSED:
                                break
                        # update bar with loop value +1 so that bar eventually reaches the maximum
                            progress_bar.UpdateBar(i + 1)
                        # done with loop... need to destroy the window as it's still open
                        window.close()                
                    progressBar()

                elif 'DEBUG LEVEL' in label_str or 'INFO LEVEL' in label_str:

                    def test():
                        import threading
                        layout = [[sg.Text('Testing progress bar:')],
                                [sg.ProgressBar(max_value=10, orientation='h', size=(20, 20), key='progress_1')],
                                [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')]]

                        main_window = sg.Window('Test', layout, finalize=True)
                        current_value = 1
                        main_window['progress_1'].update(current_value)

                        threading.Thread(target=another_function,
                                        args=(main_window, ),
                                        daemon=True).start()

                        while True:
                            window, event, values = sg.read_all_windows()
                            if event == 'Exit':
                                break
                            if event.startswith('update_'):
                                print(f'event: {event}, value: {values[event]}')
                                key_to_update = event[len('update_'):]
                                print('key to update' , key_to_update)
                                window[key_to_update].update(values[event])
                                window.refresh()
                                continue
                            # process any other events ...
                        window.close()

                    def generateHelp():
                        import FreeSimpleGUI as sg
                        from libraries.BuiltIn import help
                        #help("all , ../autobot/assets/studio/help.xlsx")
                        if help("all , ./assets/studio/help.xlsx"):
                            from pathlib import Path
                            helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                            #sg.popup(f"Help documentation refreshed for new libraries.\nFile:{helpFile}\nAccess from Studio.", title='Help Documentation')
                        else:
                            #sg.popup("Help documentation refresh failed.", title='Help Documentation')
                            pass

                    def another_function(window):
                        import time
                        import random
                        #for i in range(10):
                        #    time.sleep(2)
                        #    current_value = random.randrange(1, 10)
                        #    window.write_event_value('update_progress_1', current_value)
                        #time.sleep(2)
                        generateHelp()
                        print('Done!!!')
                        window.write_event_value('Exit', '')

                    test()

                elif '2DEBUG LEVEL' in label_str or '2INFO LEVEL' in label_str:

                    def progressWindow():
                        import FreeSimpleGUI as sg
                        import time
                        import threading
                        
                        def run_progress_bar():
                            for i in range(100):
                                # Update the progress bar
                                window['progressbar'].update(i + 1)
                                time.sleep(0.1)
                            return True

                        layout2 = [[sg.Text('Progress of the task:')],
                                [sg.ProgressBar(100, orientation='h', size=(20, 20), key='progressbar')],
                                [sg.Button('Start'), sg.Button('Cancel')]]

                        window = sg.Window('Progress Bar Example', layout2)
                        result = ''
                        while True:
                            event, values = window.read()
                            if event == sg.WIN_CLOSED or event == 'Cancel' or 'success' in result:
                                break
                            if event == 'Start':
                                import queue
                                def run_other_function():
                                    for i in range(50):
                                        print('other run ', str(i))
                                        time.sleep(0.1)
                                    #return 'success'
                                    #q.put_nowait(5)

                                q = queue.Queue()
                                # Start the progress bar in a separate thread
                                progress_thread = threading.Thread(target=run_progress_bar)
                                progress_thread.start()
                                # Start the other function in a separate thread
                                #other_thread = threading.Thread(target=run_other_function, args=(q,))
                                other_thread = threading.Thread(target=run_other_function)
                                other_thread.start()

                                # Wait for the other thread to complete
                                #other_thread.join()
                                #result = q.get_nowait()
                                #print(result)

                                # Stop the progress bar
                                #progress_thread.join()

                        window.close()
                    progressWindow()

                elif label_str=='UPGRADE3':
                    #upgrade_sub_window(f'{prog_path}\{program}')

                    # This function does the actual "running" of the command.  Also watches for any output. If found output is printed
                    def runCommand(cmd, timeout=None, window=None):
                        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                        output = ''
                        for line in p.stdout:
                            line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                            output += line
                            print(line)
                            window.Refresh() if window else None        # yes, a 1-line if, so shoot me
                        retval = p.wait(timeout)
                        return (retval, output)                         # also return the output just for fun

                    layout = [  [sg.Text('Enter a command to execute (e.g. dir or ls)')],
                            [sg.Input(key='_IN_')],             # input field where you'll type command
                            [sg.Output(size=(60,15))],          # an output area where all print output will go
                            [sg.Button('Run'), sg.Button('Exit')] ]     # a couple of buttons

                    window = sg.Window('Realtime Shell Command Output', layout)
                    while True:             # Event Loop
                        event, values = window.Read()
                        if event in (None, 'Exit'):         # checks if user wants to 
                            exit
                            break

                        if event == 'Run':                  # the two lines of code needed to get button and run command
                            runCommand(cmd=values['_IN_'], window=window)

                    window.Close()



                elif label_str=='UPGRADE2':

                    command = program.split(" ")
                    shell=True
                    print(program, "|", shell, "|", command)
                    markdown_text = \
f"""============= UPGRADE =============
Upgrading in progress ...
"""               
                    import subprocess
                    proc = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   # non blocking
                    output, error = proc.communicate()
                    sg.popup(output.decode(), title='Upgrade Package')



