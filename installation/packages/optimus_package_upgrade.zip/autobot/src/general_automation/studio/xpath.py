_H='node_name'
_G='value'
_F='for'
_E='title'
_D='href'
_C='class'
_B='id'
_A='content'
def xpathObj(element):D='type';from bs4 import BeautifulSoup as E;F=E(element,'html.parser');A=F.find();C=A.attrs;print(C);B={};B[_H]=A.name;B[_B]=A.get(_B);B[_A]=A.string;B[_C]=A.get(_C);B[_D]=A.get(_D);B[_E]=A.get(_E);B[_F]=A.get(_F);B[D]=A.get(D);B[_G]=A.get(_G);G={C:A for(C,A)in B.items()if A is not None};B.clear();B.update(G);C[_H]=A.name;C[_A]=A.string;return C
def xpathBuild(el,key=None):
	B=el;A=key;C=''
	if A==None:
		if _E in B:A=_E
		elif _B in B:A=_B
		elif _F in B:A=_F
		elif _G in B:A=_G
		elif _D in B:A=_D
		elif _A in B:A=_A
		elif _C in B:A=_C
		else:A=next(iter(B))
	else:0
	if A==_A:C='{0}="{1}"'.format('text()',B[A])
	else:C='@{0}="{1}"'.format(A,B[A])
	print(C);D='//{0}'.format(B[_H])
	if not C=='':D='{0}[{1}]'.format(D,C)
	return A,D
import pandas as pd
def saveToExcel(dataframe,excel='output.xlsx',worksheet='recorded',mode='a'):
	G=False;F=worksheet;E=excel;B=dataframe;B=B.drop(columns=[A for A in B.columns if A.startswith('Unnamed:')]);from pathlib import Path;import xlwings as C
	with C.App(visible=G)as I:
		if Path(E).exists():print('excel exist');A=C.Book(E)
		else:A=C.Book()
		try:D=A.sheets[F];D.clear()
		except Exception as H:print(H);D=A.sheets.add(name=F)
		D['A1'].options(pd.DataFrame,expand='table',index=G).value=B;A.save();A.close()