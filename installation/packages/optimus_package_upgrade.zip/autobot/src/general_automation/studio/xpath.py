
def xpathObj(element:str):
    
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(element, 'html.parser') 
    tag = soup.find() 
    attrib = tag.attrs 
    print(attrib)
    el={}
    el['node_name']=tag.name
    el['id'] = tag.get('id') 
    el['content'] = tag.string 
    el['class'] = tag.get('class') 
    el['href'] = tag.get('href') 
    el['title'] = tag.get('title') 
    el['for'] = tag.get('for') 
    el['type'] = tag.get('type')     
    el['value'] = tag.get('value')
    filtered = {k: v for k, v in el.items() if v is not None}
    el.clear()
    el.update(filtered)    
    attrib['node_name']=tag.name
    attrib['content'] = tag.string 
    return attrib
def xpathBuild(el:object, key=None):
    
    attrib=''
    if key==None:
        if 'title' in el: key='title'
        elif 'id' in el: key='id'
        elif 'for' in el: key='for'
        elif 'value' in el: key='value'
        elif 'href' in el: key='href'
        elif 'content' in el: key='content'
        elif 'class' in el: key='class'
        else: key= next(iter(el)) 
    else:
        pass
    if key=='content':   attrib='{0}="{1}"'.format('text()', el[key])
    else:               attrib='@{0}="{1}"'.format(key, el[key])
    print(attrib)
    xpath = "//{0}".format(el['node_name'])
    if not attrib=='': 
        xpath = "{0}[{1}]".format(xpath, attrib)
    return key, xpath
import pandas as pd
def saveToExcel(dataframe:pd.DataFrame, excel:str='output.xlsx', worksheet:str='recorded', mode='a'):
    
    dataframe = dataframe.drop(columns=[col for col in dataframe.columns if col.startswith("Unnamed:")])
    from pathlib import Path
    import xlwings as xw
    with xw.App(visible=False) as app:
        if Path(excel).exists():
            print('excel exist')
            book = xw.Book(excel)
        else:
            book = xw.Book()
        try:
            sheet = book.sheets[worksheet] 
            sheet.clear()
        except Exception as e:
            print(e)
            sheet = book.sheets.add(name=worksheet)
        sheet['A1'].options(pd.DataFrame, expand='table', index=False).value = dataframe 
        book.save()
        book.close()
    
