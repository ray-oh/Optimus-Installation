#!/usr/bin/env python
_A='default'
from datetime import datetime
def getDuration(then,now=datetime.now(),interval=_A):
	A=None;C=now-then;B=C.total_seconds()
	def F():return divmod(B,31536000)
	def G(seconds=A):C=seconds;return divmod(C if C!=A else B,86400)
	def H(seconds=A):C=seconds;return divmod(C if C!=A else B,3600)
	def I(seconds=A):C=seconds;return divmod(C if C!=A else B,60)
	def J(seconds=A):
		C=seconds
		if C!=A:return divmod(C,1)
		return B
	def D():
		E=F();D=G(E[1]);B=H(D[1]);A=I(B[1]);C=J(A[1])
		if int(E[0])>0:return '{} years, {} days, {} hours, {} minutes and {} seconds'.format(int(E[0]),int(D[0]),int(B[0]),int(A[0]),int(C[0]))
		if int(D[0])>0:return '{} days, {} hours, {} minutes and {} seconds'.format(int(D[0]),int(B[0]),int(A[0]),int(C[0]))
		if int(B[0])>0:return '{} hours, {} minutes and {} seconds'.format(int(B[0]),int(A[0]),int(C[0]))
		if int(A[0])>0:return '{} minutes and {} seconds'.format(int(A[0]),int(C[0]))
		return '{} seconds'.format(int(C[0]))
	return{'years':int(F()[0]),'days':int(G()[0]),'hours':int(H()[0]),'minutes':int(I()[0]),'seconds':int(J()),_A:D()}[interval]