#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

Excel manipulation and processing

mergeFiles(fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool , df)

    elif codeID.lower() == 'mergeFiles'.lower():    _mergeFiles(codeValue, df)                               # mergeFiles: fileList, keep, uniqueColumnsList, fileName, encoding 
"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def mergeFiles(fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool , df):
    """Merge files and deduplicate records.
    mergeFiles: fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool

    Example: 
        mergeFiles:
        mergeFiles: mergeFilelist, last, deDuplicationColumnList, ./merged.xlsx,  latin-1
    """
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure    
    import pandas as pd

    # e.g. mergeFiles: mergeFilelist, first, deDuplicationColumnList, ./merged.csv,  latin-1 .... Handles csv or excel
    #tmpDict = parseArguments('fileList, keep, uniqueColumnsList, fileName, encoding',codeValue)
    #print(tmpDict)
    #if tmpDict == {}: return

    if fileList in df[(df.Type == 'list')]['Object'].dropna().values.tolist():           #run Block of Code
        fileList = dfObjList(df, fileList)
        fileList = [updateConstants(df, s) for s in fileList]
        fileList = [s.strip() for s in fileList]        # using list comprehension to trim spaces of every element in list

    if uniqueColumnsList in df[(df.Type == 'list')]['Object'].dropna().values.tolist():           #run Block of Code
        uniqueColumnsList = dfObjList(df, uniqueColumnsList)
        uniqueColumnsList = [updateConstants(df, s) for s in uniqueColumnsList]

    #logg('tmpDict', tmpDict = tmpDict, level = 'info')
    #logg('fileList', fileList = tmpDict['fileList'], level = 'info')

    df_merged = pd.concat(map(lambda x: pd.read_csv(x, encoding=encoding) if x.upper().endswith('.CSV') else pd.read_excel(x), fileList), ignore_index=True)        
    df_merged = df_merged.drop_duplicates(uniqueColumnsList, keep=keep)
    saveFile = fileName
    df_merged.to_csv(saveFile, index=False) if saveFile.upper().endswith('CSV') else df_merged.to_excel(fileName, index=False)
    print('      ', 'Merge Files:', fileList, ' Save to:', saveFile)

