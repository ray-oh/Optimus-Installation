#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'runJupyterNb'.lower():       _runJupyterNb(codeValue)                          # runJupyterNb:notebook_file, parameters

"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def runJupyterNb(nb_file:str, jsonString:str):
    """Run Jupyter Notebook.

    Example: 
        runJupyterNb: {{notebook file}} , {{parameters in json format}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    #nb_file = codeValue.split(',', 1)[0].strip()
    #jsonString = codeValue.split(',', 1)[1].strip()

    logger.debug(f"{log_space}Run Jupyter Notebook = {nb_file}, Parameters = {jsonString}")

    from auto_initialize import checkWorkDirectory
    from pathlib import Path, PureWindowsPath

    CWD_DIR = checkWorkDirectory('.')
    #logger.info(f"curDIR = {CWD_DIR}")

    #print(jsonString)
    import papermill as pm

    #file = r'C:\Users\roh\Downloads\d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx'
    #country = 'All'

    import json

    #jsonString = '{"file":"C:\\Users\\roh\\Downloads\\d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
    #jsonString = '{"file": "C:/Users/roh/Downloads/d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'

    paramDict = json.loads(jsonString)
    #logger.info(f"parameter dictionary = {paramDict}")    
    #print(paramDict['file'])
    #print(paramDict['country'])

    #res = pm.execute_notebook(
    #    'C:\\Users\\roh\Documents\\python\\Optimus\\autobot\\DClickReport.ipynb',
    #    'C:\\Users\\roh\\Documents\\python\\Optimus\\autobot\\DClickReport_output.ipynb',
    #    parameters = paramDict
    #)

    from datetime import datetime
    currentDateAndTime = datetime.now()
    #print("The current date and time is", currentDateAndTime)
    # Output: The current date and time is 2022-03-19 10:05:39.482383
    #currentTime = currentDateAndTime.strftime("%H:%M:%S")
    #print("The current time is", currentTime)
    # The current time is 10:06:55

    res = pm.execute_notebook(
        nb_file, nb_file.replace('.ipynb', '_output_'+ currentDateAndTime.strftime("%Y%m%d_%H%M%S") +'.ipynb'),
        parameters = paramDict
    )



