#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).
"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def rem(arg: str, **kwargs) -> None:
    """Remarks - do nothing

    Args:
        None

    Example:
        rem: {{text or action to comment}}
        
    Raises:
        None

    Returns:
        None
    """
    print(arg)
    return None

#def PRINT(arg: str, *args, **kwargs) -> None:
@validate_args
@type_check
def PRINT(arg: str):
    """Prints to console.  And logs to dashboard.

    Example:
        print: {{text to print}}
    """
    #logg('print:', codeValue = codeValue, level = 'info')
    #print(codeValue)
    #print('PRINT', arg) #, args, kwargs)
    #return None
    pass

@validate_args
@type_check
def IF(condition: str, true_block:str = None, false_block:str = None):
    """If Else statement.

    Args:
        condition (bool): condition to evaluate as True or False
        run if true (str): command to run if condition is True
        run if false (str): command to run if condition is False. Optional.  If empty then pass/do nothing.

    Example:
        if: {{condition}} , {{run if true}} , {{run if false or do nothing if empty}}
        Legacy if statement syntax:
        IF: {{condition}} : {{run if True}}  ELSE  {{run if false or if empty then pass}}        
    Raises:
        None

    Returns:
        None
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    if ' : ' in condition: return _if_legacy(condition)  # new if is without ' : '

    logger.debug(f'{log_space}IF {str(eval(condition)).upper()} THEN {true_block} ELSE {false_block}')
    if eval(condition):

        #sub_code, [df] * n, [objVar] * n
        return [true_block]
    else:
        if str(false_block) == 'None':
            return []
        else:
            return [false_block]

@validate_args
@type_check
def ELSEIF(condition: str, true_block:str = None, false_block:str = None):
    """If Else statement.

    Args:
        condition (bool): condition to evaluate as True or False
        run if true (str): command to run if condition is True
        run if false (str): command to run if condition is False. Optional.  If empty then pass/do nothing.

    Example:
        if: {{condition}} , {{run if true}} , {{run if false or do nothing if empty}}
        Legacy if statement syntax:
        IF: {{condition}} : {{run if True}}  ELSE  {{run if false or if empty then pass}}        
    Raises:
        None

    Returns:
        None
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    logger.debug(f'{log_space}ELSEIF {str(eval(condition)).upper()} THEN {true_block} ELSE {false_block}')
    if eval(condition):

        #sub_code, [df] * n, [objVar] * n
        return [true_block]
    else:
        if str(false_block) == 'None':
            return []
        else:
            return [false_block]


def _if_legacy(codeValue, **kwargs):
    """Legacy IF ELSE statement. Condition must be delimited with ' : '.  And alternative action is delimited with ' ELSE '.
    Or else, use the new IF which is delimited with ' , '.

    Example: 
        IF: {{condition}} : {{run if True}}  ELSE  {{run if false or if empty then pass}}
    """
    #if len(codeValue.split(' : ')) == 0: return if2(codeValue)  # new if is without ' : '
    if not ' : ' in codeValue: return IF(codeValue)  # new if is without ' : '

    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    logger = get_run_logger()    
    # codeValue = condition : if true block, if false block or if empty then pass
    condition = codeValue.split(':',1)[0].strip()
    codeBlock = codeValue.split(':',1)[1].strip()
    import re
    match = re.findall( r"'''(.*?)'''", codeBlock)     # Output: ['cats', 'dogs']
    # if codeBlock is encapsulated with ''' ''' then the internal is a statement
    #print(match)
    i = 0
    for item in match:
        codeBlock = codeBlock.replace(f"'''{item}'''", 'match'+str(i))
        i = i+1

    args = codeBlock.split(' ELSE ')

    if len(args)>0:
        if 'match0' in codeBlock:
            codeBlock1 = args[0].replace('match0', match[0]).strip()
        else:
            codeBlock1 = args[0].strip()
        print(codeBlock1)        
    if len(args)>1:
        if 'match1' in codeBlock:
            codeBlock2 = args[1].replace('match1', match[1]).strip()
        else:
            codeBlock2 = args[1].strip()
        print(codeBlock2)
    else:
        codeBlock2 = 'pass'

    logger.debug(f'{log_space}IF {str(eval(condition)).upper()} THEN {codeBlock1} ELSE {codeBlock2}')
    
    if eval(condition):
        return [codeBlock1]
    else:
        if codeBlock2 != 'pass':
            return [codeBlock2]
        else:
            return []


def LOG(codeValue, **kwargs):
    """Logs some text to dashboard.

    Example:
        Log: {{some text}}
    """
    #logg('log:', errorMsg = codeValue)
    #pass
    return None

def EXIT(*args, **kwargs):
    """Close RPA Browser and Exit program.

    Example: 
        Exit:
    """
    import sys
    import rpa as r    
    def exitProg():
        '''Close RPA browser'''
        r.close()
        sys.exit(config.EX_OK) # code 0, all ok    
        #exit()
    exitProg()


@validate_args
@type_check
def exitError(codeValue:str, **kwargs):
    """Exit with an Error.

    Example: 
        exitError: {{error code in integer from 1 to 10}}
    """
    import sys
    import rpa as r    
    def exitProgWError(errorCode: int):
        '''Close RPA browser'''
        r.close()
        sys.exit(errorCode) # code 0, all ok        
        #exit(errorCode)
    if codeValue.isdigit():
        if int(codeValue) in [1,2,3,4,5,6,7,8,9,10]:                
            exitProgWError(errorCode=int(codeValue))

@validate_args
@type_check
def raiseError(codeValue:str, **kwargs):
    """Raise an Error message.

    Example: 
        raiseError: {{Error message}}
    """
    raise ValueError(f"Raise Error: {codeValue}")

@validate_args
@type_check
def help(libraries_list:str = "" , file_save_as:str = "help.xlsx", sheet_name='help', **kwargs):
    """Generates the help file in Excel
    ['Browser_playwright', 'Browser_tagui', 'BuiltIn', 'DataFrame', 'Email_Exchange', 'Excel', 'FileSystem', 'Flows', 'Image', 'PDF', 'Python', 'Table', 'Vault', 'Windows']

    Example:
        help: {{libraries list - default "all"}} , {{file save as - default in scripts folder}}
        help: all , ../../autobot/assets/studio/help.xlsx
        help: BuiltIn, Browser_tagui
    """
    from pathlib import Path, PureWindowsPath
    import sys, os
    #PROGRAM_DIR = Path(".").resolve().parents[0].absolute().__str__()
    from config import PROGRAM_DIR
    print(PROGRAM_DIR)
    if Path("./autobot").exists():
        PROGRAM_DIR = Path(".").resolve().absolute().__str__()
    elif Path("../autobot").exists():
        PROGRAM_DIR = Path(".").resolve().parents[0].absolute().__str__()
    elif Path("../../autobot").exists():
        PROGRAM_DIR = Path(".").resolve().parents[0].parents[0].absolute().__str__()
    else:
        PROGRAM_DIR = "ERROR"

    print(libraries_list, file_save_as, PROGRAM_DIR, Path(".").resolve().absolute().__str__())

    if Path(file_save_as).parent.exists():
        print('File save as', Path(file_save_as).absolute.__str__())
    else:
        print('File save as path invalid')
        return False

    #MODULE_PATH_file = Path(__file__).parents[0].resolve().absolute().__str__()
    MODULE_PATH_libraries = Path(f"{PROGRAM_DIR}/autobot/src/general_automation/libraries").resolve().absolute().__str__()
    import sys
    sys.path.append(MODULE_PATH_libraries)

    def __list_modules_from_folder__(MODULE_PATH_libraries: str = MODULE_PATH_libraries) -> list:
        from os import listdir
        from os.path import isfile, join
        mypath = MODULE_PATH_libraries #"/path/to/folder"
        onlyfiles = [f[:-3] for f in listdir(mypath) if isfile(join(mypath, f)) and f.endswith(".py")]
        return onlyfiles

    defaultLibraries = __list_modules_from_folder__() #['passwords','BuiltIn']
    print('DefaultLibraries', defaultLibraries)

    def import_module(module_name:str) -> object:
        """To import a module with a given string name in Python,
        """
        import importlib
        #module_name = "BuiltIn"
        module = importlib.import_module(module_name)
        return module

    import inspect

    def get_functions(module_name):
        functions = {}
        module = import_module(module_name)
        functions['module'] = []
        functions['name'] = []
        functions['help'] = []
        functions['arguments'] = []        
        functions['types'] = []                
        for name, obj in inspect.getmembers(module):
            print("----", str(module.__name__), name.strip(" ").strip("_"), obj.__doc__.__str__().strip())
            if inspect.isfunction(obj):
                functions['module'] += [str(module.__name__)]
                functions['name'] += [name.strip(" ").strip("_")]
                functions['help'] += [obj.__doc__]  #.__str__().strip()
                functions['arguments'] += [obj.__annotations__.keys()]
                functions['types'] += [obj.__annotations__.values()]                
        return functions

    def get_callable_functions_bak(module_name: str) -> dict:
        #import sys             if not module_name in sys.modules: 
        module = import_module(module_name)
        callableFunctions = [func for func in dir(module) if callable(getattr(module, func))]
        prefix = "__"
        listFunctions = [item for item in callableFunctions if not item.startswith(prefix)]  # remove items with that prefix    
        return {module_name: listFunctions}   

    def get_callable_functions(module_name: str) -> dict:
        #import sys             if not module_name in sys.modules: 
        functions = {}
        module = import_module(module_name)
        functions['module'] = []
        functions['name'] = []
        functions['help'] = []
        functions['arguments'] = []

        print('module name' , module_name)

        callableFunctions = [func for func in dir(module) if callable(getattr(module, func))]
        #for name, obj in inspect.getmembers(module):
        #    print("----", str(module.__name__), name.strip(" ").strip("_"), obj.__doc__.__str__().strip())
        name_func = [obj.__name__.__str__().strip() for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]

        print('functions', name_func)

        doc_strings = [obj.__doc__.__str__().strip() for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]
        import json
        #argument_strings = [json.dumps(obj.__annotations__) for name, obj in inspect.getmembers(module) if callable(getattr(module, name))]       
        #argument_strings = [str(obj.__annotations__) for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]
        argument_strings = [{key: value.__name__ if value!=None else None for key, value in obj.__annotations__.items()} \
                            for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]        
        print('argstr:', argument_strings)
        #argument_strings = [json.dumps({key: value.__name__ if key!="return" else value for key, value in obj.__annotations__.items()}) \
        #                    for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]        
        argument_strings = [json.dumps({key: value.__name__ if value!=None else None for key, value in obj.__annotations__.items()}) \
                            for name, obj in inspect.getmembers(module, inspect.isfunction) if callable(getattr(module, name))]        

        #import inspect
        #import my_module

        annotations_list = []

        for name, obj in inspect.getmembers(module, inspect.isfunction):
            #annotations_list.append(json.dumps(obj.__annotations__))
            print('*********', type(obj.__annotations__) , str(obj.__annotations__) )
            annotations_list.append(str(obj.__annotations__))

        print(annotations_list)

        prefix = "__"
        listFunctions = [item for item in callableFunctions if not item.startswith(prefix)]  # remove items with that prefix
        functions['name'] = name_func #listFunctions
        functions['module'] = [str(module.__name__)]*len(name_func) #len(listFunctions)
        functions['help'] = doc_strings
        functions['arguments'] = argument_strings
        return functions   

    print('libraries_list param:', libraries_list)    
    if libraries_list.strip() == "" or libraries_list.strip() == "all": #[]:
        #listModules = defaultLibraries
        #listModules = ['Browser_playwright', 'Browser_tagui', 'BuiltIn', 'DataFrame', 'Email_Exchange', 'Excel', 'FileSystem', 'Flows', 'Github', 'Image', 'LibraryTemplate', 'PDF', 'Prefect', 'Python', 'Table', 'Vault', 'Windows']
        listModules = ['Browser_playwright', 'Browser_tagui', 'BuiltIn', 'DataFrame', 'Email_Exchange', 'Excel', 'FileSystem', 'Flows', 'Github', 'Image', 'LibraryTemplate', 'PDF', 'Python', 'Table', 'Vault', 'Windows']
    else:
        print('libraries_list:', libraries_list)
        listModules = [item.strip() for item in libraries_list.split(',')]
    print('listModules', listModules)
    myobject = {}

    import pandas as pd
    df = pd.DataFrame()
    for Module in listModules:
        #dictKeywords = dictKeywords | get_callable_functions(Module)
        #import BuiltIn   #Browser_tagui#
        #myobject = myobject | get_callable_functions(Module) #get_functions(Module)

        # Convert the dictionary to a pandas dataframe
        df_module_new = pd.DataFrame.from_dict(get_callable_functions("libraries."+Module))
        df = pd.concat([df, df_module_new], ignore_index=True)
        #print(">>>>", myobject)
    #print("****",myobject)

    # Export the dataframe to an Excel file
    df.rename(columns={'module': 'Type', 'name': 'Command', 'help': 'Documentation', 'arguments': 'Arguments'}, inplace=True)

    def trimSpaceText(text):
        # Split the text into lines
        lines = text.split('\n')

        # Remove leading spaces from each line
        for i in range(len(lines)):
            lines[i] = lines[i].strip()

        # Join the lines back into a single string
        text = '\n'.join(lines)
        return text

    # Apply the function on each item in column 'B'
    df['Documentation'] = df['Documentation'].apply(trimSpaceText)

    # split the column into two columns based on the delimiter ':'
    #df[['Description', 'Others']] = df['Documentation'].str.split('\n\n', expand=True)
    df['Others'] = df['Documentation'].str.split('\n\n')
    df['Description'] = df['Others'].apply(lambda x: x[0])

    def itemInListWithPrefix(my_list = ['apple', 'banana', 'cherry', 'date'], prefix = 'te'):

        #my_list = ['apple', 'banana', 'cherry', 'date']
        #prefix = 'te'

        # Return the element in my_list that matches the prefix
        result = next((x for x in my_list if x.startswith(prefix)), None)
        if result != None:
            result = result.replace(prefix, "", 1).replace("\n", "", 1)
        return result

    df['Example'] = df['Others'].apply(lambda x: itemInListWithPrefix(x, 'Example:'))

    # filter for rows where 'col1' does not start with '_'
    # and is not in the list ['test1', 'test2']
    filtered_df = df[~df['Command'].str.startswith('_') & ~df['Command'].isin(['consoleOutput', 'redirectConsole','resetConsole','type_check','validate_args'])]

    filtered_df.to_excel(file_save_as, sheet_name=sheet_name, index=False)
    return True


@validate_args
@type_check
def checkVariable(variable_name:str):
    """Prints the value of the variable name to console and log.

    Example:
        checkVariable: {{variable name}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from config import constants, variables

    logger = get_run_logger()
    variableValue = variables[variable_name]
    logger.debug(f"{log_space}checkVariable:', key = {variable_name}, variableValue = {variableValue}")


@validate_args
@type_check
def set(variable_name:str , variable_value:str = None):
    """Sets the variable name with a given value.  If variable name does not exist, create the variable.

    Example:
        set: {{variable name}} , {{variable value}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from config import constants, variables

    if "=" in variable_name and variable_value==None:
        key = variable_name.split('=',1)[0].strip()
        value = variable_name.split('=',1)[1].strip()
    else:
        key = variable_name
        value = variable_value
    if key == 'iterationCount':
        # special case iteration count
        constants[key] = int(value)
    else:
        variables[key] = value
        #logg('set: ', key = key, variablesValue = variables[key])        


@validate_args
@type_check
def regexSearch(search_pattern:str, text_to_search:str, variable_name:str):
    """Set result of a regex pattern search in a variable.
    Search for a pattern in a given string and return the matching pattern value

    Example:
        regexSearch: {{search pattern}} , {{text to search}} , {{variable value}}
    """
    #from config import constants, variables
    #from auto_utility_parsers import parseArguments, regexSearch

    #regexSearch:PACIFIC.ASIA.(..........),<strSearch>,lastDataUpdate
    #strPattern = codeValue.split(',')[0]
    #strSearch = codeValue.split(',')[1]
    #variable_name = codeValue.split(',')[2]

    import re
    # called by auto_code command regexSearch:
    def regexSearch(strPattern, strSearch):
        ''' search for a pattern in a given string and return the matching pattern value'''
        try:
            # found = re.search('AAA(.+?)ZZZ', str).group(1)
            print('regexSearch .....', strPattern, strSearch)
            found = re.search(strPattern, strSearch).group(1)
            #logg(found)
            return found
        except AttributeError:
            pass
        return None

    import config
    config.variables[variable_name] = regexSearch(search_pattern, text_to_search)
    #logg('regexSearch', strPattern = strPattern, strSearch = strSearch, variable_name = variable_name, result = variables[variable_name])


@validate_args
@type_check
def deploy():
    """Deploy a script to prefect for scheduling.

    Example:
        deploy:
    """
    from prefect.deployments import Deployment
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    log_space = "          "

    from pathlib import Path

    from config import constants, variables, program_args, AUTOBOT_DIR
    #from auto_initialize import changeWorkingDirectory
    from core.files import changeWorkingDirectory

    # deployment.py
    def workflowDeployment(deploymentname, parametervalue):
        from run import run
        #print('AUTOBOT DIR:', f"{AUTOBOT_DIR}\\src\\general_automation\\")
        changeWorkingDirectory(f"{AUTOBOT_DIR}\\src\\general_automation\\")
        #tCWD_DIR = checkWorkDirectory('.')
        #print(tCWD_DIR)
        deployment = Deployment.build_from_flow(
            flow=run.with_options(name=deploymentname),
            name=deploymentname,
            parameters=parametervalue,
            infra_overrides={"env": {"PREFECT_LOGGING_LEVEL": "DEBUG"}},
            work_queue_name=computername
        )
        #            path = f"{AUTOBOT_DIR}\\src\\general_automation\\"

        #     storage=fs
        deployment.apply()
        logger.warning(log_space+f'Deployed flow: {deploymentname}')
        logger.info(log_space+f'Parameters: {parametervalue}')        

    #print("CREATE DEPLOYMENT")
    import socket
    computername = socket.gethostname()
    #deploymentname = config.FLOW_NAME + "-"+ str(computername)
    #parametervalue = {"commandStr": Path(config.PROGRAM_DIR + '/runRPA.bat -f ' + Path(config.STARTFILE).name.__str__()).absolute().__str__()}
    deploymentname = program_args['startfile'] + "-" + str(computername)
    if '4' in str(program_args['background']):
        prefectdeploymentname=program_args['startfile'] + "-TRIGGER-" + str(computername)
    else:
        prefectdeploymentname=deploymentname
    parametervalue = {"file": program_args['startfile'] +".xlsm", "flowrun": 1, "deploymentname": deploymentname, \
        "PROGRAM_DIR": Path(AUTOBOT_DIR).parents[0].resolve().absolute().__str__(), \
        "update": program_args['update'], \
        "retries": program_args['retries'], \
        "startcode": program_args['startcode'], \
        "startsheet": program_args['startsheet'], \
        "background": str(program_args['background']), \
        "kwargs": {}
        } 

    #print(prefectdeploymentname, '|' , parametervalue)
    #from deployment import workflowDeployment
    workflowDeployment(prefectdeploymentname, parametervalue)


"""
def PRINT():
    pass

def log():
    pass

def exit():
    pass

def exitError():
    pass

def raiseError():
    pass

def IF():
    pass
"""