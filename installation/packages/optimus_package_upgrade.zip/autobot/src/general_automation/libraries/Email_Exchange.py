#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

Email processing

_isWorkSheetName(obj, excelfile)
_selectTable(codeValue: str, df)

email(codeValue:str, df:pd.DataFrame=None)
waitEmailComplete(*args, **kwargs)


    elif codeID.lower() == 'email'.lower():  _email(codeValue, df)
    elif codeID.lower() == 'waitEmailComplete'.lower():  _waitEmailComplete(codeValue, df)

"""

from core.lexicon import validate_args, type_check
from core.email import EmailsSender

def _isWorkSheetName(obj, excelfile):
    #check if obj is a worksheet in excelfile and returns result of sheet as dataframe
    #logger = get_run_logger()
    try:
        #elif obj in wb.sheetnames:
        sheet = obj
        #excelfile = STARTFILE
        objTableSet = pd.read_excel(excelfile, sheet_name=sheet)
        #logger.info('sheet exists')
        #logger.info(objTableSet)
        return True, objTableSet
    except ValueError as e:
        pass
    return False, None

def _selectTable(codeValue: str, df):
    # Returns a objTableSet (table object) with parameter which is either a table object in the list or a worksheet
    from config import STARTFILE

    #logger = get_run_logger()
    # table specified
    obj = codeValue
    #from openpyxl import load_workbook
    #wb = load_workbook(STARTFILE, read_only=True)   # open an Excel file and return a workbook
    if obj in df[(df.Type == 'table')]['Object'].dropna().values.tolist():
        #objTableSet = df[(df.Type == 'key') & ((df.Object == obj))]
        objTableSet = df[(df.Type == 'table') & ((df.Object == obj))]   # filter for specified object
        objTableSet = objTableSet.dropna(axis=1, how='all')  # drop all columns where values are nan
        #objTableSet = objTableSet.loc[:, ~objTableSet.columns.str.contains('^Unnamed')]  # remove unnamed columns
        #objTableSet.set_index("Type", inplace = True)
        objTableSet = objTableSet.reset_index(drop=True)    # remove index
        objTableSet = objTableSet.drop(['Type', 'Object'], axis=1)  # drop Type and Object column  
        #logger.info(objTableSet.head())
        objTableSet.columns = objTableSet.iloc[0]   # promote 1st row to header
        objTableSet = objTableSet[1:] #take the data less the header row
        #objTableSet = objTableSet.drop(columns=[0])

        #new_header = objTableSet.iloc[0] #grab the first row for the header
        #objTableSet = objTableSet[1:] #take the data less the header row
        #objTableSet.set_axis(new_header, axis=1, inplace=True)
        #objTableSet.columns = new_header #set the header row as the df header
        #logger.info(objTableSet.head())
        return True, objTableSet
    else:
        result, objTableSet = _isWorkSheetName(obj, excelfile=STARTFILE)
        return result, objTableSet

import pandas as pd
@validate_args
@type_check
def email(codeValue:str, df:pd.DataFrame=None):
    """ Send email using locally installed outlook client.  Requires following key value parameters/members:
    EmailObj or To, CC, Subject, HTMLBody, Attachment etc. Attachment comma delimited list
    table, Email_Lists, Subject, HTMLBody, Attachment, To, CC, boolForce, boolRun
    Daily Sales - APAC, apac.html, "CountryStore_report.png, APACProductCat_report.png, WomenUniverseCountryStore_report.png", , , FALSE, TRUE 

    Example:
        email: {{row number}} , {{data frame}}
    """
    import datetime
    import json
    import traceback

    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    

    from config import constants, variables, log_space
    import config
    if df==None:    df = config.variables['optimusDF']

    #logger.info(f"Email codeValue: {codeValue}")

    # parse codeValue:
    try:
        emailObj = json.loads(codeValue)    # if codeValue is a Json object
        #logger.info(emailObj)
        #logger.info(emailObj['To'])

    except ValueError as e:
        #logger.info(f"ValueError")
        # not a json format - i.e. assume its a table
        # raise ValueError(f"Raise Error: incorrect json format, {codeValue}")
        if len(codeValue.split(',')) > 1:
            colsMapping = codeValue.split(',',1)[1].strip()
            codeValue = codeValue.split(',',1)[0].strip()
            #logger.info(f"colsMapping:{colsMapping}, codeValue: {codeValue}")
        result, objTableSet = _selectTable(codeValue, df)
        #if _ifObjectExist('colsMapping'): # rename columns to names required by email send function
        if 'colsMapping' in locals(): #or var in globals()
            #logger.info(f"Rename cols: {json.loads(colsMapping)}")
            #logger.info(json.loads(colsMapping))
            objTableSet.rename(columns = json.loads(colsMapping), inplace = True)
        mailfieldlst = ['To', 'CC', 'Subject', 'Body', 'HTMLBody', 'Attachment', 'boolDisplay', 'boolRun', 'boolForce']
        objTableSet = objTableSet[objTableSet.columns.intersection(mailfieldlst)]  # select columns for mailing
        if result == True:  # is a table
            n = constants['iterationCount']
            #logger.info('iterationCount ' + str(n))
            objTableSet = objTableSet.iloc[n]  # fiter tableset for current iteration row
            #logger.info(objTableSet)
            #logger.info('columns')
            emailObj = json.loads(objTableSet.to_json(orient="columns"))
            logger.debug(f"{log_space}{emailObj}")
    #logger.info(type(emailObj)) # dictionary object

    # Send email
    #logger.info(f"****** Send Email - emailObj:{emailObj}")
    try:
        To = emailObj['To']
        Subject = emailObj['Subject']
        #HTMLBody = emailObj['HTMLBody']
        #Attachment = emailObj['Attachment']
        #email_sender.send_email(boolDisplay=False, To=To, Subject=Subject, HTMLBody=HTMLBody, Attachment=Attachment)
        #logger.info(f"******** Email To:{To} Subject:{Subject}")

        boolRun = emailObj['boolRun'] if 'boolRun' in emailObj else True 
        boolDisplay = emailObj['boolDisplay'] if 'boolDisplay' in emailObj else False
        boolForce = emailObj['boolForce'] if 'boolForce' in emailObj else False        

        if boolRun: 
            email_sender = EmailsSender()
            cutOffDateTme=datetime.datetime.today().replace(hour=int(variables['sentEmailCheck_hour']), minute=int(variables['sentEmailCheck_min']), second=0, microsecond=0)
            sentEmailSubjectList = email_sender.getSentEmailSubjectList(sentEmailSubjectList = [], cutOffDateTme=cutOffDateTme)
            if not Subject in sentEmailSubjectList or boolForce:
                email_sender.send_email(boolDisplay=boolDisplay, boolRun=boolRun, EmailObj = emailObj)
                logger.debug(f'{log_space}email SENT')
            else:
                logger.debug(f'{log_space}email NOT SENT - already sent')
        else:
            logger.debug(f'{log_space}boolRun is FALSE')
        #result = email_sender.wait_send_complete()
    except ValueError as e:
        logger.error('error --', e)
    except Exception as e:
        logger.error(traceback.format_exc())
        #logger.info('error --', e)
    #print('complete')


@validate_args
@type_check
def waitEmailComplete(*args, **kwargs):
    """Wait for email sending to complete before closing outlook client.

    Example:
        waitEmailComplete:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    email_sender = EmailsSender()
    result = email_sender.wait_send_complete()
    #import datetime
    #today = datetime.datetime.today().replace(hour=0, minute=0, second=0, microsecond=0) #.strftime('%Y-%m-%d')

    #print(today.strftime('%d/%m/%Y %H:%M %p'))
    #result2 = email_sender.folderItemsList(ofolder=5,dateRange_StartOn=today)          #.sentFolderList()
    #print(result2)
    
    #from auto_utility_email import today, sentEmailSubjectList
    #global today
    #global sentEmailSubjectList
    #print(today.strftime('%d/%m/%Y %H:%M %p'), sentEmailSubjectList)
    #print(sentEmailSubjectList)
 
    #email_sender.refreshMail()
 
    logger.debug(f'{log_space}Email complete = ' + str(result))


