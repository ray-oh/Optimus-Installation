#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

Password management functions

get_password(username:str, origin:str)
"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def get_password(username:str, origin:str):
    """Get password from default Chrome user profile password vault.

    Example: 
        get_password: {{user name}} , {{origin}}
    """
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    log_space = "          "

    #tmpDict = parseArguments('username, origin',codeValue)
    #print(tmpDict)
    #if tmpDict == {}: return

    from core.passwords import retrieveHttpCredentials
    http_credentials=retrieveHttpCredentials(origin, username)

    if http_credentials['username'] == '':
        return
    else:
        import config
        config.variables['username'] = http_credentials['username']
        config.variables['password'] = http_credentials['password']
