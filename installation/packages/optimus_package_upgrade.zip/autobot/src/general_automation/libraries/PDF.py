#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

PDF processing

_createPDFfromImages(files, path, saveFile)
_addContentPDF(pageTitlesList, sourcePDF, targetPDF)

createPDF(imagelist:str , outputPath:str = None , saveFileName:str = None, df=str)
addContentPDF(pageTitles:str , sourcePDF:str , targetPDF:str , df)

    elif codeID.lower() == 'createPDF'.lower():   _createPDF(codeValue, df)

    #add_page_numbers(saveFile, pageTitles)
    #addContentPDF(pdf_path, pageTitles, file_extension = '_' + yesterdayYYYYMMDD + '.pdf')
    #addContentPDF:pageTitles,sourcePDF,targetPDF
    elif codeID.lower() == 'addContentPDF'.lower():  _addContentPDF(codeValue, df)
"""
from core.lexicon import validate_args, type_check

#from auto_utility_PDF_Image import addContentPDF # cropImage createPDFfromImages, 

from PIL import Image
def _createPDFfromImages(files, path, saveFile):
    files = files
    iterator = map(lambda file: Image.open(path + file).convert('RGB'), files)
    image_list = list(iterator)
    image_list[0].save(saveFile, save_all=True, append_images=image_list[1:])
    return

from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('Vera', 'Vera.ttf'))
pdfmetrics.registerFont(TTFont('VeraBd', 'VeraBd.ttf'))
pdfmetrics.registerFont(TTFont('VeraIt', 'VeraIt.ttf'))
pdfmetrics.registerFont(TTFont('VeraBI', 'VeraBI.ttf'))
def _createPagePdf(numPages, tmp, pageHeight, title):
    # create pdf with title from bottom left X, Y
    c = canvas.Canvas(tmp)
    #c.drawString(10, 150, "Some text encoded in UTF-8")
    #c.drawString(10, 100, "In the Vera TT Font!")
    print(numPages, len(title))

    for i in range(1, numPages + 1):
        #c.drawString((210 // 2) * mm, (4) * mm, str(i))
        #c.setFillColorRGB(1,0,0) # font color RED, (255,255,255) white
        c.setFillColorRGB(255, 255, 0) # Yellow
        c.setFont('VeraBd', 22)
        c.drawString((25) * mm, pageHeight - (9) * mm, title[i-1])
        #c.drawString(10, 40, title[i-1])
        c.showPage()
    c.save()

import os
from PyPDF4.pdf import PdfFileReader, PdfFileWriter
def _addContentPDF(pageTitlesList, sourcePDF, targetPDF):
    """
    Add page titles or numbers to a pdf, save the result as a new pdf
    @param pdf_path: path to pdf
    """
    tmp = "__tmp.pdf"

    output = PdfFileWriter()
    with open(sourcePDF, 'rb') as f:
        pdf = PdfFileReader(f, strict=False)
        n = pdf.getNumPages()
        #reader = PdfFileReader('./Output/my_images.pdf')
        #pageHeight = reader.pages[0].mediaBox.getHeight()
        pageHeight = int(pdf.pages[0].mediaBox.getHeight())
        print('page height', pageHeight)

        # create new PDF with page numbers
        _createPagePdf(n, tmp, pageHeight, pageTitlesList)

        with open(tmp, 'rb') as ftmp:
            numberPdf = PdfFileReader(ftmp)
            # iterarte pages
            for p in range(n):
                page = pdf.getPage(p)
                numberLayer = numberPdf.getPage(p)
                # merge number page with actual page
                page.mergePage(numberLayer)
                output.addPage(page)

            # write result
            if output.getNumPages():
                #newpath = pdf_path[:-4] + file_extension
                with open(targetPDF, 'wb') as f:
                    output.write(f)
        os.remove(tmp)

@validate_args
@type_check
def createPDF(imagelist:str , outputPath:str = None , saveFileName:str = None, df=str):
    """Create PDF from a list of image files.

    Example: 
        createPDF: {{image file list}} , {{output path}} , {{save file name}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure

    #tmpDict = parseArguments('imagelist,outputPath,saveFileName',codeValue)
    if imagelist != None:
        #logg('imagelist', content = tmpDict['imagelist'].strip())
        imagelist = imagelist.strip()
        imagelist = dfObjList(df, imagelist)

        #logg('imagelist', imagelist = imagelist)
        #if imagelist == '': imagelist = ''
        if imagelist == None:
            #imagelist = ''
            logger.error('Error - no imagelist ...')
        else:
            if outputPath != None:
                #logg('outputPath', content = tmpDict['outputPath'])  # D:\\iCristal\\
                outputPath = outputPath.strip()
                if outputPath == '': outputPath = './' #'.\\' #'D:\\iCristal\\'
            if saveFileName != None:
                #logg('saveFileName', content = tmpDict['saveFileName'])  # 'D:/iCristal/Output/APAC_Daily_Sales/'
                saveFileName = saveFileName.strip()
                if saveFileName == '': saveFileName = './savefile.pdf' #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
            _createPDFfromImages(imagelist, outputPath, saveFileName)


@validate_args
@type_check
def addContentPDF(pageTitles:str , sourcePDF:str , targetPDF:str , df):
    """Add content to PDF file e.g. page titles

    Example: 
        addContentPDF: {{page titles}} , {{source PDF file}} , {{target PDF file}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER

    #tmpDict = parseArguments('pageTitles,sourcePDF,targetPDF',codeValue)
    if pageTitles != None:
        #logg('pageTitles', content = tmpDict['pageTitles'].strip())
        pageTitles = pageTitles.strip()
        pageTitlesList = dfObjList(df, pageTitles)
        #logg('pageTitlesList', pageTitlesList = pageTitlesList)
        if not len(pageTitlesList) : return # error - no pageTitles provided
    if sourcePDF != None:
        #logg('sourcePDF', content = tmpDict['sourcePDF'])  # D:\\iCristal\\
        sourcePDF = sourcePDF.strip()
        if sourcePDF == '': return # error - no pdf_path defined
    if targetPDF != None:
        #logg('targetPDF', content = tmpDict['targetPDF'])  # 'D:/iCristal/Output/APAC_Daily_Sales/'
        targetPDF = targetPDF.strip()
        file_extension = '_' + yesterdayYYYYMMDD + '.pdf'
        if targetPDF == '': targetPDF = sourcePDF + file_extension #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
    _addContentPDF(pageTitlesList, sourcePDF, targetPDF)



