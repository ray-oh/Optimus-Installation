"""
An always available standard library with often needed keywords.
PDF processing
_createPDFfromImages(files, path, saveFile)
_addContentPDF(pageTitlesList, sourcePDF, targetPDF)
createPDF(imagelist:str , outputPath:str = None , saveFileName:str = None, df=str)
addContentPDF(pageTitles:str , sourcePDF:str , targetPDF:str , df)
    elif codeID.lower() == 'createPDF'.lower():   _createPDF(codeValue, df)
    elif codeID.lower() == 'addContentPDF'.lower():  _addContentPDF(codeValue, df)
"""
from core.lexicon import validate_args, type_check
from PIL import Image
def _createPDFfromImages(files, path, saveFile):
    files = files
    iterator = map(lambda file: Image.open(path + file).convert('RGB'), files)
    image_list = list(iterator)
    image_list[0].save(saveFile, save_all=True, append_images=image_list[1:])
    return
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('Vera', 'Vera.ttf'))
pdfmetrics.registerFont(TTFont('VeraBd', 'VeraBd.ttf'))
pdfmetrics.registerFont(TTFont('VeraIt', 'VeraIt.ttf'))
pdfmetrics.registerFont(TTFont('VeraBI', 'VeraBI.ttf'))
def _createPagePdf(numPages, tmp, pageHeight, title):
    c = canvas.Canvas(tmp)
    print(numPages, len(title))
    for i in range(1, numPages + 1):
        c.setFillColorRGB(255, 255, 0) 
        c.setFont('VeraBd', 22)
        c.drawString((25) * mm, pageHeight - (9) * mm, title[i-1])
        c.showPage()
    c.save()
import os
from PyPDF4.pdf import PdfFileReader, PdfFileWriter
def _addContentPDF(pageTitlesList, sourcePDF, targetPDF):
    """
    Add page titles or numbers to a pdf, save the result as a new pdf
    @param pdf_path: path to pdf
    """
    tmp = "__tmp.pdf"
    output = PdfFileWriter()
    with open(sourcePDF, 'rb') as f:
        pdf = PdfFileReader(f, strict=False)
        n = pdf.getNumPages()
        pageHeight = int(pdf.pages[0].mediaBox.getHeight())
        print('page height', pageHeight)
        _createPagePdf(n, tmp, pageHeight, pageTitlesList)
        with open(tmp, 'rb') as ftmp:
            numberPdf = PdfFileReader(ftmp)
            for p in range(n):
                page = pdf.getPage(p)
                numberLayer = numberPdf.getPage(p)
                page.mergePage(numberLayer)
                output.addPage(page)
            if output.getNumPages():
                with open(targetPDF, 'wb') as f:
                    output.write(f)
        os.remove(tmp)
@validate_args
@type_check
def createPDF(imagelist:str , outputPath:str = None , saveFileName:str = None, df=str):
    """Create PDF from a list of image files.
    Example: 
        createPDF: {{image file list}} , {{output path}} , {{save file name}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    if imagelist != None:
        imagelist = imagelist.strip()
        imagelist = dfObjList(df, imagelist)
        if imagelist == None:
            logger.error('Error - no imagelist ...')
        else:
            if outputPath != None:
                outputPath = outputPath.strip()
                if outputPath == '': outputPath = './' 
            if saveFileName != None:
                saveFileName = saveFileName.strip()
                if saveFileName == '': saveFileName = './savefile.pdf' 
            _createPDFfromImages(imagelist, outputPath, saveFileName)
@validate_args
@type_check
def addContentPDF(pageTitles:str , sourcePDF:str , targetPDF:str , df):
    """Add content to PDF file e.g. page titles
    Example: 
        addContentPDF: {{page titles}} , {{source PDF file}} , {{target PDF file}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    if pageTitles != None:
        pageTitles = pageTitles.strip()
        pageTitlesList = dfObjList(df, pageTitles)
        if not len(pageTitlesList) : return 
    if sourcePDF != None:
        sourcePDF = sourcePDF.strip()
        if sourcePDF == '': return 
    if targetPDF != None:
        targetPDF = targetPDF.strip()
        file_extension = '_' + yesterdayYYYYMMDD + '.pdf'
        if targetPDF == '': targetPDF = sourcePDF + file_extension 
    _addContentPDF(pageTitlesList, sourcePDF, targetPDF)
