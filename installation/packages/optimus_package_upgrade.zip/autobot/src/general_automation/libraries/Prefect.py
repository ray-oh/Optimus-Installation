"""
An always available standard library with often needed keywords.
Prefect orchestration functions
list_flow_runs_with_state(state:list=['Completed', 'Running', 'Pending'], hours=24*1)
return_flow_from_run_id(flow_run_id)
list_flows_with_state(state:list=['Completed', 'Running', 'Pending', 'Crashed'], hours=24*1, flow_runs=None)
delete_flow_runs(flow_runs: list)
print_flow_runs(flow_runs)
delete_running_flows(hours=1)
bulk_delete_flow_runs(state: list = ["Failed"], hours=24*1 , prompt:bool=True)
query_flow_runs(state=["Completed", "Failed", "Crashed"], hours=24*3, window=None)
"""
from core.lexicon import validate_args, type_check
from core.dates import localTime
@validate_args
@type_check
def test1(excel:str, macro:str):
    """Run Excel Macro.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    from pathlib import Path, PureWindowsPath
import asyncio
from prefect.client.orchestration import get_client
from prefect.server.schemas.filters import FlowRunFilter, FlowRunFilterState, FlowRunFilterStateName, FlowRunFilterStartTime, FlowRunFilterId, FlowFilterId
async def list_flow_runs_with_state(state:list=['Completed', 'Running', 'Pending'], hours=24*1):
    """Returns a list of flow runs that match specific flow run state.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from datetime import datetime, timedelta
    start_time = datetime.now() - timedelta(hours=hours)  # minutes
    async with get_client() as client:
        flow_runs = await client.read_flow_runs(
            flow_run_filter=FlowRunFilter(
                state=FlowRunFilterState(
                    name=FlowRunFilterStateName(any_=state)
                ),
                start_time=FlowRunFilterStartTime(
                    after_=start_time
                )
            )
        )
    flow_runs.sort(key=lambda x: x.start_time, reverse=True) #localTime(x.start_time, format="%Y%m%d%H%M")
    flow_run_list = []
    flow_name_list = []
    for idx, flow_run in enumerate(flow_runs):
        flow_run_list = flow_run_list + [flow_run.id]
        flow_name_list = flow_name_list + [flow_run.name]
    return flow_runs
async def return_flow_from_run_id(flow_run_id):
    """Return name of flow from flow run id
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    async with get_client() as client:
        flows = await client.read_flows(
            limit=50,
            flow_run_filter=FlowRunFilter(
                id=FlowFilterId(any_=[flow_run_id])
                )
            )
    return flows[0].name
async def list_flows_with_state(state:list=['Completed', 'Running', 'Pending', 'Crashed'], hours=24*1, flow_runs=None):
    """Return list of flows with specific state.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from datetime import datetime, timedelta
    start_time = datetime.now() - timedelta(hours=hours)  # minutes
    if not flow_runs==None:
        flow_run_list = []
        for idx, flow_run in enumerate(flow_runs):
            flow_run_list = flow_run_list + [flow_run.id]
    else:
        return
    async with get_client() as client:
        flows = await client.read_flows(
            limit=50,
            flow_run_filter=FlowRunFilter(
                id=FlowFilterId(any_=flow_run_list),  
                state=FlowRunFilterState(
                    name=FlowRunFilterStateName(any_=state)
                ),
                start_time=FlowRunFilterStartTime(
                    after_=start_time
                )
            )
        )
    return flows
    f = await client.read_flows(
        limit=50,
        flow_run_filter=FlowRunFilter(
            id=FlowFilterId(any_=[flow.id]),  
            start_time=FlowRunFilterStartTime(
                after_=start_time
            )
    ))
    zflowName = f[0].name  # flow.parameters['deploymentname'].split('-C')[0][:8]  Instead of using the deployment name, get actual flow name
    text = [st, f'({duration})', status, zflowName[:8] , flow.name.split('-')[1][:7]  ] #flow.state_name[:3]
    text = " ".join(text)
    result = result + '\n' + text
async def delete_flow_runs(flow_runs: list):
    """Delete list of flow runs
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    async with get_client() as client:
        for flow_run in flow_runs:
            await client.delete_flow_run(flow_run_id=flow_run.id)
def print_flow_runs(flow_runs):
    """Run Excel Macro.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    for idx, flow_run in enumerate(flow_runs):
        print(f"[{idx + 1}] Flow '{flow_run.name}' with ID '{flow_run.id}'")
async def bulk_delete_flow_runs(state: list = ["Failed"], hours=24*1 , prompt:bool=True):
    """Delete flows that match specific state (Completed, Failed, Crashed, Running, Pending, Scheduled, Late), 
    and duration (e.g. past 1 day), with/without confirmation prompt.
    Called by launcher.py.  Used in conjunction with query_flow_runs to filter list of flows.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    flow_runs = await list_flow_runs_with_state(state, hours)
    if len(flow_runs) == 0:
        print(f"There are no flow runs in state '{state}'")
        return
    print(f"There are {len(flow_runs)} flow runs with state {state}\n")
    for idx, flow_run in enumerate(flow_runs):
        print(f"[{idx + 1}] Flow '{flow_run.name}' with ID '{flow_run.id}'")
    if prompt:
        if input("\n[Y/n] Do you wish to proceed: ") == "Y":
            print(f"Deleting {len(flow_runs)} flow runs...")
            await delete_flow_runs(flow_runs)
            print("Done.")
        else:
            print("Aborting...")
    else:
        print(f"Deleting {len(flow_runs)} flow runs...")
        await delete_flow_runs(flow_runs)
        print("Done.")
async def query_flow_runs(state=["Completed", "Failed", "Crashed"], hours=24*3, window=None):
    """Used by sub_windows_prefect for query on flow run activity
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    import asyncio
    flow_runs = await list_flow_runs_with_state(state=state, hours=hours) 
    window.Refresh() if window else None
    msg = ""
    for idx, flow_run in enumerate(flow_runs):
        flow_name = await return_flow_from_run_id(flow_run.id)
        msg = msg + f"\n[{idx + 1}] {flow_run.state_name.upper()} Flow {flow_name} > '{flow_run.name}' {localTime(flow_run.start_time, 'Asia/Hong_Kong')}" #with ID '{flow_run.id}
        window.Refresh() if window else None
    return msg
    """
    """
def delete_running_flows(hours=1):
    """Delete running flows in past hour
    Example: 
        delete_running_flows:
    """
    from prefect.backend import FlowView
    flow = FlowView.from_flow_name("your-name")
    print(flow.flow_id)
    return None
