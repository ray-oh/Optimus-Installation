#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'runExcelMacro'.lower():       _runExcelMacro(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'runPowerShellScript'.lower():       _runPowerShellScript(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'runBatchScript'.lower():       _runBatchScript(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'triggerRPAScript'.lower():       _triggerRPAScript(codeValue)                          # triggerRPAScript:command with flags    
    elif codeID.lower() == 'openProgram'.lower():       _openProgram(codeValue)                          # openProgram:path
    elif codeID.lower() == 'focusWindow'.lower():       _focusWindow(codeValue)                          # focusWindow:windowName

"""
from core.lexicon import validate_args, type_check
from core.dates import localTime

@validate_args
@type_check
def test1(excel:str, macro:str):
    """Run Excel Macro.

    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from pathlib import Path, PureWindowsPath

# https://github.com/erdewit/nest_asyncio
# https://github.com/python-telegram-bot/python-telegram-bot/issues/3251
# when using jupyter notebook to run this - add the following 2 lines
#import nest_asyncio
#nest_asyncio.apply()

import asyncio

from prefect.client.orchestration import get_client
from prefect.server.schemas.filters import FlowRunFilter, FlowRunFilterState, FlowRunFilterStateName, FlowRunFilterStartTime, FlowRunFilterId, FlowFilterId

async def list_flow_runs_with_state(state:list=['Completed', 'Running', 'Pending'], hours=24*1):
    from datetime import datetime, timedelta
    start_time = datetime.now() - timedelta(hours=hours)  # minutes

    async with get_client() as client:
        flow_runs = await client.read_flow_runs(
            flow_run_filter=FlowRunFilter(
                state=FlowRunFilterState(
                    name=FlowRunFilterStateName(any_=state)
                ),
                start_time=FlowRunFilterStartTime(
                    after_=start_time
                )
            )
        )
        #print(flow_runs)

    
    #flow_runs = 
    flow_runs.sort(key=lambda x: x.start_time, reverse=True) #localTime(x.start_time, format="%Y%m%d%H%M")
    #'{flow_run.name}' {flow_run.state_name} {localTime(flow_run.start_time, 'Asia/Hong_Kong')}" flow.id

    flow_run_list = []
    flow_name_list = []
    for idx, flow_run in enumerate(flow_runs):
        #print(f"[{idx + 1}] Flow '{flow_run.name}' {flow_run.state_name} {localTime(flow_run.start_time, 'Asia/Hong_Kong')}") #with ID '{flow_run.id}
        flow_run_list = flow_run_list + [flow_run.id]
        flow_name_list = flow_name_list + [flow_run.name]
    #print(flow_run_list)
    #print(flow_name_list)

    return flow_runs

async def return_flow_from_run_id(flow_run_id):
    # use flow id from flow run, to get flow name from read flows #[flow_runs.id]
    async with get_client() as client:
        flows = await client.read_flows(
            limit=50,
            flow_run_filter=FlowRunFilter(
                id=FlowFilterId(any_=[flow_run_id])
                )
            )
    return flows[0].name

async def list_flows_with_state(state:list=['Completed', 'Running', 'Pending', 'Crashed'], hours=24*1, flow_runs=None):
    from datetime import datetime, timedelta
    start_time = datetime.now() - timedelta(hours=hours)  # minutes
    
    if not flow_runs==None:
        flow_run_list = []
        for idx, flow_run in enumerate(flow_runs):
            #print(f"[{idx + 1}] Flow '{flow_run.name}' {flow_run.state_name} {localTime(flow_run.start_time, 'Asia/Hong_Kong')}") #with ID '{flow_run.id}
            flow_run_list = flow_run_list + [flow_run.id]
    else:
        return

    # use flow id from flow run, to get flow name from read flows #[flow_runs.id]
    async with get_client() as client:
        flows = await client.read_flows(
            limit=50,
            flow_run_filter=FlowRunFilter(
                id=FlowFilterId(any_=flow_run_list),  
                state=FlowRunFilterState(
                    name=FlowRunFilterStateName(any_=state)
                ),
                start_time=FlowRunFilterStartTime(
                    after_=start_time
                )
            )
        )
    #print(flow_run_list)
    #print(flows)
    return flows

    # use flow id from flow run, to get flow name from read flows
    f = await client.read_flows(
        limit=50,
        flow_run_filter=FlowRunFilter(
            #state=FlowRunFilterState(
            #    type=FlowRunFilterStateName(any_=["COMPLETED"])
            #),
            #flow_run_filter_id=FlowRunFilterId(id=FlowRunFilterId(any_=[flow.id])),
            #flow_run_filter_id=FlowRunFilterId(id=FlowRunFilterId(any_=[flow.id])),
            #flow_filter=FlowFilter(id=FlowFilterId(any_=[flow_id])),
            #flow_filter=FlowFilter(id=FlowFilterId(any_=[flow.id])),
            id=FlowFilterId(any_=[flow.id]),  
            # refer to link below on documentation for how to use FlowRunFilter:
            #https://docs.prefect.io/2.10.12/api-ref/server/schemas/filters/#prefect.server.schemas.filters.FlowRunFilter
            start_time=FlowRunFilterStartTime(
                after_=start_time
            )
    ))
    zflowName = f[0].name  # flow.parameters['deploymentname'].split('-C')[0][:8]  Instead of using the deployment name, get actual flow name
    # note this flow name is different from flow.name below which is name of the instance of flow run
    text = [st, f'({duration})', status, zflowName[:8] , flow.name.split('-')[1][:7]  ] #flow.state_name[:3]
    text = " ".join(text)
    result = result + '\n' + text


async def delete_flow_runs(flow_runs):
    async with get_client() as client:
        for flow_run in flow_runs:
            await client.delete_flow_run(flow_run_id=flow_run.id)

def print_flow_runs(flow_runs):
    for idx, flow_run in enumerate(flow_runs):
        print(f"[{idx + 1}] Flow '{flow_run.name}' with ID '{flow_run.id}'")

async def bulk_delete_flow_runs(state: list = ["Failed"], hours=24*1 , prompt:bool=True):
    flow_runs = await list_flow_runs_with_state(state, hours)

    if len(flow_runs) == 0:
        print(f"There are no flow runs in state '{state}'")
        return

    print(f"There are {len(flow_runs)} flow runs with state {state}\n")

    for idx, flow_run in enumerate(flow_runs):
        print(f"[{idx + 1}] Flow '{flow_run.name}' with ID '{flow_run.id}'")

    if prompt:
        if input("\n[Y/n] Do you wish to proceed: ") == "Y":
            print(f"Deleting {len(flow_runs)} flow runs...")
            await delete_flow_runs(flow_runs)
            print("Done.")
        else:
            print("Aborting...")
    else:
        print(f"Deleting {len(flow_runs)} flow runs...")
        await delete_flow_runs(flow_runs)
        print("Done.")

async def query_flow_runs(state=["Completed", "Failed", "Crashed"], hours=24*3, window=None):
    """ Used by sub_windows_prefect for query on flow run activity
    """
    #from libraries.Prefect import list_flow_runs_with_state, print_flow_runs, list_flows_with_state, return_flow_from_run_id
    import asyncio

    flow_runs = await list_flow_runs_with_state(state=state, hours=hours) 
    #flows = await list_flows_with_state(state=['Completed', 'Running', 'Pending', 'Crashed'], hours=24*3, flow_runs=flow_runs)
    #print_flow_runs(flow_runs)
    #print(flows)
    window.Refresh() if window else None
    msg = ""
    for idx, flow_run in enumerate(flow_runs):
        flow_name = await return_flow_from_run_id(flow_run.id)
        msg = msg + f"\n[{idx + 1}] {flow_run.state_name.upper()} Flow {flow_name} > '{flow_run.name}' {localTime(flow_run.start_time, 'Asia/Hong_Kong')}" #with ID '{flow_run.id}
        #{flows[idx].name.removesuffix('.xlsm')} 
        window.Refresh() if window else None
    return msg

if __name__ == "__main__":
    asyncio.run(bulk_delete_flow_runs(state="Failed"))

