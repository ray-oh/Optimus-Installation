"""
An always available standard library with often needed keywords.
Flow processing logic
_runInBackground()
increment(key:str , value:str)
_iterationCount(countValue:int, objVar:str = '')
iterate(objVar:str , sub_code:str)
_isCodeListTask(df, code, objVar)
_isCodeListFlow(df, code, objVar)
Arguments()
_runFunction(function_name:str, argument_string:str = '') -> list
runModule(sheet:str , initial_step:str = 'main' , excelfile:str = '')
runTask(codeValue, df, objVar)
runFlow(codeValue, df, objVar)
codeList(list_of_actions:str)
switch(case_table_name:str)
    elif codeID in df[(df.Type == 'list')]['Object'].dropna().values.tolist(): return _isCodeList(df, codeID, codeValue, objVar)          #run Block of Code
    elif codeID.lower() == 'runTask'.lower() and codeValue in df[(df.Type == 'list')]['Object'].dropna().values.tolist(): return _isCodeListTask(df, codeValue, objVar)          #run Block of Code    .with_options(name=codeValue.split(',')[0].strip())    
    elif codeID.lower() == 'runFlow'.lower() and codeValue in df[(df.Type == 'list')]['Object'].dropna().values.tolist(): return _isCodeListFlow(df, codeValue, objVar)          #run Block of Code        
    elif codeID.lower() == 'runModule'.lower(): return _runModule(codeValue, df, objVar)                  #runModule:sheet, codeblock, excelfile
    elif codeID.lower() == 'runTask'.lower(): return _runTask(codeValue, df, objVar)                  #runModule:sheet, excelfile .with_options(name=codeValue.split(',')[0].strip())
    elif codeID.lower() == 'runFlow'.lower(): return _runFlow(codeValue, df, objVar)                  #runModule:sheet, excelfile .with_options(name=codeValue.split(',')[0].strip())
    elif codeID.lower() == 'codeList'.lower(): return _codeList(codeValue, df, objVar)
"""
from core.lexicon import validate_args, type_check
def _runInBackground():
    runInBackground()
@validate_args
@type_check
def increment(key:str , value:str):
    '''Increment a variable counter by the given value
    Example:
        increment: iterationCount , 1
    '''
    import config
    if key == 'iterationCount':
        config.constants[key] = int(value) + int(config.constants[key])
    else:
        config.variables[key] = int(value) + int(config.variables[key])
@validate_args
@type_check
def _iterationCount(countValue:int, objVar:str = ''): #df, objVar
    '''Used by iterate keyword to keep track of the interation count status.
    Example:
        iterationCount: 0 , Incidents
    '''
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    import config
    config.constants['iterationCount'] = int(countValue)  
    logger.info(f">>>>>>>>>>>>>>>>>>>> ITERATION:{int(countValue)+1}, {objVar} <<<<<<<<<<<<<<<<<")
    return None
@validate_args
@type_check
def iterate(objVar:str , sub_code:str):
    '''Defines iteration steps and appends to runcode list to handle loops over object list or tables.  Syntax: iterate: obj or table list, codelist to run
    if a number is specified, then repeat the activity according to the number.
    Example:
        iterate: URL_Web_Pages , openPages
        iterate: 9 , openPages
    '''
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList
    import pandas as pd
    import config
    df = config.variables['optimusDF']
    def _isWorkSheetName(obj, excelfile):
        try:
            sheet = obj
            objTableSet = pd.read_excel(excelfile, sheet_name=sheet)
            return True, objTableSet
        except ValueError as e:
            pass
        return False, None
    worksheetTable = False
    configVariableTable = False
    if objVar.lower()[:4]=='tbl@':  # special table object with headers
        withHeader = 1
        objVar = objVar[4:]
    elif objVar in df[(df.Type == 'table')]['Object'].dropna().values.tolist():  # special table object with headers
        withHeader = 1
    elif objVar in config.variables.keys():    # HANDLE dataframe objects
        if isinstance(config.variables[objVar], pd.DataFrame):
            objTableSet = config.variables[objVar]
            logger.debug(f'Table columns: {objTableSet.columns.tolist()}')            
            configVariableTable = True
    else:
        result, objTableSet = _isWorkSheetName(objVar, excelfile=STARTFILE)
        if result == True:
            withHeader = 0 #1  Does not support 2 table headers.  Apply a rename instead to align names to function param
            worksheetTable = True
        else:
            withHeader = 0
    if objVar.isdigit():   # is integer - just standard loop
        totalCount = int(objVar)
        codeBeforeTemplateUpdate = variables['codeBeforeTemplateUpdate']
        sub_code = codeBeforeTemplateUpdate.split(',')[1].strip()
        if len(codeBeforeTemplateUpdate.split(','))==3:
            startCount = codeBeforeTemplateUpdate.split(',')[2].strip()
            startCount = int(startCount) if startCount.isdigit() else 0 
        else:
            startCount = 0
        n = 1
        additionalCodeList = []
        additionalDFlist = []
        additionalobjVarList = []
        for i in range(startCount, startCount + totalCount):
            logger.info(f"'ITERATION ---------------------------------------- LOOP {n}")
            increment = 'set:loopCount=' + str(i)
            additionalCodeList = additionalCodeList + [increment] + [sub_code]
            additionalDFlist = additionalDFlist + [df, df]
            additionalobjVarList = additionalobjVarList + [objVar, objVar]
            n += 1
        import config
        config.variables['optimusDF'] = df
        config.variables['optimusobjVar'] = objVar
        return additionalCodeList  #, additionalDFlist, additionalobjVarList 
    else:
        if worksheetTable:
            objVarList = objTableSet.iloc[withHeader:, 0].values.tolist() # row and column           
        elif configVariableTable:
            objVarList = objTableSet.iloc[0:, 0].values.tolist()  # all rows (index 0: to end) and first column
        else:
            objVarList = dfObjList(df, objVar, withHeader)
        logger.debug(f"{log_space}Do {sub_code} while LOOPing over {objVar}:{objVarList}")
        i = 0
        rtn_code = []
        rtn_df = []
        rtn_obj = []
        for x in objVarList:
            rtn_code = rtn_code + [f"_iterationCount:{i} , {objVarList[i]}"]  # inserts a interationCount step to increase interatation counter
            rtn_df = rtn_df + [df]
            rtn_obj = rtn_obj+ [objVarList[i]]
            rtn_code = rtn_code + [sub_code]
            rtn_df = rtn_df + [df]
            rtn_obj = rtn_obj+ [objVarList[i]]
            i = i + 1
        import config
        config.variables['optimusDF'] = df
        config.variables['optimusobjVar'] = rtn_obj[0]
        n = len(rtn_code)
        first_row = config.variables["df_list"]
        df_rtn_code = pd.concat([first_row]*n, ignore_index=True)  #  + [df]
        df_rtn_code['Key'] = rtn_code
        config.variables["df_list"] = df_rtn_code
        return df_rtn_code #, rtn_df, rtn_obj
        logger.warning(f'INFO: CHECK {config.variables["df_list"][["Row","Sheet","Key"]]}') #.iloc[0]["Key"]
        logger.error(f'ERROR: {rtn_code} | {rtn_obj[0]}')
def _isCodeListTask(df, code, objVar):
    sub_code = dfObjList(df, code)
    sub_code = ['### StartTask:'+code] + sub_code + ['### EndTask']
    n = len(sub_code)
    logger = get_run_logger()
    logger.debug(f"{log_space}Steps:{sub_code}")
    return sub_code, [df] * n, [objVar] * n
def _isCodeListFlow(df, code, objVar):
    sub_code = dfObjList(df, code)
    sub_code = ['### StartFlow:'+code] + sub_code + ['### EndFlow']
    n = len(sub_code)
    logger = get_run_logger()
    logger.debug(f"{log_space}Steps:{sub_code}")
    return sub_code, [df] * n, [objVar] * n
def Arguments():
    '''Runs a function in the script with given arguments.  Returns the actions from the function.
    The first line in the function when prefixed with "[Argument]:" initializes the arguments in the function which can be accessed like {{argument}}.
    Previous keyword was isCodeList.
    Example:
        Power BI Logon: {{user@email.com}}  ,  {{http://website.com}}
        list    |	Power BI Logon  |	[Arguments]:  username  ,  from domain  ,  additional_argument = 1
    '''
    from prefect import get_run_logger
    logger = get_run_logger()    
def _runFunction(function_name:str, argument_string:str = '') -> list:
    '''Runs a function in the script with given arguments.  Returns the actions from the function.
    The first line in the function when prefixed with "[Argument]:" initializes the arguments in the function which can be accessed like {{argument}}.
    Previous keyword was isCodeList.
    Example:
        Power BI Logon: {{user@email.com}}  ,  {{http://website.com}}
        list    |	Power BI Logon  |	[Arguments]:  username  ,  from domain  ,  additional_argument = 1
    '''
    from prefect import get_run_logger
    logger = get_run_logger()    
    from config import log_space, variables
    from core.core import dfObjList
    import config
    df = config.variables['optimusDF']
    sub_code = dfObjList(df, function_name)
    df_sub_code = dfObjList(df, function_name, df_list=True)
    firstElement = sub_code[0]
    firstElementKey = firstElement.split(':',1)[0].strip()
    if False:
        firstElementArguments = firstElement.split(':',1)[1].strip()
    if firstElementKey == '[Arguments]' and False:
        sub_code.pop(0) # remove first element of list
        keyLists = firstElementArguments.split('  ,  ')
        valueLists = argument_string.strip().split('  ,  ')
        logger.warning(log_space + '[Arguments]:' + str(keyLists) + ' | Values:' +  str(valueLists))
        import config
        i=0
        for item in keyLists:
            key = item
            if ' = ' in item:
                key = item.split(' = ')[0].strip()
            if i < len(valueLists):
                if ' = ' in valueLists[i]:
                    key = valueLists[i].split(' = ')[0].strip()
                    config.variables[key] = valueLists[i].split(' = ')[1].strip()
                else:
                    config.variables[key] = valueLists[i]                    
            else:
                if ' = ' in item:
                    key = item.split(' = ')[0].strip()
                    config.variables[key] = item.split(' = ')[1].strip()
                else:
                    logger.error(log_space + 'Argument index not matching function parameters')
                    raise ValueError(f"Raise Error: Argument index not matching function definition")
            logger.debug(log_space + 'Item: ' + item + ' Key: ' + key + ' Value: ' + config.variables[key])
            i=i+1
    logger.debug(f"{log_space}Steps:{sub_code}")
    import config
    config.variables['optimusDF'] = df
    return df_sub_code  #sub_code
@validate_args
@type_check
def runModule(sheet:str , initial_step:str = 'main' , excelfile:str = ''): #codeValue, df, objVar
    """Run the script in a given Excel sheet ("module") and at given initial action step.
    Example: 
        runModule: {{sheet}} , {{intial action step}}
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList
    import config
    logger = get_run_logger()
    codeBlock = initial_step
    from config import SCRIPTS_DIR
    if excelfile=='': excelfile = STARTFILE
    from pathlib import Path
    if Path(excelfile).__str__() == Path(excelfile).name:  # only name given, add script path
        excelfile = Path(SCRIPTS_DIR, excelfile).resolve().__str__()
    else:
        excelfile = Path(excelfile).resolve().__str__()
    if not Path(excelfile).exists():
        logger.error(f"{log_space}runModule file not exists .... sheet:{sheet} excelfile:{excelfile}") # df:{df.shape}
        return []
    import pandas as pd
    from core.files import cacheScripts
    from config import PROGRAM_DIR
    sp_count = 7
    displayMsg = f'{log_space}Loaded:'
    new_df, msgStr = cacheScripts(script=excelfile, program_dir=PROGRAM_DIR, startsheet=sheet, refresh=True, msgStr='')
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*sp_count}{msgStr}'
    new_df, msgStr = cacheScripts(script='OptimusLib.xlsm',df=new_df,program_dir=PROGRAM_DIR, startsheet='main', refresh=False)  #, msgStr=msgStr
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*sp_count}{msgStr}'
    new_df, msgStr = cacheScripts(script='OptimusLibPublic.xlsm',df=new_df,program_dir=PROGRAM_DIR, startsheet='main', refresh=False) #, msgStr=msgStr
    displayMsg = f"{displayMsg}" if msgStr=='' else f'{displayMsg}\n{log_space*sp_count}{msgStr}'
    logger.debug(f"{displayMsg}")
    run_code = dfObjList(new_df, codeBlock)               # run the main code block
    df_run_code = dfObjList(new_df, codeBlock, df_list=True)
    n = len(run_code)
    import config
    config.variables['optimusDF'] = new_df
    return df_run_code #, [new_df] * n, [objVar] * n
@validate_args
@type_check
def runTask(codeValue, df, objVar):
    """Run as a task the script in a given Excel sheet and at given initial action step.
    Example: 
        runTask: sheet , intial action step
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList, readExcelConfig
    sheet = codeValue.split(',')[0]
    num_arg = len(codeValue.split(','))
    if num_arg==1: 
        codeBlock = 'main'
        excelfile = ''
    elif num_arg==2: 
        codeBlock = codeValue.split(',')[1]
        excelfile = ''
    elif num_arg==3:
        codeBlock = codeValue.split(',')[1]
        excelfile = codeValue.split(',')[2]
    if excelfile=='': excelfile = STARTFILE
    new_df = readExcelConfig(sheet, excelfile)
    run_code = dfObjList(new_df, codeBlock)               # run the main code block
    n = len(run_code)
    return run_code, [new_df] * n, [objVar] * n
@validate_args
@type_check
def runFlow(codeValue, df, objVar):
    """Run as a flow the script in a given Excel sheet and at given initial action step.
    Example: 
        runFlow: sheet , intial action step
    """
    sheet = codeValue.split(',')[0]
    num_arg = len(codeValue.split(','))
    if num_arg==1: 
        codeBlock = 'main'
        excelfile = ''
    elif num_arg==2: 
        codeBlock = codeValue.split(',')[1]
        excelfile = ''
    elif num_arg==3:
        codeBlock = codeValue.split(',')[1]
        excelfile = codeValue.split(',')[2]
    if excelfile=='': excelfile = STARTFILE
    new_df = readExcelConfig(sheet, excelfile)
    run_code = dfObjList(new_df, codeBlock)               # run the main code block
    n = len(run_code)
    return run_code, [new_df] * n, [objVar] * n
@validate_args
@type_check
def codeList(list_of_actions:str):  #, df, objVar
    """Runs a list of commands.  List of actions can be defined in a "list" variable in the script.
    Or as a ', ' comma delimited string.
    Do not use ' , ' delimiter with space before comma, else, it will give wrong result and treat each item between comma as an argument, instead of item in a list.
    Wrap the comma within quotes e.g. "command1, command2, 'some, string', command4" to present item from separation as item in a list.
    Example: 
        codeList: {{list_of_actions}}
        codeList: openPages, downloadFile, wait:5, incrementalUpdate
        iterate: URL_pages , codeList: {{URL_pages:RunProcess}}
    """
    import shlex
    from prefect import task, flow, get_run_logger, context
    import config
    logger = get_run_logger()
    def split_string_by_comma_except_within_quotes(string):
        return [x.strip(',') for x in shlex.split(string)]
    codeList = split_string_by_comma_except_within_quotes(list_of_actions)
    config.constants['lastCodelist'] = codeList
    import pandas as pd
    n = len(codeList)
    first_row = config.variables["df_list"][:1]
    df_codeList = pd.concat([first_row]*n, ignore_index=True)  #  + [df]
    df_codeList['Key'] = codeList
    config.variables["df_list"] = df_codeList
    return df_codeList #, rtn_df, rtn_obj
    logger.warning(f'INFO: CHECK {config.variables["df_list"][["Row","Sheet","Key"]]}') #.iloc[0]["Key"]
    logger.error(f'ERROR: {codeList}')  #  | {rtn_obj[0]}
    return codeList #, [df] * n, [objVar] * n
@validate_args
@type_check
def switch(case_table_name:str):  #, df, objVar
    """case is a table of conditions and actions
    Example: 
        codeList: {{list_of_actions}}
        codeList: openPages, downloadFile, wait:5, incrementalUpdate
        iterate: URL_pages , codeList: {{URL_pages:RunProcess}}
    """
    from prefect import get_run_logger
    import pandas as pd
    import config
    logger = get_run_logger()
    df = config.variables['optimusDF']
    table_name = case_table_name
    if table_name in df[(df.Type == 'table')]['Object'].dropna().values.tolist(): 
        objTableSet = df[(df.Type == 'table') & ((df.Object == table_name))]
        first_row = objTableSet.iloc[0] #grab the first row to check if its the header
        if set(['labels', 'conditions', 'actions']).issubset(first_row):
            objTableSet.columns = first_row #set the header row as the df header
            objTableSet = objTableSet[1:] #take the data less the header row
        else:
            new_column_names = ['Type', 'Object' 'labels', 'conditions', 'actions'] # + list(df.columns[3:])
            objTableSet.columns = new_column_names
    elif table_name in config.variables.keys():    # HANDLE dataframe objects
        if isinstance(config.variables[table_name], pd.DataFrame):
            objTableSet = config.variables[table_name]
            logger.debug(f'Table columns: {objTableSet.columns.tolist()}')            
            configVariableTable = True
    conditionsLists = objTableSet['conditions'].values.tolist()
    actionsList = objTableSet['actions'].values.tolist()
    i=0
    for condition in conditionsLists:
        if eval(condition):
            return [actionsList[i]]
        i=i+1
    return []
