"""
An always available standard library with often needed keywords.
Image processing
cropImage(files, savefiles, left, top, right, bottom, boolPercentage)
cropImage(files, savefiles, left, top, right, bottom, boolPercentage, df)
start_recording(file_to_save:str = "recording.mp4", fps:int = 10) -> None
pause_recording()
resume_recording()
stop_recording()
resize(image_file, new_size, encode_format='PNG')
"""
from core.lexicon import validate_args, type_check
from pathlib import Path, PureWindowsPath
from PIL import Image
def cropImage(files, savefiles, left, top, right, bottom, boolPercentage):
    i = 0
    for file in files:
        im = Image.open(file)
        width, height = im.size
        print('      ','File:', Path(file).name, ' Size:', im.size)
        if boolPercentage == True:
            if left is None: left = 0
            if top is None: top = 0        
            if right is None: right = 1
            if bottom is None: bottom = 1        
            left_ = int(left) * width
            top_ = int(top) * height
            right_ = int(right) * width
            bottom_ = int(bottom) * height
        else:
            if left is None: left = 0
            if top is None: top = 0        
            if right is None: right = width
            if bottom is None: bottom = height        
            left_ = int(left)
            top_ = int(top)
            right_ = int(right)
            bottom_ = int(bottom)
        im1 = im.crop((left_, top_, right_, bottom_))
        im1.save(savefiles[i])
        i = i + 1
    return
@validate_args
@type_check
def cropImage(files, savefiles, left, top, right, bottom, boolPercentage, df):
    """Crop image files.
    Example: 
        cropImage: {{files}} , {{save files}} , {{left}} , {{top}} , {{right}} , {{bottom}} , {{values in percentage: True / False}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    files = [updateConstants(df, s) for s in dfObjList(df, files)]
    savefiles = [updateConstants(df, s) for s in dfObjList(df, savefiles)]        
    cropImage(files, savefiles, left, top, right, bottom, boolPercentage)
import pyscreenrec
recorder = pyscreenrec.ScreenRecorder()
@validate_args
@type_check
def start_recording(file_to_save:str = "recording.mp4", fps:int = 10) -> None:
    """Screen recording. Default file_to_save = "recording.mp4", fps = 10 frames per sec
    'recording.mp4' is the name of the output video file, may also contain full path like 'C:/Users/<user>/Videos/video.mp4'
    the second parameter(10) is the FPS. You can specify the FPS for the screen recording using the second parameter. It must not be greater than 60.
    Requires pyscreeze, opencv, pillow
    Example: 
        start_recording: {{file_to_save}} , {{fps}}
    """
    print(f'Record start: {file_to_save}')
    recorder.start_recording(file_to_save, 10) 
@validate_args
@type_check
def pause_recording():
    """Screen recording pause.
    Example: 
        pause_recording:
    """
    print('pause')
    recorder.pause_recording()
@validate_args
@type_check
def resume_recording():
    """Screen recording resume.
    Example: 
        resume_recording:
    """
    print('resume')
    recorder.resume_recording()
@validate_args
@type_check
def stop_recording():
    """Screen recording stop.
    Example: 
        stop_recording:
    """
    print('Record stop')
    recorder.stop_recording()
def resize(image_file, new_size, encode_format='PNG'):
    """ Resize image
    """
    from io import BytesIO
    from pathlib import Path
    from PIL import Image, UnidentifiedImageError
    im = Image.open(image_file)
    new_im = im.resize(new_size, Image.Resampling.LANCZOS)    
    with BytesIO() as buffer:
        new_im.save(buffer, format=encode_format)
        data = buffer.getvalue()
    return data
'''
import asyncio
async def screenRecord(stop_event, saveVideoFile:str = "output.avi", fps:int = 12.0, record_seconds:int = 10) -> None:
    """Screen recording using OpenCV and pyautogui. Default save as output.avi in scripts folder.
    Example: 
        screenRecord: {{saveVideoFile=output.avi}} , {{frames per sec=12.0}} , {{record_seconds=10}}
    """
    import cv2
    import numpy as np
    import pyautogui
    SCREEN_SIZE = tuple(pyautogui.size())
    fourcc = cv2.VideoWriter_fourcc(*"XVID")
    out = cv2.VideoWriter(saveVideoFile, fourcc, fps, (SCREEN_SIZE))
    while not stop_event.is_set():
        img = pyautogui.screenshot()
        frame = np.array(img)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        out.write(frame)
        await asyncio.sleep(1 / fps)
    out.release()
    cv2.destroyAllWindows()
@validate_args
@type_check
async def main():
    """Screen recording using OpenCV and pyautogui. Default save as output.avi in scripts folder.
    Example: 
        screenRecord: {{saveVideoFile=output.avi}} , {{frames per sec=12.0}} , {{record_seconds=10}}
    """
    stop_event = asyncio.Event()
    task = asyncio.create_task(record_screen(stop_event))
    print("Running other Python code...")
    await asyncio.sleep(5)
    stop_event.set()
    print("Event set")
'''
