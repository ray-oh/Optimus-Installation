__version__ = '2.1.6'
__annotations__ = """
Major enhancements:
Launcher
- New tab layout - Optimus Core, Settings, Agents, Upgrade.  Flexible adjustment via studio.xlsx
- Run Script - new features: debug/break point
- Task Schedule - create, delete, run, query script schedules via windows task scheduler
- Notifications - via telegram, Recordings - video recordings, Services - Agent and Orion schedules
Refactored: 
- studio.sub_windows - for all sub windows e.g. task scheduling, notifications
- libraries.Prefect
- core.lexicon - bypass argument string parser, to use libraries functions natively in python
- _main_ - arguments - handle arguments from runrpa.bat.  Stored in config.constants['arg'].  Accessed in script via \{\{arg}}
"""
__date__ = '2023-12-27'
__updated__ = '2024-01-24'
__author__ = 'GitHub: ray-oh'
__description__ = """
RPA solution with Excel front end
designed to make automation easy for beginners.
Automate more with less, using
Excel automation script templates.
"""