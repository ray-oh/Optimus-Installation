from __version__ import __version__,__description__,__date__,__updated__,__author__
from studio.launcher import launcher_window
launcher_window(__version__,__description__,__date__,__updated__,__author__)