#!/usr/bin/env python
import config,logging
logging.basicConfig(filename=config.SRCLOG,level=logging.INFO,format='%(asctime)s - %(name)s - %(threadName)s -  %(levelname)s - %(message)s')
logger=logging.getLogger(__name__)