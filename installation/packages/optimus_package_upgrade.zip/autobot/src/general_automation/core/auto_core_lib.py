# Standard library imports
import pandas as pd
from pathlib import Path, PureWindowsPath

# Third-party imports
from prefect import task, flow, get_run_logger, context

# Local application/library specific imports
import config
from config import MEMORYPATH, log_space, variables
#from auto_helper_lib import updateConstants
#from auto_utility_PDF_Image import *
#from auto_utility_browser import *
#from auto_utility_parsers import *

def runCodelist(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):
    """ df_list is a dataframe that is like the codeList but with additional information columns, like Type, Object, Key, Value ...
    """    
    logger = get_run_logger()
    #logger.info(f"RunCodeList checking ...:  {codeList} ")
    if config.variables['debug_log']: logger.debug(f'INFO: runCodelist #codeList {len(codeList)} | #df_list: {len(df_list)}')
    if len(df_list)==0 and len(codeList)>0:
        df_list = pd.DataFrame(columns=['Type', 'Object', 'Key', 'Value', 'Comments', 'Row', 'Excel', 'Sheet'])
        df_list.loc[0] = ['list', 'main', 'Deploy:', 'Value', 'Comments', 'NA', 'NA', 'NA']
        # duplicate the row n times
        n = len(codeList)
        df_list = pd.concat([df_list]*n, ignore_index=True)

    #logger.info(f'WARNING:RunCodeList {len(codeList)} | {codeList}') #, '|', df_list['Key'].tolist())
    #logger.info(f"ERROR: RunDFList {len(df_list)} | {df_list['Key'].tolist()}") ##, '|', df_list['Key'].tolist())
    #logger.info(f"ERROR: ################################") #, '|', df_list['Key'].tolist())
    if run_code_until != '':
        codeList = codeList[:int(run_code_until)]
        print('******************************ERROR !!!!! **************************************')
        logger.warning(f"{log_space}WARNING *** codeList sliced ****', codeList = {codeList}")
    queueSteps(df, codeList, run_code_until, objVar, file, df_list)
    return

#from job_monitor import touchFile

def queueSteps(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):
    """
    Manage the queue of steps in the code step list.  Inserting additional steps for block codes and removing run steps.
    """
    logger = get_run_logger()

    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    #DFlist = [df] * len(df_list)
    #objVarList = [objVar] * len(df_list)
    i=0

    codeList_prev = None
    df_list_prev = None            
    DFlist_prev = None
    objVarList_prev = None

    while len(codeList) > 0: # len(df_list) > 0:
        i += 1

        df = DFlist[0]
        x = codeList[0]
        objVar = objVarList[0]
        x_df_list = df_list.iloc[:1].copy()
        config.variables['df_list'] = x_df_list

        # Track previous values
        codeList_prev = codeList[0]
        df_list_prev = df_list.iloc[:1]            
        DFlist_prev = DFlist[0]
        objVarList_prev = objVarList[0]

        # checking
        #logger.warning(f'INFO: CHECK') #.iloc[0]["Key"] # {config.variables["df_list"]}
        #print(config.variables["df_list"][['Excel','Sheet','Row','Object','Key']])        

        # touch process file - to indicate process still running
        state='process'
        '''touchFile(rf"{MEMORYPATH}\{state}\{Path(file).stem}.txt")
        '''

        prefix = x.split(':',1)
        codeID = prefix[0].strip()
        if not codeID in ['### StartFlow','### EndFlow','rem','_iterationCount']:  #.startswith('_iterationCount') 
            if config.variables['debug_log']: logger.debug(f'{"INFO: TRUE" if x==x_df_list.iloc[0]["Key"] else "ERROR: FALSE " + x + "<>" + x_df_list.iloc[0]["Key"]}|{codeID}: {i} of code {len(codeList)}/df {len(df_list)}') #.iloc[0]["Key"]
            #!#! print('codeList', codeList, '| prev:', codeList_prev)
            #!#! print('df_list', df_list, '| prev:', df_list_prev)
            if not x==x_df_list.iloc[0]["Key"] and False:
                #if (len(codeList) - len(df_list)) == 1:
                n = len(codeList) - len(df_list)

                df_list_additional = df_list_prev
                df_list_additional.loc[df_list_additional.index[0], 'Key'] = x
                #df_list_additional.iloc[0]["Key"] = x
                #!#! print('***',df_list_additional)
                #df_list = df_list_additional + df_list
                df_list = pd.concat([df_list_additional, df_list], ignore_index=True)
                x_df_list = df_list.iloc[:1]                    
                logger.debug(f'INFO PATCHED: x= {x} |  {x_df_list.iloc[0]["Key"]} | {df_list_additional.iloc[0]["Key"]} ') 
                logger.debug(f'{"INFO PATCHED: TRUE" if x==x_df_list.iloc[0]["Key"] else "ERROR PATCHED: FALSE " + x + "<>" + x_df_list.iloc[0]["Key"]}|{codeID}: {i} of code {len(codeList)}/df {len(df_list)}') #.iloc[0]["Key"]
                #if len(df_list)==0 and len(codeList)>0:
                #    df_list = pd.DataFrame(columns=['Type', 'Object', 'Key', 'Value', 'Comments', 'Row', 'Excel', 'Sheet'])
                #    df_list.loc[0] = ['list', 'main', 'Deploy:', 'Value', 'Comments', 'NA', 'NA', 'NA']
                #    # duplicate the row n times
                #    n = len(codeList)
                #    df_list = pd.concat([df_list]*n, ignore_index=True)
                #else:
                #    exit()

        if isinstance(x, list):
            logger.error('ERROR')
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
            #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y

        else:
            #try_catch(runCode(df, x, objVar), x)
            #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

            #print('DEBUG .......', config.variables['debug'])

            # DEBUG case - Step or Continue program
            interactive_result = ''
            if not 'Auto save activate' in config.variables: config.variables['Auto save activate'] = False

            if not 'record' in config.variables: config.variables['record'] = False
            if config.variables['record']:
                button_color = ('white','red')
            else:
                button_color = ('white','#283b5b')

            if not 'recorded_df_list' in config.variables:
                completed_codelist = []
            else:
                completed_codelist = config.variables['recorded_df_list']['Key'].to_list()

            if config.variables['debug']:
                if 'break point' in config.variables:
                    break_point = config.variables['break point']
                else:
                    break_point = ''
                #logger.debug(f'##################### Break: {break_point} |  {x}')
                if break_point.lower() in x.lower():
                    # Pause Program
                    from studio.launcher import popup, sub_window
                    import FreeSimpleGUI as sg
                    if not '_iterationCount' in x:

                        from config import variables, constants
                        variableType = ['Script constants', 'Script variables', 'Optimus constants', 'Optimus variables', 'Optimus globals', 'Optimus locals']
                        variableList = df[(df.Object == 'constants')]['Key'].values.tolist()
                        #variableList = variableList + df[(df.Object == 'variables')]['Key'].values.tolist()
                        #variableList = variableList + list(constants.keys())
                        #variableList = variableList + list(variables.keys())
                        
                        window_buttons_layout=[[sg.Text('Interactive Run'),sg.Button('Step', key='INTERACTIVE - Step'), 
                            sg.Button('Continue', key='INTERACTIVE - Continue'),sg.Input(break_point, size=(30, 1), key="INTERACTIVE -BREAK POINT"),
                            sg.VSeparator(), sg.Button('Terminate', key='INTERACTIVE - Terminate')],
                            [sg.Button('Record', button_color=button_color, key='INTERACTIVE - Record'), sg.Button('Save', key='INTERACTIVE - Save'),
                            sg.Checkbox("auto save", default=config.variables['Auto save activate'], enable_events=True, key='INTERACTIVE - Auto Save'), 
                            sg.VSeparator(),sg.Button('Edit', key='INTERACTIVE - Edit'),sg.Button('Studio', key='INTERACTIVE - Studio')],
                            [sg.Text('Variables'),
                             sg.Combo(variableType, size=(20, 1), default_value=variableType[0], key='INTERACTIVE - VariableType', readonly=True, enable_events=True),                             
                             sg.Combo(variableList, size=(20, 1), default_value=variableList[0], key='INTERACTIVE - Variablelist', readonly=True, enable_events=True),
                             sg.Input('', size=(15, 1), key="INTERACTIVE -Variables"),sg.Button('Resolve', key='INTERACTIVE - Resolve')],
                            [sg.Text('Next'), sg.Combo(codeList, size=(30, 1), default_value=codeList[0], key='INTERACTIVE - Codelist', readonly=True),
                            sg.Text('Completed'), sg.Combo(completed_codelist, size=(30, 1), default_value=completed_codelist[-1] if completed_codelist else '', key='INTERACTIVE - completed_Codelist', readonly=True)]]
                        interactive_result = sub_window(program=f'{x}', title='INTERACTIVE MODE - STEP, CONTINUE, MODFIY COMMAND', run=False, disabled=False, 
                                    message = f'[{x_df_list.iloc[0]["Object"]}] Enter/modify command:', variable= [codeID,df],
                                    replace_window_buttons=True, location=config.variables['window position'],
                                    window_buttons=window_buttons_layout
                                    )
            if not interactive_result == '':
                x = interactive_result # replace run step with interactive command  
                #x_df_list.iloc[0]["Key"] = x    # gives copy error
                x_df_list.iloc[0, x_df_list.columns.get_loc('Key')] = interactive_result   # ensure recording is with correct interactive step              

            ################################## RUN CODE #################################################
            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar, x_df_list)

            #Store a dataframe of run code and save to sheet "recorded"
            x_df_list.loc[0, 'Key'] = x   #x_df_list.iloc[0, 'Key'] = x
            if not 'recorded_df_list' in config.variables:
                config.variables['recorded_df_list'] = x_df_list
                #logger.error(f'first: {x_df_list}')
            else:
                config.variables['recorded_df_list'] = pd.concat([config.variables['recorded_df_list'], x_df_list.head(1)], ignore_index=True, sort=False)    # append
                #logger.error(f"append {config.variables['recorded_df_list']['Key'].to_list()}")
                #logger.error(f'append {x_df_list}')                
                #logger.error(f'append first row {x_df_list.head(1)}')

            # record True: insert step
            if not config.variables['record']:
                # Remove processed values
                codeList.pop(0)
                #if not codeID in ('_iterationCount'):   # 
                df_list = df_list.iloc[1:]            
                DFlist.pop(0)
                objVarList.pop(0)
            else:
                # Record True: insert step
                pass

            if isinstance(additionalCodeList, pd.DataFrame):

                #!#!logger.debug(f'{log_space}RUN CASE: INFO:Queue {len(additionalCodeList)} items to codelist') #, '|', df_list['Key'].tolist()) | {additionalCodeList}
                #print(additionalCodeList[['Excel','Sheet','Row','Object','Key']])
                #logger.error(f"ERROR: {len(additionalDFlist)} | {additionalDFlist['Key'].tolist()}") ##, '|', df_list['Key'].tolist())
                #logger.error(f"ERROR: ++++++++++++++++++++++++++++++++++++++++") #, '|', df_list['Key'].tolist())

                codeList = additionalCodeList["Key"].tolist() + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
                df_list = pd.concat([additionalCodeList, df_list], ignore_index=True, sort=False)    # append

            elif not (additionalCodeList == None or additionalCodeList == []):
                #!#!logger.debug(f"RUN CASE: additional {len(additionalCodeList)} CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")
                #logger.debug(f'codeList {codeList}')

                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
                #additional_df_list = pd.DataFrame(columns=['Type', 'Object', 'Key', 'Value', 'Comments', 'Row', 'Excel', 'Sheet'])
                #additional_df_list.loc[0] = ['list', 'main', 'Deploy:', 'Value', 'Comments', 'NA', 'NA', 'NA']
                additional_df_list = df_list_prev
                # duplicate the row n times
                n = len(additionalCodeList)
                additional_df_list = pd.concat([additional_df_list]*n, ignore_index=True)
                additional_df_list['Key'] = additionalCodeList
                df_list = pd.concat([additional_df_list, df_list], ignore_index=True, sort=False)    # append

                #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")
            else:
                #!#!logger.debug(f"RUN CASE: additional codelist NONE")
                pass

            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
            #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
            #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
 
        if '### StartFlow' in x and False:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsFlow.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]

            # codeList.pop(0)
            # DFlist.pop(0)
            # objVarList.pop(0)

        elif '### StartTask' in x and False:
            index = codeList.index('### EndTask')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsTask.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]

            # codeList.pop(0)
            # DFlist.pop(0)
            # objVarList.pop(0)

        elif True:
            pass
 
    return

@flow(name="Test Flow")
def queueStepsFlow(df, codeList, run_code_until, objVar): #(df: pd.DataFrame, codeList: list, run_code_until: str = '', objVar: str = ''):
    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    logger = get_run_logger()
    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]

        #logger = get_run_logger()
        #logger.info(f">>>>>runCodelist ...:  {x} {df.__len__()} {objVar}")

        if x in ['### StartFlow']:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])

        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        #prefix = x.split(':',1)
        #logger.info(f">>>>>runCodelist ... popped :  {x} {df.__len__()} {objVar}")
         
        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
            #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y
        else:
            #try_catch(runCode(df, x, objVar), x)
            #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)



            #logger = get_run_logger()
            if not (additionalCodeList == None or additionalCodeList == []):
                #logger.info(f"additional CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")

                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList

                #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
            #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
            #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
    return

@task(name="Test Flow")
def queueStepsTask(df, codeList, run_code_until, objVar): #(df: pd.DataFrame, codeList: list, run_code_until: str = '', objVar: str = ''):
    logger = get_run_logger()

    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)

    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]
        #logger = get_run_logger()
        #logger.info(f">>>>>runCodelist ...:  {x} {df.__len__()} {objVar}")

        if x in ['### StartFlow']:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])

        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        #prefix = x.split(':',1)
        #logger.info(f">>>>>runCodelist ... popped :  {x} {df.__len__()} {objVar}")

        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
            #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y
        else:
            #try_catch(runCode(df, x, objVar), x)
            #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)

            #logger = get_run_logger()
            if not (additionalCodeList == None or additionalCodeList == []):
                #logger.info(f"additional CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")

                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList

                #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
            #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
            #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
    return


config.variables['Excel']=''
config.variables['Sheet']=''
config.variables['Row']=''
config.variables['Object']=''
config.variables['Key']=''

def runCode(df, code, objVar='', df_list:pd.DataFrame = None):
    from core.core import updateConstants
    logger = get_run_logger()
    #logger.info(f".... start runcode .... code:{code} objVar:{objVar} df:{df.shape}")
    from pathlib import Path, PureWindowsPath    
    prefix = code.split(':',1)
    codeID = prefix[0].strip()

    config.variables['codeID']=codeID
    if not df_list.empty: #!= df_list.empty:
        config.variables['Excel']=df_list.iloc[0]['Excel']
        config.variables['Sheet']=df_list.iloc[0]['Sheet']
        config.variables['Row']=df_list.iloc[0]['Row']
        config.variables['Object']=df_list.iloc[0]['Object']
        config.variables['Key']=df_list.iloc[0]['Key']                

    if codeID == 'rem' or codeID in ['### StartFlow','### EndFlow']: return [], [], []                     # remarks - do nothing
    codeBeforeTemplateUpdate = code
    variables['codeBeforeTemplateUpdate'] = codeBeforeTemplateUpdate
    #logg('### runCode before replacing templated values ###:', CODE = code, OBJVAR = objVar) 
    code = updateConstants(df, code.strip())  # replace templated values
    #logg('### runCode after update template values ###:', CODE = code, OBJVAR = objVar)  
    prefix = code.split(':',1)
    codeID = prefix[0].strip()
    if len(prefix) > 1: 
        codeValue = prefix[1].rstrip() 
    else: 
        codeValue = None

    #run_count = context.get_run_context().task_run.run_count #context.get("task_run_count")
    #logger.info("%s. TaskRun", run_count)
    from config import FLOW_COUNT
    run_count = FLOW_COUNT

    #print(f'RUN {run_count} STEP | {codeBeforeTemplateUpdate}')  # prints code after templated values update

    if not codeBeforeTemplateUpdate.startswith('_iterationCount'): #not '_iterationCount' in codeBeforeTemplateUpdate:
        #{run_count} 
        logger.info(f"RUN STEP | {codeBeforeTemplateUpdate} | {codeBeforeTemplateUpdate==config.variables['Key']}")
    #logger.debug(f"{log_space}EX:{config.variables['Excel']} | SH:{config.variables['Sheet']} | R{config.variables['Row']} | Obj:{config.variables['Object']}")    
    if codeBeforeTemplateUpdate.strip() != code.strip():
        #print('       updated:', code)
        logger.debug(f"{log_space}updated:{code}")
    if False: pass
        #elif codeID in commands_df['commands'].dropna().values.tolist():           #run Block of Code
        #pass
    else:
        import re
        flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', code)
        #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
        #return _otherRunCode.with_options(name=flowname)(df, code, codeID, codeValue, objVar)
        #from core.auto_core_lib_helper import _otherRunCode
        return _otherRunCode(df, code, codeID, codeValue, objVar, df_list)

    #return [], [], []




def _otherRunCode(df, code, codeID, codeValue, objVar, df_list:pd.DataFrame = None):

    # code for handling block codes - extract parameters if that is defined e.g. command(parameter)
    # parameters are in json string format e.g. {"name":"value","name":"value"}
    from prefect import get_run_logger
    from core.Keywords import Keywords
    k = Keywords()
    logger = get_run_logger()

    import re
    param = re.search('\((.*?)\)', code, re.IGNORECASE)
    ##print("param:", param, "| code:", code)
    if param and code.strip()[-1:]==')':               # if parameters exist
        ##print("param exist")
        parameters = param.group(1).strip()
        command = re.search('(.*?)\(', code, re.IGNORECASE)        
        code = command.group(1).strip()
        ##print(code, parameters)

        import json
        #jsonString = '{"file":"C:\\Users\\roh\\Downloads\\d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
        #jsonString = '{"file": "C:/Users/roh/Downloads/d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
        variables.update(json.loads(parameters))
        print(variables)
    ##print("No param")

    #!#!logger.debug(f'codeID: {codeID} | codeValue: {codeValue}')
    if False: pass
    elif k.present(codeID.lower()) and ":" in code:
        """
        If codeID / keyword matches function in module, run the function -> [codelist], [dflist], [objvarlist]
            keywords.init(): check if libraries and modules are loaded, if not load them
                libaries - load core.  And load user defined if exist in script
                validate keys to see if duplicate
            keywords.present(key): keywords.run_codeStr(codeValue) -> bool
                keywords.run(key, module, arguments)
                    keywords.parse_codeStr(codeValue) -> dict of arguments, key, module
                    keywords.arguments(key)
                    keywords.module(key)
                    keywords.validate(codeValue, arguments)
        """
        ##print(f'================= Keyword: {codeID.lower()}')

        import config
        config.variables['optimusDF']=df
        config.variables['optimusobjVar']=objVar
        ##print("xxxxxxxxxxxxxxxxxxxxxxxxxxx Test", codeID.lower(), "|", codeValue)
        sub_code = k.run(codeID.lower(), codeValue) #, df=df, objVar=objVar)

        ##print(f'================= Result for {codeID.lower()}: {str(sub_code)}')

        if isinstance(sub_code, pd.DataFrame):
            #!print('case 1', 'Dataframe')
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

        elif sub_code == None  or sub_code == []: 
            #!print('case 2', 'None')
            return [], [], []

        elif isinstance(sub_code, list):
            #!print('case 3', 'Others')
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            #!# print('sub code', sub_code, len(sub_code))
            #!# print('df',df.head(5))
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)
        
        else:
            return [], [], []
        
    elif codeID in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
        #!print('case 4', 'Match object list in script')
        #print(f'================= Keyword is a script function: {codeID.lower()}')
        # keyword is a function in the script
        import config
        config.variables['optimusDF']=df

        if not codeValue == None:
            config.variables[codeID] = codeValue.split(' , ')
            #!#!logger.warning (f'RUN function codeID {codeID}')
            #!#!logger.warning(f'RUN function {config.variables[codeID]}')
            #logger.warning(df_list)
            #!#!for i, item in enumerate(config.variables[codeID]): 
            #!#!    logger.warning(config.variables[codeID][i])

        from libraries.Flows import _runFunction #isCodeList
        sub_code = _runFunction(codeID, codeValue)          #run Block of Code

        if isinstance(sub_code, pd.DataFrame):
            #!print('case 5', 'Is dataframe')
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

        return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

    elif codeID.lower() in '[Arguments]'.lower():
        import config
        dfObject = df_list.iloc[0, df_list.columns.get_loc('Object')]
        #!#!logger.error(f'Object: {dfObject} Arguments: {codeValue.split(" , ")}')        
        #!#!logger.error(f'Value: {config.variables[dfObject]}')
        for i, item in enumerate(codeValue.split(' , ')):
            key = item.strip()
            #logger.debug(log_space + 'Object: ' + dfObject + ' Key: ' + key + ' Value: ' + config.variables[dfObject][i])
            if ' = ' in key:
                key = item.split(' = ')[0].strip()
                value = item.split(' = ')[1].strip()
            else:
                #key = key
                value = config.variables[dfObject][i]
            config.variables[key]=value
            logger.debug(log_space + dfObject + ': ' + key + ' = ' + config.variables[key])
            #config.variables[key] = item.split(' = ')[1].strip()
            """
            if i < len(valueLists):
                if ' = ' in valueLists[i]:
                    key = valueLists[i].split(' = ')[0].strip()
                    config.variables[key] = valueLists[i].split(' = ')[1].strip()
                else:
                    config.variables[key] = valueLists[i]                    
            else:
                if ' = ' in item:
                    key = item.split(' = ')[0].strip()
                    config.variables[key] = item.split(' = ')[1].strip()
                else:
                    logger.error(log_space + 'Argument index not matching function parameters')
                    raise ValueError(f"Raise Error: Argument index not matching function definition")
            """
            #i=i+1

        pass

    elif codeID.lower() in ['### StartTask'.lower(), '### EndTask'.lower(), '### StartFlow'.lower(), '### EndFlow'.lower()]:  pass

    else:
        #print('~~~~~~~~~~~~~~~ Keyword invalid')
        from prefect import get_run_logger
        #from config import log_space
        logger.error(f'{log_space}Keyword invalid: {code}')

    return [], [], []
