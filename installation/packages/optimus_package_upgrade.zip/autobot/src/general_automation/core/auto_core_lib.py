_E='Test Flow'
_D='[^a-zA-Z0-9 \n\\.]'
_C=None
_B='### EndFlow'
_A='### StartFlow'
from prefect import task,flow,get_run_logger,context
import config
from config import MEMORYPATH
from pathlib import Path,PureWindowsPath
from auto_helper_lib import *
from auto_utility_PDF_Image import *
from auto_utility_browser import *
from auto_utility_parsers import *
def runCodelist(df,codeList,run_code_until='',objVar='',file=''):
	logger=get_run_logger()
	if run_code_until!='':codeList=codeList[:int(run_code_until)];print('******************************ERROR !!!!! **************************************');logger.debug(f"{log_space}DEBUG *** codeList sliced ****', codeList = {codeList}, level = 'WARNING'")
	queueSteps(df,codeList,run_code_until,objVar,file);return
from job_monitor import touchFile
def queueSteps(df,codeList,run_code_until='',objVar='',file=''):
	DFlist=[df]*len(codeList);objVarList=[objVar]*len(codeList);logger=get_run_logger()
	while len(codeList)>0:
		x=codeList[0];df=DFlist[0];objVar=objVarList[0]
		if _A in x:index=codeList.index(_B);print(index,len(codeList),codeList);print(codeList[:index+1]);print(codeList[index+1:]);print(x.split(':')[1].strip());queueStepsFlow.with_options(name=x.split(':')[1].strip())(df,codeList[:index+1],run_code_until,objVar);codeList=codeList[index+1:];DFlist=DFlist[index+1:];objVarList=objVarList[index+1:]
		elif'### StartTask'in x:index=codeList.index('### EndTask');print(index,len(codeList),codeList);print(codeList[:index+1]);print(codeList[index+1:]);print(x.split(':')[1].strip());queueStepsTask.with_options(name=x.split(':')[1].strip())(df,codeList[:index+1],run_code_until,objVar);codeList=codeList[index+1:];DFlist=DFlist[index+1:];objVarList=objVarList[index+1:]
		else:
			codeList.pop(0);DFlist.pop(0);objVarList.pop(0);state='process'
			if isinstance(x,list):logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
			else:
				additionalCodeList,additionalDFlist,additionalobjVarList=runCode(df,x,objVar)
				if not(additionalCodeList==_C or additionalCodeList==[]):codeList=additionalCodeList+codeList;DFlist=additionalDFlist+DFlist;objVarList=additionalobjVarList+objVarList
				import re;flowname=re.sub(_D,'_',x)
	return
@flow(name=_E)
def queueStepsFlow(df,codeList,run_code_until,objVar):
	DFlist=[df]*len(codeList);objVarList=[objVar]*len(codeList);logger=get_run_logger()
	while len(codeList)>0:
		x=codeList[0];df=DFlist[0];objVar=objVarList[0]
		if x in[_A]:index=codeList.index(_B);print(index,len(codeList),codeList);print(codeList[:index+1]);print(codeList[index+1:])
		codeList.pop(0);DFlist.pop(0);objVarList.pop(0)
		if isinstance(x,list):logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
		else:
			additionalCodeList,additionalDFlist,additionalobjVarList=runCode(df,x,objVar)
			if not(additionalCodeList==_C or additionalCodeList==[]):codeList=additionalCodeList+codeList;DFlist=additionalDFlist+DFlist;objVarList=additionalobjVarList+objVarList
			import re;flowname=re.sub(_D,'_',x)
	return
@task(name=_E)
def queueStepsTask(df,codeList,run_code_until,objVar):
	DFlist=[df]*len(codeList);objVarList=[objVar]*len(codeList);logger=get_run_logger()
	while len(codeList)>0:
		x=codeList[0];df=DFlist[0];objVar=objVarList[0]
		if x in[_A]:index=codeList.index(_B);print(index,len(codeList),codeList);print(codeList[:index+1]);print(codeList[index+1:])
		codeList.pop(0);DFlist.pop(0);objVarList.pop(0)
		if isinstance(x,list):logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
		else:
			additionalCodeList,additionalDFlist,additionalobjVarList=runCode(df,x,objVar)
			if not(additionalCodeList==_C or additionalCodeList==[]):codeList=additionalCodeList+codeList;DFlist=additionalDFlist+DFlist;objVarList=additionalobjVarList+objVarList
			import re;flowname=re.sub(_D,'_',x)
	return
def runCode(df,code,objVar=''):
	logger=get_run_logger();from pathlib import Path,PureWindowsPath;prefix=code.split(':',1);codeID=prefix[0].strip()
	if codeID=='rem'or codeID in[_A,_B]:return[],[],[]
	codeBeforeTemplateUpdate=code;variables['codeBeforeTemplateUpdate']=codeBeforeTemplateUpdate;code=updateConstants(df,code.strip());prefix=code.split(':',1);codeID=prefix[0].strip()
	if len(prefix)>1:codeValue=prefix[1].rstrip()
	else:codeValue=_C
	from config import FLOW_COUNT;run_count=FLOW_COUNT
	if not'iterationCount'in codeBeforeTemplateUpdate:logger.info(f"RUN {run_count} STEP | {codeBeforeTemplateUpdate}")
	if codeBeforeTemplateUpdate.strip()!=code.strip():logger.debug(f"{log_space}updated:{code}")
	if False:0
	else:flowname=re.sub(_D,'_',code);from core.auto_core_lib_helper import _otherRunCode;return _otherRunCode(df,code,codeID,codeValue,objVar)
	return[],[],[]