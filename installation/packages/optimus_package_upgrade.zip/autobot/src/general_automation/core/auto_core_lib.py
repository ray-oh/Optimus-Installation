import pandas as pd
from pathlib import Path, PureWindowsPath
from prefect import task, flow, get_run_logger, context
import config
from config import MEMORYPATH, log_space, variables
def runCodelist(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):
        
    logger = get_run_logger()
    if config.variables['debug_log']: logger.debug(f'INFO: runCodelist 
    if len(df_list)==0 and len(codeList)>0:
        df_list = pd.DataFrame(columns=['Type', 'Object', 'Key', 'Value', 'Comments', 'Row', 'Excel', 'Sheet'])
        df_list.loc[0] = ['list', 'main', 'Deploy:', 'Value', 'Comments', 'NA', 'NA', 'NA']
        n = len(codeList)
        df_list = pd.concat([df_list]*n, ignore_index=True)
    if run_code_until != '':
        codeList = codeList[:int(run_code_until)]
        print('******************************ERROR !!!!! **************************************')
        logger.warning(f"{log_space}WARNING *** codeList sliced ****', codeList = {codeList}")
    queueSteps(df, codeList, run_code_until, objVar, file, df_list)
    return
def queueSteps(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):
    
    logger = get_run_logger()
    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    i=0
    codeList_prev = None
    df_list_prev = None            
    DFlist_prev = None
    objVarList_prev = None
    while len(codeList) > 0: 
        i += 1
        df = DFlist[0]
        x = codeList[0]
        objVar = objVarList[0]
        x_df_list = df_list.iloc[:1].copy()
        config.variables['df_list'] = x_df_list
        codeList_prev = codeList[0]
        df_list_prev = df_list.iloc[:1]            
        DFlist_prev = DFlist[0]
        objVarList_prev = objVarList[0]
        state='process'
        
        prefix = x.split(':',1)
        codeID = prefix[0].strip()
        if not codeID in ['
            if config.variables['debug_log']: logger.debug(f'{"INFO: TRUE" if x==x_df_list.iloc[0]["Key"] else "ERROR: FALSE " + x + "<>" + x_df_list.iloc[0]["Key"]}|{codeID}: {i} of code {len(codeList)}/df {len(df_list)}') 
            if not x==x_df_list.iloc[0]["Key"] and False:
                n = len(codeList) - len(df_list)
                df_list_additional = df_list_prev
                df_list_additional.loc[df_list_additional.index[0], 'Key'] = x
                df_list = pd.concat([df_list_additional, df_list], ignore_index=True)
                x_df_list = df_list.iloc[:1]                    
                logger.debug(f'INFO PATCHED: x= {x} |  {x_df_list.iloc[0]["Key"]} | {df_list_additional.iloc[0]["Key"]} ') 
                logger.debug(f'{"INFO PATCHED: TRUE" if x==x_df_list.iloc[0]["Key"] else "ERROR PATCHED: FALSE " + x + "<>" + x_df_list.iloc[0]["Key"]}|{codeID}: {i} of code {len(codeList)}/df {len(df_list)}') 
        if isinstance(x, list):
            logger.error('ERROR')
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
        else:
            interactive_result = ''
            if not 'Auto save activate' in config.variables: config.variables['Auto save activate'] = False
            if not 'record' in config.variables: config.variables['record'] = False
            if config.variables['record']:
                button_color = ('white','red')
            else:
                button_color = ('white','
            if not 'recorded_df_list' in config.variables:
                completed_codelist = []
            else:
                completed_codelist = config.variables['recorded_df_list']['Key'].to_list()
            if config.variables['debug']:
                if 'break point' in config.variables:
                    break_point = config.variables['break point']
                else:
                    break_point = ''
                if break_point.lower() in x.lower():
                    from studio.launcher import popup, sub_window
                    import FreeSimpleGUI as sg
                    if not '_iterationCount' in x:
                        from config import variables, constants
                        variableType = ['Script constants', 'Script variables', 'Optimus constants', 'Optimus variables', 'Optimus globals', 'Optimus locals']
                        variableList = df[(df.Object == 'constants')]['Key'].values.tolist()
                        window_buttons_layout=[[sg.Text('Interactive Run'),sg.Button('Step', key='INTERACTIVE - Step'), 
                            sg.Button('Continue', key='INTERACTIVE - Continue'),sg.Input(break_point, size=(30, 1), key="INTERACTIVE -BREAK POINT"),
                            sg.VSeparator(), sg.Button('Terminate', key='INTERACTIVE - Terminate')],
                            [sg.Button('Record', button_color=button_color, key='INTERACTIVE - Record'), sg.Button('Save', key='INTERACTIVE - Save'),
                            sg.Checkbox("auto save", default=config.variables['Auto save activate'], enable_events=True, key='INTERACTIVE - Auto Save'), 
                            sg.VSeparator(),sg.Button('Edit', key='INTERACTIVE - Edit'),sg.Button('Studio', key='INTERACTIVE - Studio')],
                            [sg.Text('Variables'),
                             sg.Combo(variableType, size=(20, 1), default_value=variableType[0], key='INTERACTIVE - VariableType', readonly=True, enable_events=True),                             
                             sg.Combo(variableList, size=(20, 1), default_value=variableList[0], key='INTERACTIVE - Variablelist', readonly=True, enable_events=True),
                             sg.Input('', size=(15, 1), key="INTERACTIVE -Variables"),sg.Button('Resolve', key='INTERACTIVE - Resolve')],
                            [sg.Text('Next'), sg.Combo(codeList, size=(30, 1), default_value=codeList[0], key='INTERACTIVE - Codelist', readonly=True),
                            sg.Text('Completed'), sg.Combo(completed_codelist, size=(30, 1), default_value=completed_codelist[-1] if completed_codelist else '', key='INTERACTIVE - completed_Codelist', readonly=True)]]
                        interactive_result = sub_window(program=f'{x}', title='INTERACTIVE MODE - STEP, CONTINUE, MODFIY COMMAND', run=False, disabled=False, 
                                    message = f'[{x_df_list.iloc[0]["Object"]}] Enter/modify command:', variable= [codeID,df],
                                    replace_window_buttons=True, location=config.variables['window position'],
                                    window_buttons=window_buttons_layout
                                    )
            if not interactive_result == '':
                x = interactive_result 
                x_df_list.iloc[0, x_df_list.columns.get_loc('Key')] = interactive_result   
            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar, x_df_list)
            x_df_list.loc[0, 'Key'] = x   
            if not 'recorded_df_list' in config.variables:
                config.variables['recorded_df_list'] = x_df_list
            else:
                config.variables['recorded_df_list'] = pd.concat([config.variables['recorded_df_list'], x_df_list.head(1)], ignore_index=True, sort=False)    
            if not config.variables['record']:
                codeList.pop(0)
                df_list = df_list.iloc[1:]            
                DFlist.pop(0)
                objVarList.pop(0)
            else:
                pass
            if isinstance(additionalCodeList, pd.DataFrame):
                codeList = additionalCodeList["Key"].tolist() + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
                df_list = pd.concat([additionalCodeList, df_list], ignore_index=True, sort=False)    
            elif not (additionalCodeList == None or additionalCodeList == []):
                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
                additional_df_list = df_list_prev
                n = len(additionalCodeList)
                additional_df_list = pd.concat([additional_df_list]*n, ignore_index=True)
                additional_df_list['Key'] = additionalCodeList
                df_list = pd.concat([additional_df_list, df_list], ignore_index=True, sort=False)    
            else:
                pass
            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
        if '
            index = codeList.index('
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsFlow.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]
        elif '
            index = codeList.index('
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsTask.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]
        elif True:
            pass
    return
@flow(name="Test Flow")
def queueStepsFlow(df, codeList, run_code_until, objVar): 
    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    logger = get_run_logger()
    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]
        if x in ['
            index = codeList.index('
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
        else:
            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)
            if not (additionalCodeList == None or additionalCodeList == []):
                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
    return
@task(name="Test Flow")
def queueStepsTask(df, codeList, run_code_until, objVar): 
    logger = get_run_logger()
    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]
        if x in ['
            index = codeList.index('
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
        else:
            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)
            if not (additionalCodeList == None or additionalCodeList == []):
                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList
            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
    return
config.variables['Excel']=''
config.variables['Sheet']=''
config.variables['Row']=''
config.variables['Object']=''
config.variables['Key']=''
def runCode(df, code, objVar='', df_list:pd.DataFrame = None):
    from core.core import updateConstants
    logger = get_run_logger()
    from pathlib import Path, PureWindowsPath    
    prefix = code.split(':',1)
    codeID = prefix[0].strip()
    config.variables['codeID']=codeID
    if not df_list.empty: 
        config.variables['Excel']=df_list.iloc[0]['Excel']
        config.variables['Sheet']=df_list.iloc[0]['Sheet']
        config.variables['Row']=df_list.iloc[0]['Row']
        config.variables['Object']=df_list.iloc[0]['Object']
        config.variables['Key']=df_list.iloc[0]['Key']                
    if codeID == 'rem' or codeID in ['
    codeBeforeTemplateUpdate = code
    variables['codeBeforeTemplateUpdate'] = codeBeforeTemplateUpdate
    code = updateConstants(df, code.strip())  
    prefix = code.split(':',1)
    codeID = prefix[0].strip()
    if len(prefix) > 1: 
        codeValue = prefix[1].rstrip() 
    else: 
        codeValue = None
    from config import FLOW_COUNT
    run_count = FLOW_COUNT
    if not codeBeforeTemplateUpdate.startswith('_iterationCount'): 
        logger.info(f"RUN STEP | {codeBeforeTemplateUpdate} | {codeBeforeTemplateUpdate==config.variables['Key']}")
    if codeBeforeTemplateUpdate.strip() != code.strip():
        logger.debug(f"{log_space}updated:{code}")
    if False: pass
    else:
        import re
        flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', code)
        return _otherRunCode(df, code, codeID, codeValue, objVar, df_list)
def _otherRunCode(df, code, codeID, codeValue, objVar, df_list:pd.DataFrame = None):
    from prefect import get_run_logger
    from core.Keywords import Keywords
    k = Keywords()
    logger = get_run_logger()
    import re
    param = re.search('\((.*?)\)', code, re.IGNORECASE)
    if param and code.strip()[-1:]==')':               
        parameters = param.group(1).strip()
        command = re.search('(.*?)\(', code, re.IGNORECASE)        
        code = command.group(1).strip()
        import json
        variables.update(json.loads(parameters))
        print(variables)
    if False: pass
    elif k.present(codeID.lower()) and ":" in code:
        
        import config
        config.variables['optimusDF']=df
        config.variables['optimusobjVar']=objVar
        sub_code = k.run(codeID.lower(), codeValue) 
        if isinstance(sub_code, pd.DataFrame):
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)
        elif sub_code == None  or sub_code == []: 
            return [], [], []
        elif isinstance(sub_code, list):
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)
        else:
            return [], [], []
    elif codeID in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
        import config
        config.variables['optimusDF']=df
        if not codeValue == None:
            config.variables[codeID] = codeValue.split(' , ')
        from libraries.Flows import _runFunction 
        sub_code = _runFunction(codeID, codeValue)          
        if isinstance(sub_code, pd.DataFrame):
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)
        return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)
    elif codeID.lower() in '[Arguments]'.lower():
        import config
        dfObject = df_list.iloc[0, df_list.columns.get_loc('Object')]
        for i, item in enumerate(codeValue.split(' , ')):
            key = item.strip()
            if ' = ' in key:
                key = item.split(' = ')[0].strip()
                value = item.split(' = ')[1].strip()
            else:
                value = config.variables[dfObject][i]
            config.variables[key]=value
            logger.debug(log_space + dfObject + ': ' + key + ' = ' + config.variables[key])
            
        pass
    elif codeID.lower() in ['
    else:
        from prefect import get_run_logger
        logger.error(f'{log_space}Keyword invalid: {code}')
    return [], [], []
