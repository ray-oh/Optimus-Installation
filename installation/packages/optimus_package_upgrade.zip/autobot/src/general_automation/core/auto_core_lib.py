_E='Test Flow'
_D='[^a-zA-Z0-9 \n\\.]'
_C=None
_B='### EndFlow'
_A='### StartFlow'
from prefect import task,flow,get_run_logger,context
import config
from config import MEMORYPATH,log_space,variables
from pathlib import Path,PureWindowsPath
from auto_helper_lib import updateConstants
def runCodelist(df,codeList,run_code_until='',objVar='',file=''):
	B=run_code_until;A=codeList;C=get_run_logger()
	if B!='':A=A[:int(B)];print('******************************ERROR !!!!! **************************************');C.debug(f"{log_space}DEBUG *** codeList sliced ****', codeList = {A}, level = 'WARNING'")
	queueSteps(df,A,B,objVar,file);return
from job_monitor import touchFile
def queueSteps(df,codeList,run_code_until='',objVar='',file=''):
	I=run_code_until;G=objVar;F=df;A=codeList;D=[F]*len(A);E=[G]*len(A);J=get_run_logger()
	while len(A)>0:
		C=A[0];F=D[0];G=E[0]
		if _A in C:B=A.index(_B);print(B,len(A),A);print(A[:B+1]);print(A[B+1:]);print(C.split(':')[1].strip());queueStepsFlow.with_options(name=C.split(':')[1].strip())(F,A[:B+1],I,G);A=A[B+1:];D=D[B+1:];E=E[B+1:]
		elif'### StartTask'in C:B=A.index('### EndTask');print(B,len(A),A);print(A[:B+1]);print(A[B+1:]);print(C.split(':')[1].strip());queueStepsTask.with_options(name=C.split(':')[1].strip())(F,A[:B+1],I,G);A=A[B+1:];D=D[B+1:];E=E[B+1:]
		else:
			A.pop(0);D.pop(0);E.pop(0);M='process'
			if isinstance(C,list):J.debug(f"{log_space}click', codeInCodeList = {C[0]}")
			else:
				H,K,L=runCode(F,C,G)
				if not(H==_C or H==[]):A=H+A;D=K+D;E=L+E
				import re;N=re.sub(_D,'_',C)
	return
@flow(name=_E)
def queueStepsFlow(df,codeList,run_code_until,objVar):
	E=objVar;A=codeList;C=[df]*len(A);D=[E]*len(A);H=get_run_logger()
	while len(A)>0:
		B=A[0];df=C[0];E=D[0]
		if B in[_A]:F=A.index(_B);print(F,len(A),A);print(A[:F+1]);print(A[F+1:])
		A.pop(0);C.pop(0);D.pop(0)
		if isinstance(B,list):H.debug(f"{log_space}click', codeInCodeList = {B[0]}")
		else:
			G,I,J=runCode(df,B,E)
			if not(G==_C or G==[]):A=G+A;C=I+C;D=J+D
			import re;K=re.sub(_D,'_',B)
	return
@task(name=_E)
def queueStepsTask(df,codeList,run_code_until,objVar):
	E=objVar;A=codeList;C=[df]*len(A);D=[E]*len(A);H=get_run_logger()
	while len(A)>0:
		B=A[0];df=C[0];E=D[0]
		if B in[_A]:F=A.index(_B);print(F,len(A),A);print(A[:F+1]);print(A[F+1:])
		A.pop(0);C.pop(0);D.pop(0)
		if isinstance(B,list):H.debug(f"{log_space}click', codeInCodeList = {B[0]}")
		else:
			G,I,J=runCode(df,B,E)
			if not(G==_C or G==[]):A=G+A;C=I+C;D=J+D
			import re;K=re.sub(_D,'_',B)
	return
def runCode(df,code,objVar=''):
	A=code;E=get_run_logger();from pathlib import Path,PureWindowsPath;B=A.split(':',1);C=B[0].strip()
	if C=='rem'or C in[_A,_B]:return[],[],[]
	D=A;variables['codeBeforeTemplateUpdate']=D;A=updateConstants(df,A.strip());B=A.split(':',1);C=B[0].strip()
	if len(B)>1:F=B[1].rstrip()
	else:F=_C
	from config import FLOW_COUNT as G;H=G
	if not'iterationCount'in D:E.info(f"RUN {H} STEP | {D}")
	if D.strip()!=A.strip():E.debug(f"{log_space}updated:{A}")
	if False:0
	else:import re;J=re.sub(_D,'_',A);from core.auto_core_lib_helper import _otherRunCode as I;return I(df,A,C,F,objVar)
	return[],[],[]