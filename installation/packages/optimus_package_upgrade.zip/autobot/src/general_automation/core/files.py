#!/usr/bin/env python
# coding: utf-8

"""
Module:         auto_utility_file.py
Description:    file utilities e.g. rename File, get full path of file, getRecentCreatedFile, Json file handling, Excel file handling
Created:        30 Jul 2022

Versions:
20210216        Refactor all utility codes
"""
from prefect import task, flow, get_run_logger, context
from prefect.task_runners import SequentialTaskRunner

import os

def getFullPath(path):
    #import os
    return os.path.abspath(path)

def renameFile(sourceFilePath, targetFilePath):
    #logg('renameFile', sourceFilePath = sourceFilePath, targetFilePath = targetFilePath)
    #rename a file
    if os.path.exists(targetFilePath):
      os.remove(targetFilePath)
    os.rename(sourceFilePath, targetFilePath)


def isFileNewer(file1: str, file2: str, type="m") -> bool:
    """Is file1 newer, return True or False
    """
    import os.path

    # m = modified, c = creation date
    if type == "m":
        #local_time_file1 = time.ctime(os.path.getmtime(file1))
        #local_time_file2 = time.ctime(os.path.getmtime(file2))            
        #print("mtime (Local time):", local_time_file1, local_time_file2)
        return os.path.getmtime(file1) > os.path.getmtime(file2)
    elif type == "c":
        #local_time_file1 = time.ctime(os.path.getctime(file1))
        #local_time_file2 = time.ctime(os.path.getctime(file2))            
        #print("ctime (Local time):", local_time_file1, local_time_file2)
        return os.path.getctime(file1) > os.path.getctime(file2)
    else:
        return

import time
import glob
import os
from pathlib import Path, PureWindowsPath
def GetRecentCreatedFile(filepath,filetype,inLastNumOfSec):
    #GetRecentCreatedFile('C:/Users/roh/Downloads/','*.png',10)
    #print(filepath,filetype,inLastNumOfSec)
    filepath = Path(filepath)
    #print(filepath.absolute())
    file_pattern = filepath / filetype # filepath + filetype
    #print('GetRecentCreatedFile', str(filepath), filetype, str(file_pattern), inLastNumOfSec)
    list_of_files = glob.glob(str(file_pattern)) # * means all if need specific format then *.csv
    #print(not not list_of_files ) # returns true if empty
    if list_of_files:
        latest_file = max(list_of_files, key=os.path.getctime)
        # time.ctime(c_time)
        print('Latest file', latest_file, 'create', time.ctime(os.path.getctime(latest_file)), '>', time.ctime(time.time()-inLastNumOfSec), os.path.getctime(latest_file) > time.time()-inLastNumOfSec)
        if os.path.getctime(latest_file) > time.time()-inLastNumOfSec:
            print('Time', time.time()-inLastNumOfSec, '|' , latest_file)            
            return latest_file
        else:
            return None
    else:
        return None
#downloadedFile = GetRecentCreatedFile('D:\\iCristal\\','*.pdf',120) # get most recent file of pdf format in last 120 sec in path
#print('none') if downloadedFile is None else print(downloadedFile)
#renameFile(downloadedFile, 'D:/iCristal/Output/APAC_Daily_Sales/' + saveName + '.pdf')


import pandas as pd
from pathlib import Path
from auto_helper_lib import try_catch, readExcelConfig
from config import log_space  # sys_variables
def cacheScripts(script='OptimusLib.xlsm', df=pd.DataFrame(), program_dir = "D:/optimus/", startsheet = "main", refresh=False, msgStr=''):
    """ Check if cache exist - use cache, else keep a cache
    """
    script_name = Path(script).stem   # without extension     
    scriptPath = Path(program_dir).joinpath( 'scripts', script )
    scriptPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.pickle' )
    scriptExcelPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.xlsx' )            
    if scriptPath.exists():
        if scriptPathCache.exists() and isFileNewer(scriptPathCache.__str__(), scriptPath.__str__()) and not refresh:
            # use cache file if cache file is newer
            df_script = pd.read_pickle(scriptPathCache.__str__())
            #if not msgStr == '': msgStr = msgStr + "\n"
            msgStr = msgStr + f"{script_name} ---- from Cache" #     {log_space}
            #logger.debug(f"{msgStr}")
        else:
            df_script = try_catch(readExcelConfig(sheet=startsheet, excel=str(scriptPath) , refresh=refresh )) #Path(program_dir).stem.__str__() + "OptimusLib"))
            #logger.debug(f"{log_space}{script_name} ---- read from Excel")
            #if not msgStr == '': msgStr = msgStr + "\n"
            msgStr = msgStr + f"{script_name} ---- from Excel" #     {log_space}
            #logger.debug(f"{msgStr}")                
            #pickle_storeData(dfmain_lib, optimusLibraryPathCache.__str__())
            pd.to_pickle(df_script, scriptPathCache.__str__())
            df_script.to_excel(scriptExcelPathCache.__str__(), index=False)            

        # remove columns with name starting with "Unnamed"
        #df_script = df_script.filter(regex='^(?!Unnamed)') 
        # create a new column with default value
        #df_script = df_script.assign(Row=df_script.index) 
        #df_script = df_script.assign(Excel=script)
        #df_script = df_script.assign(Sheet=startsheet)
        #print(df_script.columns.tolist())
        #print(df_script[:20])
        
        if df.empty:
            df = df_script
        else:
            df = pd.concat([df, df_script], ignore_index=True, sort=False)    # append optimus library commands
    return df, msgStr


def runInBackground(prog_path):
    #https://riptutorial.com/python/example/5714/more-flexibility-with-popen
    from subprocess import Popen
    from pathlib import Path, PureWindowsPath

    import subprocess
    import sys

    #result = subprocess.run([sys.executable, "-c", "print('ocean')"])
    #print('      ', 'Command:', prog_path + r"\autobot\src\console.bat")

    result = subprocess.run(
        Path(prog_path + r"\autobot\src\console.bat").absolute(),
        capture_output=True, text=True
    )
    print('      ', 'Activate remote console session. Return code:', result.returncode, result.stderr)
    result = subprocess.run(
        str(Path(prog_path + r"\autobot\src\Qres\Qres.exe").absolute()) + " /x:1920 /y:1080",
        capture_output=True, text=True
    )
    #result = subprocess.run(
    #    [sys.executable, "-c", "raise ValueError('oops')"], capture_output=True, text=True
    #)
    #print("stdout:", result.stdout)
    print('      ',"Set screen resolution 1920 x 1080.", result.stderr)
    #stdout=subprocess.DEVNULL,
    #stderr=subprocess.STDOUT, 
    #creationflags=subprocess.CREATE_NO_WINDOW
    return

def killprocess(processName: str):
    logger = get_run_logger()
    import subprocess
    command = "Get-Process | Where-Object {{$_.Name -Like '{}'}} ".format(processName)
    result = subprocess.run(["powershell.exe", command], capture_output=True)
    if len(result.stdout.decode('ASCII')) > 0:
        logger.info("process killed" + result.stdout.decode('ASCII'))
        print("process killed" + result.stdout.decode('ASCII'))
        result = subprocess.run(["powershell.exe", command + " | Stop-Process -force "], capture_output=True)
        return True
    else:
        return False

def printscreen(file=".\screen.jpg"):
    # Importing Image and ImageGrab module from PIL package 
    from PIL import Image, ImageGrab                    
    # creating an image object
    #im1 = Image.open(r"C:\Users\sadow984\Desktop\download2.JPG")
        
    # using the grab method
    im2 = ImageGrab.grab(bbox = None)
    #im2.show()
    # save a image using extension
    im2 = im2.save(file)
#printscreen()

def list_of_files(folder:str, pattern:str):
    """ returns a file list for specific folder and pattern.  Used by studio.launcher
    """
    import glob
    import os
    #current_dir = os.path.dirname(os.path.realpath(__file__))
    matching_files = glob.glob(os.path.join(folder, pattern))
    #print(matching_files)
    return [os.path.basename(file) for file in matching_files]

def _getProgPath() -> str:
    """Auto detect program path.  Used by studio.launcher and studio.studio
    """
    from pathlib import Path
    curr_path = Path.cwd() #D:\Optimus6\scripts\test-sample
    if (curr_path / "autobot/assets").exists():
        prog_path = curr_path
    elif (curr_path.parent / "autobot/assets").exists():
        prog_path = curr_path.parent
    elif (curr_path.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent
    else:
        raise ValueError('Studio.launcher: Cannot detect program path')
    return prog_path.as_posix()


def get_filename_without_extension(file_path:str) -> str:
    """ Used by studio.launcher
    """
    from pathlib import Path
    path = Path(file_path)
    filename_without_extension = path.stem
    full_path = path.parent
    return str (full_path / filename_without_extension)
    return filename_without_extension


def readfile(filepath = "", sheet_name=0): #scriptKeywordsDefn
    """ Read optimus script keyword definitions.  Used in studio.launcher
    """
    import pandas as pd
    print('filepath', filepath, 'sheet', sheet_name)
    df = pd.read_excel(filepath, sheet_name) # can also index sheet by name or fetch all sheets
    if sheet_name=="Commands":
        df['Type']=df['Type'].fillna(method="ffill")
        df['Description']=df['Description'].astype(str)
        df['Command']=df['Command'].astype(str)
    if sheet_name=="Apps":
        df['Description']=df['Description'].astype(str)
        df['Label']=df['Label'].astype(str)        
    return df



def jsonWrite(obj, file:str):
    """#Helper functions for JSON
    https://tutswiki.com/read-write-json-config-file-in-python/
    """
    import json
    with open(file, "w") as jsonfile:
        json.dump(obj, jsonfile, indent=4)
        print(file, obj, " : Write successful")
        jsonfile.close()
    return True

def jsonRead(file:str):
    import json
    with open(file, "r") as jsonfile:
        obj = json.load(jsonfile) # Reading the file
        print(file, " : Read successful")
        jsonfile.close()
    return obj

def checkIfFileOpen(FILENAME: str):
    import os
    import pythoncom
    import win32api
    import win32com.client

    #FILENAME = win32api.GetLongPathName(os.path.join(os.environ["TEMP"], "temp.csv"))
    #open(FILENAME, "wb").write ("1,2,3\n4,5,6\n")
    #obj = win32com.client.GetObject(FILENAME)

    context = pythoncom.CreateBindCtx(0)
    for moniker in pythoncom.GetRunningObjectTable():
        name = moniker.GetDisplayName(context, None)
        if name.endswith(FILENAME):
            print("Found", name)
            #break
            return True
        else:
            #print("Not found")
            pass
    return False


def pickleRead(filename_pickle:str='filename.pickle'):
    import pickle
    with open(filename_pickle, 'rb') as handle:
        obj = pickle.load(handle)
    return obj

def pickleWrite(obj:object={}, filename_pickle:str='filename.pickle'):
    import pickle
    from pathlib import Path
    import os
    folder = Path(filename_pickle).parents[0]
    print('folder', folder)
    if not folder.exists():
        os.mkdir(folder)
    #Path(filename_pickle).mkdir(parents=True, exist_ok=True)
    with open(filename_pickle, 'wb') as handle:
        pickle.dump(obj, handle, protocol=pickle.HIGHEST_PROTOCOL)

