#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
Module:         files.py  Previously auto_utility_file.py
Description:    file utilities e.g. rename File, get full path of file, getRecentCreatedFile, Json file handling, Excel file handling
Created:        30 Jul 2022

Versions:
20210216        Refactor all utility codes
"""
#!/usr/bin/env python
# coding: utf-8

from pathlib import Path
from prefect import task, flow, get_run_logger, context
from prefect.task_runners import SequentialTaskRunner

import os

def getFullPath(path):
    #import os
    return os.path.abspath(path)

def renameFile(sourceFilePath, targetFilePath):
    #logg('renameFile', sourceFilePath = sourceFilePath, targetFilePath = targetFilePath)
    #rename a file
    if os.path.exists(targetFilePath):
      os.remove(targetFilePath)
    os.rename(sourceFilePath, targetFilePath)


def isFileNewer(file1: str, file2: str, type="m") -> bool:
    """Is file1 newer, return True or False
    """
    import os.path

    # m = modified, c = creation date
    if type == "m":
        #local_time_file1 = time.ctime(os.path.getmtime(file1))
        #local_time_file2 = time.ctime(os.path.getmtime(file2))            
        #print("mtime (Local time):", local_time_file1, local_time_file2)
        return os.path.getmtime(file1) > os.path.getmtime(file2)
    elif type == "c":
        #local_time_file1 = time.ctime(os.path.getctime(file1))
        #local_time_file2 = time.ctime(os.path.getctime(file2))            
        #print("ctime (Local time):", local_time_file1, local_time_file2)
        return os.path.getctime(file1) > os.path.getctime(file2)
    else:
        return

import time
import glob
import os
from pathlib import Path, PureWindowsPath
def GetRecentCreatedFile(filepath,filetype,inLastNumOfSec):
    #GetRecentCreatedFile('C:/Users/roh/Downloads/','*.png',10)
    #print(filepath,filetype,inLastNumOfSec)
    filepath = Path(filepath)
    #print(filepath.absolute())
    file_pattern = filepath / filetype # filepath + filetype
    #print('GetRecentCreatedFile', str(filepath), filetype, str(file_pattern), inLastNumOfSec)
    list_of_files = glob.glob(str(file_pattern)) # * means all if need specific format then *.csv
    #print(not not list_of_files ) # returns true if empty
    if list_of_files:
        latest_file = max(list_of_files, key=os.path.getctime)
        # time.ctime(c_time)
        print('Latest file', latest_file, 'create', time.ctime(os.path.getctime(latest_file)), '>', time.ctime(time.time()-inLastNumOfSec), os.path.getctime(latest_file) > time.time()-inLastNumOfSec)
        if os.path.getctime(latest_file) > time.time()-inLastNumOfSec:
            print('Time', time.time()-inLastNumOfSec, '|' , latest_file)            
            return latest_file
        else:
            return None
    else:
        return None
#downloadedFile = GetRecentCreatedFile('D:\\iCristal\\','*.pdf',120) # get most recent file of pdf format in last 120 sec in path
#print('none') if downloadedFile is None else print(downloadedFile)
#renameFile(downloadedFile, 'D:/iCristal/Output/APAC_Daily_Sales/' + saveName + '.pdf')


import pandas as pd
from pathlib import Path
#from auto_helper_lib import try_catch, readExcelConfig
from core.core import try_catch, readExcelConfig
from config import log_space  # sys_variables
def cacheScripts(script='OptimusLib.xlsm', df=pd.DataFrame(), program_dir = "D:/optimus/", startsheet = "main", refresh=False, msgStr=''):
    """ Check if cache exist - use cache, else keep a cache
    """
    script_name = Path(script).stem   # without extension     
    scriptPath = Path(program_dir).joinpath( 'scripts', script )
    scriptPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.pickle' )
    scriptExcelPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.xlsx' )            
    if scriptPath.exists():
        if scriptPathCache.exists() and isFileNewer(scriptPathCache.__str__(), scriptPath.__str__()) and not refresh:
            # use cache file if cache file is newer
            df_script = pd.read_pickle(scriptPathCache.__str__())
            #if not msgStr == '': msgStr = msgStr + "\n"
            msgStr = msgStr + f"{script_name} ---- from Cache" #     {log_space}
            #logger.debug(f"{msgStr}")
        else:
            df_script = try_catch(readExcelConfig(sheet=startsheet, excel=str(scriptPath) , refresh=refresh )) #Path(program_dir).stem.__str__() + "OptimusLib"))
            #logger.debug(f"{log_space}{script_name} ---- read from Excel")
            #if not msgStr == '': msgStr = msgStr + "\n"
            msgStr = msgStr + f"{script_name} ---- from Excel" #     {log_space}
            #logger.debug(f"{msgStr}")                
            #pickle_storeData(dfmain_lib, optimusLibraryPathCache.__str__())
            pd.to_pickle(df_script, scriptPathCache.__str__())
            df_script.to_excel(scriptExcelPathCache.__str__(), index=False)            

        # remove columns with name starting with "Unnamed"
        #df_script = df_script.filter(regex='^(?!Unnamed)') 
        # create a new column with default value
        #df_script = df_script.assign(Row=df_script.index) 
        #df_script = df_script.assign(Excel=script)
        #df_script = df_script.assign(Sheet=startsheet)
        #print(df_script.columns.tolist())
        #print(df_script[:20])
        
        if df.empty:
            df = df_script
        else:
            df = pd.concat([df, df_script], ignore_index=True, sort=False)    # append optimus library commands
    return df, msgStr


def runInBackground(prog_path):
    #https://riptutorial.com/python/example/5714/more-flexibility-with-popen
    from subprocess import Popen
    from pathlib import Path, PureWindowsPath

    import subprocess
    import sys

    #result = subprocess.run([sys.executable, "-c", "print('ocean')"])
    #print('      ', 'Command:', prog_path + r"\autobot\src\console.bat")

    result = subprocess.run(
        Path(prog_path + r"\autobot\src\console.bat").absolute(),
        capture_output=True, text=True
    )
    print('      ', 'Activate remote console session. Return code:', result.returncode, result.stderr)
    result = subprocess.run(
        str(Path(prog_path + r"\autobot\src\Qres\Qres.exe").absolute()) + " /x:1920 /y:1080",
        capture_output=True, text=True
    )
    #result = subprocess.run(
    #    [sys.executable, "-c", "raise ValueError('oops')"], capture_output=True, text=True
    #)
    #print("stdout:", result.stdout)
    print('      ',"Set screen resolution 1920 x 1080.", result.stderr)
    #stdout=subprocess.DEVNULL,
    #stderr=subprocess.STDOUT, 
    #creationflags=subprocess.CREATE_NO_WINDOW
    return

def killprocess(processName: str, object: str = 'Name', match: str = 'Like'):
    '''Powershell get matching process via process Name and using Like matching
    May be not used - using killOptimus in Windows library to kill obsolete optimus windows'''
    logger = get_run_logger()
    import subprocess
    command = "Get-Process | Where-Object {{$_.{} -{} '{}'}} ".format(object, match, processName)
    #Get-Process | Where-Object {$_.mainWindowTitle -Match "PTIMUS"} | Format-Table Id, Name, mainWindowtitle -AutoSize
    result = subprocess.run(["powershell.exe", command], capture_output=True)
    if len(result.stdout.decode('ASCII')) > 0:
        logger.info("process killed" + result.stdout.decode('ASCII'))
        print("process killed" + result.stdout.decode('ASCII'))
        result = subprocess.run(["powershell.exe", command + " | Stop-Process -force "], capture_output=True)
        return True
    else:
        return False

def printscreen(file=".\screen.jpg"):
    # Importing Image and ImageGrab module from PIL package 
    from PIL import Image, ImageGrab                    
    # creating an image object
    #im1 = Image.open(r"C:\Users\sadow984\Desktop\download2.JPG")
        
    # using the grab method
    im2 = ImageGrab.grab(bbox = None)
    #im2.show()
    # save a image using extension
    im2 = im2.save(file)
#printscreen()

def list_of_files(folder:str, pattern:str):
    """ returns a file list for specific folder and pattern.  Used by studio.launcher
    """
    import glob
    import os
    #current_dir = os.path.dirname(os.path.realpath(__file__))
    matching_files = glob.glob(os.path.join(folder, pattern))
    #print(matching_files)
    return [os.path.basename(file) for file in matching_files]

def _getProgPath() -> str:
    """Auto detect program path.  Used by studio.launcher and studio.studio
    """
    from pathlib import Path
    curr_path = Path.cwd() #D:\Optimus6\scripts\test-sample or current path D:\Optimus2.0\autobot\src\general_automation
    #print('current path', curr_path)
    #print('current path parent', (curr_path.parent.parent.parent / "autobot/assets"))    
    #print('current path exist', (curr_path.parent.parent.parent / "autobot/assets").exists())        
    if (curr_path / "autobot/assets").exists():
        prog_path = curr_path
    elif (curr_path.parent / "autobot/assets").exists():
        prog_path = curr_path.parent
    elif (curr_path.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent
    elif (curr_path.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent
    elif (curr_path.parent.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent.parent
    else:
        raise ValueError('Studio.launcher: Cannot detect program path')
    #print('PROGRAM PATH', prog_path.as_posix())
    return prog_path.as_posix()


def get_filename_without_extension(file_path:str) -> str:
    """ Used by studio.launcher
    """
    from pathlib import Path
    path = Path(file_path)
    filename_without_extension = path.stem
    full_path = path.parent
    return str (full_path / filename_without_extension)
    return filename_without_extension


def readfile(filepath = "", sheet_name=0): #scriptKeywordsDefn
    """ Read optimus script keyword definitions.  Used in studio.launcher
    """
    import pandas as pd
    print('filepath', filepath, 'sheet', sheet_name)
    df = pd.read_excel(filepath, sheet_name) # can also index sheet by name or fetch all sheets
    if sheet_name=="Commands":
        df['Type']=df['Type'].fillna(method="ffill")
        df['Description']=df['Description'].astype(str)
        df['Command']=df['Command'].astype(str)
    if sheet_name=="Apps":
        df['Description']=df['Description'].astype(str)
        df['Label']=df['Label'].astype(str)        
    return df



def jsonWrite(obj, file:str):
    """#Helper functions for JSON
    https://tutswiki.com/read-write-json-config-file-in-python/
    """
    import json
    with open(file, "w") as jsonfile:
        json.dump(obj, jsonfile, indent=4)
        print(file, obj, " : Write successful")
        jsonfile.close()
    return True

def jsonRead(file:str):
    import json
    with open(file, "r") as jsonfile:
        obj = json.load(jsonfile) # Reading the file
        print(file, " : Read successful")
        jsonfile.close()
    return obj

def checkIfFileOpen(FILENAME: str):
    import os
    import pythoncom
    import win32api
    import win32com.client

    #FILENAME = win32api.GetLongPathName(os.path.join(os.environ["TEMP"], "temp.csv"))
    #open(FILENAME, "wb").write ("1,2,3\n4,5,6\n")
    #obj = win32com.client.GetObject(FILENAME)

    context = pythoncom.CreateBindCtx(0)
    for moniker in pythoncom.GetRunningObjectTable():
        name = moniker.GetDisplayName(context, None)
        if name.endswith(FILENAME):
            print("Found", name)
            #break
            return True
        else:
            #print("Not found")
            pass
    return False


def pickleRead(filename_pickle:str='filename.pickle'):
    import pickle
    with open(filename_pickle, 'rb') as handle:
        obj = pickle.load(handle)
    return obj

def pickleWrite(obj:object={}, filename_pickle:str='filename.pickle'):
    import pickle
    from pathlib import Path
    import os
    folder = Path(filename_pickle).parents[0]
    print('folder', folder)
    if not folder.exists():
        os.mkdir(folder)
    #Path(filename_pickle).mkdir(parents=True, exist_ok=True)
    with open(filename_pickle, 'wb') as handle:
        pickle.dump(obj, handle, protocol=pickle.HIGHEST_PROTOCOL)

def checkFileValid(file : Path):
    if not file.is_file():
        print('Warning - Invalid file or path: ', file.absolute())
        return False
        #sys.exit(config.EX_CONFIG)     
    return True

def changeWorkingDirectory(NEW_DIR):
    import os
    # Change the current working directory
    os.chdir(NEW_DIR)

    # Print the current working directory
    CWD_DIR = Path('.').absolute().__str__()
    #print("Current working directory changed to: {0}".format(os.getcwd()))
    #exit()
    return CWD_DIR    

def checkWorkDirectory(strpath: str):
    # Check working directory
    W_DIR = Path(strpath).resolve().absolute().__str__()
    #print('Current working path ',CWD_DIR)  # ./autobot
    return W_DIR

def checkStartFile(STARTFILE: Path, SCRIPTS_DIR: Path):
    #check if file name is fully formed with extension
    if not STARTFILE.endswith((".xls", ".xlsm", ".xlsx")): STARTFILE = STARTFILE + ".xlsm"

    # check if startfile is a file name (0) or directory (1)
    import os
    if len(os.path.dirname(STARTFILE)) == 0:
        STARTFILE = Path(SCRIPTS_DIR, STARTFILE)
    else:
        STARTFILE = Path(STARTFILE)

    #print('startfile',STARTFILE.absolute())
    return STARTFILE.absolute().__str__()

def setup_assetDirectories(STARTFILE, SCRIPTS_DIR, OUTPUT_PATH, IMAGE_PATH, LOG_PATH, ADDON_PATH, SRCLOGFILE):
    SCRIPT_NAME = Path(STARTFILE).name.__str__()  # stem - without extension
    SCRIPT_NAME_WO_EXT = Path(STARTFILE).stem.__str__()  # stem - without extension
    ASSETS_DIR = (Path(STARTFILE).parents[0] / SCRIPT_NAME_WO_EXT).resolve().absolute().__str__()
    #ASSETS_DIR = Path(SCRIPTS_DIR + '/' + SCRIPT_NAME.split('.')[0]).absolute().__str__()
    #print(SCRIPT_NAME.split('.')[0])
    #print(ASSETS_DIR + '/' + SCRIPT_NAME.split('.')[0] + '/' + OUTPUT_PATH)
    OUTPUT_DIR = Path(ASSETS_DIR + '/' + OUTPUT_PATH).absolute().__str__()
    IMAGE_DIR = Path(ASSETS_DIR  + '/' + IMAGE_PATH).absolute().__str__()
    LOG_DIR = Path(ASSETS_DIR + '/' + LOG_PATH).absolute().__str__()
    ADDON_DIR = Path(ASSETS_DIR + '/' + ADDON_PATH).absolute().__str__()
    SRCLOG = Path(LOG_DIR + '/' + SRCLOGFILE).absolute().__str__()
    #print('ASSETS', ASSETS_DIR, IMAGE_DIR, LOG_DIR, OUTPUT_DIR, SCRIPT_NAME, SRCLOG)
    if not(Path(ASSETS_DIR).exists() and Path(OUTPUT_DIR).exists() and Path(IMAGE_DIR).exists() and Path(LOG_DIR).exists() and Path(ADDON_DIR).exists()): 
        if not Path(ASSETS_DIR).exists(): os.mkdir(ASSETS_DIR)
        if not Path(OUTPUT_DIR).exists(): os.mkdir(OUTPUT_DIR)
        if not Path(OUTPUT_DIR).exists(): os.mkdir(OUTPUT_DIR)
        if not Path(IMAGE_DIR).exists(): os.mkdir(IMAGE_DIR)
        if not Path(LOG_DIR).exists(): os.mkdir(LOG_DIR)
        if not Path(ADDON_DIR).exists(): os.mkdir(ADDON_DIR)
        print('Script Directories created ...')
    return SCRIPT_NAME, ASSETS_DIR, OUTPUT_DIR, IMAGE_DIR, LOG_DIR, ADDON_DIR, SRCLOG 

