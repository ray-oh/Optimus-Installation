
from pathlib import Path
from prefect import task, flow, get_run_logger, context
from prefect.task_runners import SequentialTaskRunner
import os
def getFullPath(path):
    return os.path.abspath(path)
def renameFile(sourceFilePath, targetFilePath):
    if os.path.exists(targetFilePath):
      os.remove(targetFilePath)
    os.rename(sourceFilePath, targetFilePath)
def isFileNewer(file1: str, file2: str, type="m") -> bool:
    
    import os.path
    if type == "m":
        return os.path.getmtime(file1) > os.path.getmtime(file2)
    elif type == "c":
        return os.path.getctime(file1) > os.path.getctime(file2)
    else:
        return
import time
import glob
import os
from pathlib import Path, PureWindowsPath
def GetRecentCreatedFile(filepath,filetype,inLastNumOfSec):
    filepath = Path(filepath)
    file_pattern = filepath / filetype 
    list_of_files = glob.glob(str(file_pattern)) 
    if list_of_files:
        latest_file = max(list_of_files, key=os.path.getctime)
        print('Latest file', latest_file, 'create', time.ctime(os.path.getctime(latest_file)), '>', time.ctime(time.time()-inLastNumOfSec), os.path.getctime(latest_file) > time.time()-inLastNumOfSec)
        if os.path.getctime(latest_file) > time.time()-inLastNumOfSec:
            print('Time', time.time()-inLastNumOfSec, '|' , latest_file)            
            return latest_file
        else:
            return None
    else:
        return None
import pandas as pd
from pathlib import Path
from core.core import try_catch, readExcelConfig
from config import log_space  
def cacheScripts(script='OptimusLib.xlsm', df=pd.DataFrame(), program_dir = "D:/optimus/", startsheet = "main", refresh=False, msgStr=''):
    
    script_name = Path(script).stem   
    scriptPath = Path(program_dir).joinpath( 'scripts', script )
    scriptPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.pickle' )
    scriptExcelPathCache = Path(program_dir).joinpath( 'scripts', '_cache', script_name + '_' + startsheet + '.xlsx' )            
    if scriptPath.exists():
        if scriptPathCache.exists() and isFileNewer(scriptPathCache.__str__(), scriptPath.__str__()) and not refresh:
            df_script = pd.read_pickle(scriptPathCache.__str__())
            msgStr = msgStr + f"{script_name} ---- from Cache" 
        else:
            df_script = try_catch(readExcelConfig(sheet=startsheet, excel=str(scriptPath) , refresh=refresh )) 
            msgStr = msgStr + f"{script_name} ---- from Excel" 
            pd.to_pickle(df_script, scriptPathCache.__str__())
            df_script.to_excel(scriptExcelPathCache.__str__(), index=False)            
        if df.empty:
            df = df_script
        else:
            df = pd.concat([df, df_script], ignore_index=True, sort=False)    
    return df, msgStr
def runInBackground(prog_path):
    from subprocess import Popen
    from pathlib import Path, PureWindowsPath
    import subprocess
    import sys
    result = subprocess.run(
        Path(prog_path + r"\autobot\src\console.bat").absolute(),
        capture_output=True, text=True
    )
    print('      ', 'Activate remote console session. Return code:', result.returncode, result.stderr)
    result = subprocess.run(
        str(Path(prog_path + r"\autobot\src\Qres\Qres.exe").absolute()) + " /x:1920 /y:1080",
        capture_output=True, text=True
    )
    print('      ',"Set screen resolution 1920 x 1080.", result.stderr)
    return
def killprocess(processName: str, object: str = 'Name', match: str = 'Like'):
    
    logger = get_run_logger()
    import subprocess
    command = "Get-Process | Where-Object {{$_.{} -{} '{}'}} ".format(object, match, processName)
    result = subprocess.run(["powershell.exe", command], capture_output=True)
    if len(result.stdout.decode('ASCII')) > 0:
        logger.info("process killed" + result.stdout.decode('ASCII'))
        print("process killed" + result.stdout.decode('ASCII'))
        result = subprocess.run(["powershell.exe", command + " | Stop-Process -force "], capture_output=True)
        return True
    else:
        return False
def printscreen(file=".\screen.jpg"):
    from PIL import Image, ImageGrab                    
    im2 = ImageGrab.grab(bbox = None)
    im2 = im2.save(file)
def list_of_files(folder:str, pattern:str):
    
    import glob
    import os
    matching_files = glob.glob(os.path.join(folder, pattern))
    return [os.path.basename(file) for file in matching_files]
def _getProgPath() -> str:
    
    from pathlib import Path
    curr_path = Path.cwd() 
    if (curr_path / "autobot/assets").exists():
        prog_path = curr_path
    elif (curr_path.parent / "autobot/assets").exists():
        prog_path = curr_path.parent
    elif (curr_path.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent
    elif (curr_path.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent
    elif (curr_path.parent.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent.parent
    else:
        raise ValueError('Studio.launcher: Cannot detect program path')
    return prog_path.as_posix()
def get_filename_without_extension(file_path:str) -> str:
    
    from pathlib import Path
    path = Path(file_path)
    filename_without_extension = path.stem
    full_path = path.parent
    return str (full_path / filename_without_extension)
    return filename_without_extension
def readfile(filepath = "", sheet_name=0): 
    
    import pandas as pd
    print('filepath', filepath, 'sheet', sheet_name)
    df = pd.read_excel(filepath, sheet_name) 
    if sheet_name=="Commands":
        df['Type']=df['Type'].fillna(method="ffill")
        df['Description']=df['Description'].astype(str)
        df['Command']=df['Command'].astype(str)
    if sheet_name=="Apps":
        df['Description']=df['Description'].astype(str)
        df['Label']=df['Label'].astype(str)        
    return df
def jsonWrite(obj, file:str):
    
    import json
    with open(file, "w") as jsonfile:
        json.dump(obj, jsonfile, indent=4)
        print(file, obj, " : Write successful")
        jsonfile.close()
    return True
def jsonRead(file:str):
    import json
    with open(file, "r") as jsonfile:
        obj = json.load(jsonfile) 
        print(file, " : Read successful")
        jsonfile.close()
    return obj
def checkIfFileOpen(FILENAME: str):
    import os
    import pythoncom
    import win32api
    import win32com.client
    context = pythoncom.CreateBindCtx(0)
    for moniker in pythoncom.GetRunningObjectTable():
        name = moniker.GetDisplayName(context, None)
        if name.endswith(FILENAME):
            print("Found", name)
            return True
        else:
            pass
    return False
def pickleRead(filename_pickle:str='filename.pickle'):
    import pickle
    with open(filename_pickle, 'rb') as handle:
        obj = pickle.load(handle)
    return obj
def pickleWrite(obj:object={}, filename_pickle:str='filename.pickle'):
    import pickle
    from pathlib import Path
    import os
    folder = Path(filename_pickle).parents[0]
    print('folder', folder)
    if not folder.exists():
        os.mkdir(folder)
    with open(filename_pickle, 'wb') as handle:
        pickle.dump(obj, handle, protocol=pickle.HIGHEST_PROTOCOL)
def checkFileValid(file : Path):
    if not file.is_file():
        print('Warning - Invalid file or path: ', file.absolute())
        return False
    return True
def changeWorkingDirectory(NEW_DIR):
    import os
    os.chdir(NEW_DIR)
    CWD_DIR = Path('.').absolute().__str__()
    return CWD_DIR    
def checkWorkDirectory(strpath: str):
    W_DIR = Path(strpath).resolve().absolute().__str__()
    return W_DIR
def checkStartFile(STARTFILE: Path, SCRIPTS_DIR: Path):
    if not STARTFILE.endswith((".xls", ".xlsm", ".xlsx")): STARTFILE = STARTFILE + ".xlsm"
    import os
    if len(os.path.dirname(STARTFILE)) == 0:
        STARTFILE = Path(SCRIPTS_DIR, STARTFILE)
    else:
        STARTFILE = Path(STARTFILE)
    return STARTFILE.absolute().__str__()
def setup_assetDirectories(STARTFILE, SCRIPTS_DIR, OUTPUT_PATH, IMAGE_PATH, LOG_PATH, ADDON_PATH, SRCLOGFILE):
    SCRIPT_NAME = Path(STARTFILE).name.__str__()  
    SCRIPT_NAME_WO_EXT = Path(STARTFILE).stem.__str__()  
    ASSETS_DIR = (Path(STARTFILE).parents[0] / SCRIPT_NAME_WO_EXT).resolve().absolute().__str__()
    OUTPUT_DIR = Path(ASSETS_DIR + '/' + OUTPUT_PATH).absolute().__str__()
    IMAGE_DIR = Path(ASSETS_DIR  + '/' + IMAGE_PATH).absolute().__str__()
    LOG_DIR = Path(ASSETS_DIR + '/' + LOG_PATH).absolute().__str__()
    ADDON_DIR = Path(ASSETS_DIR + '/' + ADDON_PATH).absolute().__str__()
    SRCLOG = Path(LOG_DIR + '/' + SRCLOGFILE).absolute().__str__()
    if not(Path(ASSETS_DIR).exists() and Path(OUTPUT_DIR).exists() and Path(IMAGE_DIR).exists() and Path(LOG_DIR).exists() and Path(ADDON_DIR).exists()): 
        if not Path(ASSETS_DIR).exists(): os.mkdir(ASSETS_DIR)
        if not Path(OUTPUT_DIR).exists(): os.mkdir(OUTPUT_DIR)
        if not Path(OUTPUT_DIR).exists(): os.mkdir(OUTPUT_DIR)
        if not Path(IMAGE_DIR).exists(): os.mkdir(IMAGE_DIR)
        if not Path(LOG_DIR).exists(): os.mkdir(LOG_DIR)
        if not Path(ADDON_DIR).exists(): os.mkdir(ADDON_DIR)
        print('Script Directories created ...')
    return SCRIPT_NAME, ASSETS_DIR, OUTPUT_DIR, IMAGE_DIR, LOG_DIR, ADDON_DIR, SRCLOG 
