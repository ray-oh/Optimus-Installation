
from config import log_space, startTime, codeVersion, flow_run_name, MEMORYPATH, AUTOBOT_DIR
from core.files import checkFileValid, changeWorkingDirectory, checkWorkDirectory, checkStartFile, setup_assetDirectories
from pathlib import Path, PureWindowsPath
from prefect import task, flow, get_run_logger, context
def initializeFromSettings(SETTINGS_PATH, deploymentRun=False):
    import configparser
    from core.parsers import parseArg
    configObj = configparser.ConfigParser()
    configObj.read(SETTINGS_PATH)
    program_args = parseArg(configObj, deploymentRun)
    return configObj, program_args
try:   
    isDeploymentFlowRun = not context.get_run_context().flow_run.deployment_id == None
    logger = get_run_logger()
    logger.warning(f"DeploymentFlowRun:{isDeploymentFlowRun}, ID:{context.get_run_context().flow_run.deployment_id}")
    logger.warning(f"CONTEXT {context.get_run_context().flow_run.parameters['file']}  {context.get_run_context().flow_run.parameters} {context.get_run_context().flow_run}")
except Exception as e:
    if "No run context" in str(e):
        isDeploymentFlowRun = False
    else:
        print(f'Unknown error {e}')
        exit()
if not isDeploymentFlowRun:
    CWD_DIR = checkWorkDirectory('.')  
    AUTOBOT_DIR = CWD_DIR
    import os
    
    SETTINGS_PATH = Path(AUTOBOT_DIR + "/settings.ini").resolve().absolute().__str__()
    COMMANDS_PATH = Path(AUTOBOT_DIR + "/commands.xlsx").resolve().absolute().__str__()
    if not checkFileValid(Path(SETTINGS_PATH)):
        raise ValueError(f"Software Error: settings.ini")
        import sys
        sys.exit(EX_CONFIG)
    configObj, program_args = initializeFromSettings(SETTINGS_PATH, deploymentRun=False)
    
    options = (option for option in configObj.options('settings')) 
    for option in options:
        optionValue = configObj['settings'][option]
        exec(f"{option.upper()} = configObj['settings']['{option.upper()}']")
    for arg in program_args:
        configObj['settings'][arg.upper()] = str(program_args[arg.lower()])
        exec(f"{arg.upper()} = program_args['{arg.lower()}']")
    PROGRAM_DIR = Path(CWD_DIR).parent.absolute().__str__()
    SCRIPTS_DIR = Path(PROGRAM_DIR + "/scripts").resolve().absolute().__str__()
    OUTPUT_PATH = '/output'
    IMAGE_PATH = '/rpa'
    LOG_PATH = '/log'
    ADDON_PATH = '/addon'
    SRCLOGFILE = 'generalAutomation.log'
    BACKGROUND = program_args['background']
    UPDATE = program_args['update']
    RETRIES = program_args['retries']
    STARTFILE = program_args['startfile']
    STARTCODE = program_args['startcode']
    STARTSHEET = program_args['startsheet']
else:
    import os
    SETTINGS_PATH = Path(context.get_run_context().flow_run.parameters['PROGRAM_DIR'] + "/autobot/settings.ini").resolve().absolute().__str__()    
    if not checkFileValid(Path(SETTINGS_PATH)):
        raise ValueError(f"Software Error: settings.ini")
    configObj, program_args = initializeFromSettings(SETTINGS_PATH, deploymentRun=True)
    
    PROGRAM_DIR = Path(context.get_run_context().flow_run.parameters['PROGRAM_DIR']).resolve().absolute().__str__()
    AUTOBOT_DIR = Path(f"{PROGRAM_DIR}/autobot").resolve().absolute().__str__()
    CWD_DIR = changeWorkingDirectory(AUTOBOT_DIR)   
    SCRIPTS_DIR = Path(context.get_run_context().flow_run.parameters['PROGRAM_DIR'] + "/scripts").resolve().absolute().__str__()
    OUTPUT_PATH = '/output'
    IMAGE_PATH = '/rpa'
    LOG_PATH = '/log'
    ADDON_PATH = '/addon'
    SRCLOGFILE = 'generalAutomation.log'
    if 'background' in context.get_run_context().flow_run.parameters: BACKGROUND = context.get_run_context().flow_run.parameters['background']
    if 'update' in context.get_run_context().flow_run.parameters: UPDATE = context.get_run_context().flow_run.parameters['update']
    if 'retries' in context.get_run_context().flow_run.parameters: RETRIES = context.get_run_context().flow_run.parameters['retries']    
    if 'file' in context.get_run_context().flow_run.parameters: STARTFILE = context.get_run_context().flow_run.parameters['file']
    if 'startsheet' in context.get_run_context().flow_run.parameters: STARTSHEET = context.get_run_context().flow_run.parameters['startsheet']
    if 'startcode' in context.get_run_context().flow_run.parameters: STARTCODE = context.get_run_context().flow_run.parameters['startcode']
    deployment_id = context.get_run_context().flow_run.deployment_id
VERSION = configObj['settings']['version']
if not configObj['settings']['memoryPath'] == '':
    MEMORYPATH = configObj['settings']['memoryPath']
if MEMORYPATH == '':
    MEMORYPATH = rf"{PROGRAM_DIR}\memory"
from pathlib import Path, PureWindowsPath
import socket
hostname = str(socket.gethostname())


STARTFILE = checkStartFile(STARTFILE, Path(PROGRAM_DIR) / "scripts") 
if not checkFileValid(Path(STARTFILE)):
    
    if isDeploymentFlowRun: logger.critical(f"SCRIPT START FILE INVALID - Check file path: {Path(STARTFILE)}")            
    raise ValueError(f"Start File Error {STARTFILE} PROGRAM DIR {PROGRAM_DIR} {MEMORYPATH} ")
    exit
else:
    SCRIPT_NAME, ASSETS_DIR, OUTPUT_DIR, IMAGE_DIR, LOG_DIR, ADDON_DIR, SRCLOG = \
        setup_assetDirectories(STARTFILE, SCRIPTS_DIR, OUTPUT_PATH, IMAGE_PATH, LOG_PATH, ADDON_PATH, SRCLOGFILE)
    
def configuResultMsg():
    if isDeploymentFlowRun:
        configResultMsg = f"\
            {log_space}RPA start  :{startTime.strftime('%m/%d/%Y, %H:%M:%S')}, {codeVersion}, \n \
            {log_space}Deployment :{isDeploymentFlowRun}, Id({deployment_id}), \n \
            {log_space}Program dir:{PROGRAM_DIR}, \n \
            {log_space}Autobot dir:{AUTOBOT_DIR}, \n \
            {log_space}Assets dir :{ASSETS_DIR}, \n \
            {log_space}Working dir:{CWD_DIR}, \n \
            {log_space}Start file :{STARTFILE}, \n \
            {log_space}Start sheet:{STARTSHEET}, \n \
            {log_space}Start code :{STARTCODE}, \n \
            {log_space}Scripts dir:{SCRIPTS_DIR}, \n \
            {log_space}Output dir :{OUTPUT_PATH}, \n \
            {log_space}Image dir  :{IMAGE_PATH}, \n \
            {log_space}Log dir    :{LOG_PATH}, \n \
            {log_space}Addon Dir  :{ADDON_PATH}, \n \
            {log_space}SrcLog file:{SRCLOGFILE}, \n \
            {log_space}Memory path:{MEMORYPATH}, \n \
            {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),\n \
            "
    else:
        configResultMsg = f"\
            {log_space}RPA start  :{startTime.strftime('%m/%d/%Y, %H:%M:%S')}, {codeVersion}, \n \
            {log_space}Deployment :{isDeploymentFlowRun}, Id(None), \n \
            {log_space}Program dir:{PROGRAM_DIR}, \n \
            {log_space}Autobot dir:{AUTOBOT_DIR}, \n \
            {log_space}Assets dir :{ASSETS_DIR}, \n \
            {log_space}Working dir:{CWD_DIR}, \n \
            {log_space}Start file :{STARTFILE}, \n \
            {log_space}Start sheet:{STARTSHEET}, \n \
            {log_space}Start code :{STARTCODE}, \n \
            {log_space}Scripts dir:{SCRIPTS_DIR}, \n \
            {log_space}Output dir :{OUTPUT_PATH}, \n \
            {log_space}Image dir  :{IMAGE_PATH}, \n \
            {log_space}Log dir    :{LOG_PATH}, \n \
            {log_space}Addon Dir  :{ADDON_PATH}, \n \
            {log_space}SrcLog file:{SRCLOGFILE}, \n \
            {log_space}Memory path:{MEMORYPATH}, \n \
            {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),\n \
            "
    return configResultMsg
import config
config.configObj = configObj
config.program_args = program_args
config.configuResultMsg = configuResultMsg
config.isDeploymentFlowRun = isDeploymentFlowRun
config.PROGRAM_DIR = PROGRAM_DIR
config.SCRIPTS_DIR = SCRIPTS_DIR
config.OUTPUT_PATH = OUTPUT_PATH
config.IMAGE_PATH = IMAGE_PATH
config.IMAGE_DIR = IMAGE_DIR
config.LOG_PATH = LOG_PATH
config.ADDON_PATH = ADDON_PATH
config.SRCLOGFILE = SRCLOGFILE
config.BACKGROUND = BACKGROUND
config.UPDATE = UPDATE
config.RETRIES = RETRIES
config.STARTFILE = STARTFILE
config.STARTCODE = STARTCODE
config.STARTSHEET = STARTSHEET
config.CWD_DIR = CWD_DIR
config.flow_run_name = flow_run_name
config.ASSETS_DIR = ASSETS_DIR
config.AUTOBOT_DIR = AUTOBOT_DIR