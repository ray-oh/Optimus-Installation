#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
Module:         dates.py   Previously - auto_utility_dates.py
Description:    library for date processing
Created:        30 Jul 2022

Versions:
20210216    Reorganize utility files
"""
#!/usr/bin/env python
# coding: utf-8
#import config

from datetime import datetime

def localTime(st_utc, _timezone:str='Asia/Hong_Kong', format:str="%d/%m/%Y %H:%M"):
    """Convert utc to local time
    https://stackoverflow.com/questions/1111317/how-do-i-print-a-datetime-in-the-local-timezone
    https://gist.github.com/heyalexej/8bf688fd67d7199be4a1682b3eec7568  timezone list
    """
    import pytz
    from datetime import datetime, timezone
    from tzlocal import get_localzone            
    #st_utc = flow.start_time  #.strftime("%d/%m %H:%M") #/%Y  :%S")  uiversal time
    HKT = pytz.timezone(_timezone) #"Asia/Hong_Kong")
    st = st_utc.astimezone(HKT).strftime(format)  #.isoformat()
    return st

def getDuration(then, now = datetime.now(), interval = "default"):
    '''Returns a duration as specified by variable interval
    Functions, except totalDuration, returns [quotient, remainder]

        # Example usage
    then = datetime(2022, 9, 30, 0, 22, 15)
    now = datetime.now()

    print(getDuration(then)) # E.g. Time between dates: 7 years, 208 days, 21 hours, 19 minutes and 15 seconds
    print(getDuration(then, now, 'years'))      # Prints duration in years
    print(getDuration(then, now, 'days'))       #                    days
    print(getDuration(then, now, 'hours'))      #                    hours
    print(getDuration(then, now, 'minutes'))    #                    minutes
    print(getDuration(then, now, 'seconds'))    #                    seconds
    '''
    duration = now - then # For build-in functions
    duration_in_s = duration.total_seconds()
    
    def years():
        return divmod(duration_in_s, 31536000) # Seconds in a year=31536000.

    def days(seconds = None):
        return divmod(seconds if seconds != None else duration_in_s, 86400) # Seconds in a day = 86400

    def hours(seconds = None):
        return divmod(seconds if seconds != None else duration_in_s, 3600) # Seconds in an hour = 3600

    def minutes(seconds = None):
        return divmod(seconds if seconds != None else duration_in_s, 60) # Seconds in a minute = 60

    def seconds(seconds = None):
        if seconds != None:
            return divmod(seconds, 1)   
        return duration_in_s

    def totalDuration():
        y = years()
        d = days(y[1]) # Use remainder to calculate next variable
        h = hours(d[1])
        m = minutes(h[1])
        s = seconds(m[1])
        if int(y[0]) > 0: return "{} years, {} days, {} hours, {} minutes and {} seconds".format(int(y[0]), int(d[0]), int(h[0]), int(m[0]), int(s[0]))
        if int(d[0]) > 0: return "{} days, {} hours, {} minutes and {} seconds".format(int(d[0]), int(h[0]), int(m[0]), int(s[0]))
        if int(h[0]) > 0: return "{} hours, {} minutes and {} seconds".format(int(h[0]), int(m[0]), int(s[0]))
        if int(m[0]) > 0: return "{} minutes and {} seconds".format(int(m[0]), int(s[0]))
        return "{} seconds".format(int(s[0]))

    return {
        'years': int(years()[0]),
        'days': int(days()[0]),
        'hours': int(hours()[0]),
        'minutes': int(minutes()[0]),
        'seconds': int(seconds()),
        'default': totalDuration()
    }[interval]

