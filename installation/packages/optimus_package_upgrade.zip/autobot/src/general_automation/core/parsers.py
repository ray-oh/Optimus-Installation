
def parseArg(configObj, deploymentRun):
    from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter, RawDescriptionHelpFormatter
    from pathlib import Path   
    version = configObj['settings']['version']
    import sys
    if len(sys.argv) > 1 or deploymentRun:  
        activateGooey=False
        parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter, description= 'Optimus ' + version + '\n' +  'Utility to process RPA scripts with steps defined from an Excel input.')
    else:  
        activateGooey=True
        parser = parseArgGUI(configObj)
    required = parser.add_argument_group('Required arguments')
    optional = parser.add_argument_group('Optional arguments')
    def addArg(op, widget_action, activateGooey, defaultValue, typeValue, key):  
        def filelistcheck(value):  
            from pathlib import Path
            scripts = [f.stem for f in Path.cwd().parents[0].glob("./scripts/*.xlsm")]  
            if value in scripts:
                return value
            else:
                raise TypeError("Incorrect file")
        if not activateGooey:
            op.add_argument(flag, flagLong, default=defaultValue, type=typeValue, help=help)
        elif key == 'startfile': 
            scripts = [f.stem for f in Path.cwd().parents[0].glob("./scripts/*.xlsm")]  
            op.add_argument(flag, flagLong, help=help, choices=scripts, widget='FilterableDropdown', type=filelistcheck,  gooey_options={'full_width': True}, required=True)            
        elif 'choices[' in widget_action:   
            op.add_argument(flag, flagLong, help=help, default=defaultValue, choices=eval(widget_action[7:]))                
        elif str(widget_action).lower() in ['dirchooser','filechooser','integerfield']: 
            op.add_argument(flag, flagLong, help=help, default=defaultValue, widget=widget_action, required=True)
        elif str(widget_action).lower() in ['store','count']: 
            op.add_argument(flag, flagLong, help=help, action=widget_action, default=defaultValue)
        elif typeValue==bool: 
            defaultValue=eval(defaultValue) 
            op.add_argument(flag, flagLong, help=help, widget='CheckBox', default=defaultValue)
        else:
            op.add_argument(flag, flagLong, default=defaultValue, type=typeValue, help=help)
        return op
    config_keys = configObj.options('flag')
    flags_items = configObj.items('flag')
    help_items = configObj.items('help')
    for key in config_keys:
        flag = "-" + configObj['flag'][key]
        flagLong = "--" + key
        typeValue = eval(configObj['type'][key])
        defaultValue = configObj['settings'][key]
        widget_action = configObj['widget'][key]
        help = configObj['help'][key]
        if key in ['startfile','program_dir']: 
            required = addArg(required, widget_action, activateGooey, defaultValue, typeValue, key)
        else:
            optional = addArg(optional, widget_action, activateGooey, defaultValue, typeValue, key)
    args = vars(parser.parse_args())
    return args
