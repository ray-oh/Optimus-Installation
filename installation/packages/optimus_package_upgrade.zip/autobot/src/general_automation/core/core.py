
import pandas as pd
from prefect import task, flow, get_run_logger, context
def dfObjList(df, object_value, withHeader=0, df_list=False):
    
    Run update constants twice to handle substitutions within formulasSearch and replace special characters and values i.e. <template values> or {{ template values }} in the code objItem:key or objItem:value like <URL_pages:key> <URL_pages:value> <URL_pages:4> where 4 is offset from key, <URL_pages:@custom_header> 
        office = win32com.client.Dispatch("Excel.Application",pythoncom.CoInitialize())
        wb = office.Workbooks.Open(Path(excel).absolute().__str__())
        wb.RefreshAll()
        office.CalculateUntilAsyncQueriesDone()
        wb.Save()
        wb.Close(SaveChanges=False)
        office.Quit()
        
        import xlwings as xw
        logger.warning("********************************************************1")
        app_excel = xw.App(visible = False)
        logger.warning("********************************************************2")
        wbk = xw.Book(Path(excel).absolute().__str__())
        wbk.api.RefreshAll()
        logger.debug(f'{log_space}Excel refreshed: {excel}')
        wbk.save(Path(excel).absolute().__str__()) 
        wbk.close()
        app_excel.kill()
        del app_excel
        '''
        processName = "Excel"
        import subprocess
        command = "Get-Process | Where-Object {{$_.Name -Like '{}'}} ".format(processName)
        result = subprocess.run(["powershell.exe", command], capture_output=True)
        if len(result.stdout.decode('ASCII')) > 0:
            logger.warning("process killed" + result.stdout.decode('ASCII'))
        df = pd.read_excel(tempfilepath, sheet_name=sheet)
    else:
        df = pd.read_excel(excel, sheet_name=sheet)
    df = df.assign(Row=df.index+2)  
    df = df.assign(Excel=Path(excel).stem)
    df = df.assign(Sheet=sheet)
    df = df[df.Key.notna()]     
    df[['Type','Object']] = df[['Type','Object']].ffill() 
    import config
    config.constants['iterationCount'] = 0     
    return df
class CriticalAccessFailure(Exception):
    def __init__(self, err):
        print('a: critical')
        Exception.__init__(self)
        self.error = err
    def __str__(self):
        print('b: critical')
        return "%r" % self.error
from logging import raiseExceptions
def try_catch(func, comment=''):
    logger = get_run_logger()
    try:
        result = func
    except CriticalAccessFailure as caf:
        print('Critical Error')
        logger.info(f"'Critical failure', level = 'critical', caf = {caf}")
    except Exception as e:
        print('Exception error')
        logger.info(f"'exception', e = {e}, level = 'error'")
        pass
    except:
        print('Except error')
        logger.info(f"'except', level = 'error'")
        pass
    finally:
        return result
