#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
Core functions

"""
import pandas as pd
from prefect import task, flow, get_run_logger, context

def dfObjList(df, object_value, withHeader=0, df_list=False):
    '''# return list of "key" values for given object'''
    try:
        #list = df[((df.Type == 'list') | (df.Type == 'key')) & (df.Object == parameter)]['Key'].values.tolist()
        if df_list:
            list = df[(df.Object == object_value)]
            return list
        elif object_value in df['Object'].unique().tolist():
            list = df[(df.Object == object_value)]['Key'].values.tolist()
            if withHeader: list = list[1:]
            return list
        else:
            # get first rows of each group of table            
            result = df[(df.Type=='table')].groupby('Object', as_index=False)
            final = result.nth(0) # Selecting 1st row of group by result
            #list = []
            for i in range(len(final)):
                #list = list + final.iloc[i].values.tolist()
                if object_value in final.iloc[i].values.tolist():
                    objTable = final.iloc[i].values.tolist()[1]
                    objTableSet = df[(df.Type == 'table') & ((df.Object == objTable))]
                    new_header = objTableSet.iloc[0] #grab the first row for the header
                    objTableSet = objTableSet[1:] #take the data less the header row
                    #objTableSet.set_axis(new_header, axis=1, inplace=True)
                    objTableSet.columns = new_header #set the header row as the df header
                    list = objTableSet[object_value].values.tolist()                    
                    print(objTableSet)
                    print(list)
                    return list
            return None
    except:
        return None

def dfKey_value(df, key, offset = 1):
    '''# return value given object and key
        #def dfKey_value(df, object, key):
    '''
    try:
        # retrieve all URLs as a list
        #df = df[(df.Type == 'key') & (df.Object == object)][['Key', 'Value']]
        #df = df[(df.Type == 'key')][['Key', 'Value']]
        df = df[(df.Type == 'key')].reset_index(drop=True)
        #print(df)
        #df.set_index("Key", inplace = True) # setting first name as index column
        #print(df.loc[key]['Value']) # return specific value of key
        x = df.index[(df['Key']==key)].tolist()[0]
        y = df.columns.get_loc('Key')+offset
        #print(key,x,y)
        #print(df)
        result = df.iloc[x,y]
        #print(result)
        #df.loc[key]['Value']
        return result 
    except KeyError:
        print('Key does not exist - key error:', key)
        #pass
        return None
    except IndexError:
        print('Key does not exist - index error:', key)
        #pass
        return None
#print(dfKey_value(df, 'URL', 'url1'))

def _formula(name:str, code:str = ''):
    logger = get_run_logger()
    logger.info(f"   formula: {name}, parameters: {code}")
    if name.lower() == 'fileuptodate':
        try:
            param1 = code.split(',')[0].strip()
            date_string = code.split(',')[1].strip()
            logger.info(param1 + " | " + date_string)
            param2 = datetime.strptime(date_string, '%Y-%m-%d %H:%M:%S')
            if config.variables['debug_log']: logger.info(f'formula .... name {name} param1 {param1} param2 {param2}')
            return _fileuptodate(param1, param2)
        except Exception as e:
            logger.info(traceback.format_exc())     # Logs the error appropriately. 
            return None
    elif True:
        try:
            #from core.auto_core_lib_helper import Keywords
            from core.Keywords import Keywords
            k = Keywords()
            result = k.run(name.lower(), code)
            return result
        except Exception as e:
            logger.info(traceback.format_exc())     # Logs the error appropriately. 
            return None
        pass
    elif False:
        pass
    return None



def updateConstants(df, code):
    '''Run update constants twice to handle substitutions within formulas'''
    code = _updateConstants(df, code, formulas=False)
    code = _updateConstants(df, code, formulas=True)
    return code

def _updateConstants(df, code, formulas=False):
    '''Search and replace special characters and values i.e. <template values> or {{ template values }} in the code'''
    from config import variables, constants, log_space
    import config
    logger = get_run_logger()
    import re
    matchConstants = re.findall( r'<(.*?)>', code) + re.findall( r'{{(.*?)}}', code)     # Output: ['cats', 'dogs']
    if not matchConstants: 
        return code
    else:
        #matchConstants.sort(key=lambda x: (x != 'abc', x))  # 
        #mylist = ['@user1', 'item2', '@user3', 'item4', '@user5']
        if formulas:
            matchConstants = [item for item in matchConstants if item.startswith('@')]
        else:
            matchConstants = [item for item in matchConstants if not item.startswith('@')]
        # Result: ['item2', 'item4']
    ##logger.info(f"   updateConstants ...', code = {code}, matchConstants = {matchConstants}")

    for item in matchConstants:                
        #logger.info(f"    process item {item}")

        # handle argument list
        itemIndex = None
        if item[-1:]=="]":
            vlist = item.strip("]").strip().rsplit('[',1)
            if len(vlist) == 2:
                if str(vlist[1]).isdigit():
                    itemIndex = int(vlist[1])
                    originalItem = item
                    item = vlist[0]
                    logger.error(log_space + 'Argument list. index:' + str(itemIndex) + ' argument: ' + item)                

        #Evaluate contents
        if len(re.findall( r'[eE][vV][aA][lL]\((.*)\)', item.strip()))>0:
            evalValue=re.findall( r'[eE][vV][aA][lL]\((.*)\)', item.strip()) # greedy mode without ?, instead of lazy mode
            from datetime import datetime
            evalStr = str(evalValue[0])
            print("evalValue:",evalValue, evalStr)
            try:
                value = eval(evalStr)
                code = code.replace("<" + item + ">", str(value))  # replace templated values
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values
            except Exception as e:
                print("Error:", e)

        # formulas
        elif len(re.findall( r'@(.*?)\((.*?)\)', item))>=1:     
            value = ''
            formula = re.findall( r'@(.*?)\((.*?)\)', item) # returns tuple with formula name and parameters
            import traceback
            try:
                name = formula[0][0].strip()
                parameters = formula[0][1].strip()
                value = _formula(name, parameters)
                if config.variables['debug_log']: logger.info(f"   match formula >>> item: {item} formula: {name}, parameters: {parameters}, result: {value}")
                code = code.replace("<" + item + ">", str(value))
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values
            except Exception as e:
                logger.info(traceback.format_exc())     # Logs the error appropriately. 

        # objects with key value pair defined in excel e.g. code has <obj:attribute> 
        elif len(item.split(':')) == 2: 
            ''' objItem:key or objItem:value like <URL_pages:key> <URL_pages:value> <URL_pages:4> where 4 is offset from key, <URL_pages:@custom_header> '''
            obj = item.split(':')[0].strip()
            attribute = item.split(':')[1].strip().strip("\"")  # strip quotes.  Use double quotes to preserve trailing spaces e.g. "some value   ".  

            # handle table objects - old legacy syntax - see below for new syntax
            if obj[:4]=='tbl@':
                obj = obj[4:]
                withHeader = 1
            else:
                withHeader = 0

            # Handle table objects from table object variables - row = iterationCount (starting from 0)
            if obj in config.variables.keys():    # HANDLE dataframe objects
                objTableSet = config.variables[obj]
                if isinstance(objTableSet, pd.DataFrame):
                    if attribute in list(objTableSet.columns.values):
                        objLists = objTableSet[attribute].values.tolist()
                        if 'iterationCount' in constants:
                            value = objLists[constants['iterationCount']]
                            code = code.replace("<" + item + ">", str(value))
                            code = code.replace("{{" + item + "}}", str(value))  # replace templated values

            # HANDLE Table Objects from Excel object with Type table - row = iterationCount (starting from 0)
            elif obj in df[(df.Type == 'table')]['Object'].dropna().values.tolist():  
                #logger.info("A7")
                custom_header_field = attribute
                objTableSet = df[(df.Type == 'table') & ((df.Object == obj))]
                new_header = objTableSet.iloc[0] #grab the first row for the header
                objTableSet = objTableSet[1:] #take the data less the header row
                #objTableSet.set_axis(new_header, axis=1, inplace=True)
                objTableSet.columns = new_header #set the header row as the df header
                objLists = objTableSet[custom_header_field].values.tolist()                    
                if 'iterationCount' in constants:
                    #logger.info("A8")
                    value = objLists[constants['iterationCount']]
                    #logger.info(f"   replace <item> with value in code >>> item: {item}, value: {str(value)}, iterationCount: {str(constants['iterationCount'])}")
                    code = code.replace("<" + item + ">", str(value))
                    code = code.replace("{{" + item + "}}", str(value))  # replace templated values

            # Handling Key:Value pair object - Type key
            #logger.info(f"   match obj >>> item: {item}, key: {obj}, attribute: {attribute}, iterationCount: {str(constants['iterationCount'])}")
            elif obj in df[(df.Type == 'key')]['Object'].dropna().values.tolist():
                # and attribute.lower() in ['key','value','0','1','2','3','4','5','6','7','8','9','10','11']:
                #objLists = df[(df.Type == 'key') & ((df.Object == obj))][['Key','Value']].dropna().values.tolist()
                if withHeader==1:       # table objects with header
                    #logger.info("A1")
                    custom_header_field = attribute
                    objTableSet = df[(df.Type == 'key') & ((df.Object == obj))]
                    new_header = objTableSet.iloc[0] #grab the first row for the header
                    objTableSet = objTableSet[1:] #take the data less the header row
                    #objTableSet.set_axis(new_header, axis=1, inplace=True)
                    objTableSet.columns = new_header #set the header row as the df header
                    objLists = objTableSet[custom_header_field].values.tolist()                    
                elif attribute.lower() == 'key':
                    #logger.info("A2")
                    objLists = df[(df.Type == 'key') & ((df.Object == obj))]['Key'].values.tolist()
                elif attribute.lower() == 'value':
                    #logger.info("A3")
                    objLists = df[(df.Type == 'key') & ((df.Object == obj))]['Value'].values.tolist()
                elif attribute.lower() in ['0','1','2','3','4','5','6','7','8','9','10','11']: # '0', '1', ....
                    #logger.info("A4")
                    offset = int(attribute.lower())
                    columnIndex = df.columns.get_loc('Key')+offset
                    objLists = df[(df.Type == 'key') & ((df.Object == obj))].iloc[:,columnIndex].values.tolist()
                elif attribute.lower()[:1] == '@': # table with custom header
                    #logger.info("A5")
                    custom_header = attribute[1:]
                    objTableSet = df[(df.Type == 'key') & ((df.Object == obj))]
                    new_header = objTableSet.iloc[0] #grab the first row for the header
                    objTableSet = objTableSet[1:] #take the data less the header row
                    #objTableSet.set_axis(new_header, axis=1, inplace=True)
                    objTableSet.columns = new_header #set the header row as the df header
                    objLists = objTableSet[custom_header].values.tolist()
                if 'iterationCount' in constants:
                    #logger.info("A6")
                    value = objLists[constants['iterationCount']]
                    #logger.info(f"   replace <item> with value in code >>> item: {item}, value: {str(value)}, iterationCount: {str(constants['iterationCount'])}")
                    code = code.replace("<" + item + ">", str(value))
                    code = code.replace("{{" + item + "}}", str(value))  # replace templated values

        #Constants defined by user in excel
        elif item in df[(df.Object == 'constants')]['Key'].values.tolist(): 
            value = dfKey_value(df[(df.Object == 'constants')], item)
            if value!=value:  # is NAN
                logger.error(f"{log_space}Updating constants:{item} ->  {value}  isNaN {value!=value}  ")
                value = ''
            #logger.info(f"   match constants >>> key: {item}, value: {str(value)}")            
            code = code.replace("<" + item + ">", str(value))  # replace templated values
            code = code.replace("{{" + item + "}}", str(value))  # replace templated values

        #system constants e.g. ['yesterdayYYYYMMDD', 'yesterdayDDMMYYYY', 'todayDDMMYYYY', 'todayYYYYMMDD', 'iterationCount']:
        elif item in constants: 
            if item == 'iterationCount':
                #logger.info(f"   match iterationCount >>> count = {constants['iterationCount']}")                
                value = constants['iterationCount']
                #code = code.replace("<iterationCount>", str(constants['iterationCount']))  
                code = code.replace("<" + item + ">", str(value))  # replace templated values
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values
            else:
                #logger.info(f"   match system constants >>> key: {item}, value: {str(constants[item])}")                
                value = constants[item]                
                #code = code.replace("<" + item + ">", str(constants[item]))  
                code = code.replace("<" + item + ">", str(value))  # replace templated values
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values

        # variables defined by user in excel  .keys()
        elif item in variables or item in df[(df.Object == 'variables')]['Key'].values.tolist():  
            # or item in df[(df.Object == 'variables')]['Key'].values.tolist(): 
            #logger.info(f"   match variables >>> key: {item}, variables: {variables}")
            if item in variables:       # .keys()
                value = variables[item]
                if isinstance(value, list):     # handle argument list
                    if itemIndex == None:
                        value = value[0]
                    elif len(value) > itemIndex:
                        value = value[itemIndex]
                        item = originalItem
                    else:
                        continue
                code = code.replace("<" + item + ">", str(value))
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values
            else:
                value = dfKey_value(df[(df.Object == 'variables')], item)
                # check if value is nan (when not defined in excel).  And if so, patch it as blank
                import math
                if math.isnan(value):
                    #print('dfkey', type(value), value)
                    value = ''                
                #logger.info(f"   match constants >>> key: {item}, value: {str(value)}")            
                code = code.replace("<" + item + ">", str(value))  # replace templated values
                code = code.replace("{{" + item + "}}", str(value))  # replace templated values

    ##logger.info(f"   Updated Code >>> code: {code}")
    return code



# import configuration Excel
import pandas as pd
from core.files import getFullPath
import config
#print('autohelper lib', startfile)
def readExcelConfig(sheet, excel = config.STARTFILE, refresh=True):
    logger = get_run_logger()
    from config import PROGRAM_DIR, STARTFILE, log_space, variables
    from pathlib import Path, PureWindowsPath

    if variables['debug_log']: logger.info(f"readExcelConfig sheet:{sheet} excel:{excel} refresh:{refresh}")

    #print('readexcelconfig', config.STARTFILE)
    excel = getFullPath(excel)
    filename = Path(excel).name.__str__()
    filepath = Path(excel).parent.resolve().__str__()
    tempfilepath = Path(f"{filepath}/tmp.xlsx").__str__()
    if variables['debug_log']: logger.info(f"readExcelConfig path:{filepath} file:{filename} tmp: {tempfilepath}")

    #logger.info(f"readExcelConfig fullpath {sheet} {excel}")

    #print('excel value', excel)
    #logger.debug(f"{log_space}refreshExcel {sheet} {excel}") # {PROGRAM_DIR} {STARTFILE}
    if refresh:#refreshExcel(excel):        
        import pythoncom
        pythoncom.CoInitialize()    # to avoid com_error: (-2147221008, 'CoInitialize has not been called.', None, None)
        #logger.debug(f'{log_space}Coinitialized')
        from config import CWD_DIR
        #from pathlib import Path
        #logger.debug(f'{log_space}CWD {Path(".").resolve().absolute().__str__()}')  # script dir
        #logger.debug(f'{log_space}CWD_DIR {CWD_DIR}')  # autobot dir
        '''
        #import win32com.client
        #xl=win32com.client.Dispatch("Excel.Application",pythoncom.CoInitialize())
        
        # https://stackoverflow.com/questions/61071022/pywintypes-com-error-2147221008-coinitialize-has-not-been-called-none-n
        office = win32com.client.Dispatch("Excel.Application",pythoncom.CoInitialize())
        wb = office.Workbooks.Open(Path(excel).absolute().__str__())
        wb.RefreshAll()
        office.CalculateUntilAsyncQueriesDone()
        wb.Save()
        wb.Close(SaveChanges=False)
        office.Quit()
        '''
        import xlwings as xw
        # open Excel app in the background
        with xw.App(visible=False) as app:
            wb = app.books.open(Path(excel).absolute().__str__())
            wb.api.RefreshAll()
            logger.debug(f'{log_space}Refreshed: {excel}')
            #sheet = wb.sheets['SheetName']
            #wb.save(Path(excel).absolute().__str__()) # this will overwrite the file
            wb.save(tempfilepath) # this will overwrite the file

        '''
        import xlwings as xw
        # open Excel app in the background
        logger.warning("********************************************************1")

        app_excel = xw.App(visible = False)
        logger.warning("********************************************************2")

        wbk = xw.Book(Path(excel).absolute().__str__())
        wbk.api.RefreshAll()
        logger.debug(f'{log_space}Excel refreshed: {excel}')

        # two options to save
        wbk.save(Path(excel).absolute().__str__()) # this will overwrite the file
        #wbk.save( 'D:\stuff\name1.xlsx' ) # this will save the file with a name
        wbk.close()

        # kill Excel process
        app_excel.kill()
        del app_excel
        #app_excel.quit()
        '''
        processName = "Excel"
        import subprocess
        command = "Get-Process | Where-Object {{$_.Name -Like '{}'}} ".format(processName)
        result = subprocess.run(["powershell.exe", command], capture_output=True)
        if len(result.stdout.decode('ASCII')) > 0:
            logger.warning("process killed" + result.stdout.decode('ASCII'))
            #print("process killed" + result.stdout.decode('ASCII'))

        # read from a temp file
        df = pd.read_excel(tempfilepath, sheet_name=sheet)
    else:
        # read excel
        df = pd.read_excel(excel, sheet_name=sheet)

    #df = df[['Type','Object','Key','Value']][df.Key.notna()]

    #print('readExcel', df.columns.tolist())
    # remove columns with name starting with "Unnamed"
    #df = df.filter(regex='^(?!Unnamed)') # cannot remove Unamed - contains table columns 
    # create a new column with default value
    df = df.assign(Row=df.index+2)  # +2 due to (1) dataframe index starting with 0, and (2) account for header row 
    df = df.assign(Excel=Path(excel).stem)
    df = df.assign(Sheet=sheet)

    df = df[df.Key.notna()]     # do not only filter key and value columns
    #df[['Type','Object']] = df[['Type','Object']].fillna(method='ffill') - fillna is deprecated, use ffill instead
    df[['Type','Object']] = df[['Type','Object']].ffill() # forward fill na / missing values - inplace=True
    import config
    config.constants['iterationCount'] = 0     # reset iterationCount when running a new sheet

    # CHECK if results are correct
    #print(df.columns.tolist())
    #print(df[:10][['Row','Excel','Sheet','Object','Key']])

    return df
    #else:
    #    exit(2)

#dfmain = readExcelConfig('DCLICK2')


# Wrapper for catching exceptions
class CriticalAccessFailure(Exception):
    def __init__(self, err):
        print('a: critical')
        Exception.__init__(self)
        self.error = err
    def __str__(self):
        print('b: critical')
        return "%r" % self.error

from logging import raiseExceptions
def try_catch(func, comment=''):
    logger = get_run_logger()
    try:
        #print('try',func)
        #logger.info(f"'entering try catch func call ', comment = {comment}")
        result = func
    except CriticalAccessFailure as caf:
        #snapImage('Snap picture - Critical Failure - at', '_Fail.PNG')
        print('Critical Error')
        logger.info(f"'Critical failure', level = 'critical', caf = {caf}")
        #logging.critical(caf)
        #AutoCloseMessageBoxW('Citrical failure ... ','TEST_CLOSE',3)
        #copyfile(srcLog, dstLog)
        #r.close()
        #sys.exit(3)
        #exit(3)
    except Exception as e:
        print('Exception error')
        logger.info(f"'exception', e = {e}, level = 'error'")
        #r.close()
        #sys.exit(4)
        pass
    except:
        print('Except error')
        logger.info(f"'except', level = 'error'")
        #r.close()
        #sys.exit(5)
        #exit(3)
        pass
    finally:
        #print('catch finally')
        #logger.info(f"try_catch finally")
        return result

