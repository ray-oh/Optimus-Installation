_G='optimus-telegram-bot'
_F='RUNNING'
_E='run'
_D='list'
_C=True
_B='id'
_A='username'
from prefect import get_client
from prefect.server.schemas.core import FlowRun
from prefect.server.schemas.filters import FlowFilter,FlowFilterName,FlowRunFilter,FlowRunFilterName,FlowRunFilterState,FlowRunFilterStateName,FlowRunFilterStartTime,DeploymentFilter,DeploymentFilterName,FlowRunFilterId,FlowFilterId
import asyncio
from prefect.client import get_client
async def remove_all_flows():
	B=get_client();E=await B.read_flows(limit=15,flow_run_filter=FlowRunFilter(state=FlowRunFilterState(type=FlowRunFilterStateName(any_=[_F]))));A=''
	for C in E:
		D=C.id;await B._client.delete(f"/flows/{D}")
		if A!='':A=A+'\n'
		A=A+f"Deleted flow: {C.name}, UUID {D}"
	return A
from core.dates import localTime
async def prefectQuery(hours=24*1,flowname='',param='J'):
	D=param;from datetime import datetime as L,timedelta as M;C=L.now()-M(hours=hours)
	if'J'in D:E=FlowRunFilter(start_time=FlowRunFilterStartTime(after_=C))
	elif'R'in D:E=FlowRunFilter(state=FlowRunFilterState(type=FlowRunFilterStateName(any_=[_F])),start_time=FlowRunFilterStartTime(after_=C))
	elif'F'in D:E=FlowRunFilter(state=FlowRunFilterState(type=FlowRunFilterStateName(any_=['FAILED','CRASHED'])),start_time=FlowRunFilterStartTime(after_=C))
	async with get_client()as H:
		I=await H.read_flow_runs(flow_filter=FlowFilter(name=FlowFilterName(like_=flowname)),limit=50,flow_run_filter=E);import socket as J;K=J.gethostname();N=J.gethostbyname(K);F=f"{K} VM{N.split('.')[3]}"
		def T(e):print(e);return len(e)
		I.sort(key=lambda x:x.start_time)
		for A in I:
			O=A.total_run_time;P=localTime(A.start_time,'Asia/Hong_Kong',format='%d/%m %H:%M');Q=':'.join(str(O).split(':')[:2])
			if'Completed'in A.state_name:B=' ✅'
			elif'Failed'in A.state_name:B='❌'
			elif'Crashed'in A.state_name:B='⛔️'
			elif'Running'in A.state_name:B='⚡️'
			else:B='⚠️'
			R=await H.read_flows(limit=50,flow_run_filter=FlowRunFilter(id=FlowFilterId(any_=[A.id]),start_time=FlowRunFilterStartTime(after_=C)));S=R[0].name;G=[P,f"({Q})",B,S[:8],A.name.split('-')[1][:7]];G=' '.join(G);F=F+'\n'+G
		return F
if __name__=='__mainXXX__':import asyncio;print(asyncio.run(prefectQuery()))
import nest_asyncio
nest_asyncio.apply()
import logging
from telegram import __version__ as TG_VER
try:from telegram import __version_info__
except ImportError:__version_info__=0,0,0,0,0
if __version_info__<(20,0,0,'alpha',1):raise RuntimeError(f"This example is not compatible with your current PTB version {TG_VER}. To view the {TG_VER} version of this example, visit https://docs.python-telegram-bot.org/en/v{TG_VER}/examples.html")
from telegram import ForceReply,Update
from telegram.ext import Application,CommandHandler,ContextTypes,MessageHandler,filters
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',level=logging.INFO)
logger=logging.getLogger(__name__)
validUser=['raymondoh097']
def userAuthorized(user):return user in validUser
async def start(update,context):
	B=update;A=B.effective_user;print('You talk with user {} and his user ID: {} '.format(A[_A],A[_B]));global token;token='start'
	if not(userAuthorized(A[_A])or userAuthorized(str(A[_B]))):await B.message.reply_html(f"Hi {A.mention_html()}! You are not authorized");return
	await B.message.reply_html(f"Hi {A.mention_html()}! Welcome to Optimus V5.  You can check status of jobs(list) or run specific jobs")
async def help_command(update,context):global token;token='help';await update.message.reply_text('Help!')
async def list_command(update,context):
	A=update;global token;token=_D;B=A.effective_user
	if not(userAuthorized(B[_A])or userAuthorized(str(B[_B]))):await A.message.reply_html(f"Hi {B.mention_html()}! You are not authorized");return
	await A.message.reply_html(f"What do you want to list: type J (job status - optional hours e.g. J24), R (running), F (fail, crashed) or S (available scripts) or D (delete running flow runs)",reply_markup=ForceReply(selective=_C));print(token)
async def run_command(update,context):
	A=update;global token;token=_E;B=A.effective_user
	if not(userAuthorized(B[_A])or userAuthorized(str(B[_B]))):await A.message.reply_html(f"Hi {B.mention_html()}! You are not authorized");return
	await A.message.reply_html(f"Enter name of flow to run: (shortcut:1=prefectdashboard)",reply_markup=ForceReply(selective=_C));print(token)
async def echo(update,context):
	H='scripts';A=update;global token;print(f"echo {token}")
	def I(script):
		A=script;from pathlib import Path as B;C=B().resolve().parent/'runRPA.bat';D=B().resolve().parent/H/f"{A}.xlsm";E=f"{str(C)} -f {A}"
		if C.exists()and D.exists():import subprocess as F;G=F.Popen(E,shell=_C);return _C
		else:return False
	if token==_E:
		import os;print('Path at terminal when executing this file');print(os.getcwd()+'\n')
		if A.message.text=='1':B='prefectdashboard'
		else:B=A.message.text
		if I(script=B):await A.message.reply_text(f"Processed script: {B}")
		else:await A.message.reply_text(f"run file does not exist: {A.message.text}")
	elif token==_D:
		if A.message.text.upper()[:1]in'JRF'or A.message.text=='':
			import asyncio;E=A.message.text.upper();C=int('0'+E[1:])
			if C==0:C=24*1
			D=await prefectQuery(hours=C,param=E);await A.message.reply_text(D)
		elif A.message.text.upper()=='D':import asyncio;D=await remove_all_flows();await A.message.reply_text(D)
		elif A.message.text.upper()=='P':
			def J():from PIL import Image,ImageGrab as B;A=B.grab(bbox=None);A=A.save('D:\\OneDrive-Sync\\OneDrive\\Shared Documents - RPA Project-APAC_FIN\\screen.jpg')
			J();await A.message.reply_text('Print screen')
		elif A.message.text.upper()=='S':
			import os;from pathlib import Path;K=Path().resolve().parent/H;L=str(K);F=[]
			for G in os.listdir(L):
				if G.endswith('.xlsm'):F.append(G[:-5])
			await A.message.reply_text(f"Scripts: {F}")
		else:await A.message.reply_text(f"Did not understand your command: {A.message.text}")
	else:await A.message.reply_text(f"Normal echo: {A.message.text}")
	token='echo'
async def echo2(update,context):A=update;await A.message.reply_text(f"echo 2: {A.message.text}");global token;token='echo2'
from passwords import returnPassword
from prefect.blocks.system import Secret
def retrieve_secret(key=_G):A=Secret.load(key).get();return A
BOT_TOKEN=retrieve_secret(key=_G)
def main():application.run_polling()
token=0
if __name__=='__main__':application=Application.builder().token(BOT_TOKEN).build();application.add_handler(CommandHandler('start',start));application.add_handler(CommandHandler('help',help_command));application.add_handler(CommandHandler(_D,list_command));application.add_handler(CommandHandler(_E,run_command));application.add_handler(MessageHandler(filters.TEXT&~ filters.COMMAND,echo));main()