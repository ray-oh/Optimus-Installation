_F=') but instead is type ('
_E='` should be type ('
_D='Variable `'
_C=False
_B=True
_A="'"
import ast
def parse_args(args):
	E='@@@';C="\\'";A=args
	def F(my_string,delimiter=' , '):
		E=delimiter;D=my_string
		if D.rstrip()=='':return None
		A=D.split(E)
		for B in range(len(A)):
			if not A[B].startswith(_A)and not A[B].endswith(_A):A[B]=_A+A[B].strip().replace(_A,C)+_A
		return E.join(A)
	B=F(A)
	if B==None:A='f()'
	else:A='f({})'.format(B.replace(C,E)).replace('\\','\\\\').replace(E,C)
	G=ast.parse(A);D=G.body[0].value;A=[ast.literal_eval(A)for A in D.args];H={A.arg:ast.literal_eval(A.value)for A in D.keywords};return A,H
def validate_args(func):
	@functools.wraps(func)
	def A(args_str,**A):B,C=parse_args(args_str);A=A|C;return func(*(B),**A)
	return A
import functools
def type_check(func):
	D=func
	@functools.wraps(D)
	def A(*F,**G):
		B=list(F)
		for C in range(len(B)):
			A=B[C];H=list(D.__annotations__.keys())[C];E=list(D.__annotations__.values())[C];I=_D+str(H)+_E+str(E)+_F+str(type(A)).split(_A)[1]+')'
			if isinstance(A,str)and E==int:A=int(A);B[C]=A
			elif isinstance(A,str)and E==bool:J={'true':_B,'false':_C,'1':_B,'0':_C};A=J[A.lower()];B[C]=A
			assert isinstance(A,E),I
		F=tuple(B);return D(*(F),**G)
	return A
@validate_args
@type_check
def my_function(arg1,arg2='2',**A):print(arg1,arg2,A)
@type_check
def my_function2(arg1,arg2):0
def validate_args1(func):
	def A(args_str,**A):B=args_str;print('Validate',B,A);C,D=parse_args(B);print('Validate args:',C,'kwargs2:',D);A=A|D;return func(*(C),**A)
	return A
import functools
def type_check1(func):
	C=func
	def A(*D,**F):
		for E in range(len(D)):
			A=D[E];G=list(C.__annotations__.keys())[E];B=list(C.__annotations__.values())[E];H=_D+str(G)+_E+str(B)+_F+str(type(A)).split(_A)[1]+')'
			if isinstance(A,str)and B==int:A=int(A)
			elif isinstance(A,str)and B==bool:I={'true':_B,'false':_C,'1':_B,'0':_C};A=I[A.lower()]
			assert isinstance(A,B),H
		return C(*(D),**F)
	return A