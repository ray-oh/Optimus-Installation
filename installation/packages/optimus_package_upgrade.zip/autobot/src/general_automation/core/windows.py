from prefect import task,flow,get_run_logger,context
import pygetwindow as gw
from config import log_space
class Window:
	def __init__(A):A.title=[];A.new=[];A.win=[];A.snap()
	def get(A,name=''):return gw.getWindowsWithTitle(name)
	def getTitles(A,name=''):return gw.getWindowsWithTitle(name)
	def snap(E,name=''):
		F=get_run_logger();G=gw.getWindowsWithTitle(name);B=[];C=[];D=f"{log_space}List of open windows:"
		for A in G:
			B=B+[A];C=C+[A.title]
			if not A.title=='':D=D+'\n'+f"     {log_space}"+A.title
		F.debug(f"{D}");E.win=B;E.title=C
	def getNew(A):C=A.get();D=A.win;B=Diff(C,D);A.new=B;return B
	def getTitles(C,selection):
		A=[]
		for B in selection:A=A+[B.title]
		return A
	def closeNew(A):
		B=get_run_logger()
		try:
			B.debug(f"{log_space}Closed:{A.getTitles(A.new)}")
			for C in A.new:C.close()
			A.new=[]
		except Exception as D:B.debug('none closed');B.debug(str(D));pass
	def focus(C,name=''):
		B=get_run_logger()
		try:
			print('Focus *******',name.lower());C.snap()
			for A in C.win:
				if name.lower()in str(A.title).lower():print('selected ****',str(A.title).lower());B.debug(f"{log_space}Focus:{A.title}");A.minimize();A.restore()
		except Exception as D:B.debug('error');B.debug(str(D))
def Diff(li1,li2):A=[A for A in li1 if A not in li2];return A