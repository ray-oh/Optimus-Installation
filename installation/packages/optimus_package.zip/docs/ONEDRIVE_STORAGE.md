# ONE DRIVE
OPTIMUS uses ONE DRIVE for storage and exchange of data or files that can be input for a automation process.  Or output or results of the automation process.
Typically in an enterprise context, this data for ONE DRIVE will be part of a Microsoft TEAMS site.  
Access to the data is controlled by TEAMS.  And the data is synced to the RPA VM via the ONE DRIVE client.  
  
ONE DRIVE folders synced to the desktop as seen in windows explorer. ONE DRIVE Enterprise and ONE DRIVE Personal folders are shown in the example.  
![Onedrive explorer](https://user-images.githubusercontent.com/115925194/213614115-c5c2850c-8161-4a2b-9b1c-0e697540b81e.png)

## TIPS
### Managing Storage Space
Typically, the storage on the VM is limited.  And when running an regular daiy automation script downloading data, significant storage space will be used up over time and requires housekeeping.  
Storage space on the local VM can be freed up by removing from the files on the local VM but keeping the backup on the ONE DRIVE cloud as follows:  
  
Open Settings from ONE DRIVE on the windows taskbar  
![image](https://user-images.githubusercontent.com/115925194/213614712-281201cb-441a-444d-babb-b72a278f5f9f.png)
  
Select *Choose Folders* to manage which folders to sync/view on local VM  
Select *Manage Storage* to view and manage storage of ONE DRIVE space  
![image](https://user-images.githubusercontent.com/115925194/213614969-1bab630a-3b1d-4970-b9fd-fb281d7d3d49.png)
  
From *Choose Folders* - select which folders to view on local VM.  
De-selecting the folder removes all local files stored on the VM but keeps the files on ONE DRIVE cloud.
![image](https://user-images.githubusercontent.com/115925194/213615093-0f2da478-e31c-4325-a370-7d6fd2ead968.png)
  
### References
[Add and Sync Shared Folders to OneDrive](https://support.microsoft.com/en-us/office/add-and-sync-shared-folders-to-onedrive-for-home-8a63cd47-1526-4cd8-bd09-ee3f9bfc1504)  
[Save disk space with OneDrive files on demand for windows](https://support.microsoft.com/en-us/office/save-disk-space-with-onedrive-files-on-demand-for-windows-0e6860d3-d9f3-4971-b321-7092438fb38e)  
[Change location of OneDrive folder](https://support.microsoft.com/en-us/office/change-the-location-of-your-onedrive-folder-f386fb81-1461-40a7-be2c-712676b2c4ae)  
[Sync 2 OneDrive Accounts on One Computer](https://www.multcloud.com/tutorials/sync-two-onedrive-accounts-1004.html#:~:text=Yes%2C%20you%20can%20sync%20two,for%20work%20or%20school%20accounts.)  
[Save space by enabling OneDrive files on demand. Default enabled for all new OneDrive sync clients.](https://support.microsoft.com/en-us/office/save-disk-space-with-onedrive-files-on-demand-for-windows-0e6860d3-d9f3-4971-b321-7092438fb38e)

## Space saving tips in Windows 10
[Automatically free up hard drive space with the Disk Cleanup tool on Windows 10](https://www.windowscentral.com/how-automate-disk-cleanup-tool-windows-10)  
Use Disk Cleanup - "cleanmgr /sageset:11" - setup a clean up setting for scheduling.  
![image](https://github.com/ray-oh/OptimusEnterprise/assets/115925194/8ec4c3ad-8c14-4ee9-81d8-566184e2bf78)
![image](https://github.com/ray-oh/OptimusEnterprise/assets/115925194/c19e0567-2fb9-4241-9d86-4e79b1a1155f)
To check and analyze space in disk for further optimization, can use WizTree - a very fast disk scan and analyzer:  
![image](https://github.com/ray-oh/OptimusEnterprise/assets/115925194/b89e2918-2a17-46ff-bae4-f230606010aa)


[Delete a user profile in Windows](https://learn.microsoft.com/en-us/troubleshoot/windows-server/user-profiles-and-logon/delete-user-profile)


