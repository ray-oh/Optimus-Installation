# Creating installation package for Optimus-Installation repo
- update __version__.py file  
![image](https://github.com/user-attachments/assets/864ad6c5-d238-4be0-9a96-a6bb120546c0)

- create packages using installation\packaging_tool scripts  
![image](https://github.com/user-attachments/assets/ad172cdb-a81b-4834-bc1a-a53db7894b98)
![image](https://github.com/user-attachments/assets/e4428a0a-f41e-4df7-a684-f7e917b0db07)  
![image](https://github.com/user-attachments/assets/2f34d0fa-8b66-4732-aa03-451228a8150d)
  - use minify scripts to secure code
    - full minified package with template folder structures for new install
      - D:\OptimusEnterprise\OptimusEnterprise>.\installation\package_tools\optimus_package_mini.bat
    - minified upgrade package
      - D:\OptimusEnterprise\OptimusEnterprise>.\installation\package_tools\optimus_package_mini_upgrade.bat
- Create a release in the Optimus-Installation repo  
![image](https://github.com/user-attachments/assets/6307b963-a2f5-4441-ae5f-d22d6b404a01)

