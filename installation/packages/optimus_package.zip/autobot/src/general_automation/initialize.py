_M='memoryPath'
_L='generalAutomation.log'
_K='/addon'
_J='/output'
_I='/scripts'
_H='PROGRAM_DIR'
_G='startsheet'
_F='startcode'
_E='retries'
_D='update'
_C='background'
_B='file'
_A='settings'
from config import log_space,startTime,codeVersion,flow_run_name,MEMORYPATH,AUTOBOT_DIR
from auto_initialize import setEnvVar,checkFileValid,checkWorkDirectory,configValidation,initializeFromSettings,setup_assetDirectories,checkSettingsPath,checkSaveSettings,checkStartFile,save_settings,changeWorkingDirectory
from pathlib import Path,PureWindowsPath
from prefect import task,flow,get_run_logger,context
try:isDeploymentFlowRun=not context.get_run_context().flow_run.deployment_id==None;logger=get_run_logger();logger.warning(f"DeploymentFlowRun:{isDeploymentFlowRun}, ID:{context.get_run_context().flow_run.deployment_id}");logger.warning(f"CONTEXT {context.get_run_context().flow_run.parameters[_B]}  {context.get_run_context().flow_run.parameters} {context.get_run_context().flow_run}")
except Exception as e:
	if'No run context'in str(e):isDeploymentFlowRun=False
	else:print(f"Unknown error {e}");exit()
if not isDeploymentFlowRun:
	CWD_DIR=checkWorkDirectory('.');AUTOBOT_DIR=CWD_DIR;import os;SETTINGS_PATH=Path(AUTOBOT_DIR+'/settings.ini').resolve().absolute().__str__();COMMANDS_PATH=Path(AUTOBOT_DIR+'/commands.xlsx').resolve().absolute().__str__()
	if not checkFileValid(Path(SETTINGS_PATH)):raise ValueError(f"Software Error: settings.ini");import sys;sys.exit(EX_CONFIG)
	configObj,program_args=initializeFromSettings(SETTINGS_PATH,deploymentRun=False);options=(option for option in configObj.options(_A))
	for option in options:optionValue=configObj[_A][option];exec(f"{option.upper()} = configObj['settings']['{option.upper()}']")
	for arg in program_args:configObj[_A][arg.upper()]=str(program_args[arg.lower()]);exec(f"{arg.upper()} = program_args['{arg.lower()}']")
	PROGRAM_DIR=Path(CWD_DIR).parent.absolute().__str__();SCRIPTS_DIR=Path(PROGRAM_DIR+_I).resolve().absolute().__str__();OUTPUT_PATH=_J;IMAGE_PATH='/rpa';LOG_PATH='/log';ADDON_PATH=_K;SRCLOGFILE=_L;BACKGROUND=program_args[_C];UPDATE=program_args[_D];RETRIES=program_args[_E];STARTFILE=program_args['startfile'];STARTCODE=program_args[_F];STARTSHEET=program_args[_G]
else:
	import os;SETTINGS_PATH=Path(context.get_run_context().flow_run.parameters[_H]+'/autobot/settings.ini').resolve().absolute().__str__()
	if not checkFileValid(Path(SETTINGS_PATH)):raise ValueError(f"Software Error: settings.ini")
	configObj,program_args=initializeFromSettings(SETTINGS_PATH,deploymentRun=True);PROGRAM_DIR=Path(context.get_run_context().flow_run.parameters[_H]).resolve().absolute().__str__();AUTOBOT_DIR=Path(f"{PROGRAM_DIR}/autobot").resolve().absolute().__str__();CWD_DIR=changeWorkingDirectory(AUTOBOT_DIR);SCRIPTS_DIR=Path(context.get_run_context().flow_run.parameters[_H]+_I).resolve().absolute().__str__();OUTPUT_PATH=_J;IMAGE_PATH='/rpa';LOG_PATH='/log';ADDON_PATH=_K;SRCLOGFILE=_L
	if _C in context.get_run_context().flow_run.parameters:BACKGROUND=context.get_run_context().flow_run.parameters[_C]
	if _D in context.get_run_context().flow_run.parameters:UPDATE=context.get_run_context().flow_run.parameters[_D]
	if _E in context.get_run_context().flow_run.parameters:RETRIES=context.get_run_context().flow_run.parameters[_E]
	if _B in context.get_run_context().flow_run.parameters:STARTFILE=context.get_run_context().flow_run.parameters[_B]
	if _G in context.get_run_context().flow_run.parameters:STARTSHEET=context.get_run_context().flow_run.parameters[_G]
	if _F in context.get_run_context().flow_run.parameters:STARTCODE=context.get_run_context().flow_run.parameters[_F]
	deployment_id=context.get_run_context().flow_run.deployment_id
VERSION=configObj[_A]['version']
if not configObj[_A][_M]=='':MEMORYPATH=configObj[_A][_M]
if MEMORYPATH=='':MEMORYPATH=f"{PROGRAM_DIR}\\memory"
from pathlib import Path,PureWindowsPath
import socket
hostname=str(socket.gethostname())
STARTFILE=checkStartFile(STARTFILE,Path(PROGRAM_DIR)/'scripts')
if not checkFileValid(Path(STARTFILE)):
	if isDeploymentFlowRun:logger.critical(f"SCRIPT START FILE INVALID - Check file path: {Path(STARTFILE)}")
	raise ValueError(f"Start File Error {STARTFILE} PROGRAM DIR {PROGRAM_DIR} {MEMORYPATH} ");exit
else:SCRIPT_NAME,ASSETS_DIR,OUTPUT_DIR,IMAGE_DIR,LOG_DIR,ADDON_DIR,SRCLOG=setup_assetDirectories(STARTFILE,SCRIPTS_DIR,OUTPUT_PATH,IMAGE_PATH,LOG_PATH,ADDON_PATH,SRCLOGFILE)
def configuResultMsg():
	A='%m/%d/%Y, %H:%M:%S'
	if isDeploymentFlowRun:configResultMsg=f"""            {log_space}RPA start  :{startTime.strftime(A)}, {codeVersion}, 
             {log_space}Deployment :{isDeploymentFlowRun}, Id({deployment_id}), 
             {log_space}Program dir:{PROGRAM_DIR}, 
             {log_space}Autobot dir:{AUTOBOT_DIR}, 
             {log_space}Assets dir :{ASSETS_DIR}, 
             {log_space}Working dir:{CWD_DIR}, 
             {log_space}Start file :{STARTFILE}, 
             {log_space}Start sheet:{STARTSHEET}, 
             {log_space}Start code :{STARTCODE}, 
             {log_space}Scripts dir:{SCRIPTS_DIR}, 
             {log_space}Output dir :{OUTPUT_PATH}, 
             {log_space}Image dir  :{IMAGE_PATH}, 
             {log_space}Log dir    :{LOG_PATH}, 
             {log_space}Addon Dir  :{ADDON_PATH}, 
             {log_space}SrcLog file:{SRCLOGFILE}, 
             {log_space}Memory path:{MEMORYPATH}, 
             {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),
             """
	else:configResultMsg=f"""            {log_space}RPA start  :{startTime.strftime(A)}, {codeVersion}, 
             {log_space}Deployment :{isDeploymentFlowRun}, Id(None), 
             {log_space}Program dir:{PROGRAM_DIR}, 
             {log_space}Autobot dir:{AUTOBOT_DIR}, 
             {log_space}Assets dir :{ASSETS_DIR}, 
             {log_space}Working dir:{CWD_DIR}, 
             {log_space}Start file :{STARTFILE}, 
             {log_space}Start sheet:{STARTSHEET}, 
             {log_space}Start code :{STARTCODE}, 
             {log_space}Scripts dir:{SCRIPTS_DIR}, 
             {log_space}Output dir :{OUTPUT_PATH}, 
             {log_space}Image dir  :{IMAGE_PATH}, 
             {log_space}Log dir    :{LOG_PATH}, 
             {log_space}Addon Dir  :{ADDON_PATH}, 
             {log_space}SrcLog file:{SRCLOGFILE}, 
             {log_space}Memory path:{MEMORYPATH}, 
             {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),
             """
	return configResultMsg
import config
config.configObj=configObj
config.program_args=program_args
config.configuResultMsg=configuResultMsg
config.isDeploymentFlowRun=isDeploymentFlowRun
config.PROGRAM_DIR=PROGRAM_DIR
config.SCRIPTS_DIR=SCRIPTS_DIR
config.OUTPUT_PATH=OUTPUT_PATH
config.IMAGE_PATH=IMAGE_PATH
config.IMAGE_DIR=IMAGE_DIR
config.LOG_PATH=LOG_PATH
config.ADDON_PATH=ADDON_PATH
config.SRCLOGFILE=SRCLOGFILE
config.BACKGROUND=BACKGROUND
config.UPDATE=UPDATE
config.RETRIES=RETRIES
config.STARTFILE=STARTFILE
config.STARTCODE=STARTCODE
config.STARTSHEET=STARTSHEET
config.CWD_DIR=CWD_DIR
config.flow_run_name=flow_run_name
config.ASSETS_DIR=ASSETS_DIR
config.AUTOBOT_DIR=AUTOBOT_DIR