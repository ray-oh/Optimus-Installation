#!/usr/bin/env python
_Z='Element is None'
_Y='ERROR: {0} | {1}'
_X='//*[@*="{0}"]'
_W='//*[@name="{0}"]'
_V='//*[@class="{0}"]'
_U='//*[@id="{0}"]'
_T='//*[text()="{0}"]'
_S='text_content_implicit'
_R='password'
_Q='username'
_P='title_fuzzy'
_O='attribute'
_N='text_content_exact2'
_M='text_content_exact'
_L='title_exact'
_K='name'
_J='class'
_I='id'
_H='role'
_G='placeholder'
_F='label'
_E='None'
_D='selector'
_C=True
_B=False
_A=None
import re
from playwright.sync_api import sync_playwright,expect
from core.passwords import retrieveHttpCredentials
from prefect import get_run_logger
logger=get_run_logger()
from config import log_space,RPABROWSER,HIGHLIGHT,EXPECT_VALIDATION
class Browser:
	def __init__(A,**B):A.playwright=_A;A.RPABROWSER=RPABROWSER;A.browsertype=_A;A.browser=_A;A.context=_A;A.page=_A;A.frame=_A;A.view=_A;A.domain=_A;A.http_credentials={_Q:'',_R:''}
	def initialize(A,**B):
		K='Persistent';H='headless';from prefect import get_run_logger as L;C=L();import traceback as M;N={H:_B}
		if not H in B:B[H]=N[H]
		C.debug(f"{log_space}RPABROWSER: {str(RPABROWSER)} Setup: {str(B)}")
		try:
			if A.playwright==_A:
				A.playwright=sync_playwright().start();I=_E;D='';E='';F=''
				if RPABROWSER==1:A.browser=A.new_browser(**B);D=A.browser.browser_type.name;E=A.browser.is_connected().__str__();F=A.browser.contexts.__str__();G=_C
				elif RPABROWSER==2:A.context=A.new_browser(**B);D=K;E=K;F=A.context.__str__();G=_C
			elif RPABROWSER==1:
				if not A.browser.is_connected():A.playwright=sync_playwright().start();A.browser=A.new_browser(**B)
				else:A.page=A.new_page()
				I=str(A.playwright);D=A.browser.browser_type.name;E=A.browser.is_connected().__str__();F=A.browser.contexts.__str__();G=_B
			elif RPABROWSER==2:0
			C.debug(f"{log_space}Playwright {I} | Browser {D} | connected: {E} | context: {F}")
		except Exception as J:C.error('{0}Initialization Error: {1} | {2}'.format(log_space,type(J).__name__,J));C.debug(log_space+M.format_exc());G=_B
		return G
	def new_browser(D,**A):
		from prefect import get_run_logger as E;B=E();C=D.playwright.chromium
		if RPABROWSER==1:B.debug(f"{log_space}Browser launched {str(A)}");return C.launch(**A)
		elif RPABROWSER==2:import os;F=os.getenv('LOCALAPPDATA');G=os.path.join(F,'Chromium\\User Data\\Default');B.debug(f"{log_space}Persistent context created");return C.launch_persistent_context(user_data_dir=G,**A)
	def new_context(A,**B):
		from prefect import get_run_logger as D;C=D()
		if RPABROWSER==2:C.warning(f"{log_space}Reuse existing browser context - RPABROWSER {RPABROWSER}");return A.context
		else:
			C.warning(f"{log_space}New browser context created - RPABROWSER {RPABROWSER}")
			if B=={}:return A.browser.new_context()
			else:return A.browser.new_context(**B)
	def cookies(A):return A.context.cookies()
	def new_page(A):A.page=A.context.new_page();A.frame=_A;A.view=A.page;return A.page
	def close_browser(A):
		F='Persistent browser';E='| context: ';D='| connected:';C='Browser Type:';from prefect import get_run_logger as G;B=G()
		if RPABROWSER==1:A.browser.close();A.playwright.stop();B.warning(log_space+C+A.browser.browser_type.name+D+A.browser.is_connected().__str__()+E+A.browser.contexts.__str__());A.__init__()
		elif RPABROWSER==2:A.context.close();A.playwright.stop();B.warning(log_space+C+F+D+F+E+A.context.__str__());A.__init__()
	def page_goto(A,url,authentication=0,user='',origin='',wait_until='load'):
		O='http_credentials';N='with_credentials';M='changed_credentials';L='changed_to_no_credentials';K=authentication;J='no_credentials';I=wait_until;G=url;C='record_video_dir';F=retrieveHttpCredentials(G,user,origin);E=_A
		try:
			if A.playwright==_A:A.initialize()
			if RPABROWSER==1 and K==1:
				if F[_Q]=='':
					if A.http_credentials!=F:E=L
					else:E=J
				elif A.http_credentials!=F:E=M
				else:E=N
				if A.page!=_A:
					if E==J:0
					elif E==N:0
					elif E==M or E==L:
						if A.page!=_A:A.page.close()
						from config import variables as D;B={O:F}
						if D[C]!=_E:B[C]=D[C]
						A.context=A.new_context(**B);A.page=A.new_page()
				elif E==J:
					from config import variables as D;B={}
					if D[C]!=_E:B[C]=D[C]
					A.context=A.new_context(**B);A.page=A.new_page()
				else:
					from config import variables as D;B={O:F}
					if D[C]!=_E:B[C]=D[C]
					A.context=A.new_context(**B);A.page=A.new_page()
				A.http_credentials=F;A.page.goto(G,wait_until=I);logger.debug(f"{log_space}loaded page")
			elif RPABROWSER==1 and K==0:
				from config import variables as D;B={}
				if D[C]!=_E:B[C]=D[C]
				if A.context==_A:A.context=A.new_context(**B)
				if A.page==_A:A.page=A.new_page()
				A.page.goto(G,wait_until=I);logger.debug(f"{log_space}Loaded page. Arguments: {str(B)}")
			else:
				if A.page==_A:A.page=A.new_page()
				A.page.goto(G,wait_until=I);logger.debug(f"{log_space}loaded page")
		except Exception as H:
			if'net::ERR_UNEXPECTED'in str(H):logger.error(f"{log_space}ERROR: net::ERR_UNEXPECTED. Reload attempted ...");logger.error(f"{log_space}{str(H)}");A.reload()
			else:logger.error(f"{log_space}{str(H)}");raise ValueError(f"{str(H)}")
	def reload(A):A.page.reload()
	def setView(A,**B):
		F='viewType';E='debug';from prefect import get_run_logger as G;C=_C
		if E in B:C=B[E]
		D=G()
		if C:D.debug(f"{log_space}setview"+B.__str__())
		A.view=A.page;A.view=A.frame
		if'page'in B[F]:
			A.view=A.page
			if C:D.debug(f"{log_space}setview - page")
		elif'frame'in B[F]:
			if _D in B.keys():
				A.frame=A.page.frame_locator(B[_D]);A.view=A.frame
				if C:D.debug(f"{log_space}setview - selector: {B[_D]}")
			elif not A.frame==_A:
				A.view=A.frame
				if C:D.debug(f"{log_space}setview - frame")
			else:0
	def _locator(C,selector,debug=_B,timeout=5,validate=EXPECT_VALIDATION,nth_occurence=0):
		M='xpath_css';L='implicit_selectors';G='text_content_fuzzy';F='explicit_selectors';A=selector;from prefect import get_run_logger as N;H=N();A=str(A).strip();import traceback;B=_A
		for D in [F,_F,_G,_H,_I,_J,_K,_L,_M,_N,_O,L,_P,G,'none']:
			if _B:0
			elif D==F:
				E=C.view.locator(A)
				if str(A).startswith('text=')or str(A).startswith('xpath=')or str(A).startswith('//')or str(A).startswith('..')or str(A).startswith('css=')or str(A).startswith('//')or str(A).startswith('..'):B=M;break
				elif str(A).startswith('"')and str(A).endswith('"')or str(A).startswith("'")and str(A).endswith("'"):B=_S;break
				continue;C.page.wait_for_load_state('domcontentloaded');C.page.wait_for_load_state();C.page.wait_for_load_state('networkidle')
			elif D==L:E=C.view.locator(A);B=M
			elif D==_L:E=C.view.get_by_title(A,exact=_C);B=_L
			elif D==_P:E=C.view.get_by_title(A);B=_P
			elif D==_M:E=C.view.get_by_text(A,exact=_C);B=_M
			elif D==_N:E=C.view.locator(_T.format(A));B=_N
			elif D==G:E=C.view.get_by_text(re.compile(A,re.IGNORECASE));B=G
			elif D==_H:
				if'role='in A[:5].lower():I=A[5:].split('|')[0].strip();J=A[5:].split('|')[1].strip();H.error(f'Role="{I}", "{J}"');E=C.view.get_by_role(I,name=J);B=_H
			elif D==_F:E=C.view.get_by_label(A,exact=_C);B=_F
			elif D==_G:E=C.view.get_by_placeholder(A,exact=_C);B=_G
			elif D==_I:E=C.view.locator(_U.format(A));B=_I
			elif D==_J:E=C.view.locator(_V.format(A));B=_J
			elif D==_K:E=C.view.locator(_W.format(A));B=_K
			elif D==_O:E=C.view.locator(_X.format(A));B=_O
			else:B=_A
			try:
				if'xpath'in B and D==F:break
				elif B==_A:break
				if validate:expect(E).to_be_visible(timeout=timeout)
				break
			except Exception as K:
				if debug:H.warning('{0}_locator error: {1} | {2} | {3}'.format(log_space,D,type(K).__name__,K))
				pass
		return B
	def old_wait(D,millisec=15000,**E):
		C=millisec;from prefect import get_run_logger as G;import traceback;H=G()
		try:
			if not _D in E.keys():D.page.wait_for_timeout(C);return _C
			else:
				I=E[_D];import time as A;J=A.time()+int(C/1000)
				while A.time()<J:
					B=D.findElement(I)
					if B==_A:A.sleep(1)
					elif not B.is_visible():A.sleep(1)
					else:break
				if B==_A:return _B
				else:B.wait_for(timeout=C);return _C
		except Exception as F:H.error(log_space+_Y.format(type(F).__name__,F));return _B
	def wait(D,millisec=15000,state='visible',**E):
		A=millisec;from prefect import get_run_logger as G;import traceback;H=G()
		try:
			if not _D in E.keys():D.page.wait_for_timeout(A);return _C
			else:
				I=E[_D];import time as B;J=B.time()+int(A/1000)
				while B.time()<J:
					C=D.findElement(selector=I,validate=_B)
					if C==_A:B.sleep(1)
					else:break
				if C==_A:return _B
				else:C.wait_for(timeout=A,state=state);return _C
		except Exception as F:H.error(log_space+_Y.format(type(F).__name__,F));return _B
	def wait_for_url(A,url,timeout,wait_until):
		from prefect import get_run_logger as B;C=B()
		try:A.page.wait_for_url(url=url,timeout=timeout,wait_until=wait_until);return _C
		except Exception as D:C.debug(f"ERROR: {D}");return _B
	def read(D,xpath,timeout=30000):
		B=timeout;A=xpath;from prefect import get_run_logger as G;import traceback;C=G();C.debug(log_space+'READ: {0} | {1}'.format(A,B))
		try:expect(D.page.locator(f"xpath={A}")).to_have_count(1,timeout=B)
		except Exception as E:C.error(log_space+'READ Error: {0} | {1}'.format(type(E).__name__,E))
		F=D.page.locator(f"xpath={A}").inner_text(timeout=B);C.debug(log_space+'READ result:'+F);return F
	def findElement(D,selector,highlight=HIGHLIGHT,validate=EXPECT_VALIDATION,debug=_B):
		F='debug_log';A=selector;from prefect import get_run_logger as H;import traceback;I=H();import re;A=str(A).strip();C=D._locator(A,debug=debug);import config as E
		if E.variables[F]:print('>>>>',C)
		if _B:0
		elif C==_A:B=_A
		elif'text'in C:
			if C==_S:
				if A.startswith('"'):A=A.strip('"')
				elif A.startswith("'"):A=A.strip("'")
			if C==_M:B=D.view.get_by_text(A,exact=_C)
			else:B=D.view.get_by_text(re.compile(A,re.IGNORECASE))
		elif'xpath'in C or'undefined'in C or C=='error':B=D.view.locator(A)
		elif C==_L:B=D.view.get_by_title(A,exact=_C)
		elif C==_P:B=D.view.get_by_title(A)
		elif _H in C:B=D.view.get_by_role(A[5:].split('|')[0].strip(),name=A[5:].split('|')[1].strip(),exact=_C)
		elif _F in C:B=D.view.get_by_label(A,exact=_C)
		elif _G in C:B=D.view.get_by_placeholder(A,exact=_C)
		elif C==_N:B=D.view.locator(_T.format(A))
		elif C==_I:B=D.view.locator(_U.format(A))
		elif C==_J:B=D.view.locator(_V.format(A))
		elif C==_K:B=D.view.locator(_W.format(A))
		elif C==_O:B=D.view.locator(_X.format(A))
		else:B=_A
		if B==_A:
			G=0
			if E.variables[F]:print('Not found')
		else:
			G=B.count();B=B.first
			if highlight:B.highlight()
			I.debug(log_space+'Type: {0} | {1} | Count: {2} | Visible: {3}'.format(C,A,G,B.is_visible().__str__()))
			if E.variables[F]:print('Found')
		return B
	def selector_exists(C,selector,timeout=3000):
		from prefect import get_run_logger as D;import traceback;E=D()
		try:
			A=C.findElement(selector)
			if A==_A:return _B
			else:A.is_visible(timeout=timeout);return _C
		except Exception as B:E.error(log_space+'Selector Error: {0} | {1}'.format(type(B).__name__,B))
		return _B
	def _exist(A,selector,timeout=3000):
		try:B=A.view.locator(selector).is_visible(timeout=timeout);return _C
		except:return _B
	def click(A,selector,**C):
		B=selector;from prefect import get_run_logger as G;import traceback;D=G();import traceback
		try:
			E=A.findElement(B)
			if E==_A:return _B
			else:E.click(**C);return _C
		except Exception as F:D.error(log_space+'Click Error: {0} | {1}'.format(type(F).__name__,F));D.debug(log_space+traceback.format_exc())
		return _B
		if C=={}:A.page.locator(B).click()
		else:A.page.locator(B).click(**C)
	def hover(D,selector,**E):
		from prefect import get_run_logger as F;import traceback;A=F();import traceback
		try:
			B=D.findElement(selector)
			if B==_A:return _B
			else:B.hover(**E);return _C
		except Exception as C:A.error(log_space+'Hover Error: {0} | {1}'.format(type(C).__name__,C));A.debug(log_space+traceback.format_exc())
		return _B
	def select_option(D,selector,value):
		from prefect import get_run_logger as E;import traceback as F;A=E()
		try:
			B=D.findElement(selector)
			if B==_A:return _B
			else:B.select_option(value);return _C
		except Exception as C:A.error(log_space+'Select Error: {0} | {1}'.format(type(C).__name__,C));A.debug(log_space+F.format_exc())
	def download(B,text,save_as):
		from prefect import get_run_logger as E;import traceback;A=E();import traceback;from pathlib import Path
		try:
			with B.page.expect_download(timeout=600000)as F:
				C=B.findElement(text)
				if C==_A:A.error(log_space+_Z);return _B
				else:C.click();G=F.value
			H=Path(save_as);G.save_as(H);return _C
		except Exception as D:A.error(log_space+'Download Error: {0} | {1}'.format(type(D).__name__,D));A.debug(log_space+traceback.format_exc())
	def upload(B,selector,file):
		from prefect import get_run_logger as E;import traceback;A=E();import traceback;from pathlib import Path
		try:
			C=B.findElement(selector)
			if C==_A:A.error(log_space+_Z);return _B
			else:
				with B.page.expect_file_chooser()as F:C.click()
				G=F.value;G.set_files(file);return _C
		except Exception as D:A.error(log_space+'Upload Error: {0} | {1}'.format(type(D).__name__,D));A.debug(log_space+traceback.format_exc())
	def pause(A):A.page.pause()
	def evaluate(A,*B,**C):D=A.page.evaluate(*(B),**C);return D
	def press(A,key):A.page.keyboard.press(key)
	def authenticate(A,username,origin):B=username;from prefect import get_run_logger as C;import traceback;D=C();E=retrieveHttpCredentials(origin,B);F=A.input(_Q,B);G=A.input(_R,E[_R]);D.debug(log_space+'username:'+str(F)+'password:'+str(G));A.press('Enter')
	def input(D,selector,value):
		from prefect import get_run_logger as E;import traceback;A=E();import traceback
		try:
			B=D.findElement(selector)
			if B==_A:return _B
			else:B.fill(value,no_wait_after=_C);return _C
		except Exception as C:A.error(log_space+'Input Error: {0} | {1}'.format(type(C).__name__,C));A.debug(log_space+traceback.format_exc())
		return _B
	def type(A,keys):A.page.keyboard.type(keys)
	def snap(A,**B):A.page.screenshot(**B)
def test():B='//h2[@title]';C='https://qliksense/sense/app/70c92b52-3e94-4802-994c-5cfdec371d4a/sheet/6299ee78-10be-4f89-b8a9-4746ff64f094/state/analysis/bookmark/e702c838-8bc9-40c9-b7bc-6277ac24646e';A=Browser();A.initialize(headless=_B,slow_mo=500);A.page_goto(C,authentication=1);A.wait(60000,text='Data up to ');print('wait 15 sec');D=A.read(B,13000);A.click('//button[@title="Navigation"]');A.click('//div[@class="qs-toolbar__toggle-touch-switch"]');A.click('//button[text()="Continue"]');A.wait(60000,selector='//html[@class="touch-off"]');A.select_option('//select[@class="qui-select lui-select"]','Local');A.click(B,button='right');A.click('//span[@title="Download as..."]');A.click('text="Data"');A.download('Click here to download your data file.','./test1.xlsx');A.wait();A.close_browser()
p=Browser()
if __name__=='__main__':test()