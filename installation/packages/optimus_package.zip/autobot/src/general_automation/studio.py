
from __version__ import __version__, __description__, __date__, __updated__, __author__
from studio.launcher import launcher_window
print(f'Optimus version:\n{__version__}')
def ensureOneInstance(function, lockfile="program.lock", errorMsg=""):
    
    import os
    import sys
    temp_dir = os.environ["TEMP"]
    lockfile = f"{temp_dir}/{lockfile}"
    try:
        if os.path.exists(lockfile):
            raise RuntimeError(errorMsg)
        with open(lockfile, "w") as f:
            f.write(str(os.getpid()))
        function
    finally:
        os.unlink(lockfile)
ensureOneInstance(launcher_window(__version__, __description__, __date__, __updated__, __author__), 
                "optimuslauncher.lock", "Another instance of Optimus Launcher is running")
