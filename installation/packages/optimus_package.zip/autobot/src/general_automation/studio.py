"""
Launch OPTIMUS studio.launcher
"""
from __version__ import __version__, __description__, __date__, __updated__, __author__
from studio.launcher import launcher_window
print(f'Optimus version:\n{__version__}')

def ensureOneInstance(function, lockfile="program.lock", errorMsg=""):
    """ Prevent multiple instances from running
    """
    import os
    import sys
    temp_dir = os.environ["TEMP"]
    lockfile = f"{temp_dir}/{lockfile}"

    try:
        # Check if the lock file exists
        if os.path.exists(lockfile):
            raise RuntimeError(errorMsg)

        # Create the lock file
        with open(lockfile, "w") as f:
            f.write(str(os.getpid()))

        # Do your program stuff here
        function

    finally:
        # Remove the lock file
        os.unlink(lockfile)

ensureOneInstance(launcher_window(__version__, __description__, __date__, __updated__, __author__), 
                "optimuslauncher.lock", "Another instance of Optimus Launcher is running")
