from __version__ import __version__,__description__,__date__,__updated__,__author__
from studio.launcher import launcher_window
print(f"Optimus version:\n{__version__}")
def ensureOneInstance(function,lockfile='program.lock',errorMsg=''):
	A=lockfile;import os,sys;B=os.environ['TEMP'];A=f"{B}/{A}"
	try:
		if os.path.exists(A):raise RuntimeError(errorMsg)
		with open(A,'w')as C:C.write(str(os.getpid()))
		function
	finally:os.unlink(A)
ensureOneInstance(launcher_window(__version__,__description__,__date__,__updated__,__author__),'optimuslauncher.lock','Another instance of Optimus Launcher is running')