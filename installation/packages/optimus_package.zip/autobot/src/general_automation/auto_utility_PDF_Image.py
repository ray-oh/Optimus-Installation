#!/usr/bin/env python
_A='VeraBd'
from config import *
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
import os
from PyPDF4.pdf import PdfFileReader,PdfFileWriter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('Vera','Vera.ttf'))
pdfmetrics.registerFont(TTFont(_A,'VeraBd.ttf'))
pdfmetrics.registerFont(TTFont('VeraIt','VeraIt.ttf'))
pdfmetrics.registerFont(TTFont('VeraBI','VeraBI.ttf'))
def createPagePdf(numPages,tmp,pageHeight,title):
	c=canvas.Canvas(tmp);print(numPages,len(title))
	for i in range(1,numPages+1):c.setFillColorRGB(255,255,0);c.setFont(_A,22);c.drawString(25*mm,pageHeight-9*mm,title[i-1]);c.showPage()
	c.save()
def addContentPDF(pageTitlesList,sourcePDF,targetPDF):
	tmp='__tmp.pdf';output=PdfFileWriter()
	with open(sourcePDF,'rb')as f:
		pdf=PdfFileReader(f,strict=False);n=pdf.getNumPages();pageHeight=int(pdf.pages[0].mediaBox.getHeight());print('page height',pageHeight);createPagePdf(n,tmp,pageHeight,pageTitlesList)
		with open(tmp,'rb')as ftmp:
			numberPdf=PdfFileReader(ftmp)
			for p in range(n):page=pdf.getPage(p);numberLayer=numberPdf.getPage(p);page.mergePage(numberLayer);output.addPage(page)
			if output.getNumPages():
				with open(targetPDF,'wb')as f:output.write(f)
		os.remove(tmp)
from PIL import Image
def createPDFfromImages(files,path,saveFile):files=files;iterator=map(lambda file:Image.open(path+file).convert('RGB'),files);image_list=list(iterator);image_list[0].save(saveFile,save_all=True,append_images=image_list[1:]);return
from pathlib import Path,PureWindowsPath
def cropImage(files,savefiles,left,top,right,bottom,boolPercentage):
	A=None;i=0
	for file in files:
		im=Image.open(file);width,height=im.size;print('      ','File:',Path(file).name,' Size:',im.size)
		if boolPercentage==True:
			if left is A:left=0
			if top is A:top=0
			if right is A:right=1
			if bottom is A:bottom=1
			left_=int(left)*width;top_=int(top)*height;right_=int(right)*width;bottom_=int(bottom)*height
		else:
			if left is A:left=0
			if top is A:top=0
			if right is A:right=width
			if bottom is A:bottom=height
			left_=int(left);top_=int(top);right_=int(right);bottom_=int(bottom)
		im1=im.crop((left_,top_,right_,bottom_));im1.save(savefiles[i]);i=i+1
	return