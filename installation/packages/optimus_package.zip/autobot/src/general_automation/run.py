_C=None
_B=False
_A=True
from pathlib import Path,PureWindowsPath
import sys,os
from datetime import datetime
from prefect import task,flow,get_run_logger,context
from config import log_space,codeVersion,startTime
from core.files import killprocess
from job_monitor import touchFile,stateChange,write_yaml,read_yaml,triggerRPA
@flow(name='launch-autobot',description='launch autobot rpa flow',version=codeVersion,retries=0)
def run(file='',flowrun=1,deploymentname='',PROGRAM_DIR='',update='',retries='',startcode='',startsheet='',background='',retry_delay_seconds=30,**AK):
	A1='%m/%d/%Y, %H:%M:%S';A0='======================== TEARDOWN ========================';z='script file';y='OPEN_CLOSE';x='PROGRAM_DIR';w='file';v='activate';u='debug';t='arguments';f=deploymentname;e='debug_log';S='error';P=update;K=startsheet;J=startcode;H=flowrun;F=background;E=PROGRAM_DIR;C=file;import core.initialize;D=get_run_logger();D.debug(f"Run started ... ");from pathlib import Path as B;g=B('.').resolve().absolute().__str__()
	if E=='':E=B(g).parents[0].resolve().absolute().__str__()
	h=B(__file__).parents[0].resolve().absolute().__str__();i=B(f"{E}/autobot/venv/Lib/site-packages").resolve().absolute().__str__();A2=B(f"{E}/autobot/src/general_automation").resolve().absolute().__str__();j=B(f"{E}/autobot/src/general_automation/libraries").resolve().absolute().__str__();sys.path.append(h);sys.path.append(i);sys.path.append(A2);sys.path.append(j);D.debug(f"Flow Run Parameters: \n         {log_space}PROGRAM_DIR={E}, \n         {log_space}current_DIR={g} | \n         {log_space}Module path:{h} and {i} and {j} | \n         {log_space}__file__={__file__} | flowExecute file={C}, flowrun={H}, deploymentname={f} ");from config import configuResultMsg as A3;from config import isDeploymentFlowRun;import config as A
	if context.get_run_context().flow_run.deployment_id==_C:
		import config as A
		if C=='':C=A.STARTFILE
		if K=='':K=A.STARTSHEET
		if J=='':J=A.STARTCODE
		if F=='':F=A.BACKGROUND
		if P=='':P=A.UPDATE
		if E=='':E=A.PROGRAM_DIR
		T=B(A.STARTFILE).stem.__str__()+'-'+A.STARTSHEET+'-'+A.STARTCODE
	else:T=f;A.STARTFILE=C;A.UPDATE=P;A.RETRIES=retries;A.BACKGROUND=F
	from config import variables as A4
	if'3'in str(F):A4['headless_mode']=_A
	if'4'in str(F)or'5'in str(F):print(f"background:{F} | Trigger script: {triggerRPA(C,memoryPath=MEMORYPATH)}");return
	A.flow_run_name=context.get_run_context().flow_run.dict()['name'];D.debug(f"RUN Settngs ... \n{A3()}");A.variables['flowrun']=A.flow_run_name;A.variables[t]=A.program_args[t].split('  ,  ');A.variables[S]='';A.variables[u]=_B
	try:
		from core.core import try_catch as L;from core.auto_core_lib import runCodelist as M;from core.files import changeWorkingDirectory as A5;from config import ASSETS_DIR as A6,CWD_DIR,program_args;CWD_DIR=A5(A6);k=f"{E}\\autobot\\_cache\\notifications.pickle";from pathlib import Path as B
		if B(k).exists():from core.files import pickleRead as N;l=N(filename_pickle=k);id=l['id'];Q=l[v]
		else:id='';Q=_B
		m=f"{E}\\autobot\\_cache\\recording.pickle"
		if B(m).exists():
			from core.files import pickleRead as N;U=N(filename_pickle=m);A7=U[w];n=U['folder'];V=U[v]
			if B(n).exists():O=(B(n)/B(A7)).absolute().__str__()
			else:O=''
		else:V=_B;O=''
		o=f"{E}\\autobot\\_cache\\log_settings.pickle"
		if B(o).exists():from core.files import pickleRead as N;A8=N(filename_pickle=o);p=A8['beta']
		else:p=_B
		A.variables[e]=p
		if A.variables[e]:print('Debug_log:',A.variables[e])
		if H==1:
			from libraries.Windows import _runRPAscript;G=context.get_run_context().flow_run.parameters;A9=f"-sc {G['startcode']} -sh {G['startsheet']} -b {G['background']} -r {G['retries']} -u {G['update']}";from pathlib import Path as B;q=B(G[x]).resolve()/'runRPA.bat';W=B(G[x]).resolve()/'scripts'/f"{G[w]}";X=f"{str(q)} -f {W.stem} {A9}";D.warning(X)
			if q.exists()and W.exists():import subprocess as AA;AL=AA.Popen(X,shell=_A);D.warning(f"*** LAUNCH: {W.stem} | {X}")
			return _A
		AB,Y,I,AC,r,R,AM,AD,AE,AF=optimus_open.with_options(name='OPEN',tags=[y])(startfile=C,startsheet=K,startcode=J,background=F,program_dir=E,update=P);A.variables[z]=C
		if H==2:L(M(I,['Deploy:'],file=C))
		elif H==0 or H==3:
			if H==3:A.variables[u]=_A
			from libraries.Browser_tagui import telegram as Z
			if not id==''and Q:Z(id,f"{B(C).stem.split('.')[0]}:⚡️",bypass=_A)
			from libraries.Image import start_recording as AG
			if not O==''and V:AG(file_to_save=f"{O}",fps=10,bypass=_A)
			if r!=_C:D.info('======================== SETUP ========================');L(M(I,r,file=C,df_list=AE))
			D.info(f"============ RUN SCRIPT: {C} ============");L(M(I,AC,file=C,df_list=AD))
			if R!=_C:D.info(A0);L(M(I,R,file=C,df_list=AF))
		optimus_close.with_options(name='CLOSE',tags=[y])(AB,Y,I,C,id,Q,O,V)
	except Exception as a:
		if a.__str__()=='Excel.Application.Workbooks':D.critical(f"kiil process: {killprocess('excel')}")
		try:A.variables[S]=a.__str__();raise ValueError(f"Software Error: {a}")
		finally:
			s=f".\\{A.startTime.strftime('%Y%m%d_%H%M%S')}_{A.flow_run_name}_ERROR.jpg";D.error(f"======================== EXCEPTION ERROR ========================");D.error(f"ERROR {A.variables['codeID']}: {A.variables[S]}");D.error(f"Screenshot: {s}");D.error(f"Excel: {A.variables['Excel']} Sheet: {A.variables['Sheet']} Row: {A.variables['Row']}");from core.files import printscreen as AH;AH(s)
			if R!=_C:D.info(A0);L(M(I,R,file=C))
			from libraries.Browser_tagui import telegram as Z
			if not id==''and Q:Z(id,f"{A.variables[S]}:❌",bypass=_A)
			from config import RPABROWSER as b
			if b==0:import rpa as AI;Y=AI.close();print('Close finally',Y)
			from core.dates import getDuration as c;d=c(startTime,datetime.now());D.info(f"Completed RPA flow. File: {C} | {T} | Sheet: {K} {J} | Time: {datetime.now().strftime(A1)} | {d}")
	from config import RPABROWSER as b
	if b==0:0
	from studio.xpath import saveToExcel as AJ
	if A.variables['Auto save activate']:AJ(dataframe=A.variables['recorded_df_list'],excel=A.variables[z],worksheet='Recorded',mode='w')
	from core.dates import getDuration as c;d=c(startTime,datetime.now());D.info(f"Completed RPA flow. File: {C} | {T} | Sheet: {K} {J} | Time: {datetime.now().strftime(A1)} | {d}");return _A
@task(name='OPEN')
def optimus_open(startfile,startsheet,startcode,background,program_dir,update):
	P='[Teardown]';O='[Setup]';N='RPABROWSER';M='browserDisable';L='main';J=startsheet;I=startfile;G=startcode;E=program_dir;Q=get_run_logger();from core.files import runInBackground as R
	if'1'in str(background):R(E)
	from core.files import isFileNewer,cacheScripts as H;from core.core import dfKey_value as F,dfObjList as D;from core.auto_core_lib import runCodelist;import pandas as S;B='';A,C=H(script=Path(I).name,df=S.DataFrame(),program_dir=E,startsheet=J,refresh=bool(update));B=f"{B}"if C==''else f"{B}\n{log_space*5}{C}";A,C=H(script='OptimusLib.xlsm',df=A,program_dir=E,startsheet=L,refresh=_B);B=f"{B}"if C==''else f"{B}\n{log_space*5}{C}";A,C=H(script='OptimusLibPublic.xlsm',df=A,program_dir=E,startsheet=L,refresh=_B);B=f"{B}"if C==''else f"{B}\n{log_space*5}{C}";T=_B if F(A,M)==_C else F(A,M);U=_B;import config as K;K.RPABROWSER=0 if F(A,N)==_C else int(F(A,N));C=f"Start file:{Path(I).name}, sheet:{J}, RPA Browser:{K.RPABROWSER}\n{log_space*5}Scripts files loaded:"+B;Q.debug(f"{C}");V=D(A,G);W=D(A,G,df_list=_A);X=D(A,G,df_list=_A);Y=D(A,O);Z=D(A,O,df_list=_A);a=D(A,P);b=D(A,P,df_list=_A);return T,U,A,V,Y,a,X,W,Z,b
@task
def optimus_close(browserDisable,instantiatedRPA,dfmain,file,id='',activate=_B,recording_path='',recording_activate=_B):
	A=instantiatedRPA;import rpa as B
	if not browserDisable and not A:A=B.close()
	from libraries.Browser_tagui import telegram as C
	if not id==''and activate:C(id,f"{Path(file).stem.split('.')[0]}:✅",bypass=_A)
	from libraries.Image import stop_recording as D
	if not recording_path==''and recording_activate:D(bypass=_A)
	return