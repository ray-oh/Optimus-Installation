# Standard library imports
import pandas as pd
from pathlib import Path, PureWindowsPath

# Third-party imports
from prefect import task, flow, get_run_logger, context

# Local application/library specific imports
import config
from config import MEMORYPATH, log_space, variables
from auto_helper_lib import updateConstants
#from auto_utility_PDF_Image import *
#from auto_utility_browser import *
#from auto_utility_parsers import *

def runCodelist(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):    
    logger = get_run_logger()
    #logger.info(f"RunCodeList checking ...:  {codeList} ")
    logger.debug(f'INFO: runCodelist #codeList {len(codeList)} | #df_list: {len(df_list)}')
    if len(df_list)==0 and len(codeList)>0:
        df_list = pd.DataFrame(columns=['Type', 'Object', 'Key', 'Value', 'Comments', 'Row', 'Excel', 'Sheet'])
        df_list.loc[0] = ['list', 'main', 'Deploy:', 'Value', 'Comments', 'NA', 'NA', 'NA']
        # duplicate the row n times
        n = len(codeList)
        df_list = pd.concat([df_list]*n, ignore_index=True)

    #logger.info(f'WARNING:RunCodeList {len(codeList)} | {codeList}') #, '|', df_list['Key'].tolist())
    #logger.info(f"ERROR: RunDFList {len(df_list)} | {df_list['Key'].tolist()}") ##, '|', df_list['Key'].tolist())
    #logger.info(f"ERROR: ################################") #, '|', df_list['Key'].tolist())
    if run_code_until != '':
        codeList = codeList[:int(run_code_until)]
        print('******************************ERROR !!!!! **************************************')
        logger.warning(f"{log_space}WARNING *** codeList sliced ****', codeList = {codeList}")
    queueSteps(df, codeList, run_code_until, objVar, file, df_list)
    return

from job_monitor import touchFile

def queueSteps(df: pd.DataFrame, codeList: list = [], run_code_until: str = '', objVar: str = '', file: str = '', df_list:pd.DataFrame = pd.DataFrame()):
    """
    Manage the queue of steps in the code step list.  Inserting additional steps for block codes and removing run steps.
    """
    logger = get_run_logger()

    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    #DFlist = [df] * len(df_list)
    #objVarList = [objVar] * len(df_list)
    i=0
    while len(codeList) > 0: # len(df_list) > 0:
        i += 1
        x = codeList[0]
        x_df_list = df_list.iloc[:1]
        config.variables['df_list'] = x_df_list

        # checking
        #logger.warning(f'INFO: CHECK') #.iloc[0]["Key"] # {config.variables["df_list"]}
        #print(config.variables["df_list"][['Excel','Sheet','Row','Object','Key']])        

        prefix = x.split(':',1)
        codeID = prefix[0].strip()
        if codeID in ['### StartFlow','### EndFlow','rem','_iterationCount']:  #.startswith('_iterationCount') 
            pass
        else:
            logger.debug(f'{"INFO: TRUE" if x==x_df_list.iloc[0]["Key"] else "ERROR: FALSE"}|{codeID}: {i} of code {len(codeList)}/df {len(df_list)}') #.iloc[0]["Key"]

        df = DFlist[0]
        objVar = objVarList[0]
        #logger = get_run_logger()
        #logger.info(f">>>>>runCodelist ...:  {x} {df.__len__()} {objVar}")
        #print('========== RUN STEP ========== | ', x)
        if '### StartFlow' in x:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsFlow.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]

            # codeList.pop(0)
            # DFlist.pop(0)
            # objVarList.pop(0)

        elif '### StartTask' in x:
            index = codeList.index('### EndTask')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])
            print(x.split(':')[1].strip())
            queueStepsTask.with_options(name=x.split(':')[1].strip())(df, codeList[:index+1], run_code_until, objVar)
            codeList = codeList[index+1:]
            DFlist = DFlist[index+1:]
            objVarList = objVarList[index+1:]

            # codeList.pop(0)
            # DFlist.pop(0)
            # objVarList.pop(0)

        else:
            codeList.pop(0)
            #if not codeID in ('_iterationCount'):   # 
            df_list = df_list.iloc[1:]            
            DFlist.pop(0)
            objVarList.pop(0)
            #prefix = x.split(':',1)
            #logger.info(f">>>>>runCodelist ... popped :  {x} {df.__len__()} {objVar}")

            # touch process file - to indicate process still running
            state='process'
            '''touchFile(rf"{MEMORYPATH}\{state}\{Path(file).stem}.txt")
            '''
            if isinstance(x, list):
                logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
                #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y

            else:
                #try_catch(runCode(df, x, objVar), x)
                #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

                from studio.launcher import popup, sub_window
                import PySimpleGUI as sg
                #print('DEBUG .......', config.variables['debug'])
                if 'break point' in config.variables:
                    break_point = config.variables['break point']
                else:
                    break_point = ''
                #print('### BREAK', break_point)

                if config.variables['debug'] and break_point.lower() in x.lower():
                    # pause program
                    #popup(True, 'DEBUG PAUSE', 'Pause Program', 'Pause Program')
                    sub_window(program=f'{x}', title='DEBUG MODE - PAUSE', run=False, disabled=False,
                               replace_window_buttons=True, window_buttons=[sg.Button('Step'), sg.Button('Continue')])

                additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar, x_df_list)
                
                if isinstance(additionalCodeList, pd.DataFrame):

                    logger.debug(f'{log_space}INFO:Queue {len(additionalCodeList)} items to codelist') #, '|', df_list['Key'].tolist()) | {additionalCodeList}
                    #print(additionalCodeList[['Excel','Sheet','Row','Object','Key']])
                    #logger.error(f"ERROR: {len(additionalDFlist)} | {additionalDFlist['Key'].tolist()}") ##, '|', df_list['Key'].tolist())
                    #logger.error(f"ERROR: ++++++++++++++++++++++++++++++++++++++++") #, '|', df_list['Key'].tolist())

                    codeList = additionalCodeList["Key"].tolist() + codeList
                    DFlist = additionalDFlist + DFlist
                    objVarList = additionalobjVarList + objVarList
                    df_list = pd.concat([additionalCodeList, df_list], ignore_index=True, sort=False)    # append

                #logger = get_run_logger()
                elif not (additionalCodeList == None or additionalCodeList == []):
                    #logger.info(f"additional CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")

                    codeList = additionalCodeList + codeList
                    DFlist = additionalDFlist + DFlist
                    objVarList = additionalobjVarList + objVarList

                    #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

                #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
                #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

                import re
                flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
                #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
                #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
    return

@flow(name="Test Flow")
def queueStepsFlow(df, codeList, run_code_until, objVar): #(df: pd.DataFrame, codeList: list, run_code_until: str = '', objVar: str = ''):
    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)
    logger = get_run_logger()
    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]

        #logger = get_run_logger()
        #logger.info(f">>>>>runCodelist ...:  {x} {df.__len__()} {objVar}")

        if x in ['### StartFlow']:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])

        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        #prefix = x.split(':',1)
        #logger.info(f">>>>>runCodelist ... popped :  {x} {df.__len__()} {objVar}")
         
        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
            #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y
        else:
            #try_catch(runCode(df, x, objVar), x)
            #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)



            #logger = get_run_logger()
            if not (additionalCodeList == None or additionalCodeList == []):
                #logger.info(f"additional CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")

                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList

                #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
            #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
            #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
    return

@task(name="Test Flow")
def queueStepsTask(df, codeList, run_code_until, objVar): #(df: pd.DataFrame, codeList: list, run_code_until: str = '', objVar: str = ''):
    logger = get_run_logger()

    DFlist = [df] * len(codeList)
    objVarList = [objVar] * len(codeList)

    while len(codeList) > 0:
        x = codeList[0]
        df = DFlist[0]
        objVar = objVarList[0]
        #logger = get_run_logger()
        #logger.info(f">>>>>runCodelist ...:  {x} {df.__len__()} {objVar}")

        if x in ['### StartFlow']:
            index = codeList.index('### EndFlow')
            print(index, len(codeList), codeList)
            print(codeList[:index+1])
            print(codeList[index+1:])

        codeList.pop(0)
        DFlist.pop(0)
        objVarList.pop(0)
        #prefix = x.split(':',1)
        #logger.info(f">>>>>runCodelist ... popped :  {x} {df.__len__()} {objVar}")

        if isinstance(x, list):
            logger.debug(f"{log_space}click', codeInCodeList = {x[0]}")
            #hoverClick(x[0], 2, 1, x[1], x[2]) # if a list is defined, call with offset x and y
        else:
            #try_catch(runCode(df, x, objVar), x)
            #logger.info(f">>>>>runCodelist ... before runCode :  {x} {df.__len__()} {objVar}")

            additionalCodeList, additionalDFlist, additionalobjVarList = runCode(df, x, objVar)

            #logger = get_run_logger()
            if not (additionalCodeList == None or additionalCodeList == []):
                #logger.info(f"additional CodeList:{additionalCodeList} DFlist: {additionalDFlist.__len__()} objVarList:{additionalobjVarList} ")

                codeList = additionalCodeList + codeList
                DFlist = additionalDFlist + DFlist
                objVarList = additionalobjVarList + objVarList

                #logger.info(f"codeList ...:{codeList} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df)))
            #try_catch(runCodeFlow.with_options(name=flowname, validate_parameters=False)(CodeObject(df), x, objVar))

            import re
            flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', x)
            #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
            #logger.info(f"CHECK codeList ...:{codeList} {codeList.__len__()} DFlist ...:{DFlist.__len__()} objVarList ...:{objVarList}")

        #r.wait(2)
    return


config.variables['Excel']=''
config.variables['Sheet']=''
config.variables['Row']=''
config.variables['Object']=''
config.variables['Key']=''

def runCode(df, code, objVar='', df_list:pd.DataFrame = None):
    logger = get_run_logger()
    #logger.info(f".... start runcode .... code:{code} objVar:{objVar} df:{df.shape}")
    from pathlib import Path, PureWindowsPath    
    prefix = code.split(':',1)
    codeID = prefix[0].strip()

    config.variables['codeID']=codeID
    if not df_list.empty: #!= df_list.empty:
        config.variables['Excel']=df_list.iloc[0]['Excel']
        config.variables['Sheet']=df_list.iloc[0]['Sheet']
        config.variables['Row']=df_list.iloc[0]['Row']
        config.variables['Object']=df_list.iloc[0]['Object']
        config.variables['Key']=df_list.iloc[0]['Key']                

    if codeID == 'rem' or codeID in ['### StartFlow','### EndFlow']: return [], [], []                     # remarks - do nothing
    codeBeforeTemplateUpdate = code
    variables['codeBeforeTemplateUpdate'] = codeBeforeTemplateUpdate
    #logg('### runCode before replacing templated values ###:', CODE = code, OBJVAR = objVar) 
    code = updateConstants(df, code.strip())  # replace templated values
    #logg('### runCode after update template values ###:', CODE = code, OBJVAR = objVar)  
    prefix = code.split(':',1)
    codeID = prefix[0].strip()
    if len(prefix) > 1: 
        codeValue = prefix[1].rstrip() 
    else: 
        codeValue = None

    #run_count = context.get_run_context().task_run.run_count #context.get("task_run_count")
    #logger.info("%s. TaskRun", run_count)
    from config import FLOW_COUNT
    run_count = FLOW_COUNT

    #print(f'RUN {run_count} STEP | {codeBeforeTemplateUpdate}')  # prints code after templated values update

    if not codeBeforeTemplateUpdate.startswith('_iterationCount'): #not '_iterationCount' in codeBeforeTemplateUpdate:
        #{run_count} 
        logger.info(f"RUN STEP | {codeBeforeTemplateUpdate} | {codeBeforeTemplateUpdate==config.variables['Key']}")
    #logger.debug(f"{log_space}EX:{config.variables['Excel']} | SH:{config.variables['Sheet']} | R{config.variables['Row']} | Obj:{config.variables['Object']}")    
    if codeBeforeTemplateUpdate.strip() != code.strip():
        #print('       updated:', code)
        logger.debug(f"{log_space}updated:{code}")
    if False: pass
        #elif codeID in commands_df['commands'].dropna().values.tolist():           #run Block of Code
        #pass
    else:
        import re
        flowname = re.sub('[^a-zA-Z0-9 \n\.]', '_', code)
        #try_catch(runCodeFlow.with_options(name=flowname)(CodeObject(df), x, objVar))
        #return _otherRunCode.with_options(name=flowname)(df, code, codeID, codeValue, objVar)
        from core.auto_core_lib_helper import _otherRunCode
        return _otherRunCode(df, code, codeID, codeValue, objVar)

    #return [], [], []

