_Q='Test Flow'
_P='### EndTask'
_O='### StartTask'
_N='debug_log'
_M='_iterationCount'
_L='[^a-zA-Z0-9 \n\\.]'
_K='Sheet'
_J='Excel'
_I='Row'
_H='### EndFlow'
_G='### StartFlow'
_F='Object'
_E=':'
_D=False
_C=None
_B=True
_A='Key'
import pandas as pd
from pathlib import Path,PureWindowsPath
from prefect import task,flow,get_run_logger,context
import config
from config import MEMORYPATH,log_space,variables
def runCodelist(df,codeList=[],run_code_until='',objVar='',file='',df_list=pd.DataFrame()):
	G='Comments';F='Value';D='NA';C=run_code_until;B=df_list;A=codeList;E=get_run_logger()
	if config.variables[_N]:E.debug(f"INFO: runCodelist #codeList {len(A)} | #df_list: {len(B)}")
	if len(B)==0 and len(A)>0:B=pd.DataFrame(columns=['Type',_F,_A,F,G,_I,_J,_K]);B.loc[0]=['list','main','Deploy:',F,G,D,D,D];H=len(A);B=pd.concat([B]*H,ignore_index=_B)
	if C!='':A=A[:int(C)];print('******************************ERROR !!!!! **************************************');E.warning(f"{log_space}WARNING *** codeList sliced ****', codeList = {A}")
	queueSteps(df,A,C,objVar,file,B);return
def queueSteps(df,codeList=[],run_code_until='',objVar='',file='',df_list=pd.DataFrame()):
	f='break point';e='white';X=run_code_until;W='Auto save activate';S='record';L=objVar;K='recorded_df_list';I=df;F=df_list;A=codeList;M=get_run_logger();G=[I]*len(A);H=[L]*len(A);T=0;g=_C;U=_C;h=_C;i=_C
	while len(A)>0:
		T+=1;I=G[0];B=A[0];L=H[0];D=F.iloc[:1].copy();config.variables['df_list']=D;g=A[0];U=F.iloc[:1];h=G[0];i=H[0];m='process';j=B.split(_E,1);N=j[0].strip()
		if not N in[_G,_H,'rem',_M]:
			if config.variables[_N]:M.debug(f"{'INFO: TRUE'if B==D.iloc[0][_A]else'ERROR: FALSE '+B+'<>'+D.iloc[0][_A]}|{N}: {T} of code {len(A)}/df {len(F)}")
			if not B==D.iloc[0][_A]and _D:Y=len(A)-len(F);O=U;O.loc[O.index[0],_A]=B;F=pd.concat([O,F],ignore_index=_B);D=F.iloc[:1];M.debug(f"INFO PATCHED: x= {B} |  {D.iloc[0][_A]} | {O.iloc[0][_A]} ");M.debug(f"{'INFO PATCHED: TRUE'if B==D.iloc[0][_A]else'ERROR PATCHED: FALSE '+B+'<>'+D.iloc[0][_A]}|{N}: {T} of code {len(A)}/df {len(F)}")
		if isinstance(B,list):M.error('ERROR');M.debug(f"{log_space}click', codeInCodeList = {B[0]}")
		else:
			P=''
			if not W in config.variables:config.variables[W]=_D
			if not S in config.variables:config.variables[S]=_D
			if config.variables[S]:Z=e,'red'
			else:Z=e,'#283b5b'
			if not K in config.variables:Q=[]
			else:Q=config.variables[K][_A].to_list()
			if config.variables['debug']:
				if f in config.variables:V=config.variables[f]
				else:V=''
				if V.lower()in B.lower():
					from studio.launcher import popup,sub_window as k;import FreeSimpleGUI as C
					if not _M in B:from config import variables,constants;a=['Script constants','Script variables','Optimus constants','Optimus variables','Optimus globals','Optimus locals'];b=I[I.Object=='constants'][_A].values.tolist();l=[[C.Text('Interactive Run'),C.Button('Step',key='INTERACTIVE - Step'),C.Button('Continue',key='INTERACTIVE - Continue'),C.Input(V,size=(30,1),key='INTERACTIVE -BREAK POINT'),C.VSeparator(),C.Button('Terminate',key='INTERACTIVE - Terminate')],[C.Button('Record',button_color=Z,key='INTERACTIVE - Record'),C.Button('Save',key='INTERACTIVE - Save'),C.Checkbox('auto save',default=config.variables[W],enable_events=_B,key='INTERACTIVE - Auto Save'),C.VSeparator(),C.Button('Edit',key='INTERACTIVE - Edit'),C.Button('Studio',key='INTERACTIVE - Studio')],[C.Text('Variables'),C.Combo(a,size=(20,1),default_value=a[0],key='INTERACTIVE - VariableType',readonly=_B,enable_events=_B),C.Combo(b,size=(20,1),default_value=b[0],key='INTERACTIVE - Variablelist',readonly=_B,enable_events=_B),C.Input('',size=(15,1),key='INTERACTIVE -Variables'),C.Button('Resolve',key='INTERACTIVE - Resolve')],[C.Text('Next'),C.Combo(A,size=(30,1),default_value=A[0],key='INTERACTIVE - Codelist',readonly=_B),C.Text('Completed'),C.Combo(Q,size=(30,1),default_value=Q[-1]if Q else'',key='INTERACTIVE - completed_Codelist',readonly=_B)]];P=k(program=f"{B}",title='INTERACTIVE MODE - STEP, CONTINUE, MODFIY COMMAND',run=_D,disabled=_D,message=f"[{D.iloc[0][_F]}] Enter/modify command:",variable=[N,I],replace_window_buttons=_B,location=config.variables['window position'],window_buttons=l)
			if not P=='':B=P;D.iloc[0,D.columns.get_loc(_A)]=P
			J,c,d=runCode(I,B,L,D);D.loc[0,_A]=B
			if not K in config.variables:config.variables[K]=D
			else:config.variables[K]=pd.concat([config.variables[K],D.head(1)],ignore_index=_B,sort=_D)
			if not config.variables[S]:A.pop(0);F=F.iloc[1:];G.pop(0);H.pop(0)
			else:0
			if isinstance(J,pd.DataFrame):A=J[_A].tolist()+A;G=c+G;H=d+H;F=pd.concat([J,F],ignore_index=_B,sort=_D)
			elif not(J==_C or J==[]):A=J+A;G=c+G;H=d+H;R=U;Y=len(J);R=pd.concat([R]*Y,ignore_index=_B);R[_A]=J;F=pd.concat([R,F],ignore_index=_B,sort=_D)
			else:0
			import re;n=re.sub(_L,'_',B)
		if _G in B and _D:E=A.index(_H);print(E,len(A),A);print(A[:E+1]);print(A[E+1:]);print(B.split(_E)[1].strip());queueStepsFlow.with_options(name=B.split(_E)[1].strip())(I,A[:E+1],X,L);A=A[E+1:];G=G[E+1:];H=H[E+1:]
		elif _O in B and _D:E=A.index(_P);print(E,len(A),A);print(A[:E+1]);print(A[E+1:]);print(B.split(_E)[1].strip());queueStepsTask.with_options(name=B.split(_E)[1].strip())(I,A[:E+1],X,L);A=A[E+1:];G=G[E+1:];H=H[E+1:]
		elif _B:0
	return
@flow(name=_Q)
def queueStepsFlow(df,codeList,run_code_until,objVar):
	E=objVar;A=codeList;C=[df]*len(A);D=[E]*len(A);H=get_run_logger()
	while len(A)>0:
		B=A[0];df=C[0];E=D[0]
		if B in[_G]:F=A.index(_H);print(F,len(A),A);print(A[:F+1]);print(A[F+1:])
		A.pop(0);C.pop(0);D.pop(0)
		if isinstance(B,list):H.debug(f"{log_space}click', codeInCodeList = {B[0]}")
		else:
			G,I,J=runCode(df,B,E)
			if not(G==_C or G==[]):A=G+A;C=I+C;D=J+D
			import re;K=re.sub(_L,'_',B)
	return
@task(name=_Q)
def queueStepsTask(df,codeList,run_code_until,objVar):
	E=objVar;A=codeList;H=get_run_logger();C=[df]*len(A);D=[E]*len(A)
	while len(A)>0:
		B=A[0];df=C[0];E=D[0]
		if B in[_G]:F=A.index(_H);print(F,len(A),A);print(A[:F+1]);print(A[F+1:])
		A.pop(0);C.pop(0);D.pop(0)
		if isinstance(B,list):H.debug(f"{log_space}click', codeInCodeList = {B[0]}")
		else:
			G,I,J=runCode(df,B,E)
			if not(G==_C or G==[]):A=G+A;C=I+C;D=J+D
			import re;K=re.sub(_L,'_',B)
	return
config.variables[_J]=''
config.variables[_K]=''
config.variables[_I]=''
config.variables[_F]=''
config.variables[_A]=''
def runCode(df,code,objVar='',df_list=_C):
	B=df_list;A=code;from core.core import updateConstants as H;F=get_run_logger();from pathlib import Path,PureWindowsPath;C=A.split(_E,1);D=C[0].strip();config.variables['codeID']=D
	if not B.empty:config.variables[_J]=B.iloc[0][_J];config.variables[_K]=B.iloc[0][_K];config.variables[_I]=B.iloc[0][_I];config.variables[_F]=B.iloc[0][_F];config.variables[_A]=B.iloc[0][_A]
	if D=='rem'or D in[_G,_H]:return[],[],[]
	E=A;variables['codeBeforeTemplateUpdate']=E;A=H(df,A.strip());C=A.split(_E,1);D=C[0].strip()
	if len(C)>1:G=C[1].rstrip()
	else:G=_C
	from config import FLOW_COUNT as I;J=I
	if not E.startswith(_M):F.info(f"RUN STEP | {E} | {E==config.variables[_A]}")
	if E.strip()!=A.strip():F.debug(f"{log_space}updated:{A}")
	if _D:0
	else:import re;K=re.sub(_L,'_',A);return _otherRunCode(df,A,D,G,objVar,B)
def _otherRunCode(df,code,codeID,codeValue,objVar,df_list=_C):
	T=' , ';M=df_list;K=' = ';J='optimusobjVar';I='optimusDF';G=codeValue;F=code;E=codeID;D=objVar;C=df;from prefect import get_run_logger as N;from core.Keywords import Keywords as U;O=U();P=N();import re;Q=re.search('\\((.*?)\\)',F,re.IGNORECASE)
	if Q and F.strip()[-1:]==')':V=Q.group(1).strip();W=re.search('(.*?)\\(',F,re.IGNORECASE);F=W.group(1).strip();import json;variables.update(json.loads(V));print(variables)
	if _D:0
	elif O.present(E.lower())and _E in F:
		import config as B;B.variables[I]=C;B.variables[J]=D;A=O.run(E.lower(),G)
		if isinstance(A,pd.DataFrame):C=B.variables[I];D=B.variables[J];return A,[C]*len(A),[D]*len(A)
		elif A==_C or A==[]:return[],[],[]
		elif isinstance(A,list):C=B.variables[I];D=B.variables[J];return A,[C]*len(A),[D]*len(A)
		else:return[],[],[]
	elif E in C[C.Type=='list'][_F].dropna().values.tolist():
		import config as B;B.variables[I]=C
		if not G==_C:B.variables[E]=G.split(T)
		from libraries.Flows import _runFunction as X;A=X(E,G)
		if isinstance(A,pd.DataFrame):C=B.variables[I];D=B.variables[J];return A,[C]*len(A),[D]*len(A)
		return A,[C]*len(A),[D]*len(A)
	elif E.lower()in '[Arguments]'.lower():
		import config as B;R=M.iloc[0,M.columns.get_loc(_F)]
		for (Y,L) in enumerate(G.split(T)):
			H=L.strip()
			if K in H:H=L.split(K)[0].strip();S=L.split(K)[1].strip()
			else:S=B.variables[R][Y]
			B.variables[H]=S;P.debug(log_space+R+': '+H+K+B.variables[H])
	elif E.lower()in[_O.lower(),_P.lower(),_G.lower(),_H.lower()]:0
	else:from prefect import get_run_logger as N;P.error(f"{log_space}Keyword invalid: {F}")
	return[],[],[]