def parseArg(configObj,deploymentRun):
	E='help';D='startfile';C='settings';B='flag';A=True;from argparse import ArgumentParser,ArgumentDefaultsHelpFormatter,RawDescriptionHelpFormatter;from pathlib import Path;version=configObj[C]['version'];import sys
	if len(sys.argv)>1 or deploymentRun:activateGooey=False;parser=ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter,description='Optimus '+version+'\n'+'Utility to process RPA scripts with steps defined from an Excel input.')
	else:activateGooey=A;parser=parseArgGUI(configObj)
	required=parser.add_argument_group('Required arguments');optional=parser.add_argument_group('Optional arguments')
	def addArg(op,widget_action,activateGooey,defaultValue,typeValue,key):
		B='./scripts/*.xlsm'
		def filelistcheck(value):
			from pathlib import Path;scripts=[f.stem for f in Path.cwd().parents[0].glob(B)]
			if value in scripts:return value
			else:raise TypeError('Incorrect file')
		if not activateGooey:op.add_argument(flag,flagLong,default=defaultValue,type=typeValue,help=help)
		elif key==D:scripts=[f.stem for f in Path.cwd().parents[0].glob(B)];op.add_argument(flag,flagLong,help=help,choices=scripts,widget='FilterableDropdown',type=filelistcheck,gooey_options={'full_width':A},required=A)
		elif'choices['in widget_action:op.add_argument(flag,flagLong,help=help,default=defaultValue,choices=eval(widget_action[7:]))
		elif str(widget_action).lower()in['dirchooser','filechooser','integerfield']:op.add_argument(flag,flagLong,help=help,default=defaultValue,widget=widget_action,required=A)
		elif str(widget_action).lower()in['store','count']:op.add_argument(flag,flagLong,help=help,action=widget_action,default=defaultValue)
		elif typeValue==bool:defaultValue=eval(defaultValue);op.add_argument(flag,flagLong,help=help,widget='CheckBox',default=defaultValue)
		else:op.add_argument(flag,flagLong,default=defaultValue,type=typeValue,help=help)
		return op
	config_keys=configObj.options(B);flags_items=configObj.items(B);help_items=configObj.items(E)
	for key in config_keys:
		flag='-'+configObj[B][key];flagLong='--'+key;typeValue=eval(configObj['type'][key]);defaultValue=configObj[C][key];widget_action=configObj['widget'][key];help=configObj[E][key]
		if key in[D,'program_dir']:required=addArg(required,widget_action,activateGooey,defaultValue,typeValue,key)
		else:optional=addArg(optional,widget_action,activateGooey,defaultValue,typeValue,key)
	args=vars(parser.parse_args());return args