_D='filename.pickle'
_C=None
_B=False
_A=True
from pathlib import Path
from prefect import task,flow,get_run_logger,context
from prefect.task_runners import SequentialTaskRunner
import os
def getFullPath(path):return os.path.abspath(path)
def renameFile(sourceFilePath,targetFilePath):
	A=targetFilePath
	if os.path.exists(A):os.remove(A)
	os.rename(sourceFilePath,A)
def isFileNewer(file1,file2,type='m'):
	B=file2;A=file1;import os.path
	if type=='m':return os.path.getmtime(A)>os.path.getmtime(B)
	elif type=='c':return os.path.getctime(A)>os.path.getctime(B)
	else:return
import time,glob,os
from pathlib import Path,PureWindowsPath
def GetRecentCreatedFile(filepath,filetype,inLastNumOfSec):
	C=filepath;B=inLastNumOfSec;C=Path(C);E=C/filetype;D=glob.glob(str(E))
	if D:
		A=max(D,key=os.path.getctime);print('Latest file',A,'create',time.ctime(os.path.getctime(A)),'>',time.ctime(time.time()-B),os.path.getctime(A)>time.time()-B)
		if os.path.getctime(A)>time.time()-B:print('Time',time.time()-B,'|',A);return A
		else:return _C
	else:return _C
import pandas as pd
from pathlib import Path
from core.core import try_catch,readExcelConfig
from config import log_space
def cacheScripts(script='OptimusLib.xlsm',df=pd.DataFrame(),program_dir='D:/optimus/',startsheet='main',refresh=_B,msgStr=''):
	L='_cache';K=refresh;J=script;I='scripts';G=startsheet;F=program_dir;B=msgStr;A=df;D=Path(J).stem;H=Path(F).joinpath(I,J);E=Path(F).joinpath(I,L,D+'_'+G+'.pickle');M=Path(F).joinpath(I,L,D+'_'+G+'.xlsx')
	if H.exists():
		if E.exists()and isFileNewer(E.__str__(),H.__str__())and not K:C=pd.read_pickle(E.__str__());B=B+f"{D} ---- from Cache"
		else:C=try_catch(readExcelConfig(sheet=G,excel=str(H),refresh=K));B=B+f"{D} ---- from Excel";pd.to_pickle(C,E.__str__());C.to_excel(M.__str__(),index=_B)
		if A.empty:A=C
		else:A=pd.concat([A,C],ignore_index=_A,sort=_B)
	return A,B
def runInBackground(prog_path):E='      ';B=prog_path;from subprocess import Popen;from pathlib import Path as C,PureWindowsPath;import subprocess as D,sys;A=D.run(C(B+'\\autobot\\src\\console.bat').absolute(),capture_output=_A,text=_A);print(E,'Activate remote console session. Return code:',A.returncode,A.stderr);A=D.run(str(C(B+'\\autobot\\src\\Qres\\Qres.exe').absolute())+' /x:1920 /y:1080',capture_output=_A,text=_A);print(E,'Set screen resolution 1920 x 1080.',A.stderr);return
def killprocess(processName,object='Name',match='Like'):
	F='process killed';E='powershell.exe';B='ASCII';G=get_run_logger();import subprocess as C;D="Get-Process | Where-Object {{$_.{} -{} '{}'}} ".format(object,match,processName);A=C.run([E,D],capture_output=_A)
	if len(A.stdout.decode(B))>0:G.info(F+A.stdout.decode(B));print(F+A.stdout.decode(B));A=C.run([E,D+' | Stop-Process -force '],capture_output=_A);return _A
	else:return _B
def printscreen(file='.\\screen.jpg'):from PIL import Image,ImageGrab as B;A=B.grab(bbox=_C);A=A.save(file)
def list_of_files(folder,pattern):import glob,os;A=glob.glob(os.path.join(folder,pattern));return[os.path.basename(B)for B in A]
def _getProgPath():
	C='autobot/assets';from pathlib import Path;A=Path.cwd()
	if (A/C).exists():B=A
	elif (A.parent/C).exists():B=A.parent
	elif (A.parent.parent/C).exists():B=A.parent.parent
	elif (A.parent.parent.parent/C).exists():B=A.parent.parent.parent
	elif (A.parent.parent.parent.parent/C).exists():B=A.parent.parent.parent.parent
	else:raise ValueError('Studio.launcher: Cannot detect program path')
	return B.as_posix()
def get_filename_without_extension(file_path):from pathlib import Path;A=Path(file_path);B=A.stem;C=A.parent;return str(C/B);return B
def readfile(filepath='',sheet_name=0):
	G='Label';F='Command';E='Type';D=filepath;C='Description';B=sheet_name;import pandas as H;print('filepath',D,'sheet',B);A=H.read_excel(D,B)
	if B=='Commands':A[E]=A[E].fillna(method='ffill');A[C]=A[C].astype(str);A[F]=A[F].astype(str)
	if B=='Apps':A[C]=A[C].astype(str);A[G]=A[G].astype(str)
	return A
def jsonWrite(obj,file):
	import json
	with open(file,'w')as A:json.dump(obj,A,indent=4);print(file,obj,' : Write successful');A.close()
	return _A
def jsonRead(file):
	import json
	with open(file,'r')as A:B=json.load(A);print(file,' : Read successful');A.close()
	return B
def checkIfFileOpen(FILENAME):
	import os,pythoncom as A,win32api,win32com.client;C=A.CreateBindCtx(0)
	for D in A.GetRunningObjectTable():
		B=D.GetDisplayName(C,_C)
		if B.endswith(FILENAME):print('Found',B);return _A
		else:0
	return _B
def pickleRead(filename_pickle=_D):
	import pickle as A
	with open(filename_pickle,'rb')as B:C=A.load(B)
	return C
def pickleWrite(obj={},filename_pickle=_D):
	B=filename_pickle;import pickle as C;from pathlib import Path;import os;A=Path(B).parents[0];print('folder',A)
	if not A.exists():os.mkdir(A)
	with open(B,'wb')as D:C.dump(obj,D,protocol=C.HIGHEST_PROTOCOL)
def checkFileValid(file):
	if not file.is_file():print('Warning - Invalid file or path: ',file.absolute());return _B
	return _A
def changeWorkingDirectory(NEW_DIR):import os;os.chdir(NEW_DIR);A=Path('.').absolute().__str__();return A
def checkWorkDirectory(strpath):A=Path(strpath).resolve().absolute().__str__();return A
def checkStartFile(STARTFILE,SCRIPTS_DIR):
	B='.xlsm';A=STARTFILE
	if not A.endswith(('.xls',B,'.xlsx')):A=A+B
	import os
	if len(os.path.dirname(A))==0:A=Path(SCRIPTS_DIR,A)
	else:A=Path(A)
	return A.absolute().__str__()
def setup_assetDirectories(STARTFILE,SCRIPTS_DIR,OUTPUT_PATH,IMAGE_PATH,LOG_PATH,ADDON_PATH,SRCLOGFILE):
	G=STARTFILE;D='/';H=Path(G).name.__str__();I=Path(G).stem.__str__();A=(Path(G).parents[0]/I).resolve().absolute().__str__();B=Path(A+D+OUTPUT_PATH).absolute().__str__();E=Path(A+D+IMAGE_PATH).absolute().__str__();C=Path(A+D+LOG_PATH).absolute().__str__();F=Path(A+D+ADDON_PATH).absolute().__str__();J=Path(C+D+SRCLOGFILE).absolute().__str__()
	if not(Path(A).exists()and Path(B).exists()and Path(E).exists()and Path(C).exists()and Path(F).exists()):
		if not Path(A).exists():os.mkdir(A)
		if not Path(B).exists():os.mkdir(B)
		if not Path(B).exists():os.mkdir(B)
		if not Path(E).exists():os.mkdir(E)
		if not Path(C).exists():os.mkdir(C)
		if not Path(F).exists():os.mkdir(F)
		print('Script Directories created ...')
	return H,A,B,E,C,F,J