_J='ChromeData.db'
_I='Login Data'
_H='default'
_G='User Data'
_F='Chrome'
_E='Google'
_D='AppData'
_C='USERPROFILE'
_B='username'
_A=None
import os,json,base64,sqlite3,win32crypt
from Crypto.Cipher import AES
import shutil
chromePath=os.path.join(os.environ[_C],_D,'Local',_E,_F,_G)
def __get_chrome_datetime(chromedate):from datetime import timezone,datetime as A,timedelta as B;return A(1601,1,1)+B(microseconds=chromedate)
def __get_encryption_key():
	C=os.path.join(chromePath,'Local State')
	with open(C,'r',encoding='utf-8')as D:A=D.read();A=json.loads(A)
	B=base64.b64decode(A['os_crypt']['encrypted_key']);B=B[5:];return win32crypt.CryptUnprotectData(B,_A,_A,_A,0)[1]
def __decrypt_password(password,key):
	A=password
	try:B=A[3:15];A=A[15:];C=AES.new(key,AES.MODE_GCM,B);return C.decrypt(A)[:-16].decode()
	except:
		try:return str(win32crypt.CryptUnprotectData(A,_A,_A,_A,0)[1])
		except:return''
def retrieveSecret(**B):
	H='site';C='          ';M=__get_encryption_key();N=os.path.join(chromePath,_H,_I);E=_J;shutil.copyfile(N,E);I=sqlite3.connect(E);F=I.cursor();A=''
	if _B in B:
		if not B[_B]=='':A=f'username_value="{B[_B]}"'
	if H in B:
		if A!='':A=A+' and'
		A=f'{A} origin_url like "%{B[H]}%"'
	A='where '+A;O=f"select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins {A} order by date_created";F.execute(O);J=_A
	for D in F.fetchall():
		K=D[0];P=D[1];G=D[2];L=__decrypt_password(D[3],M)
		if G or L:print(C+f"Origin URL: {K}");print(C+f"Action URL: {P}");print(C+f"Username: {G}");print(C+f"Password: *************");J={H:f"{K}",'key':f"{G}",'value':f"{L}"};break
		else:continue
	try:F.close();I.close();os.remove(E)
	except:pass
	return J
def retrieveHttpCredentials(url,user='',origin=''):
	D='password';C=origin
	def E(url):from urllib.parse import urlparse as A;B=A(url).netloc;return B
	if not C=='':url=C
	F=E(url);A=retrieveSecret(site=F,username=user)
	if A==_A:return{_B:'',D:''}
	B={};B[_B]=A['key'];B[D]=A['value'];return B
def __main():0
def __testmain():
	I=__get_encryption_key();J=os.path.join(os.environ[_C],_D,'Local',_E,_F,_G,_H,_I);B=_J;shutil.copyfile(J,B);F=sqlite3.connect(B);C=F.cursor();C.execute('select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins where username_value="optimusRPA_bot" and origin_url like "%telegram%" order by date_created')
	for A in C.fetchall():
		K=A[0];L=A[1];G=A[2];H=__decrypt_password(A[3],I);D=A[4];E=A[5]
		if G or H:print(f"Origin URL: {K}");print(f"Action URL: {L}");print(f"Username: {G}");print(f"Password: {H}")
		else:continue
		if D!=86400000000 and D:print(f"Creation date: {str(__get_chrome_datetime(D))}")
		if E!=86400000000 and E:print(f"Last Used: {str(__get_chrome_datetime(E))}")
		print('='*50)
	C.close();F.close()
	try:os.remove(B)
	except:pass
if __name__=='__main__':__main()