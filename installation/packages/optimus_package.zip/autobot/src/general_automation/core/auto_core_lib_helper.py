import pandas as pd

from prefect import task, flow, get_run_logger, context

from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
from pathlib import Path, PureWindowsPath
import rpa as r
from browser import p #Browser
#p = Browser()

from auto_utility_parsers import parseArguments

from core.Keywords import Keywords
k = Keywords()
"""
print('====== Initialize Keywords =======')
print(k.keylistAbbrev)
print('==================================')
"""

def _otherRunCode(df, code, codeID, codeValue, objVar):

    # code for handling block codes - extract parameters if that is defined e.g. command(parameter)
    # parameters are in json string format e.g. {"name":"value","name":"value"}
    import re
    param = re.search('\((.*?)\)', code, re.IGNORECASE)
    ##print("param:", param, "| code:", code)
    if param and code.strip()[-1:]==')':               # if parameters exist
        ##print("param exist")
        parameters = param.group(1).strip()
        command = re.search('(.*?)\(', code, re.IGNORECASE)        
        code = command.group(1).strip()
        ##print(code, parameters)

        import json
        #jsonString = '{"file":"C:\\Users\\roh\\Downloads\\d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
        #jsonString = '{"file": "C:/Users/roh/Downloads/d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
        variables.update(json.loads(parameters))
        print(variables)
    ##print("No param")

    if False: pass
    elif k.present(codeID.lower()):
        """
        If codeID / keyword matches function in module, run the function -> [codelist], [dflist], [objvarlist]
            keywords.init(): check if libraries and modules are loaded, if not load them
                libaries - load core.  And load user defined if exist in script
                validate keys to see if duplicate
            keywords.present(key): keywords.run_codeStr(codeValue) -> bool
                keywords.run(key, module, arguments)
                    keywords.parse_codeStr(codeValue) -> dict of arguments, key, module
                    keywords.arguments(key)
                    keywords.module(key)
                    keywords.validate(codeValue, arguments)
        """
        ##print(f'================= Keyword: {codeID.lower()}')

        import config
        config.variables['optimusDF']=df
        config.variables['optimusobjVar']=objVar
        ##print("xxxxxxxxxxxxxxxxxxxxxxxxxxx Test", codeID.lower(), "|", codeValue)
        sub_code = k.run(codeID.lower(), codeValue) #, df=df, objVar=objVar)

        ##print(f'================= Result for {codeID.lower()}: {str(sub_code)}')

        if isinstance(sub_code, pd.DataFrame):
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

        elif sub_code == None  or sub_code == []: 
            return [], [], []

        else:
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

    elif codeID in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
        #print(f'================= Keyword is a script function: {codeID.lower()}')
        # keyword is a function in the script
        import config
        config.variables['optimusDF']=df
        from Flows import runFunction #isCodeList
        sub_code = runFunction(codeID, codeValue)          #run Block of Code

        if isinstance(sub_code, pd.DataFrame):
            df = config.variables['optimusDF']
            objVar = config.variables['optimusobjVar']
            return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

        return sub_code, [df] * len(sub_code), [objVar] * len(sub_code)

    elif codeID.lower() in ['### StartTask'.lower(), '### EndTask'.lower(), '### StartFlow'.lower(), '### EndFlow'.lower()]:  pass

    else:
        #print('~~~~~~~~~~~~~~~ Keyword invalid')
        from prefect import get_run_logger
        from config import log_space
        logger = get_run_logger()
        logger.error(f'{log_space}Keyword invalid')

    return [], [], []

    if False: pass
    # ------------------ code processing functions ------------------------------
    #elif codeID.lower() == 'rem'.lower():   pass                    # remarks - do nothing
    #elif codeID.lower() == 'print'.lower():  _print(codeValue)
    #elif codeID.lower() == 'log':  _log(codeValue)
    #elif codeID.lower() == 'exit'.lower():    _exit()
    #elif codeID.lower() == 'exitError'.lower():    _exitError(codeValue)                  # exit with an error code e.g. exitError:2
    #elif codeID.lower() == 'raiseError'.lower():    _raiseError(codeValue)                # exit with an error code e.g. exitError:2
    #elif codeID.lower() == 'if'.lower(): return _if(codeValue, df, objVar)                # codeValue = condition : if true block, if false block or if empty then pass

    #elif codeID.lower() == 'wait'.lower():  return _wait(codeValue, df, objVar)                        # wait:time_sec,identifier,run_code
    #elif codeID.lower() == 'waitDisappear'.lower(): return _waitDisappear(codeValue, df, objVar)       # waitDisappear:time_sec,identifier,run_code
    elif codeID.lower() == 'waitFile'.lower(): return _waitFile(codeValue, df, objVar)                  # waitFile: file_pattern, action, timeout, actionIfTimeout
    elif codeID.lower() == 'iterate'.lower(): return _iterate(codeValue, df, objVar)                    # iterate: objlists, runCodelist e.g. iterate: @url_pages : openPage
    elif codeID.lower() == 'iterationCount'.lower(): _iterationCount(codeValue, df, objVar)
    elif codeID.lower() == 'loopWhile'.lower(): return _loopWhile(codeValue, df, objVar)                # while:condition:do this:repeat every X sec
    elif codeID.lower() == 'test'.lower(): _test(codeValue, df, objVar)

    # ------------------ Custom functions ------------------------------
    elif codeID.lower() == 'regexSearch'.lower():        _regexSearch(codeValue)                           # regexSearch:strPattern, strSearch, variable_name e.g. regexSearch:PACIFIC.ASIA.(..........),Last data was imported at,lastDataUpdate
    # ------------------ Custom automation functions using pywinauto ------------------------------
    #elif codeID.lower() == 'openProgram'.lower():       _openProgram(codeValue)                          # keyboard_pwa:path    
    elif codeID.lower() == 'keyboard_pwa'.lower():  _keyboard_pwa(codeValue)        # key press e.g. [home] [end] [insert] [f1] .. [f15] [shift] [ctrl] [alt] [win] [cmd] [enter] [space] [tab] [esc] [backspace] [delete] [clear]

    # ------------------ Browser / Windows functions ------------------------------
    elif codeID.lower() == 'chromeZoom'.lower():  _chromeZoom(codeValue)
    elif codeID.lower() == 'raiseEvent'.lower():   _raiseEvent(codeValue)        # raise event
    elif codeID.lower() == 'ifEvent'.lower():  return _ifEvent(codeValue, df, objVar)  # if event do action
    elif codeID.lower() == 'ifTest'.lower():  return _ifTest(codeValue, df, objVar)  # if event do action

    # ------------------ RPA functions ------------------------------
    elif codeID.lower() == 'runInBackground'.lower():   _runInBackground()  # run automation in background mode without user attendance
    #elif codeID.lower() == 'initializeRPA'.lower(): _initializeRPA(codeValue)
    #elif codeID.lower() == 'closeRPA'.lower():  _closeRPA()
    #elif codeID.lower() == 'url'.lower():       _url(codeValue, df)         # url:OKTA or url:<URL_Dclick_Pages:key> or url:@<URL_Dclick_Pages:@columnHeader>
    #elif codeID.lower() == 'urls'.lower():   _urls(codeValue, objVar)        # No longer required - can remove
    #elif codeID.lower() == 'read'.lower():      _read(codeValue)        # read:checkUserName=okta-signin-username
    elif codeID.lower() == 'checkVariable'.lower(): _checkVariable(codeValue)    # checkVariable:checkUserName
    elif codeID.lower() == 'set'.lower():       _set(codeValue)             # set:checkUserName=value
    elif codeID.lower() == 'increment'.lower():       _increment(codeValue)             # increment:counter, 1    
    elif codeID.lower() == 'urlcontains'.lower(): _urlcontains(codeValue)   # urlcontains:value_to_search,variable_result_true_false
    #elif codeID.lower() == 'keyboard'.lower():  _keyboard(codeValue)        # key press e.g. [home] [end] [insert] [f1] .. [f15] [shift] [ctrl] [alt] [win] [cmd] [enter] [space] [tab] [esc] [backspace] [delete] [clear]
    #elif codeID.lower() == 'type'.lower():      _type(codeValue)            # type
    #elif codeID.lower() == 'rclick'.lower():    _rclick(codeValue)          # right click
    #elif codeID.lower() == 'present'.lower():   _present(codeID, codeValue) # right click
    #elif codeID.lower() == 'exist'.lower():     _exist(codeID, codeValue)   # Waits until the timeout for an element to exist and returns a JavaScript true or false
    #elif codeID.lower() == 'focus'.lower():   _focus(codeID, codeValue) # focus() - app_to_focus (full name of app) - make application in focus
    #elif codeID.lower() == 'popup'.lower():   _popup(codeID, codeValue) # popup(url) - focus tagui rpa on specific tab/browser by url    
    #elif codeID.lower() == 'title'.lower():   _title(codeID, codeValue) # title() - title of current tagui rpa tab/browser session        
    #elif codeID.lower() == 'count'.lower():     _count(codeID, codeValue)   # right click
    #elif codeID.lower() == 'select'.lower():    _select(codeValue)  # Selects a dropdown option in a web input. select:dropdown,option
    #elif codeID.lower() == 'type'.lower():    _type(codeValue)  # type:identifier,value
    #elif codeID.lower() == 'snap'.lower():      _snap(codeValue)    # snap:page,saveFile   Snap entire web page
    #elif codeID.lower() == 'telegram'.lower():  _telegram(codeValue)

    #elif codeID.lower() == 'download'.lower():    _download(codeValue)          # download - selector, file
    #elif codeID.lower() == 'upload'.lower():    _upload(codeValue)          # download - selector, file    
    #elif codeID.lower() == 'setview'.lower():    _setView(codeValue)          # setView - page/frame/selector    
    #elif codeID.lower() == 'pause'.lower():    _pause(codeValue)          # pause - playwright        
    #elif codeID.lower() == 'authenticate'.lower():    _authenticate(codeValue)          # pause - playwright        

    #elif codeID.lower() == 'click'.lower():  _click(codeValue)
    elif codeID.lower() in ['### StartTask'.lower(), '### EndTask'.lower(), '### StartFlow'.lower(), '### EndFlow'.lower()]:  pass
    else:
        from Browser_tagui import click
        click(code)        # normal left click
    return [], [], []

   








def _raiseEvent(codeValue):
    # touchFile: file, path optional
    # e.g. codeValue = 'renameRecentDownloadFile:D:/iCristal/Output/APAC_Daily_Sales/,D:\\iCristal\\,*.pdf,120'
    tmpDict = parseArguments('event',codeValue)
    print('event', tmpDict)
    if 'event' in tmpDict:
        from config import MEMORYPATH        
        filename = f"{MEMORYPATH}/event/{tmpDict['event']}.txt" #'/home/tuhingfg/Desktop'        
        #msg = codeValue.split(',',1)[1].strip()
        #flow_run_name = context.get_run_context().flow_run.dict()['name']  # error if this is not executed in a flow
        from auto_core_lib import touchFile 
        #r.telegram(int(id),f"{flow_run_name}-{msg}")
        print('event raised', touchFile(filename))

def _ifEvent(codeValue, df, objVar):
    tmpDict = parseArguments('event, action1, action2',codeValue)
    print('event','action1','action2', tmpDict)
    if 'event' in tmpDict and 'action1' in tmpDict:     
        # Import Path class
        from pathlib import Path
        from config import MEMORYPATH
        # Path
        path = f"{MEMORYPATH}/event/{tmpDict['event']}.txt" #'/home/tuhingfg/Desktop'
        
        # Instantiate the Path class
        obj = Path(path)
        
        # Check if path exists
        run_code = [tmpDict['action1']]
        if 'action2' in tmpDict:
            run_code_else = [tmpDict['action2']]
        else:
            run_code_else = []
        print(f"ifEvent: {tmpDict['event']} : {obj.exists()}, {run_code} ELSE {run_code_else}")
        if obj.exists():
            obj.unlink(missing_ok=False)  #if missing_ok is false (the default), FileNotFoundError is raised if the path does not exist.
            n = len(run_code)
            print('action1', run_code, n)
            return run_code, [df] * n, [objVar] * n
        else:
            n = len(run_code_else)
            print('action2', run_code_else, n)
            return run_code_else, [df] * n, [objVar] * n            
    else:
        return [], [], []        





def _urlcontains(codeValue):
    search = codeValue.split('=',1)[0]
    result_name = codeValue.split('=',1)[1]
    variables[result_name] = search in r.url()
    #logg('urlcontains: ', search = search, result_name = variables[result_name])        
    print('      ',codeID,codeValue,variables[result_name])



def _test(codeValue, df, objVar):
    logger = get_run_logger()
    result, objTableSet = selectTable(codeValue, df)  # returns objTableSet from worksheet name
    if result: logger.info(objTableSet.head())

def _ifObjectExist(var:str):
    var_exists = var in locals() or var in globals()
    #try:
    #    exec(var)
    #except NameError:
    #    var_exists = False
    #else:
    #    var_exists = True
    print(f"====================================================== {var} {var_exists}")
    #print(locals())
    #print(globals())
    return var_exists



