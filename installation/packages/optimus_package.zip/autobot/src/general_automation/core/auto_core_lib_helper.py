_B=False
_A='event'
from prefect import task,flow,get_run_logger,context
from config import variables,constants,STARTFILE,CWD_DIR,IMAGE_DIR,yesterdayYYYYMMDD,log_space,RPABROWSER
from pathlib import Path,PureWindowsPath
import rpa as r
from browser import p
from auto_utility_parsers import parseArguments
from core.Keywords import Keywords
k=Keywords()
def _otherRunCode(df,code,codeID,codeValue,objVar):
	F='### EndFlow';E='### StartFlow';D='### EndTask';C='### StartTask';B='optimusobjVar';A='optimusDF';import re;param=re.search('\\((.*?)\\)',code,re.IGNORECASE)
	if param and code.strip()[-1:]==')':parameters=param.group(1).strip();command=re.search('(.*?)\\(',code,re.IGNORECASE);code=command.group(1).strip();import json;variables.update(json.loads(parameters));print(variables)
	if _B:0
	elif k.present(codeID.lower()):
		import config;config.variables[A]=df;config.variables[B]=objVar;sub_code=k.run(codeID.lower(),codeValue)
		if sub_code==None or sub_code==[]:return[],[],[]
		else:df=config.variables[A];objVar=config.variables[B];return sub_code,[df]*len(sub_code),[objVar]*len(sub_code)
	elif codeID in df[df.Type=='list']['Object'].dropna().values.tolist():import config;config.variables[A]=df;from Flows import runFunction;sub_code=runFunction(codeID,codeValue);return sub_code,[df]*len(sub_code),[objVar]*len(sub_code)
	elif codeID.lower()in[C.lower(),D.lower(),E.lower(),F.lower()]:0
	else:from prefect import get_run_logger;from config import log_space;logger=get_run_logger();logger.error(f"{log_space}Keyword invalid")
	return[],[],[]
	if _B:0
	elif codeID.lower()=='waitFile'.lower():return _waitFile(codeValue,df,objVar)
	elif codeID.lower()=='iterate'.lower():return _iterate(codeValue,df,objVar)
	elif codeID.lower()=='iterationCount'.lower():_iterationCount(codeValue,df,objVar)
	elif codeID.lower()=='loopWhile'.lower():return _loopWhile(codeValue,df,objVar)
	elif codeID.lower()=='test'.lower():_test(codeValue,df,objVar)
	elif codeID.lower()=='regexSearch'.lower():_regexSearch(codeValue)
	elif codeID.lower()=='keyboard_pwa'.lower():_keyboard_pwa(codeValue)
	elif codeID.lower()=='chromeZoom'.lower():_chromeZoom(codeValue)
	elif codeID.lower()=='raiseEvent'.lower():_raiseEvent(codeValue)
	elif codeID.lower()=='ifEvent'.lower():return _ifEvent(codeValue,df,objVar)
	elif codeID.lower()=='ifTest'.lower():return _ifTest(codeValue,df,objVar)
	elif codeID.lower()=='runInBackground'.lower():_runInBackground()
	elif codeID.lower()=='checkVariable'.lower():_checkVariable(codeValue)
	elif codeID.lower()=='set'.lower():_set(codeValue)
	elif codeID.lower()=='increment'.lower():_increment(codeValue)
	elif codeID.lower()=='urlcontains'.lower():_urlcontains(codeValue)
	elif codeID.lower()in[C.lower(),D.lower(),E.lower(),F.lower()]:0
	else:from Browser_tagui import click;click(code)
	return[],[],[]
def _raiseEvent(codeValue):
	tmpDict=parseArguments(_A,codeValue);print(_A,tmpDict)
	if _A in tmpDict:from config import MEMORYPATH;filename=f"{MEMORYPATH}/event/{tmpDict[_A]}.txt";from auto_core_lib import touchFile;print('event raised',touchFile(filename))
def _ifEvent(codeValue,df,objVar):
	B='action2';A='action1';tmpDict=parseArguments('event, action1, action2',codeValue);print(_A,A,B,tmpDict)
	if _A in tmpDict and A in tmpDict:
		from pathlib import Path;from config import MEMORYPATH;path=f"{MEMORYPATH}/event/{tmpDict[_A]}.txt";obj=Path(path);run_code=[tmpDict[A]]
		if B in tmpDict:run_code_else=[tmpDict[B]]
		else:run_code_else=[]
		print(f"ifEvent: {tmpDict[_A]} : {obj.exists()}, {run_code} ELSE {run_code_else}")
		if obj.exists():obj.unlink(missing_ok=_B);n=len(run_code);print(A,run_code,n);return run_code,[df]*n,[objVar]*n
		else:n=len(run_code_else);print(B,run_code_else,n);return run_code_else,[df]*n,[objVar]*n
	else:return[],[],[]
def _urlcontains(codeValue):search=codeValue.split('=',1)[0];result_name=codeValue.split('=',1)[1];variables[result_name]=search in r.url();print('      ',codeID,codeValue,variables[result_name])
def _test(codeValue,df,objVar):
	logger=get_run_logger();result,objTableSet=selectTable(codeValue,df)
	if result:logger.info(objTableSet.head())
def _ifObjectExist(var):var_exists=var in locals()or var in globals();print(f"====================================================== {var} {var_exists}");return var_exists