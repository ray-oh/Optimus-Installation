#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
windows functions

"""
from prefect import task, flow, get_run_logger, context

# manage windows
# https://pypi.org/project/PyGetWindow/
import pygetwindow as gw
from config import log_space
class Window:
    def __init__(self):
        '''instantiate a new windows object'''
        self.title = []
        self.new = []
        self.win = []
        self.snap()

    def get(self, name=''):
        '''returns list of all windows'''        
        return gw.getWindowsWithTitle(name)

    def getTitles(self, name=''):
        '''returns titles of all windows'''        
        return gw.getWindowsWithTitle(name)
    
    
    def snap(self, name=''):
        '''returns list of all windows'''        
        logger = get_run_logger()    
        selectedWindows = gw.getWindowsWithTitle(name)
        win_list = []
        title_list = []
        titles_str = f"{log_space}List of open windows:"
        for win in selectedWindows:
            #if win.title != '':
            #logger.debug(f'{log_space}Open Windows:{win.title}')
            #print(f'{log_space}Open Windows:{win.title}')
            win_list = win_list + [win]
            title_list = title_list + [win.title]
            if not win.title == '':
                titles_str = titles_str + '\n' + f'     {log_space}' + win.title
        #return result
        #print(win_list, title_list)
        logger.debug(f'{titles_str}')
        self.win = win_list
        self.title = title_list

    def getNew(self):
        new_set = self.get()
        prev_set = self.win
        #print(new_set,prev_set)
        new = Diff(new_set, prev_set)
        #self.win = new_set
        self.new = new
        #self.title = self._title()
        return new

    def getTitles(self, selection):
        titles = []
        for item in selection:
            titles = titles + [item.title]
        return titles
    
    def closeNew(self):
        logger = get_run_logger()    
        try:            
            #print(f'closed {self.new}')
            logger.debug(f'{log_space}Closed:{self.getTitles(self.new)}')
            for win in self.new:
                win.close()
            self.new = []
        except Exception as e:
            logger.debug('none closed')
            logger.debug(str(e))
            pass

    def focus(self, name=''):
        '''bring selected window to front'''
        logger = get_run_logger()    
        try:
            print('Focus *******', name.lower())
            self.snap()
            for win in self.win:  #self.new
                #print('list',str(win.title).lower())
                if name.lower() in str(win.title).lower():
                    print('selected ****',str(win.title).lower())                    
                    logger.debug(f'{log_space}Focus:{win.title}')
                    win.minimize()
                    win.restore()
        except Exception as e:
            logger.debug('error')
            logger.debug(str(e))

# Python code to get difference of two lists
# Not using set()
def Diff(li1, li2):
    #li_dif = [i for i in li1 + li2 if i not in li1 or i not in li2]
    li_dif = [i for i in li1 if i not in li2]
    return li_dif    
