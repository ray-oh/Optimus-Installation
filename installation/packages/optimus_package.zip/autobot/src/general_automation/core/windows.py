
from prefect import task, flow, get_run_logger, context
import pygetwindow as gw
from config import log_space
class Window:
    def __init__(self):
        
        self.title = []
        self.new = []
        self.win = []
        self.snap()
    def get(self, name=''):
                
        return gw.getWindowsWithTitle(name)
    def getTitles(self, name=''):
                
        return gw.getWindowsWithTitle(name)
    def snap(self, name=''):
                
        logger = get_run_logger()    
        selectedWindows = gw.getWindowsWithTitle(name)
        win_list = []
        title_list = []
        titles_str = f"{log_space}List of open windows:"
        for win in selectedWindows:
            win_list = win_list + [win]
            title_list = title_list + [win.title]
            if not win.title == '':
                titles_str = titles_str + '\n' + f'     {log_space}' + win.title
        logger.debug(f'{titles_str}')
        self.win = win_list
        self.title = title_list
    def getNew(self):
        new_set = self.get()
        prev_set = self.win
        new = Diff(new_set, prev_set)
        self.new = new
        return new
    def getTitles(self, selection):
        titles = []
        for item in selection:
            titles = titles + [item.title]
        return titles
    def closeNew(self):
        logger = get_run_logger()    
        try:            
            logger.debug(f'{log_space}Closed:{self.getTitles(self.new)}')
            for win in self.new:
                win.close()
            self.new = []
        except Exception as e:
            logger.debug('none closed')
            logger.debug(str(e))
            pass
    def focus(self, name=''):
        
        logger = get_run_logger()    
        try:
            print('Focus *******', name.lower())
            self.snap()
            for win in self.win:  
                if name.lower() in str(win.title).lower():
                    print('selected ****',str(win.title).lower())                    
                    logger.debug(f'{log_space}Focus:{win.title}')
                    win.minimize()
                    win.restore()
        except Exception as e:
            logger.debug('error')
            logger.debug(str(e))
def Diff(li1, li2):
    li_dif = [i for i in li1 if i not in li2]
    return li_dif    
