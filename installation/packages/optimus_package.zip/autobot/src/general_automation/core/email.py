
import datetime
from pathlib import Path
import win32com.client as win32
from prefect import get_run_logger
from config import log_space
class EmailsSender:
    
    def __init__(self):
        
        logger = get_run_logger()
        try:
            import pythoncom
            pythoncom.CoInitialize()    
            self.outlook = win32.gencache.EnsureDispatch('outlook.application')
        except AttributeError:  
            logger.error("AttributeError - relaunch COM object")
            from pathlib import Path
            import tempfile  
            tempfolder = Path(tempfile.gettempdir(), 'gen_py') 
            f_loc = tempfolder 
            import shutil
            shutil.rmtree(f_loc)
            self.outlook = win32.gencache.EnsureDispatch('outlook.application')
        self.olOutbox = self.outlook.GetNamespace("MAPI").GetDefaultFolder(4) 
    def getSentEmailSubjectList(self, sentEmailSubjectList = [], ofolder=5, cutOffDateTme = datetime.datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)):
        
        if len(sentEmailSubjectList) == 0: sentEmailSubjectList = self.folderItemsList(ofolder=ofolder,dateRange_StartOn=cutOffDateTme) 
        return sentEmailSubjectList
    def send_email(self, boolDisplay=False, boolRun=True, **members):
        
        from pathlib import Path, PureWindowsPath
        from core.files import checkFileValid
        logger = get_run_logger()
        mail = self.outlook.CreateItem(0)
        if not boolRun: 
            logger.debug(f"{log_space}Skip run:{not boolRun}")
            return  
        for key,value in members.items():                               
            if key == "EmailObj":
                for item in value:
                    if item=="To" and value[item] is not None:          mail.To = value[item]
                    elif item=="CC" and value[item] is not None:        mail.CC = value[item]
                    elif item=="Subject" and value[item] is not None:   mail.Subject = value[item]
                    elif item=="Body" and value[item] is not None:      mail.Body = value[item]
                    elif item=="HTMLBody" and value[item] is not None:  mail.HTMLBody = value[item]
                    elif item=="Attachment" and value[item] is not None:
                        attachments = value[item].split(',')
                        for item in attachments:
                            file = Path(item.strip())
                            if file.is_file(): mail.Attachments.Add(file.resolve().absolute().__str__()) 
            else:
                if key=="To" and value is not None: mail.To = value 
                if key=="CC" and value is not None: mail.CC = value 
                if key=="Subject" and value is not None: mail.Subject = value
                if key=="Body" and value is not None: mail.Body = value
                if key=="HTMLBody" and value is not None: mail.HTMLBody = value 
                if key=="Attachment" and value is not None: 
                    attachments = value.split(',')
                    for item in attachments:
                        file = Path(item.strip())
                        if file.is_file(): mail.Attachments.Add(file.resolve().absolute().__str__()) 
        if checkFileValid(Path(mail.HTMLBody)):
            html_file = Path(mail.HTMLBody).resolve().absolute().__str__()
            with open(html_file, 'r') as f:
                mail.HTMLBody = f.read()
                f.close()
        if boolDisplay:     mail.Display(True)
        else:               mail.Send()         
    def wait_send_complete(self, timeOut=900):
        
        logger = get_run_logger()
        logger.debug(f"{log_space}Outbox sending in progress - outbox item count: {self.olOutbox.Items.Count}" )
        import time
        for i in range(timeOut):
            itemsInOutbox = self.olOutbox.Items.Count 
            if itemsInOutbox == 0: return True 
            time.sleep(1) 
            logger.debug(f"{log_space}Timeout countdown {i} to {timeOut}.  Outbox item count: {itemsInOutbox}")
        logger.debug(f'{log_space}Timeout:' + str(itemsInOutbox))
        return False
    def sentFolderList(self):
        logger = get_run_logger()
        logger.debug(f"{log_space}Sentbox item count: {self.outlook.GetNamespace('MAPI').GetDefaultFolder(5).Items.Count}" )
        import win32com.client as win32
        import datetime
        dateRange_StartOn = datetime.datetime(2022, 11, 27, 0, 1)
        dateRange_UpTo =  datetime.datetime(2022, 11, 27, 8, 0)
        sentfolder = self.outlook.GetNamespace('MAPI').GetDefaultFolder(5)
        def tzInfo2Naive(in_dtObj): 
            return datetime.datetime(in_dtObj.year,in_dtObj.month,in_dtObj.day,in_dtObj.hour,in_dtObj.minute)
        print(type(sentfolder.Items))
        format = '%d/%m/%Y %H:%M %p'
        strDate = datetime.datetime.strftime(dateRange_StartOn, format)
        _sFilter_ = "[LastModificationTime] > '" + strDate  + "'"
        print(_sFilter_)
        folderItems = sentfolder.Items.Restrict(_sFilter_)
        logger.debug(f"{log_space}Folder item count: {folderItems.Count}" )
        subjectList = []
        for message in folderItems:
            sub = message
            timeReceived = message.ReceivedTime 
            timeReceived = tzInfo2Naive(timeReceived)
            if not str(sub.Subject) in subjectList:
                print("%s :: %s" % (str(timeReceived), sub.Subject))
                subjectList = subjectList + [str(sub.Subject)]
        return subjectList
    def folderItemsList(self, ofolder=5, dateRange_StartOn = datetime.datetime(2022, 11, 27, 0, 1)):
        
        logger = get_run_logger()
        folder = self.outlook.GetNamespace('MAPI').GetDefaultFolder(ofolder)
        import datetime
        def tzInfo2Naive(in_dtObj): 
            return datetime.datetime(in_dtObj.year,in_dtObj.month,in_dtObj.day,in_dtObj.hour,in_dtObj.minute)
        format = '%m/%d/%Y %H:%M %p'                                    
        strDate = datetime.datetime.strftime(dateRange_StartOn, format) 
        _sFilter_ = "[ReceivedTime] > '" + strDate  + "'"               
        folderItems = folder.Items.Restrict(_sFilter_)
        subjectList = []
        logMaillist = ""
        if folderItems.Count > 0:
            for message in folderItems:  
                sub = message
                timeReceived = message.ReceivedTime 
                timeReceived = tzInfo2Naive(timeReceived)
                if not str(sub.Subject) in subjectList:
                    logMaillist = logMaillist + f"{log_space}{tzInfo2Naive(sub.ReceivedTime)}::{sub.Subject}\n"
                    subjectList = subjectList + [str(sub.Subject)]
            logger.debug(f"{log_space}Sent item count: {folderItems.Count} since {strDate},\n{logMaillist}" )
        return subjectList
    def refreshMail(self):
        logger = get_run_logger()
        nsp = self.outlook.GetNamespace("MAPI")
        objSyncs = nsp.SyncObjects
        objSyc = objSyncs.AppFolders
        from win32com.client import constants
        mpfInbox = nsp.GetDefaultFolder(constants.olFolderInbox)  
        logger.debug(f"{log_space}-----------------------------------refreshMail")
        objSyc.Start
        objSyc.Stop
        msg = mpfInbox.Items
        msgs = msg.GetLast().ReceivedTime 
        print(msgs)
