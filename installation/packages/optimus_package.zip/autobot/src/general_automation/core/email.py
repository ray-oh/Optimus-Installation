_A='MAPI'
import datetime
from pathlib import Path
import win32com.client as win32
from prefect import get_run_logger
from config import log_space
class EmailsSender:
	def __init__(A):
		B='outlook.application';C=get_run_logger()
		try:import pythoncom as D;D.CoInitialize();A.outlook=win32.gencache.EnsureDispatch(B)
		except AttributeError:C.error('AttributeError - relaunch COM object');from pathlib import Path;import tempfile as E;F=Path(E.gettempdir(),'gen_py');G=F;import shutil as H;H.rmtree(G);A.outlook=win32.gencache.EnsureDispatch(B)
		A.olOutbox=A.outlook.GetNamespace(_A).GetDefaultFolder(4)
	def getSentEmailSubjectList(B,sentEmailSubjectList=[],ofolder=5,cutOffDateTme=datetime.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)):
		A=sentEmailSubjectList
		if len(A)==0:A=B.folderItemsList(ofolder=ofolder,dateRange_StartOn=cutOffDateTme)
		return A
	def send_email(O,boolDisplay=False,boolRun=True,**P):
		N='Attachment';M='HTMLBody';L='Body';K='Subject';I=boolRun;D=None;from pathlib import Path as G,PureWindowsPath;from core.files import checkFileValid as Q;R=get_run_logger();C=O.outlook.CreateItem(0)
		if not I:R.debug(f"{log_space}Skip run:{not I}");return
		for (E,A) in P.items():
			if E=='EmailObj':
				for B in A:
					if B=='To'and A[B]is not D:C.To=A[B]
					elif B=='CC'and A[B]is not D:C.CC=A[B]
					elif B==K and A[B]is not D:C.Subject=A[B]
					elif B==L and A[B]is not D:C.Body=A[B]
					elif B==M and A[B]is not D:C.HTMLBody=A[B]
					elif B==N and A[B]is not D:
						H=A[B].split(',')
						for B in H:
							F=G(B.strip())
							if F.is_file():C.Attachments.Add(F.resolve().absolute().__str__())
			else:
				if E=='To'and A is not D:C.To=A
				if E=='CC'and A is not D:C.CC=A
				if E==K and A is not D:C.Subject=A
				if E==L and A is not D:C.Body=A
				if E==M and A is not D:C.HTMLBody=A
				if E==N and A is not D:
					H=A.split(',')
					for B in H:
						F=G(B.strip())
						if F.is_file():C.Attachments.Add(F.resolve().absolute().__str__())
		if Q(G(C.HTMLBody)):
			S=G(C.HTMLBody).resolve().absolute().__str__()
			with open(S,'r')as J:C.HTMLBody=J.read();J.close()
		if boolDisplay:C.Display(True)
		else:C.Send()
	def wait_send_complete(C,timeOut=900):
		D=timeOut;A=get_run_logger();A.debug(f"{log_space}Outbox sending in progress - outbox item count: {C.olOutbox.Items.Count}");import time
		for E in range(D):
			B=C.olOutbox.Items.Count
			if B==0:return True
			time.sleep(1);A.debug(f"{log_space}Timeout countdown {E} to {D}.  Outbox item count: {B}")
		A.debug(f"{log_space}Timeout:"+str(B));return False
	def sentFolderList(E):
		F=get_run_logger();F.debug(f"{log_space}Sentbox item count: {E.outlook.GetNamespace(_A).GetDefaultFolder(5).Items.Count}");import win32com.client as N,datetime as B;K=B.datetime(2022,11,27,0,1);O=B.datetime(2022,11,27,8,0);G=E.outlook.GetNamespace(_A).GetDefaultFolder(5)
		def L(in_dtObj):A=in_dtObj;return B.datetime(A.year,A.month,A.day,A.hour,A.minute)
		print(type(G.Items));format='%d/%m/%Y %H:%M %p';M=B.datetime.strftime(K,format);H="[LastModificationTime] > '"+M+"'";print(H);I=G.Items.Restrict(H);F.debug(f"{log_space}Folder item count: {I.Count}");A=[]
		for J in I:
			C=J;D=J.ReceivedTime;D=L(D)
			if not str(C.Subject)in A:print('%s :: %s'%(str(D),C.Subject));A=A+[str(C.Subject)]
		return A
	def folderItemsList(J,ofolder=5,dateRange_StartOn=datetime.datetime(2022,11,27,0,1)):
		K=get_run_logger();L=J.outlook.GetNamespace(_A).GetDefaultFolder(ofolder);import datetime as E
		def F(in_dtObj):A=in_dtObj;return E.datetime(A.year,A.month,A.day,A.hour,A.minute)
		format='%m/%d/%Y %H:%M %p';G=E.datetime.strftime(dateRange_StartOn,format);M="[ReceivedTime] > '"+G+"'";C=L.Items.Restrict(M);A=[];D=''
		if C.Count>0:
			for H in C:
				B=H;I=H.ReceivedTime;I=F(I)
				if not str(B.Subject)in A:D=D+f"{log_space}{F(B.ReceivedTime)}::{B.Subject}\n";A=A+[str(B.Subject)]
			K.debug(f"{log_space}Sent item count: {C.Count} since {G},\n{D}")
		return A
	def refreshMail(C):D=get_run_logger();A=C.outlook.GetNamespace(_A);E=A.SyncObjects;B=E.AppFolders;from win32com.client import constants as F;G=A.GetDefaultFolder(F.olFolderInbox);D.debug(f"{log_space}-----------------------------------refreshMail");B.Start;B.Stop;H=G.Items;I=H.GetLast().ReceivedTime;print(I)