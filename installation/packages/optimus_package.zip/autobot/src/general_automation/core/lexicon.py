
import ast
def parse_args(args):
    
    def encapsulate_items(my_string:str, delimiter:str=" , "):
        
        if my_string.rstrip() == '': return None
        items = my_string.split(delimiter)
        for i in range(len(items)):
            if not items[i].startswith('\'') and not items[i].endswith('\''):
                items[i] = '\'' + items[i].strip().replace("'", "\\'") + '\''
        result = delimiter.join(items)
        from config import variables
        if variables['debug_log']: print('Encapsulated', result)
        result = result.replace(", ,", ", None ,").rstrip()
        if result[-1:]==',': result=result[:-1]
        if variables['debug_log']: print(result)
        return result
    encapsulated_args = encapsulate_items(args)
    if encapsulated_args == None:
        args = 'f()'                                
    else:
        args = 'f({})'.format( encapsulated_args.replace("\\'", "@@@") ).replace("\\", "\\\\").replace("@@@", "\\'")  
    tree = ast.parse(args)
    funccall = tree.body[0].value
    args = [ast.literal_eval(arg) for arg in funccall.args]
    kwargs = {arg.arg: ast.literal_eval(arg.value) for arg in funccall.keywords}
    return args, kwargs
def validate_args(func):
    
    @functools.wraps(func)    
    def wrapper(*args, **kwargs):
        if 'bypass' in kwargs.keys():
            if kwargs['bypass']==True:
                kwargs.pop('bypass', None)
                return func(*args, **kwargs)
        else:
            args_str = args[0]
            args, kwargs2 = parse_args(args_str)
            kwargs = kwargs | kwargs2
            return func(*args, **kwargs)
    return wrapper
import functools
def type_check(func):
    
    @functools.wraps(func)
    def check(*args, **kwargs):
        arg_list = list(args)
        for i in range(len(arg_list)):
            v = arg_list[i]
            v_name = list(func.__annotations__.keys())[i]
            v_type = list(func.__annotations__.values())[i]
            error_msg = 'Variable `' + str(v_name) + '` should be type (' + str(v_type) + ') but instead is type (' + str(type(v)).split("'")[1] + ')'
            if isinstance(v , str) and v_type==int:
                v = int(v)
                arg_list[i] = v
            elif isinstance(v , str) and v_type==bool:
                string_to_bool = {"true": True, "false": False, "1":True, "0":False}
                v = string_to_bool[v.lower()]
                arg_list[i] = v
            assert isinstance(v, v_type), error_msg
        args = tuple(arg_list)
        return func(*args, **kwargs)
    return check
@validate_args
@type_check
def my_function(arg1: int, arg2: str = "2", **kwargs):
    print(arg1, arg2, kwargs)
@type_check
def my_function2(arg1: int, arg2: str):
    pass
def validate_args1(func):
    
    def wrapper(args_str, **kwargs):
        print('Validate',args_str, kwargs)
        args, kwargs2 = parse_args(args_str)
        print('Validate args:', args, 'kwargs2:', kwargs2)
        kwargs = kwargs | kwargs2
        return func(*args, **kwargs)
    return wrapper
import functools
def type_check1(func):
    
    def check(*args, **kwargs):
        for i in range(len(args)):
            v = args[i]
            v_name = list(func.__annotations__.keys())[i]
            v_type = list(func.__annotations__.values())[i]
            error_msg = 'Variable `' + str(v_name) + '` should be type (' + str(v_type) + ') but instead is type (' + str(type(v)).split("'")[1] + ')'
            if isinstance(v , str) and v_type==int:
                v = int(v)
            elif isinstance(v , str) and v_type==bool:
                string_to_bool = {"true": True, "false": False, "1":True, "0":False}
                v = string_to_bool[v.lower()]
            assert isinstance(v, v_type), error_msg
        return func(*args, **kwargs)
    return check
