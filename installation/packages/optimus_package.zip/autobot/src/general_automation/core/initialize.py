_N='memoryPath'
_M='generalAutomation.log'
_L='/addon'
_K='/output'
_J='/scripts'
_I='PROGRAM_DIR'
_H='startsheet'
_G='startcode'
_F='retries'
_E='update'
_D='background'
_C='file'
_B=False
_A='settings'
from config import log_space,startTime,codeVersion,flow_run_name,MEMORYPATH,AUTOBOT_DIR
from core.files import checkFileValid,changeWorkingDirectory,checkWorkDirectory,checkStartFile,setup_assetDirectories
from pathlib import Path,PureWindowsPath
from prefect import task,flow,get_run_logger,context
def initializeFromSettings(SETTINGS_PATH,deploymentRun=_B):import configparser;from core.parsers import parseArg;configObj=configparser.ConfigParser();configObj.read(SETTINGS_PATH);program_args=parseArg(configObj,deploymentRun);return configObj,program_args
try:isDeploymentFlowRun=not context.get_run_context().flow_run.deployment_id==None;logger=get_run_logger();logger.warning(f"DeploymentFlowRun:{isDeploymentFlowRun}, ID:{context.get_run_context().flow_run.deployment_id}");logger.warning(f"CONTEXT {context.get_run_context().flow_run.parameters[_C]}  {context.get_run_context().flow_run.parameters} {context.get_run_context().flow_run}")
except Exception as e:
	if'No run context'in str(e):isDeploymentFlowRun=_B
	else:print(f"Unknown error {e}");exit()
if not isDeploymentFlowRun:
	CWD_DIR=checkWorkDirectory('.');AUTOBOT_DIR=CWD_DIR;import os;SETTINGS_PATH=Path(AUTOBOT_DIR+'/settings.ini').resolve().absolute().__str__();COMMANDS_PATH=Path(AUTOBOT_DIR+'/commands.xlsx').resolve().absolute().__str__()
	if not checkFileValid(Path(SETTINGS_PATH)):raise ValueError(f"Software Error: settings.ini");import sys;sys.exit(EX_CONFIG)
	configObj,program_args=initializeFromSettings(SETTINGS_PATH,deploymentRun=_B);options=(option for option in configObj.options(_A))
	for option in options:optionValue=configObj[_A][option];exec(f"{option.upper()} = configObj['settings']['{option.upper()}']")
	for arg in program_args:configObj[_A][arg.upper()]=str(program_args[arg.lower()]);exec(f"{arg.upper()} = program_args['{arg.lower()}']")
	PROGRAM_DIR=Path(CWD_DIR).parent.absolute().__str__();SCRIPTS_DIR=Path(PROGRAM_DIR+_J).resolve().absolute().__str__();OUTPUT_PATH=_K;IMAGE_PATH='/rpa';LOG_PATH='/log';ADDON_PATH=_L;SRCLOGFILE=_M;BACKGROUND=program_args[_D];UPDATE=program_args[_E];RETRIES=program_args[_F];STARTFILE=program_args['startfile'];STARTCODE=program_args[_G];STARTSHEET=program_args[_H]
else:
	import os;SETTINGS_PATH=Path(context.get_run_context().flow_run.parameters[_I]+'/autobot/settings.ini').resolve().absolute().__str__()
	if not checkFileValid(Path(SETTINGS_PATH)):raise ValueError(f"Software Error: settings.ini")
	configObj,program_args=initializeFromSettings(SETTINGS_PATH,deploymentRun=True);PROGRAM_DIR=Path(context.get_run_context().flow_run.parameters[_I]).resolve().absolute().__str__();AUTOBOT_DIR=Path(f"{PROGRAM_DIR}/autobot").resolve().absolute().__str__();CWD_DIR=changeWorkingDirectory(AUTOBOT_DIR);SCRIPTS_DIR=Path(context.get_run_context().flow_run.parameters[_I]+_J).resolve().absolute().__str__();OUTPUT_PATH=_K;IMAGE_PATH='/rpa';LOG_PATH='/log';ADDON_PATH=_L;SRCLOGFILE=_M
	if _D in context.get_run_context().flow_run.parameters:BACKGROUND=context.get_run_context().flow_run.parameters[_D]
	if _E in context.get_run_context().flow_run.parameters:UPDATE=context.get_run_context().flow_run.parameters[_E]
	if _F in context.get_run_context().flow_run.parameters:RETRIES=context.get_run_context().flow_run.parameters[_F]
	if _C in context.get_run_context().flow_run.parameters:STARTFILE=context.get_run_context().flow_run.parameters[_C]
	if _H in context.get_run_context().flow_run.parameters:STARTSHEET=context.get_run_context().flow_run.parameters[_H]
	if _G in context.get_run_context().flow_run.parameters:STARTCODE=context.get_run_context().flow_run.parameters[_G]
	deployment_id=context.get_run_context().flow_run.deployment_id
VERSION=configObj[_A]['version']
if not configObj[_A][_N]=='':MEMORYPATH=configObj[_A][_N]
if MEMORYPATH=='':MEMORYPATH=f"{PROGRAM_DIR}\\memory"
from pathlib import Path,PureWindowsPath
import socket
hostname=str(socket.gethostname())
STARTFILE=checkStartFile(STARTFILE,Path(PROGRAM_DIR)/'scripts')
if not checkFileValid(Path(STARTFILE)):
	if isDeploymentFlowRun:logger.critical(f"SCRIPT START FILE INVALID - Check file path: {Path(STARTFILE)}")
	raise ValueError(f"Start File Error {STARTFILE} PROGRAM DIR {PROGRAM_DIR} {MEMORYPATH} ");exit
else:SCRIPT_NAME,ASSETS_DIR,OUTPUT_DIR,IMAGE_DIR,LOG_DIR,ADDON_DIR,SRCLOG=setup_assetDirectories(STARTFILE,SCRIPTS_DIR,OUTPUT_PATH,IMAGE_PATH,LOG_PATH,ADDON_PATH,SRCLOGFILE)
def configuResultMsg():
	A='%m/%d/%Y, %H:%M:%S'
	if isDeploymentFlowRun:configResultMsg=f"""            {log_space}RPA start  :{startTime.strftime(A)}, {codeVersion}, 
             {log_space}Deployment :{isDeploymentFlowRun}, Id({deployment_id}), 
             {log_space}Program dir:{PROGRAM_DIR}, 
             {log_space}Autobot dir:{AUTOBOT_DIR}, 
             {log_space}Assets dir :{ASSETS_DIR}, 
             {log_space}Working dir:{CWD_DIR}, 
             {log_space}Start file :{STARTFILE}, 
             {log_space}Start sheet:{STARTSHEET}, 
             {log_space}Start code :{STARTCODE}, 
             {log_space}Scripts dir:{SCRIPTS_DIR}, 
             {log_space}Output dir :{OUTPUT_PATH}, 
             {log_space}Image dir  :{IMAGE_PATH}, 
             {log_space}Log dir    :{LOG_PATH}, 
             {log_space}Addon Dir  :{ADDON_PATH}, 
             {log_space}SrcLog file:{SRCLOGFILE}, 
             {log_space}Memory path:{MEMORYPATH}, 
             {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),
             """
	else:configResultMsg=f"""            {log_space}RPA start  :{startTime.strftime(A)}, {codeVersion}, 
             {log_space}Deployment :{isDeploymentFlowRun}, Id(None), 
             {log_space}Program dir:{PROGRAM_DIR}, 
             {log_space}Autobot dir:{AUTOBOT_DIR}, 
             {log_space}Assets dir :{ASSETS_DIR}, 
             {log_space}Working dir:{CWD_DIR}, 
             {log_space}Start file :{STARTFILE}, 
             {log_space}Start sheet:{STARTSHEET}, 
             {log_space}Start code :{STARTCODE}, 
             {log_space}Scripts dir:{SCRIPTS_DIR}, 
             {log_space}Output dir :{OUTPUT_PATH}, 
             {log_space}Image dir  :{IMAGE_PATH}, 
             {log_space}Log dir    :{LOG_PATH}, 
             {log_space}Addon Dir  :{ADDON_PATH}, 
             {log_space}SrcLog file:{SRCLOGFILE}, 
             {log_space}Memory path:{MEMORYPATH}, 
             {log_space}Others     :Update({UPDATE}) retries({RETRIES}) background({BACKGROUND}) flow run name({flow_run_name}),
             """
	return configResultMsg
import config
config.configObj=configObj
config.program_args=program_args
config.configuResultMsg=configuResultMsg
config.isDeploymentFlowRun=isDeploymentFlowRun
config.PROGRAM_DIR=PROGRAM_DIR
config.SCRIPTS_DIR=SCRIPTS_DIR
config.OUTPUT_PATH=OUTPUT_PATH
config.IMAGE_PATH=IMAGE_PATH
config.IMAGE_DIR=IMAGE_DIR
config.LOG_PATH=LOG_PATH
config.ADDON_PATH=ADDON_PATH
config.SRCLOGFILE=SRCLOGFILE
config.BACKGROUND=BACKGROUND
config.UPDATE=UPDATE
config.RETRIES=RETRIES
config.STARTFILE=STARTFILE
config.STARTCODE=STARTCODE
config.STARTSHEET=STARTSHEET
config.CWD_DIR=CWD_DIR
config.flow_run_name=flow_run_name
config.ASSETS_DIR=ASSETS_DIR
config.AUTOBOT_DIR=AUTOBOT_DIR