#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
If codeID / keyword matches function in module, run the function -> [codelist], [dflist], [objvarlist]
    keywords.init(): check if libraries and modules are loaded, if not load them
        libaries - load core.  And load user defined if exist in script
        validate keys to see if duplicate
    keywords.present(key): keywords.run_codeStr(codeValue) -> bool
        keywords.run(key, module, arguments)
            keywords.parse_codeStr(codeValue) -> dict of arguments, key, module
            keywords.arguments(key)
            keywords.module(key)
            keywords.validate(codeValue, arguments)
"""
from pathlib import Path, PureWindowsPath
import sys, os
#PROGRAM_DIR = Path(".").resolve().parents[0].absolute().__str__()
from config import PROGRAM_DIR
#print(PROGRAM_DIR)

#MODULE_PATH_file = Path(__file__).parents[0].resolve().absolute().__str__()
MODULE_PATH_libraries = Path(f"{PROGRAM_DIR}/autobot/src/general_automation/libraries").resolve().absolute().__str__()

def __list_modules_from_folder__(MODULE_PATH_libraries: str = MODULE_PATH_libraries) -> list:
    from os import listdir
    from os.path import isfile, join
    mypath = MODULE_PATH_libraries #"/path/to/folder"
    onlyfiles = [f[:-3] for f in listdir(mypath) if isfile(join(mypath, f)) and f.endswith(".py")]
    return onlyfiles

defaultLibraries = __list_modules_from_folder__() #['passwords','BuiltIn']
#print(defaultLibraries)

class Keywords:

    def __init__(self, name="john"):
        self.name = name
        self.libraries_loaded = False
        #self.libraries_loaded = self.load_libraries(defaultLibraries)
        self.keywords = self.get_dict_keywords(defaultLibraries)
        self.keylistAbbrev = None
        self.keylist = self.keys()
        self.df = None
        self.objVar = None

    def import_module(self, module_name:str) -> object:
        """
        To import a module with a given string name in Python,
        """
        import importlib
        #module_name = "BuiltIn"
        module = importlib.import_module(module_name)
        return module

    def load_libraries(self, listModules: list = defaultLibraries):        
        listLibrary = {}
        for Module in listModules:
            listLibrary = listLibrary | self.import_module(Module)
        return True

    def get_dict_keywords(self, listModules: list = defaultLibraries) -> dict:
        """Get dict of keywords given a list of the module names"""
        def get_callable_functions(module_name: str) -> dict:
            #import sys             if not module_name in sys.modules: 
            module = self.import_module(module_name)
            callableFunctions = [func for func in dir(module) if callable(getattr(module, func))]
            prefix = "__"
            listFunctions = [item for item in callableFunctions if not item.startswith(prefix)]  # remove items with that prefix    
            return {module_name: listFunctions}   
        # Get list of keywords
        #listModules = ['passwords','BuiltIn'] #'passwords',
        if self.libraries_loaded == False:
            dictKeywords = {}
            for Module in listModules:
                dictKeywords = dictKeywords | get_callable_functions(Module)
            self.libraries_loaded = True
            return dictKeywords
        return self.keywords

    def keys(self) -> list:
        list_of_lists = list(self.keywords.values())
        flattened_list = [item for sublist in list_of_lists for item in sublist]
        self.keylistAbbrev = [x.replace(" ", "").replace("_", "").lower() for x in flattened_list]
        return flattened_list

    def present(self, key:str) -> bool:
        key = key.replace(" ", "").replace("_", "")
        return key in self.keylistAbbrev

    def module(self, keyStr:str) -> str:
        modulelist=[]
        for key, value in self.keywords.items():
            modulelist += [key]*len(value)
        index = self.keylist.index(keyStr)
        return modulelist[index]

    def run(self, keystr:str, argstr:str = None): #, df=None, objVar=None):
        #self.df = df
        #self.objVar = objVar
        keystr = keystr.replace(" ", "").replace("_", "")
        index = self.keylistAbbrev.index(keystr)
        function_name = self.keylist[index]
        my_module = self.import_module(  self.module(function_name) )
        function = getattr(my_module, function_name)
        ##print('ok', my_module.__str__(), function_name)
        #function("this is a arg for rem")

        if argstr == None:
            return function()
        #elif ' df ' in argstr:
        #    return function(df=df, objVar=objVar)
        #else:
        #    return function(argstr, df=df, objVar=objVar)
        else:
            from core.lexicon import validate_args, type_check
            #validated_function = validate_args(function(argstr))
            #return validated_function()
            #return validate_args(type_check(function(argstr)))
            ##print('function argstr', argstr)
            return function(argstr)

    def parse(self, codeStr:str) -> dict:
        pass

    def find_key_value(my_dict: dict, item: str) -> dict:
        """Get key and value in a dictionary given the item value"""
        result = {}
        for key, value in my_dict.items():
            if item in value:
                result[key] = item
        return result    


    def say_hello(self):
        print(f"Hello, {self.name}!")

