
from pathlib import Path, PureWindowsPath
import sys, os
from config import PROGRAM_DIR, variables
MODULE_PATH_libraries = Path(f"{PROGRAM_DIR}/autobot/src/general_automation/libraries").resolve().absolute().__str__()
def __list_modules_from_folder__(MODULE_PATH_libraries: str = MODULE_PATH_libraries) -> list:
    
    from os import listdir
    from os.path import isfile, join
    module_files = [f[:-3] for f in listdir(MODULE_PATH_libraries) if isfile(join(MODULE_PATH_libraries, f)) and f.endswith(".py")]
    return module_files
def __prioritize_module_sequence__(mylist:list, priority_list:list=[]) -> list:
    result = [] 
    for item in mylist:
        if item in priority_list: 
            result.insert(0, item)
        else:
            result.append(item)
    return result
defaultLibraries = __list_modules_from_folder__()
defaultLibraries = __prioritize_module_sequence__(defaultLibraries, priority_list=[s.strip for s in variables['MODULE'].split(',')])
print(f'module files: {defaultLibraries}')
print(f'reprioritized: {__prioritize_module_sequence__(defaultLibraries, priority_list=["Browser_tagui"])}')
class Keywords:
    def __init__(self, name="john"):
        self.name = name
        self.libraries_loaded = False
        self.keywords = self.get_dict_keywords(defaultLibraries)
        self.keylistAbbrev = None
        self.keylist = self.keys()
        self.df = None
        self.objVar = None
    def import_module(self, module_name:str) -> object:
        
        import importlib
        module = importlib.import_module(module_name)
        return module
    def load_libraries(self, listModules: list = defaultLibraries):        
        listLibrary = {}
        for Module in listModules:
            listLibrary = listLibrary | self.import_module(Module)
        return True
    def get_dict_keywords(self, listModules: list = defaultLibraries) -> dict:
        
        def get_callable_functions(module_name: str) -> dict:
            module = self.import_module(module_name)
            callableFunctions = [func for func in dir(module) if callable(getattr(module, func))]
            prefix = "__"
            listFunctions = [item for item in callableFunctions if not item.startswith(prefix)]  
            return {module_name: listFunctions}   
        if self.libraries_loaded == False:
            dictKeywords = {}
            for Module in listModules:
                dictKeywords = dictKeywords | get_callable_functions(Module)
            self.libraries_loaded = True
            return dictKeywords
        return self.keywords
    def keys(self) -> list:
        list_of_lists = list(self.keywords.values())
        flattened_list = [item for sublist in list_of_lists for item in sublist]
        self.keylistAbbrev = [x.replace(" ", "").replace("_", "").lower() for x in flattened_list]
        return flattened_list
    def present(self, key:str) -> bool:
        key = key.replace(" ", "").replace("_", "")
        return key in self.keylistAbbrev
    def module(self, keyStr:str) -> str:
        modulelist=[]
        for key, value in self.keywords.items():
            modulelist += [key]*len(value)
        index = self.keylist.index(keyStr)
        return modulelist[index]
    def run(self, keystr:str, argstr:str = None): 
        
        keystr = keystr.replace(" ", "").replace("_", "")
        index = self.keylistAbbrev.index(keystr)
        function_name = self.keylist[index]
        my_module = self.import_module(  self.module(function_name) )
        function = getattr(my_module, function_name)  
        from config import variables
        if variables['debug_log']: print('ok', my_module.__str__(), function_name)
        if argstr == None:
            return function()
        else:
            from core.lexicon import validate_args, type_check
            return function(argstr)
    def parse(self, codeStr:str) -> dict:
        pass
    def find_key_value(my_dict: dict, item: str) -> dict:
        
        result = {}
        for key, value in my_dict.items():
            if item in value:
                result[key] = item
        return result    
    def say_hello(self):
        print(f"Hello, {self.name}!")
