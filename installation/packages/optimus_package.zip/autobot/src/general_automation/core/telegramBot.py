
from prefect import get_client
from prefect.server.schemas.core import FlowRun
from prefect.server.schemas.filters import (
    FlowFilter,
    FlowFilterName,    
    FlowRunFilter,
    FlowRunFilterName,
    FlowRunFilterState,    
    FlowRunFilterStateName, 
    FlowRunFilterStartTime,    
    DeploymentFilter,
    DeploymentFilterName,
    FlowRunFilterId,
    FlowFilterId,
)
import asyncio
from prefect.client import get_client
async def remove_all_flows():
    orion_client = get_client()
    flows = await orion_client.read_flows(
            limit=15,
            flow_run_filter=FlowRunFilter(
                state=FlowRunFilterState(
                    type=FlowRunFilterStateName(any_=["RUNNING"])
                ),
            ))
    result = ''
    for flow in flows:
        flow_id = flow.id
        await orion_client._client.delete(f"/flows/{flow_id}")
        if result != '': result = result + '\n'
        result = result + f"Deleted flow: {flow.name}, UUID {flow_id}"
    return result
from core.dates import localTime
async def prefectQuery(hours=24*1, flowname="", param="J"):
    from datetime import datetime, timedelta
    start_time = datetime.now() - timedelta(hours=hours)  
    if "J" in param:
        _flow_run_filter=FlowRunFilter(
            start_time=FlowRunFilterStartTime(
                after_=start_time
            )
        )
        pass
    elif "R" in param:
        _flow_run_filter=FlowRunFilter(
            state=FlowRunFilterState(
                type=FlowRunFilterStateName(any_=["RUNNING"])    
            ),
            start_time=FlowRunFilterStartTime(
                after_=start_time
            )
        )
    elif "F" in param:
        _flow_run_filter=FlowRunFilter(
            state=FlowRunFilterState(
                type=FlowRunFilterStateName(any_=["FAILED", "CRASHED"])    
            ),
            start_time=FlowRunFilterStartTime(
                after_=start_time
            )
        )
    async with get_client() as client:
        r = await client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(like_=flowname)),       
            limit=50,
            flow_run_filter=_flow_run_filter)
        import socket
        hostname=socket.gethostname()   
        IPAddr=socket.gethostbyname(hostname) 
        result = f"{hostname} VM{IPAddr.split('.')[3]}"
        def myFunc(e):
            print(e)
            return len(e) 
        r.sort(key=lambda x: x.start_time)
        for flow in r:
            td = flow.total_run_time 
            st = localTime(flow.start_time, "Asia/Hong_Kong", format="%d/%m %H:%M")
            duration = ':'.join(str(td).split(':')[:2])
            if 'Completed' in flow.state_name:
                status = ' ✅'
            elif 'Failed' in flow.state_name:
                status = '❌'
            elif 'Crashed' in flow.state_name:
                status = '⛔️'
            elif 'Running' in flow.state_name:
                status = '⚡️'            
            else:
                status = '⚠️' 
            f = await client.read_flows(
                limit=50,
                flow_run_filter=FlowRunFilter(
                    id=FlowFilterId(any_=[flow.id]),  
                    start_time=FlowRunFilterStartTime(
                        after_=start_time
                    )
            ))
            zflowName = f[0].name  
            text = [st, f'({duration})', status, zflowName[:8] , flow.name.split('-')[1][:7]  ] 
            text = " ".join(text)
            result = result + '\n' + text
        return result 
if __name__ == "__mainXXX__":
    import asyncio
    print(asyncio.run(prefectQuery()))
import nest_asyncio
nest_asyncio.apply()
import logging
from telegram import __version__ as TG_VER
try:
    from telegram import __version_info__
except ImportError:
    __version_info__ = (0, 0, 0, 0, 0)  
if __version_info__ < (20, 0, 0, "alpha", 1):
    raise RuntimeError(
        f"This example is not compatible with your current PTB version {TG_VER}. To view the "
        f"{TG_VER} version of this example, "
        f"visit https://docs.python-telegram-bot.org/en/v{TG_VER}/examples.html"
    )
from telegram import ForceReply, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)
validUser = ['raymondoh097']
def userAuthorized(user):
    return user in validUser
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    user = update.effective_user
    print('You talk with user {} and his user ID: {} '.format(user['username'], user['id']))
    global token
    token='start'
    if not(userAuthorized(user['username']) or userAuthorized(str(user['id']))):
        await update.message.reply_html(
            rf"Hi {user.mention_html()}! You are not authorized",
        )
        return
    await update.message.reply_html(
        rf"Hi {user.mention_html()}! Welcome to Optimus V5.  You can check status of jobs(list) or run specific jobs",
    )
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    global token
    token='help'    
    await update.message.reply_text("Help!")
async def list_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    global token
    token='list'
    user = update.effective_user    
    if not(userAuthorized(user['username']) or userAuthorized(str(user['id']))):
        await update.message.reply_html(
            rf"Hi {user.mention_html()}! You are not authorized",
        )
        return
    await update.message.reply_html(
        rf"What do you want to list: type J (job status - optional hours e.g. J24), R (running), F (fail, crashed) or S (available scripts) or D (delete running flow runs)",
        reply_markup=ForceReply(selective=True),
    )
    print(token)
async def run_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    global token
    token='run'
    user = update.effective_user    
    if not(userAuthorized(user['username']) or userAuthorized(str(user['id']))):
        await update.message.reply_html(
            rf"Hi {user.mention_html()}! You are not authorized",
        )
        return
    await update.message.reply_html(
        rf"Enter name of flow to run: (shortcut:1=prefectdashboard)",
        reply_markup=ForceReply(selective=True),
    )
    print(token)
async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    global token
    print(f'echo {token}')
    def runRPA(script):
        from pathlib import Path
        currentPath = Path().resolve().parent / "runRPA.bat"   
        scriptFile = Path().resolve().parent / "scripts" / f"{script}.xlsm"
        runBatchCommand = rf'{str(currentPath)} -f {script}'
        if currentPath.exists() and scriptFile.exists():
            import subprocess
            proc = subprocess.Popen(runBatchCommand, shell=True)
            return True
        else:
            return False
    if token=='run':
        import os
        print("Path at terminal when executing this file")
        print(os.getcwd() + "\n")
        if update.message.text == "1":
            script="prefectdashboard"
        else:
            script=update.message.text            
        if runRPA(script=script):
            await update.message.reply_text(rf'Processed script: {script}')
        else:
            await update.message.reply_text(rf'run file does not exist: {update.message.text}')
    elif token=='list':
        if update.message.text.upper()[:1] in 'JRF' or update.message.text=='':
            import asyncio
            param = update.message.text.upper()
            h=int('0'+param[1:])
            if h==0: h=24*1  
            result = await prefectQuery(hours=h, param=param)
            await update.message.reply_text(result)
        elif update.message.text.upper() == 'D':
            import asyncio
            result = await remove_all_flows()   
            await update.message.reply_text(result)
        elif update.message.text.upper() == 'P':
            def printscreen():
                from PIL import Image, ImageGrab                    
                im2 = ImageGrab.grab(bbox = None)
                im2 = im2.save("D:\OneDrive-Sync\OneDrive\Shared Documents - RPA Project-APAC_FIN\screen.jpg")
            printscreen()
            await update.message.reply_text('Print screen')
        elif update.message.text.upper() == 'S':
            import os
            from pathlib import Path
            scriptPath = Path().resolve().parent / "scripts"
            dir_path = str(scriptPath) 
            res = []                
            for file in os.listdir(dir_path):
                if file.endswith('.xlsm'):                  
                    res.append(file[:-5])
            await update.message.reply_text(rf'Scripts: {res}')            
        else:
            await update.message.reply_text(rf'Did not understand your command: {update.message.text}')
    else:
        await update.message.reply_text(rf'Normal echo: {update.message.text}') 
    token='echo'    
async def echo2(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    
    await update.message.reply_text(rf'echo 2: {update.message.text}')    
    global token
    token='echo2'    
from passwords import returnPassword
from prefect.blocks.system import Secret
def retrieve_secret(key="optimus-telegram-bot"):
    pwd = Secret.load(key).get()
    return pwd
BOT_TOKEN = retrieve_secret(key="optimus-telegram-bot")
def main() -> None:
    application.run_polling()
token = 0
if __name__ == "__main__":
    
    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("list", list_command))
    application.add_handler(CommandHandler("run", run_command))    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    main()
