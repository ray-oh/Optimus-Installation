"""
An always available standard library with often needed keywords.
Formulas that can be called by RPA script using {{@formula(arg)}}
testFormula(file:str)
fileModifiedDate(file:str)
fileIsRecent(filename:str, hours:int=7)
fileExist(filepath:str)
"""
from core.lexicon import validate_args, type_check
from pathlib import Path, PureWindowsPath
@validate_args
@type_check
def testFormula(file:str):
    """Test formula - Return True if file is not blank.
    """
    try:
        if file:
            if file != '':
                print('The file is:', file)
                return 'OK'
            else:
                return 'Not OK'
    except Exception as e:
        return 'ERROR'
@validate_args
@type_check
def fileModifiedDate(file:str):
    """Return modified file date
    """
    try:
        import os
        import datetime
        t = os.path.getmtime(file)
        return datetime.datetime.fromtimestamp(t)        
    except Exception as e:
        print(e)
        return None
@validate_args
@type_check
def fileIsRecent(filename:str, hours:int=7):
    """Check if the file was modified within the last n hours.  Return True or False.  Or None if error.
    """
    try:
        import os
        import datetime
        now = datetime.datetime.now()
        delta = datetime.timedelta(hours=hours)
        return fileModifiedDate(filename) > now - delta
    except Exception as e:
        print(e)
        return None
@validate_args
@type_check
def fileExist(filepath:str):
    """Check if the file exist.  Return True or False.  Or None if error.
    """
    try:
        from pathlib import Path
        path = Path(filepath)
        return path.is_file()
    except Exception as e:
        print(e)
        return None
