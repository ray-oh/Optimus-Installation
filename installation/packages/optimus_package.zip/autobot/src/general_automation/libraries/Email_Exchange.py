"""
An always available standard library with often needed keywords.
Email processing
_isWorkSheetName(obj, excelfile)
_selectTable(codeValue: str, df)
email(codeValue:str, df:pd.DataFrame=None)
waitEmailComplete(*args, **kwargs)
    elif codeID.lower() == 'email'.lower():  _email(codeValue, df)
    elif codeID.lower() == 'waitEmailComplete'.lower():  _waitEmailComplete(codeValue, df)
"""
from core.lexicon import validate_args, type_check
from core.email import EmailsSender
def _isWorkSheetName(obj, excelfile):
    try:
        sheet = obj
        objTableSet = pd.read_excel(excelfile, sheet_name=sheet)
        return True, objTableSet
    except ValueError as e:
        pass
    return False, None
def _selectTable(codeValue: str, df):
    from config import STARTFILE
    obj = codeValue
    if obj in df[(df.Type == 'table')]['Object'].dropna().values.tolist():
        objTableSet = df[(df.Type == 'table') & ((df.Object == obj))]   # filter for specified object
        objTableSet = objTableSet.dropna(axis=1, how='all')  # drop all columns where values are nan
        objTableSet = objTableSet.reset_index(drop=True)    # remove index
        objTableSet = objTableSet.drop(['Type', 'Object'], axis=1)  # drop Type and Object column  
        objTableSet.columns = objTableSet.iloc[0]   # promote 1st row to header
        objTableSet = objTableSet[1:] #take the data less the header row
        return True, objTableSet
    else:
        result, objTableSet = _isWorkSheetName(obj, excelfile=STARTFILE)
        return result, objTableSet
import pandas as pd
@validate_args
@type_check
def email(codeValue:str, df:pd.DataFrame=None):
    """ Send email using locally installed outlook client.  Requires following key value parameters/members:
    EmailObj or To, CC, Subject, HTMLBody, Attachment etc. Attachment comma delimited list
    table, Email_Lists, Subject, HTMLBody, Attachment, To, CC, boolForce, boolRun
    Daily Sales - APAC, apac.html, "CountryStore_report.png, APACProductCat_report.png, WomenUniverseCountryStore_report.png", , , FALSE, TRUE 
    Example:
        email: {{row number}} , {{data frame}}
    """
    import datetime
    import json
    import traceback
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    from config import constants, variables, log_space
    import config
    if df==None:    df = config.variables['optimusDF']
    try:
        emailObj = json.loads(codeValue)    # if codeValue is a Json object
    except ValueError as e:
        if len(codeValue.split(',')) > 1:
            colsMapping = codeValue.split(',',1)[1].strip()
            codeValue = codeValue.split(',',1)[0].strip()
        result, objTableSet = _selectTable(codeValue, df)
        if 'colsMapping' in locals(): #or var in globals()
            objTableSet.rename(columns = json.loads(colsMapping), inplace = True)
        mailfieldlst = ['To', 'CC', 'Subject', 'Body', 'HTMLBody', 'Attachment', 'boolDisplay', 'boolRun', 'boolForce']
        objTableSet = objTableSet[objTableSet.columns.intersection(mailfieldlst)]  # select columns for mailing
        if result == True:  # is a table
            n = constants['iterationCount']
            objTableSet = objTableSet.iloc[n]  # fiter tableset for current iteration row
            emailObj = json.loads(objTableSet.to_json(orient="columns"))
            logger.debug(f"{log_space}{emailObj}")
    try:
        To = emailObj['To']
        Subject = emailObj['Subject']
        boolRun = emailObj['boolRun'] if 'boolRun' in emailObj else True 
        boolDisplay = emailObj['boolDisplay'] if 'boolDisplay' in emailObj else False
        boolForce = emailObj['boolForce'] if 'boolForce' in emailObj else False        
        if boolRun: 
            email_sender = EmailsSender()
            cutOffDateTme=datetime.datetime.today().replace(hour=int(variables['sentEmailCheck_hour']), minute=int(variables['sentEmailCheck_min']), second=0, microsecond=0)
            sentEmailSubjectList = email_sender.getSentEmailSubjectList(sentEmailSubjectList = [], cutOffDateTme=cutOffDateTme)
            if not Subject in sentEmailSubjectList or boolForce:
                email_sender.send_email(boolDisplay=boolDisplay, boolRun=boolRun, EmailObj = emailObj)
                logger.debug(f'{log_space}email SENT')
            else:
                logger.debug(f'{log_space}email NOT SENT - already sent')
        else:
            logger.debug(f'{log_space}boolRun is FALSE')
    except ValueError as e:
        logger.error('error --', e)
    except Exception as e:
        logger.error(traceback.format_exc())
@validate_args
@type_check
def waitEmailComplete(*args, **kwargs):
    """Wait for email sending to complete before closing outlook client.
    Example:
        waitEmailComplete:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    email_sender = EmailsSender()
    result = email_sender.wait_send_complete()
    logger.debug(f'{log_space}Email complete = ' + str(result))
