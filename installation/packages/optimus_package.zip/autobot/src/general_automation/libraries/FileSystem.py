"""
An always available standard library with often needed keywords.
File system manipulation and processing
waitFile(file_pattern:str, action:str, timeout:int, actionIfTimeout:str)
copyFile(source:str , dest:str)
moveFile(source:str , dest:str)
makeDir(path:str)
removeFile(filePattern:str)
renameRecentDownload(saveName:str = None, saveName_suffix:str = '' ,sourcePath:str = './', targetPath:str = './', \
                         fileExtension:str = 'pdf', withinLastSec:int = 12000)
touchFile(file:str, path:str = "")
_create_shortcut(shortcut='shortcut', createin='', program = r'C:\path\to\your\file.exe', startin = r'C:\path\to\your\working\directory', 
                     icon = r'C:\path\to\your\icon.ico')
_setup_shortcuts()
    elif codeID.lower() == 'copyFile'.lower():   _copyFile(codeValue)       # copyFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'moveFile'.lower():    _moveFile(codeValue)    # moveFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'makeDir'.lower():     _makeDir(codeValue)     # makeDir:pathname
    elif codeID.lower() == 'removeFile'.lower():  _removeFile(codeValue)        # removeFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'renameRecentDownloadFile'.lower(): _renameRecentDownloadFile(codeValue) # renameRecentDownloadFile:saveName,path,fileExtension,withinLastSec
    elif codeID.lower() == 'touchFile'.lower(): _touchFile(codeValue) # touch file https://stackoverflow.com/questions/1158076/implement-touch-using-python
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def waitFile(file_pattern:str, action:str, timeout:int, actionIfTimeout:str):
    """Wait for file to appear within timeout period.
    Example: 
        mergeFiles:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    timeout = int(timeout)   # timeout in sec
    logger.debug(f'{log_space}checking 1...')
    return [], [], []
@validate_args
@type_check
def copyFile(source:str , dest:str):
    """Copy file from source to destination.
    Example: 
        copyFile: {{source}} , {{destination}}
    """
    import os
    import shutil
    from pathlib import Path
    from prefect import get_run_logger
    logger = get_run_logger()    
    try:
        destination = shutil.copyfile(Path(source).resolve().absolute().__str__(), Path(dest).resolve().absolute().__str__())
    except Exception as e:
        logger.debug('copyFile Failed')
        logger.debug(str(e))
        pass
@validate_args
@type_check
def moveFile(source:str , dest:str):
    """Move file from source to destination.
    Example: 
        moveFile: {{source}} , {{destination}}
    """
    import os
    import shutil
    destination = shutil.move(source, dest)
@validate_args
@type_check
def makeDir(path:str):
    """Create a new directory with given path.
    Example: 
        makeDir: {{path}}
    """
    import pathlib
    p = pathlib.Path(path)
    p.mkdir(parents=True, exist_ok=True)
    print("      ","Directory created", path)
@validate_args
@type_check
def removeFile(filePattern:str):
    """Remove file with given file pattern.
    Example: 
        removeFile: {{file pattern}}
    """
    import os, glob
    fileList = glob.glob(filePattern, recursive=True)
    for file in fileList:
        try:
            os.remove(file)
        except OSError:
            print("      ","Error while deleting file")
    print("      ","Removed all matched files!")
@validate_args
@type_check
def renameRecentDownload(saveName:str = None, saveName_suffix:str = '' ,sourcePath:str = './', targetPath:str = './', \
                         fileExtension:str = 'pdf', withinLastSec:int = 12000):
    """Rename recently downloaded file
    Example: 
        renameRecentDownload: download_save ,   , D:/Output/Daily_Sales/ , D:\\target_folder\\ , pdf , 1200
    """
    from core.files import GetRecentCreatedFile, runInBackground, renameFile    
    """
    if 'saveName' in tmpDict:
        saveName = tmpDict['saveName'].strip()
        if saveName == '': saveName = variables['url']
    if 'saveName_suffix' in tmpDict:
        saveName_suffix = tmpDict['saveName_suffix'].strip()
        if saveName_suffix == '': saveName_suffix = ''
    if 'sourcePath' in tmpDict:
        sourcePath = tmpDict['sourcePath'].strip()
        if sourcePath == '': sourcePath = './' #'.\\' #'D:\\iCristal\\'
    if 'targetPath' in tmpDict:
        targetPath = tmpDict['targetPath'].strip()
        if targetPath == '': targetPath = './' #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
    if 'fileExtension' in tmpDict:
        fileExtension = tmpDict['fileExtension'].strip()
        if fileExtension == '': fileExtension = 'pdf'
    if 'withinLastSec' in tmpDict:
        withinLastSec = tmpDict['withinLastSec'].strip()
        if withinLastSec == '':
            withinLastSec = 12000
        else:
            withinLastSec = int(withinLastSec)
    """
    if saveName == None:
        from config import variables
        saveName = variables['url']
    saveName = saveName + saveName_suffix
    downloadedFile = GetRecentCreatedFile(sourcePath,'*.' + fileExtension, withinLastSec) # get most recent file of pdf format in last 120 sec in path
    if downloadedFile is not None: renameFile(downloadedFile, targetPath + saveName + '.' + fileExtension)
@validate_args
@type_check
def touchFile(file:str, path:str = ""):
    """Touch file will update the file modification time.  Or create the file if it does not exist.
    Example: 
        touchFile: {{file}} , {{path}}
    """
    from pathlib import Path
    """
    if path != None:
        _path = path
    else:
        _path = ""
    """
    Path(path, file).touch()
import os
import win32com.client
def _create_shortcut(shortcut='shortcut', createin='', program = r'C:\path\to\your\file.exe', startin = r'C:\path\to\your\working\directory', 
                     icon = r'C:\path\to\your\icon.ico'):
    """Create shortcut
    https://copyprogramming.com/howto/create-shortcut-files-in-windows-10-using-python-3-7-1
    Example: 
        create_shortcut('QUIT VM1', r'D:/Optimus6/autobot/QUIT_VM.bat', r'D:\Optimus6/autobot', r'C:/Users/svc_supplychain/Downloads/UserManual.ico' )        
    """
    try:
        path = os.path.join(createin, f'{shortcut}.lnk')
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(path)
        shortcut.Targetpath = program
        shortcut.WorkingDirectory = startin
        shortcut.IconLocation = icon
        shortcut.save()
    except Exception as e:
        print(type(e).__name__, e)
def _setup_shortcuts():
    """Setup shortcuts
    optimus.bat
    autobot\QUIT_VM.bat
    scripts\runJupyterNotebook.bat
    http://127.0.0.1:4200/flow-runs
    Example: 
        setup_shortcuts:        
    """
    try:
        from pathlib import Path
        if Path("./autobot").exists():
            PROGRAM_DIR = Path(".").resolve().absolute().__str__()
        elif Path("../autobot").exists():
            PROGRAM_DIR = Path(".").resolve().parents[0].absolute().__str__()
        elif Path("../../autobot").exists():
            PROGRAM_DIR = Path(".").resolve().parents[0].parents[0].absolute().__str__()
        else:
            PROGRAM_DIR = "ERROR"
        AUTOBOT_DIR = Path(f'{PROGRAM_DIR}/autobot').resolve().absolute().__str__()
        ICON_DIR = Path(f'{PROGRAM_DIR}/autobot/assets/shortcuts').resolve().absolute().__str__()
        import os
        DESKTOP_DIR = os.path.join(os.environ['USERPROFILE'], 'Desktop')
        WINDOWS_ICON_PATH = os.path.join(os.environ['SystemRoot'], 'System32\SHELL32.dll')
        WINDOWS_EXPL_PATH = os.path.join(os.environ['windir'], 'explorer.exe \".\\autobot\\optimus.bat\"') #, '\.\\autobot\\optimus.bat'
        CREATEIN = os.path.join(PROGRAM_DIR, 'Shortcut')
        if not os.path.exists(CREATEIN):
            os.makedirs(CREATEIN)
        _create_shortcut(shortcut='OPTIMUS RPA', createin=CREATEIN, program=f'{PROGRAM_DIR}/autobot/optimus.bat', startin=PROGRAM_DIR, icon=f'{ICON_DIR}/rocket.ico' )
        _create_shortcut(shortcut='OPTIMUS RPA 2', createin=CREATEIN, program='%windir%/explorer.exe "\.\\autobot\\optimus.bat"', startin="", icon=f'{ICON_DIR}/rocket.ico' )
        _create_shortcut('QUIT VM', CREATEIN, f'{AUTOBOT_DIR}/QUIT_VM.bat', AUTOBOT_DIR, f'{ICON_DIR}/exit.ico' )
        _create_shortcut('Jupyter Notebook', CREATEIN, f'{PROGRAM_DIR}/scripts/runJupyterNotebook.bat', f'{PROGRAM_DIR}/scripts', f'{ICON_DIR}/jupyter.ico' )
        _create_shortcut('Flow Runs', CREATEIN, f'http://127.0.0.1:4200/flow-runs', PROGRAM_DIR, f'{ICON_DIR}/flow.ico' )
        _create_shortcut('Optimus Folder', CREATEIN, PROGRAM_DIR, PROGRAM_DIR, f'{ICON_DIR}/folder.ico' )        
        def copyFiles(file='/*.lnk', src_folder = CREATEIN, dst_folder = DESKTOP_DIR):
            import glob
            import shutil
            for file in glob.glob(src_folder + file):
                shutil.copy(file, dst_folder)
        copyFiles(dst_folder = PROGRAM_DIR)
        copyFiles(dst_folder = DESKTOP_DIR)
        return True
    except Exception as e:
        print(e)
        return False
