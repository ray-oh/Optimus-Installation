"""
An always available standard library with often needed keywords.
Password management functions
get_password(username:str, origin:str)
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def get_password(username:str, origin:str):
    """Get password from default Chrome user profile password vault.
    Example: 
        get_password: {{user name}} , {{origin}}
    """
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    log_space = "          "
    from core.passwords import retrieveHttpCredentials
    http_credentials=retrieveHttpCredentials(origin, username)
    if http_credentials['username'] == '':
        return
    else:
        import config
        config.variables['username'] = http_credentials['username']
        config.variables['password'] = http_credentials['password']
