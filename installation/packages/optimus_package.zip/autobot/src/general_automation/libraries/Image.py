#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

Image processing

cropImage(files, savefiles, left, top, right, bottom, boolPercentage)
cropImage(files, savefiles, left, top, right, bottom, boolPercentage, df)
start_recording(file_to_save:str = "recording.mp4", fps:int = 10) -> None
pause_recording()
resume_recording()
stop_recording()
resize(image_file, new_size, encode_format='PNG')
"""
from core.lexicon import validate_args, type_check

#from auto_utility_PDF_Image import cropImage #, createPDFfromImages, addContentPDF

from pathlib import Path, PureWindowsPath
from PIL import Image
def cropImage(files, savefiles, left, top, right, bottom, boolPercentage):
    # Importing Image class from PIL module
    #from PIL import Image
    i = 0
    #print('Files to crop:',files)
    for file in files:
        # Opens a image in RGB mode
        #im = Image.open(r"C:\Users\Admin\Pictures\geeks.png")
        im = Image.open(file)
        # Size of the image in pixels (size of original image)
        # (This is not mandatory)
        width, height = im.size
        print('      ','File:', Path(file).name, ' Size:', im.size)
        # Setting the points for cropped image
        if boolPercentage == True:
            if left is None: left = 0
            if top is None: top = 0        
            if right is None: right = 1
            if bottom is None: bottom = 1        
            left_ = int(left) * width
            top_ = int(top) * height
            right_ = int(right) * width
            bottom_ = int(bottom) * height
        else:
            if left is None: left = 0
            if top is None: top = 0        
            if right is None: right = width
            if bottom is None: bottom = height        
            left_ = int(left)
            top_ = int(top)
            right_ = int(right)
            bottom_ = int(bottom)
        
        #print(left_, top_, right_, bottom_)
        # Cropped image of above dimension
        # (It will not change original image)
        im1 = im.crop((left_, top_, right_, bottom_))
        
        # Shows the image in image viewer
        #im1.show()    

        im1.save(savefiles[i])
        i = i + 1
    return


@validate_args
@type_check
def cropImage(files, savefiles, left, top, right, bottom, boolPercentage, df):
    """Crop image files.

    Example: 
        cropImage: {{files}} , {{save files}} , {{left}} , {{top}} , {{right}} , {{bottom}} , {{values in percentage: True / False}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure

    #tmpDict = parseArguments('files, savefiles, left, top, right, bottom, boolPercentage',codeValue)
    # cropImage - num or pct - percentage
    files = [updateConstants(df, s) for s in dfObjList(df, files)]
    savefiles = [updateConstants(df, s) for s in dfObjList(df, savefiles)]        
    #print(tmpDict['files'], tmpDict['savefiles'], tmpDict['left'], tmpDict['top'], tmpDict['right'], tmpDict['bottom'], tmpDict['boolPercentage'])
    cropImage(files, savefiles, left, top, right, bottom, boolPercentage)


import pyscreenrec
recorder = pyscreenrec.ScreenRecorder()
@validate_args
@type_check
def start_recording(file_to_save:str = "recording.mp4", fps:int = 10) -> None:
    """Screen recording. Default file_to_save = "recording.mp4", fps = 10 frames per sec
    'recording.mp4' is the name of the output video file, may also contain full path like 'C:/Users/<user>/Videos/video.mp4'
    the second parameter(10) is the FPS. You can specify the FPS for the screen recording using the second parameter. It must not be greater than 60.
    Requires pyscreeze, opencv, pillow

    Example: 
        start_recording: {{file_to_save}} , {{fps}}
    """
    # to start recording
    print(f'Record start: {file_to_save}')
    recorder.start_recording(file_to_save, 10) 

@validate_args
@type_check
def pause_recording():
    """Screen recording pause.

    Example: 
        pause_recording:
    """
    # to pause recording
    print('pause')
    recorder.pause_recording()

@validate_args
@type_check
def resume_recording():
    """Screen recording resume.

    Example: 
        resume_recording:
    """
    # to resume recording
    print('resume')
    recorder.resume_recording()

@validate_args
@type_check
def stop_recording():
    """Screen recording stop.

    Example: 
        stop_recording:
    """
    # to stop recording
    print('Record stop')
    recorder.stop_recording()


def resize(image_file, new_size, encode_format='PNG'):
    """ Resize image
    """
    from io import BytesIO
    from pathlib import Path
    from PIL import Image, UnidentifiedImageError

    im = Image.open(image_file)
    #new_im = im.resize(new_size, Image.ANTIALIAS)
    #new_im = im.resize((128, 128), Image.Resampling.LANCZOS)
    new_im = im.resize(new_size, Image.Resampling.LANCZOS)    
    with BytesIO() as buffer:
        new_im.save(buffer, format=encode_format)
        data = buffer.getvalue()
    return data


'''
# remove below

import asyncio
async def screenRecord(stop_event, saveVideoFile:str = "output.avi", fps:int = 12.0, record_seconds:int = 10) -> None:
    """Screen recording using OpenCV and pyautogui. Default save as output.avi in scripts folder.

    Example: 
        screenRecord: {{saveVideoFile=output.avi}} , {{frames per sec=12.0}} , {{record_seconds=10}}
    """
    import cv2
    import numpy as np
    import pyautogui

    # display screen resolution, get it using pyautogui itself
    SCREEN_SIZE = tuple(pyautogui.size())
    # define the codec
    fourcc = cv2.VideoWriter_fourcc(*"XVID")
    # frames per second
    #fps = 12.0
    # create the video write object
    out = cv2.VideoWriter(saveVideoFile, fourcc, fps, (SCREEN_SIZE))
    # the time you want to record in seconds
    #record_seconds = 10

    # Start recording
    #for i in range(int(record_seconds * fps)):
    while not stop_event.is_set():
        # make a screenshot
        img = pyautogui.screenshot()
        # convert these pixels to a proper numpy array to work with OpenCV
        frame = np.array(img)
        # convert colors from BGR to RGB
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # write the frame
        out.write(frame)
        # show the frame
        #cv2.imshow("screenshot", frame)
        # Wait for 1/30th of a second before capturing the next frame
        await asyncio.sleep(1 / fps)

        # if the user clicks q, it exits
        #if cv2.waitKey(1) == ord("q"):
        #    break

    # release the video writer and close window. make sure everything is closed when exited
    out.release()
    cv2.destroyAllWindows()

@validate_args
@type_check
async def main():
    """Screen recording using OpenCV and pyautogui. Default save as output.avi in scripts folder.

    Example: 
        screenRecord: {{saveVideoFile=output.avi}} , {{frames per sec=12.0}} , {{record_seconds=10}}
    """
    stop_event = asyncio.Event()
    #asyncio.create_task(my_async_function(stop_event))
    # Create a task to record the screen asynchronously
    task = asyncio.create_task(record_screen(stop_event))
    
    # Run other Python code in parallel
    print("Running other Python code...")

    # Trigger termination of the async function after 5 seconds
    await asyncio.sleep(5)
    stop_event.set()
    print("Event set")
    
    # Wait for the screen recording task to complete
    #await task
'''



