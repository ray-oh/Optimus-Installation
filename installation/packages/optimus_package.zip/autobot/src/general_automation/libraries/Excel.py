"""
An always available standard library with often needed keywords.
Excel manipulation and processing
mergeFiles(fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool , df)
    elif codeID.lower() == 'mergeFiles'.lower():    _mergeFiles(codeValue, df)                               
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def mergeFiles(fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool , df):
    """Merge files and deduplicate records.
    mergeFiles: fileList:list , keep:str , uniqueColumnsList:list , fileName:str , encoding:bool
    Example: 
        mergeFiles:
        mergeFiles: mergeFilelist, last, deDuplicationColumnList, ./merged.xlsx,  latin-1
    """
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure    
    import pandas as pd
    if fileList in df[(df.Type == 'list')]['Object'].dropna().values.tolist():           
        fileList = dfObjList(df, fileList)
        fileList = [updateConstants(df, s) for s in fileList]
        fileList = [s.strip() for s in fileList]        
    if uniqueColumnsList in df[(df.Type == 'list')]['Object'].dropna().values.tolist():           
        uniqueColumnsList = dfObjList(df, uniqueColumnsList)
        uniqueColumnsList = [updateConstants(df, s) for s in uniqueColumnsList]
    df_merged = pd.concat(map(lambda x: pd.read_csv(x, encoding=encoding) if x.upper().endswith('.CSV') else pd.read_excel(x), fileList), ignore_index=True)        
    df_merged = df_merged.drop_duplicates(uniqueColumnsList, keep=keep)
    saveFile = fileName
    df_merged.to_csv(saveFile, index=False) if saveFile.upper().endswith('CSV') else df_merged.to_excel(fileName, index=False)
    print('      ', 'Merge Files:', fileList, ' Save to:', saveFile)
