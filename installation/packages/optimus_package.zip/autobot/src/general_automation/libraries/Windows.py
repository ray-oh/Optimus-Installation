"""
An always available standard library with often needed keywords.
Windows functions:
runExcelMacro(excel:str, macro:str)
runPowerShellScript(script:str)
runBatchScript(script:str , workingDir:str = CWD_DIR)
triggerRPAScript(script, file)
openProgram(application:str, workingDIR:str = CWD_DIR)
keyboard_pwa(keys:str)
focusWindow(window_name:str)
runOptimus(script:str, flags:str)
killOptimus(windowtitle:str)
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def runExcelMacro(excel:str, macro:str):
    """Run Excel Macro.
    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    from pathlib import Path, PureWindowsPath
    import win32com.client
    xl = win32com.client.Dispatch("Excel.Application")          
    workBookName = Path(excel).name
    excel = Path(excel).absolute()
    if excel == '': return
    excelQuit = True
    wbClose = True
    if xl.Workbooks.Count > 0:  
        excelQuit = False
        if any(i.Name == workBookName for i in xl.Workbooks): 
            wbClose = False
    xl.Visible = False
    logger.debug(f"{log_space}excel {excel.__str__()} workBookName {workBookName.__str__()} macro {macro}")
    wb = xl.Workbooks.Open(excel)
    xl.Application.Run(macro)
    wb.Save()
    if wbClose: wb.Close(SaveChanges=False)
    if excelQuit: xl.Application.Quit()
@validate_args
@type_check
def runPowerShellScript(script:str):
    """Run PowerShell Script.
    Example: 
        runPowerShellScript: {{script}}
    """
    import subprocess, sys
    p = subprocess.Popen(['powershell.exe', 
        script], 
        stdout=sys.stdout)
    p.communicate()
from config import CWD_DIR
@validate_args
@type_check
def runBatchScript(script:str , workingDir:str = CWD_DIR):
    """Run Batch Script
    Example: 
        runBatchScript: {{script}} , {{in working directory.  Default is current script folder}}
    """
    from subprocess import Popen
    p = Popen(script, cwd=workingDir)
    stdout, stderr = p.communicate()
@validate_args
@type_check
def triggerRPAScript(script, file):
    """Trigger RPA Script
    Example: 
        triggerRPAScript: {{script}} , {{file}}
    """
    import yaml
    def write_yaml(py_obj,filename):
        with open(f'{filename}', 'w',) as f :
            yaml.dump(py_obj,f,sort_keys=False) 
        return True
    def read_yaml(filename):
        with open(f'{filename}','r') as f:
            output = yaml.safe_load(f)
        print(output)
        return output
    def triggerRPA(file='', token={}, memoryPath=''):
        from pathlib import Path, PureWindowsPath
        state="pending"
        from config import STARTFILE, STARTSHEET, STARTCODE, PROGRAM_DIR, UPDATE, BACKGROUND, RETRIES, MEMORYPATH
        if memoryPath=='': memoryPath=MEMORYPATH
        if token == {}:
            token['update']=UPDATE
            token['startfile']=STARTFILE
            token['startsheet']=STARTSHEET
            token['startcode']=STARTCODE
            token['background']=BACKGROUND
            token['program_dir']=PROGRAM_DIR
            print('Token',token)
        print('LAUNCH RPA SCRIPT:', Path(file).stem, write_yaml(token, rf"{memoryPath}\{state}\{Path(file).stem}.txt"))
        result = read_yaml(rf"{memoryPath}\{state}\{Path(file).stem}.txt")
        print(result)
        return True
    from config import STARTFILE, STARTSHEET, STARTCODE, PROGRAM_DIR, UPDATE, BACKGROUND, RETRIES, MEMORYPATH    
    token = {}
    token['update']=UPDATE
    token['startfile']=STARTFILE
    token['startsheet']=STARTSHEET
    token['startcode']=STARTCODE
    token['background']=BACKGROUND
    token['program_dir']=PROGRAM_DIR
    print('Token',token)    
    strSearch = script+' '
    strSearch = strSearch.replace("-u ", "--update ")
    strSearch = strSearch.replace("-b ", "--background ")
    strSearch = strSearch.replace("-r ", "--retries ")
    import re
    strPattern=r'\s-+([\D]+?)\s+(.*?)\s'
    flags = re.findall(strPattern, strSearch)
    print(flags)
    def Merge(dict1, dict2):
        print('merge',dict1, dict2)
        print('MERGED',dict2.update(dict1))
        return(dict2.update(dict1))
    def Convert(tup, di):
        for a, b in tup:
            di.setdefault(a, b)
        return di 
    dictionary = {}
    flags = Convert(flags, dictionary)
    print('flags',flags, token,type(flags), type(token) )
    Merge(flags, token)
    print('new token',token)
    print('Triggered', triggerRPA(file=file, token=token))
@validate_args
@type_check
def openProgram(application:str, workingDIR:str = CWD_DIR):
    """Open Windows Program.
    Example: 
        openProgram: {{application}} , {{in working directory.  Default current script folder.}}
    """
    from pywinauto import Application
    script = application    
    Application().start(script)
@validate_args
@type_check
def keyboard_pwa(keys:str):
    """Simulate keyboard keys with pywinauto.
    Example: 
        keyboard_pwa: {{keys}}
    """
    from pywinauto.keyboard import send_keys
    send_keys(keys.replace(" ","{SPACE}"))            
@validate_args
@type_check
def focusWindow(window_name:str):
    """Focus window to window name.
    Example: 
        focusWindow: {{window name}}
    """
    from auto_helper_lib import Window
    selectedWins= Window()  
    selectedWins.focus(name=window_name) 
@validate_args
@type_check
def _focusWindowTemp(codeValue):
    """Merge files and deduplicate records.
    Example: 
        mergeFiles:
    """
    script = codeValue.split(',')[0].strip()
    if len(codeValue.split(','))>1:
        workingDir = codeValue.split(',')[1].strip()
    else:
        workingDir = CWD_DIR
    from pywinauto import Application
    app = Application(backend="uia").connect(path=script)
    app.top_window().set_focus()
def _runRPAscript(script="test", flags="", PROGRAM_DIR=""):
    from pathlib import Path
    currentPath = Path(PROGRAM_DIR).resolve() / "runRPA.bat"   
    scriptFile = Path(PROGRAM_DIR).resolve() / "scripts" / f"{script}.xlsm"
    runBatchCommand = rf'{str(currentPath)} -f {script} {flags}'
    print(runBatchCommand)
    if currentPath.exists() and scriptFile.exists(): 
        import subprocess
        subprocess.Popen(runBatchCommand, shell=True)  
        print("*** LAUNCH:", script, ' | ' ,runBatchCommand)
        return True
    return False
def _schedule(action:str='', program:str=r"powershell.exe -WindowStyle Hidden -nologo -file D:\Optimus6\autobot\addon\launch_agent.ps1 -batchScript startAgent.bat -path D:\Optimus6",
             freq = 'HOURLY /mo 3 /du 0010:00',
             start_time = '09:00',
             task_path = 'optimus\\scripts\\',
             task = 'serviceNow'
             ):
    """ Task schedule creation, deletion, run
    _schedule(action='create', program='D:\Optimus\runrpa.bat -f Cognos-weekly5 -b 1 -u 1 -r 2', start_time='09:00', freq='HOURLY /mo 3 /du 0010:00', 
                task_path = 'optimus\\scripts\\', task='Cognos-weekly5')
    _schedule(action='run', task_path = 'optimus\\scripts\\run batch')
    """
    valid_action = ['create', 'delete', 'run', 'query', 'query all']
    if action.lower() not in valid_action: return False
    case = action.strip().lower()
    if not start_time == "": start_time = f"/ST {start_time}"
    print(f'{case} {task_path}{task}')
    if case == 'create':
        command = f'SchTasks /Create /F /SC {freq} {start_time} /TN \"{task_path}{task}\" /TR \"{program}\" '
    if case == 'delete':
        command = f'SchTasks /DELETE /F /TN \"{task_path}{task}\"'
    if case == 'run':
        command = f'SchTasks /RUN /TN \"{task_path}{task}\"'
    if case == 'query':
        command = f'SchTasks /QUERY /fo LIST /TN \"{task_path}{task}\"'  
    if case == 'query all':
        command = f'SchTasks /QUERY /fo TABLE /TN \{task_path}  /nh'  
    import subprocess
    result = ''
    try:
        result = subprocess.check_output(command, stderr=subprocess.STDOUT)
        result = str(result, "utf-8")
        print(f'SUCCESS: {command}\n{result}')
        return True 
    except subprocess.CalledProcessError:
        print(f'FAIL: {command}\n{result}')
        return False 
    if result==0:
        print(f'SUCCESS: {command}/n{result}')
        return True 
    else:
        print(f'FAIL: {command}/n{result}')
        return False 
def _schedule_window():
    pass
@validate_args
@type_check
def runOptimus(script:str, flags:str): 
    """Trigger Optimus RPA Script
    Example: 
        runOptimus: {{script}} , {{file}}
    """
    import config
    _runRPAscript(script=script, flags=flags, PROGRAM_DIR=config.PROGRAM_DIR)
@validate_args
@type_check
def killOptimus(windowtitle:str):
    """Kill optimus process with window title containing.  Using windows taskkill command.
    https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/taskkill
    Example: 
        killOptimus: {{window title that contains this}}
    """
    from prefect import get_run_logger
    logger = get_run_logger()
    import subprocess
    processes = subprocess.getoutput('tasklist /v /fo list |find /i "Window Title" |find "OPTIMUS"').split('\n')
    processes = [ele.replace("Window Title: ", "") for ele in processes if windowtitle in ele]     
    processes = list(dict.fromkeys(processes)) 
    print("Running OPTIMUS:", processes)
    for ele in processes: subprocess.run('TASKKILL /FI "WINDOWTITLE eq {}"'.format(ele))
    return True
    command = 'taskkill /FI "WINDOWTITLE eq Administrator:  OPTIMUS -f {}*"'.format(windowtitle)
    command = '/FI "imagename eq cmd.exe" /fo list /v |find /i "Window Title" |find "OPTIMUS" |find "{}"'.format(windowtitle)
    print("Command:", command)
    result = subprocess.run(["tasklist.exe", command], capture_output=True)
    print('******* KILL *******', result)
    if len(result.stdout.decode('ASCII')) > 0:
        logger.info("process killed" + result.stdout.decode('ASCII'))
        print("process killed" + result.stdout.decode('ASCII'))
        return True
    else:
        return False
