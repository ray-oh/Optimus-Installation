#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'runExcelMacro'.lower():       _runExcelMacro(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'runPowerShellScript'.lower():       _runPowerShellScript(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'runBatchScript'.lower():       _runBatchScript(codeValue)                          # runExcelMacro:excel, macro
    elif codeID.lower() == 'triggerRPAScript'.lower():       _triggerRPAScript(codeValue)                          # triggerRPAScript:command with flags    
    elif codeID.lower() == 'openProgram'.lower():       _openProgram(codeValue)                          # openProgram:path
    elif codeID.lower() == 'focusWindow'.lower():       _focusWindow(codeValue)                          # focusWindow:windowName

"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def runExcelMacro(excel:str, macro:str):
    """Run Excel Macro.

    Example: 
        runExcelMacro: {{excel}} , {{macro}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from pathlib import Path, PureWindowsPath

    #excel = codeValue.split(',')[0].strip()
    #macro = codeValue.split(',')[1].strip()
    import win32com.client
    xl = win32com.client.Dispatch("Excel.Application")          #instantiate excel app
    #xl.Visible = True is not necessary, used just for convenience'

    workBookName = Path(excel).name
    excel = Path(excel).absolute()

    if excel == '': return
    excelQuit = True
    wbClose = True
    if xl.Workbooks.Count > 0:  # excel open with workbooks - do not quit excel
        #for i in office.Workbooks: print('list of open workbooks',i.Name)
        excelQuit = False
        # target workbook is open - do not close the workbook
        if any(i.Name == workBookName for i in xl.Workbooks): 
            #print('do not close workbook')
            wbClose = False

    xl.Visible = False
    logger.debug(f"{log_space}excel {excel.__str__()} workBookName {workBookName.__str__()} macro {macro}")
    wb = xl.Workbooks.Open(excel)
    xl.Application.Run(macro)
    wb.Save()
    if wbClose: wb.Close(SaveChanges=False)
    #xl.Visible = True
    if excelQuit: xl.Application.Quit()


@validate_args
@type_check
def runPowerShellScript(script:str):
    """Run PowerShell Script.

    Example: 
        runPowerShellScript: {{script}}
    """
    #script = codeValue #.split(',')[0].strip()
    #macro = codeValue.split(',')[1].strip()
    import subprocess, sys
    #p = subprocess.Popen(['powershell.exe', '.\AddOn\cleanProcesses.ps1 -msg " Testing 123 v5 " '], stdout=sys.stdout)
    p = subprocess.Popen(['powershell.exe', 
        script], 
        stdout=sys.stdout)
    p.communicate()
    #logg('runPowerShellScript:', returnCode = p.returncode, stderr = p.stderr, stdout = p.stdout)

from config import CWD_DIR
@validate_args
@type_check
def runBatchScript(script:str , workingDir:str = CWD_DIR):
    """Run Batch Script

    Example: 
        runBatchScript: {{script}} , {{in working directory.  Default is current script folder}}
    """
    #script = codeValue.split(',')[0].strip()
    #if len(codeValue.split(','))>1:
    #    workingDir = codeValue.split(',')[1].strip()
    #else:
    #    workingDir = CWD_DIR
    #https://riptutorial.com/python/example/5714/more-flexibility-with-popen
    from subprocess import Popen
    #p = Popen("test.bat", cwd=r".\AddOn")
    p = Popen(script, cwd=workingDir)
    stdout, stderr = p.communicate()
    #logg('runBatchScript:', returnCode = p.returncode, stderr = p.stderr, stdout = p.stdout)
    #print(p.returncode)
    #print("An error occured: %s", p.stderr)
    #print("Output %s", p.stdout)

@validate_args
@type_check
def triggerRPAScript(script, file):
    """Trigger RPA Script

    Example: 
        triggerRPAScript: {{script}} , {{file}}
    """
    import yaml
    # write python obj to yaml file
    def write_yaml(py_obj,filename):
        with open(f'{filename}', 'w',) as f :
            yaml.dump(py_obj,f,sort_keys=False) 
        #print('Written to file successfully')
        return True

    # read yaml to python obj/dictionary
    def read_yaml(filename):
        with open(f'{filename}','r') as f:
            output = yaml.safe_load(f)
        print(output)
        return output

    # trigger RPA event by generating token in pending
    def triggerRPA(file='', token={}, memoryPath=''):
        from pathlib import Path, PureWindowsPath
        #print(f"background:{background}")
        state="pending"
        from config import STARTFILE, STARTSHEET, STARTCODE, PROGRAM_DIR, UPDATE, BACKGROUND, RETRIES, MEMORYPATH
        if memoryPath=='': memoryPath=MEMORYPATH
        #write_yaml_to_file(data, 'output.txt')
        if token == {}:
            #token = {}
            token['update']=UPDATE
            token['startfile']=STARTFILE
            token['startsheet']=STARTSHEET
            token['startcode']=STARTCODE
            token['background']=BACKGROUND
            token['program_dir']=PROGRAM_DIR
            print('Token',token)
        print('LAUNCH RPA SCRIPT:', Path(file).stem, write_yaml(token, rf"{memoryPath}\{state}\{Path(file).stem}.txt"))

        result = read_yaml(rf"{memoryPath}\{state}\{Path(file).stem}.txt")
        print(result)
        return True

    # ----------------------------------------
    #script = 'test -sc not ready -b okay -u happy'  # triggerRPAScript:test -u 1 -b 0 -r 3 -sh main -sc main
    #script = codeValue.split(',')[0].strip()  # triggerRPAScript:test -u 1 -b 0 -r 3 -sh main -sc main    
    #file = codeValue.split(' ')[0].strip()
    #default token values
    from config import STARTFILE, STARTSHEET, STARTCODE, PROGRAM_DIR, UPDATE, BACKGROUND, RETRIES, MEMORYPATH    
    token = {}
    token['update']=UPDATE
    token['startfile']=STARTFILE
    token['startsheet']=STARTSHEET
    token['startcode']=STARTCODE
    token['background']=BACKGROUND
    token['program_dir']=PROGRAM_DIR

    print('Token',token)    
    strSearch = script+' '
    strSearch = strSearch.replace("-u ", "--update ")
    strSearch = strSearch.replace("-b ", "--background ")
    strSearch = strSearch.replace("-r ", "--retries ")

    import re
    # Find all occurrences of single whitespace characters
    #result = re.findall(r'-+([\D]+?)\s+(.*?)\s', string)
    strPattern=r'\s-+([\D]+?)\s+(.*?)\s'
    flags = re.findall(strPattern, strSearch)
    #flags = regexSearch(strPattern=r'-+([\D]+?)\s+(.*?)\s', strSearch=strSearch)    
    print(flags)
    # Python code to merge dict using update() method
    def Merge(dict1, dict2):
        print('merge',dict1, dict2)
        print('MERGED',dict2.update(dict1))
        return(dict2.update(dict1))

    # Python code to convert into dictionary
    def Convert(tup, di):
        for a, b in tup:
            #di.setdefault(a, []).append(b)
            di.setdefault(a, b)
        return di 

    dictionary = {}
    flags = Convert(flags, dictionary)
    print('flags',flags, token,type(flags), type(token) )
    Merge(flags, token)
    print('new token',token)

    print('Triggered', triggerRPA(file=file, token=token))
    #if len(codeValue.split(','))>1:
    #    workingDir = codeValue.split(',')[1].strip()
    #else:
    #    workingDir = CWD_DIR
    #https://riptutorial.com/python/example/5714/more-flexibility-with-popen
    #from subprocess import Popen
    #p = Popen("test.bat", cwd=r".\AddOn")
    #p = Popen(script, cwd=workingDir)
    #stdout, stderr = p.communicate()

@validate_args
@type_check
def openProgram(application:str, workingDIR:str = CWD_DIR):
    """Open Windows Program.

    Example: 
        openProgram: {{application}} , {{in working directory.  Default current script folder.}}
    """
    #script = codeValue.split(',')[0].strip()
    #if len(codeValue.split(','))>1:
    #    workingDir = codeValue.split(',')[1].strip()
    #else:
    #    workingDir = CWD_DIR

    # To force the new window to the top
    #from auto_helper_lib import Window
    #selectedWindows = Window()  # instantiate windows object with snapshot of existing windows

    from pywinauto import Application
    script = application    
    Application().start(script)

    #selectedWindows.getNew()    # get newly opened windows compared to previous snapshot
    #variables['lastWindow']=selectedWindows
    #variables['lastWindow'].focus() # focus the newly opend window with name of    name='google chrome'

@validate_args
@type_check
def keyboard_pwa(keys:str):
    """Simulate keyboard keys with pywinauto.

    Example: 
        keyboard_pwa: {{keys}}
    """
    # from pywinauto.SendKeysCtypes import SendKeys # old for pywinauto==0.5.x
    from pywinauto.keyboard import send_keys
    send_keys(keys.replace(" ","{SPACE}"))            
    #send_keys("{VK_SHIFT down}"
    #        "pywinauto"
    #        "{VK_SHIFT up}") # to type PYWINAUTO    

@validate_args
@type_check
def focusWindow(window_name:str):
    """Focus window to window name.

    Example: 
        focusWindow: {{window name}}
    """
    from auto_helper_lib import Window
    selectedWins= Window()  # instantiate windows object with snapshot of existing windows
    #selectedWindows.get(name=codeValue)
    selectedWins.focus(name=window_name) # focus the newly opend window with name of    name='google chrome'     #     

@validate_args
@type_check
def _focusWindowTemp(codeValue):
    """Merge files and deduplicate records.

    Example: 
        mergeFiles:
    """
    script = codeValue.split(',')[0].strip()
    if len(codeValue.split(','))>1:
        workingDir = codeValue.split(',')[1].strip()
    else:
        workingDir = CWD_DIR
    from pywinauto import Application
    app = Application(backend="uia").connect(path=script)
    app.top_window().set_focus()


# launch token
def _runRPAscript(script="test", flags="", PROGRAM_DIR=""):
    from pathlib import Path
    #currentPath = Path().resolve().parent / "runRPA.bat"   #Path().resolve().parent.parent / "runRPA.bat"
    #scriptFile = Path().resolve().parent / "scripts" / f"{script}.xlsm"

    currentPath = Path(PROGRAM_DIR).resolve() / "runRPA.bat"   #Path().resolve().parent.parent / "runRPA.bat"
    scriptFile = Path(PROGRAM_DIR).resolve() / "scripts" / f"{script}.xlsm"

    runBatchCommand = rf'{str(currentPath)} -f {script} {flags}'
    #print(runBatchCommand)
    if currentPath.exists() and scriptFile.exists(): # and False:
        #https://stackoverflow.com/questions/21936597/blocking-and-non-blocking-subprocess-calls
        import subprocess
        proc = subprocess.Popen(runBatchCommand, shell=True)  # Popen - non-blocking
        print("*** LAUNCH:", script, ' | ' ,runBatchCommand)
        return True
    return False
