"""
An always available standard library with often needed keywords.
Playwright browser automation library
"""
from core.lexicon import validate_args, type_check
from config import RPABROWSER, IMAGE_DIR, variables, log_space
from core.core import CriticalAccessFailure
from auto_utility_browser import waitIdentifierExist
from pathlib import Path, PureWindowsPath
import rpa as r
@validate_args
@type_check
def click(element_identifier:str):
    """Click given element identifier
    Example:
        click: {{element identifier}}
    """
    code = element_identifier
    try:
        int(len(code))
    except ValueError:
        return None
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p
        p.click(code)       
    else:    
        if not waitIdentifierExist(code, 30, 1):        
                raise CriticalAccessFailure("Exception critical failure")              
                return
        if code.lower().endswith(('.png', '.jpg', '.jpeg')): code = Path(IMAGE_DIR + '/' + code).absolute().__str__() 
        r.click(code)
    return None 
@validate_args
@type_check
def rclick(element_identifier:str):
    """Right click of given element identifier
    Example:
        rclick: {{element_identifier}}
    """
    codeValue=element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p
        p.click(codeValue, button="right")        
    else:
        if codeValue.lower().endswith(('.png', '.jpg', '.jpeg')): codeValue = Path(IMAGE_DIR + '/' + codeValue).absolute().__str__() 
        r.rclick(codeValue)             
    return None
@validate_args
@type_check
def hover(element_identifier:str):
    """Move mouse to / hover over matching element (or x, y using visual automation for tagui)	
    Example:
        hover: {{element identifier}}
    """
    code = element_identifier
    try:
        int(len(code))
    except ValueError:
        return None
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p
        p.hover(code)       
    else:    
        if not waitIdentifierExist(code, 30, 1):        
                raise CriticalAccessFailure("Exception critical failure")              
                return
        if code.lower().endswith(('.png', '.jpg', '.jpeg')): code = Path(IMAGE_DIR + '/' + code).absolute().__str__() 
        r.hover(code)
    return None 
@validate_args
@type_check
def present(element_identifier:str):
    """Check if element identifier is present. Returns True/False in variable 'present'.
    Example:
        present: {{element identifier}}
    """
    codeValue = element_identifier
    codeID = present.__name__
    import config
    config.variables[codeID] = r.present(codeValue)             
    return None
@validate_args
@type_check
def exist(element_identifier:str , variable:str=None, **kwargs):
    """Returns True or False for whether a given element identifier exist/is visible or not.
    Example: 
        exist: identifier , save result to variable name (if not specified, saves it to the variable name "exist")
    """
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()
    codeValue = element_identifier
    from config import constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    if variable==None:codeID = exist.__name__
    else:codeID = variable
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser
        config.variables[codeID] = browser.p.selector_exists(codeValue)        
    else:
        config.variables[codeID] = r.exist(codeValue)             
    logger.debug(f'{log_space}Exist: {codeID}, {config.variables[codeID]}')
    return None
@validate_args
@type_check
def closeRPA(*args, **kwargs):
    """Closes the RPA browser session and window.
    Example:
        closeRPA:
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    logger = get_run_logger()
    if config.variables['rpaBrowser']:
        if RPABROWSER==0:
            instantiatedRPA = r.close()    
        else:
            from browser import p
            p.close_browser()
            instantiatedRPA = True
        logger.debug(f"{log_space}Close RPA = {instantiatedRPA}")
        config.variables['rpaBrowser'] = False
    return None
def consoleOutput(runStatement):
    from io import StringIO
    import sys
    old_stdout = sys.stdout 
    buffer = StringIO()     
    sys.stdout = buffer     
    exec(runStatement)
    buffer_output = buffer.getvalue()   
    sys.stdout = old_stdout   
    return buffer_output
from io import StringIO
import sys
def redirectConsole():
    old_stdout = sys.stdout 
    buffer = StringIO()     
    sys.stdout = buffer     
    return buffer, old_stdout
def resetConsole(buffer, old_stdout):
    buffer_output = buffer.getvalue()   
    sys.stdout = old_stdout   
    return buffer_output
@validate_args
@type_check
def url(url:str , authentication:int=0, user:str='', origin:str='', wait_until:str="load"):  
    """Go to specific url page.
    For playwright driver, additional arguments for authentication are accepted to pass authentication credentials.
    Authentication credentials are retrieved from default chrome browser profile.
    authentication: 1 for authentication. Default is 0, i.e. no authentication.
    user: e.g. email address.
    origin: url in chrome profile where the credential is stored.
    wait_until: load or networkidle
    Example: 
        url: {{url address}} , {{authentication}} , {{user}} , {{origin}}, {{load|networkidle}}
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfKey_value
    from browser import p
    logger = get_run_logger()
    import config
    df = config.variables['optimusDF']    
    key = url
    logger.debug(f'{log_space}RPABROWSER:{RPABROWSER} AUTH:{authentication} URL:{key} WAIT_UNTIL:{wait_until}') 
    if isinstance(key, str) and key[:4]=='http':  
        url_value = key
    elif key[:1]=='@':                            
        url_value = key[1:]
    else:                                         
        url_value = dfKey_value(df, key)
        logger.debug(f"{log_space}Open URL: {url_value}")
    import math
    if url_value==None or url_value!=url_value:  
        logger.error(f"{log_space}ERROR: Not a valid key value pair. url_value = {url_value} key = {key}")            
    elif not(isinstance(url_value, str)):
        url_value = url_value[0]
    if isinstance(url_value, str) and (url_value[:4]=='http' or url_value[:6]=='chrome'):
        if RPABROWSER == 0:
            buffer, old_stdout = redirectConsole()
            result = r.url(url_value) 
            consoleOutput = resetConsole(buffer, old_stdout)
            if not result:
                logger.error(f"{log_space}RPA ERROR: {consoleOutput}")
            else:
                from core.windows import Window
                selectedWindows = Window()  
                title=r.title()
                if title=='': title='about:blank'
                logger.debug(f'{log_space}Title of window to focus {title}')
                selectedWindows.focus(name=title) 
        else:  
            logger.debug(f'{log_space}USER {user} ORIGIN {origin}') 
            if authentication == 1:
                if user != '':
                    if origin != '':
                        p.page_goto(url_value, 1, user, origin, wait_until=wait_until)
                    else:
                        p.page_goto(url_value, 1, user, wait_until=wait_until)
                else:
                    p.page_goto(url_value, 1, wait_until=wait_until)
            else:
                p.page_goto(url_value, wait_until=wait_until)
            result = True
    else:
        logger.error(f"{log_space}ERROR: Not http address, url_value = {url_value}, key = {key}")
    constants['url'] = key          
    return None
def urls(codeValue:str, **kwargs):
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    url = dfKey_value(df, objVar).strip()                
    r.url(url)
    constants['url'] = objVar.strip()
    return None
@validate_args
@type_check
def initializeRPA(codeValue: str=None, *args, **kwargs):
    """Initialize RPA browser before any browser action.
    For tagui, you can specific a json string object to over write the default values.
    For playwright, accepted arguments e.g. {"headless":false, "slow_mo":30}
    Note double quotes and small case false for boolean for json object syntax.
    Example: 
        initializeRPA: visual_automation = False, chrome_browser = True, headless_mode = False, turbo_mode = False
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    logger = get_run_logger()
    if not config.variables['rpaBrowser']:
        if RPABROWSER == 1 or RPABROWSER == 2:
            if codeValue=="" or codeValue==None:
                codeValue = "{}"
            try:
                import json
                json_object = json.loads(codeValue.strip())
                if not "headless" in json_object.keys():
                    json_object['headless'] = False
            except Exception as error:
                logger.error('{0}Initialization Error: {1} | {2}'.format(log_space, type(error).__name__, error))
            var_exists = 'p' in globals() 
            global p
            if var_exists:
                del p
                p_exists = 'p' in globals() 
            import browser
            browser.p = browser.Browser()
            browser.p.initialize(**json_object)
            p_exists = 'p' in globals() 
        else:
            from auto_helper_lib import Window, process_list
            processResult = process_list(name='', minutes=5)
            selectedWindows = Window()  
            if config.variables['headless_mode']==True:
                visual_automation = False
                chrome_browser = True
                headless_mode = True
                turbo_mode = False
            else: 
                visual_automation = True 
                chrome_browser = True
                headless_mode = False
                turbo_mode = False
            if codeValue == None: codeValue = ''
            jsonString = codeValue.strip()
            import json
            if jsonString == '':
                pass
            else:
                try:
                    paramDict = json.loads(jsonString.lower())
                    logger.debug(f"{log_space}RPA Initialize Parameters = {jsonString}, {paramDict}")
                    for item in paramDict:
                        if item == "visual_automation": visual_automation=paramDict[item]
                        elif item == "chrome_browser": chrome_browser=paramDict[item]
                        elif item == "headless_mode": headless_mode=paramDict[item]
                        elif item == "turbo_mode": turbo_mode=paramDict[item]
                    print(visual_automation, chrome_browser, headless_mode, turbo_mode, type(visual_automation))
                except:
                    print("Error json string in _initializeRPA:", jsonString)
            instantiatedRPA = r.init(visual_automation = visual_automation, chrome_browser = chrome_browser, headless_mode = headless_mode, turbo_mode = turbo_mode)
            print(f"r.init(visual_automation = {visual_automation}, chrome_browser = {chrome_browser}, headless_mode = {headless_mode}, turbo_mode = {turbo_mode})")
            logger.debug(f"{log_space}Initialize RPA = {instantiatedRPA}")
            if instantiatedRPA:
                selectedWindows.getNew()    
                title=r.title()
                if title=='': title='about:blank'
                selectedWindows.focus(name=title) 
        import config
        config.variables['rpaBrowser'] = True
    return None
@validate_args
@type_check
def wait_for_url(url:str, timeout:int=30, run_code:str=None, wait_until:str='load'):
    """Waits for the main frame to navigate to the given URL.
    Arguments: url str|Pattern|Callable[URL]:bool
    A glob pattern, regex pattern or predicate receiving URL to match while waiting for the navigation. 
    Note that if the parameter is a string without wildcard characters, the method will wait for navigation to URL that is exactly equal to the string.
    wait_until = default "load"|"domcontentloaded"|"networkidle"|"commit"
    Example: 
        wait_for_url: **/target.html
    """
    from prefect import get_run_logger
    from config import log_space, RPABROWSER, variables
    from core.core import dfObjList
    logger = get_run_logger()
    df = variables['optimusDF']
    objVar = variables['optimusobjVar']
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p
        print('
        timeoutError = not p.wait_for_url(url, timeout*1000, wait_until)
        if timeoutError:
            if run_code != None:                                           
                run_code = dfObjList(df, run_code)
                logger.debug(f"{log_space}Timeout Action list:{run_code}")
                return run_code
            else:
                logger.warning(f"{log_space}Time out from waiting ...")
                return []
        else:
            return None 
import time
@validate_args
@type_check
def wait(timeout:str = None, element_identifier:str = None, run_code:str = '', run_code_until:str = None, state:str='visible'): 
    """Wait for identifier to appear.
    Arguments: timeout_sec , identifier , run_code if timeout , run_code_until, state=[default visible|hidden|detached|attached]
    Example: 
        wait: 30 , identifier , code to run if timeout or if not specified pass to next action
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    from config import variables
    df = variables['optimusDF']
    objVar = variables['optimusobjVar']
    logger = get_run_logger()
    identifier = element_identifier
    if not identifier==None: identifier = identifier.strip()
    codeValue = timeout
    if state.lower() in ['appear']: state = 'visible'
    elif state.lower() in ['disappear']: state = 'hidden'
    import config
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p
        if codeValue=="" or codeValue==None:    
            time_sec=1000        
            time.sleep(time_sec)
            return []
        if codeValue[:1]=='{':    
            if codeValue=="" or codeValue==None:
                codeValue = "{}"
            import json
            json_object = json.loads(codeValue)
            if 'time_sec' in json_object:
                time_sec = json_object["time_sec"]
                tmpDict = json_object.pop('time_sec')
            else:
                time_sec = 15000
        else:     
            time_sec = int(codeValue) 
            if identifier != None: 
                if identifier in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
                    identifier = dfObjList(df, identifier)
                timeoutError = not p.wait(millisec=time_sec * 1000, selector=identifier, state=state)
            else:
                time.sleep(int(time_sec))      
                timeoutError = False    
        if timeoutError: 
            try:
                logger.warning(f'run_code : {run_code}')
            except Exception as e:
                logger.warning(e)
            if run_code == '': 
                logger.warning(f"{log_space}Time out from waiting ...")
                return []
            else:
                run_code = dfObjList(df, run_code)
                print('wait run code list', run_code)
                logger.debug(f"{log_space}Scenario list:{identifier} Action list:{run_code}")
                run_code = run_code 
                n = len(run_code)
                return run_code
        return []
    else:
        time_sec = int(codeValue)
        if identifier != None:                 
            print('wait identifier', identifier)
            if identifier in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
                identifier = dfObjList(df, identifier)
                if run_code != None:                                           
                    run_code = dfObjList(df, run_code)
                print('wait identifier list', identifier)
                print('wait run code list', run_code)
                logger = get_run_logger()
                logger.debug(f"{log_space}Scenario list:{identifier} Action list:{run_code}")
                matchBool, index = waitIdentifierExist(identifier, time_sec, 1, False)         
                if not matchBool:
                    logger.warning(f"Time out from waiting ...")
                    return [], [], []
                else:
                    if run_code != None:                                           
                        print('      Run code from wait:', run_code[index])
                        run_code = dfObjList(df, run_code[index])
                        n = len(run_code)
                        logger.debug(f"{log_space}Action:{run_code[index]}, {n} steps:{run_code} {[objVar] * n}")
                        return run_code
                    else:
                        return []
            else: 
                if not waitIdentifierExist(identifier, time_sec, 5, False):         
                    if run_code != None:                                           
                        run_code = dfObjList(df, run_code)
                        if run_code_until != None:
                            n = len(run_code)
                            return run_code                        
                        else:                                                           
                            n = len(run_code)
                            return run_code
                else:
                    return []
        else:
            time.sleep(time_sec)
            return []
@validate_args
@type_check
def keyboard(codeValue: str, *args, **kwargs):
    """Simulates keyboard action.
    key commands: [shift] [ctrl] [alt] [win] [cmd] [enter] 
    [space] [tab] [esc] [backspace] [delete] [clear] 
    [up] [down] [left] [right] [pageup] [pagedown]
    [home] [end] [insert] [f1] .. [f15]
    [printscreen] [scrolllock] [pause] [capslock] [numlock]
    Example: 
        keyboard: {{key commands}}
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        def mapKeyCodes(test_str):
            import re
            '''
            [shift] [ctrl] [alt] [win] [cmd] [enter]
            [space] [tab] [esc] [backspace] [delete] [clear]
            [up] [down] [left] [right] [pageup] [pagedown]
            [home] [end] [insert] [f1] .. [f15]
            [printscreen] [scrolllock] [pause] [capslock] [numlock]
            https://developer.mozilla.org/en-US/docs/Web/API/UI_Events/Keyboard_event_key_values
            https://tagui.readthedocs.io/en/latest/reference.html
            https://playwright.dev/docs/api/class-keyboard
            https://github.com/tebelorg/RPA-Python
            https://www.geeksforgeeks.org/python-replace-different-characters-in-string-at-once/
            '''
            map_dict1 = {'\[':'[','\]':']',
                        '\-':'Minus','\+':'Plus','\=':'Equal',
                    }
            map_dict = {'\[':'[','\]':']',
                        'shift':'Shift+','ctrl':'Control+','alt':'Alt+','win':'Meta','cmd':'Meta','enter':'Enter',
                        'space':'Space','tab':'Tab','esc':'Escape','backspace':'Backspace','delete':'Delete','clear':'Clear',
                        'up':'ArrowUp','down':'ArrowDown','left':'ArrowLeft','right':'ArrowRight','pageup':'PageUp','pagedown':'PageDown',
                        'home':'Home','end':'End','insert':'Insert',
                    }
            map_dict2 = {'\+\]\[':'+','\]':']',
                    }
            res = re.compile("|".join(map_dict1.keys())).sub(lambda ele: map_dict1[re.escape(ele.group(0))], test_str)
            res = re.compile("|".join(map_dict.keys())).sub(lambda ele: map_dict[re.escape(ele.group(0))], res) 
            res = re.compile("|".join(map_dict2.keys())).sub(lambda ele: map_dict2[re.escape(ele.group(0))], res)
            if res[-2:]=='+]': res=res[:-2]
            import re
            pattern = r'[\[\],;|]'
            result = re.split(pattern, res)
            while("" in result): result.remove("")
            return result
        for key in mapKeyCodes(codeValue):
            try:
                p.press(key)
            except:
                print('Error type' + key)
                p.type(key)
    else:
        r.keyboard(codeValue)           
    return None
@validate_args
@type_check
def type(element_identifier: str, value:str=None, *args, **kwargs):              
    """Enter text at element.
    element_identifier can be a special table object with fields selector and value.
    Example: 
        type: identifier , text to type
        type: table object
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import updateConstants
    import config
    identifier = element_identifier
    if value == None:
        if RPABROWSER == 1 or RPABROWSER == 2:
            if element_identifier in variables.keys():
                pass
            else:
                df = variables['optimusDF']
                if element_identifier in df[(df.Type == 'table')]['Object'].dropna().values.tolist():
                    def getObjTable(table_name, df):
                        objTableSet = df[(df.Type == 'table') & ((df.Object == table_name))]
                        objTableHeader = objTableSet.iloc[0] 
                        objTableSet.columns = objTableHeader 
                        objTableSet = objTableSet.tail(objTableSet.shape[0]-1)
                        print(objTableSet)
                        return objTableSet
                    import config
                    config.variables[element_identifier] = getObjTable(table_name=element_identifier, df=df)
                else:
                    return None
        else:
            return None
    if RPABROWSER == 1 or RPABROWSER == 2: 
        from browser import p
        if value == None:
            tableObj = variables[element_identifier]
            for index, row in tableObj.iterrows():  
                inputValue = updateConstants(df=None, code=row['value'])
                p.input(row['selector'], inputValue)
        else:
            p.input(identifier,value)
    else:   
        r.type(identifier,value)
    return None
@validate_args
@type_check
def pause():
    """Pause the script run in browser for user action.
    Special dialog pop up allows user to resume script after manual action.
    Applicable only for playwright.
    Example:
        pause:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        p.pause()
@validate_args
@type_check
def authenticate(username:str, origin:str, *args, **kwargs):
    """Authenticate a login page.  Applicable only for playwright.
    The credentials are saved in your default chrome browser.
    And retrieved by specifying the "origin" url where its saved in chrome.
    User name and password are updated into input element with username and password id.
    Example: 
        authenticate: {{user name}} , {{origin}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    logger = get_run_logger()
    if username=="": return None
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        p.authenticate(username, origin)
@validate_args
@type_check
def read(element_identifier:str, variable_name:str=None , **kwargs):
    """Read and return element text at given or specified element identifier.
    For tagui: element_identifier ('page' is web page) (or x1, y1, x2, y2).
    Example: 
        read: element identifier to read, variable name to save result
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    codeValue = element_identifier
    value = variable_name
    logger = get_run_logger()
    logger.debug(f'{log_space}READ: {codeValue} | {value}')
    if value==None:
        key = codeValue.split('=',1)[0]
        value = codeValue.split('=',1)[1]
    else:
        key = variable_name
        value = element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser                
        config.variables[key] = browser.p.read(value)
    else:
        config.variables[key] = r.read(value)  
    logger.debug(f'{log_space}Result: {config.variables[key]}')
@validate_args
@type_check
def waitDisappear(timeout:str = None, element_identifier:str = None, run_code:str=None, run_code_until:str=None):
    """Wait for element identifier to disappear.
    If code to run is not specified, pass to next action upon timeout
    Arguments: 
        timeout_sec , identifier , run_code if timeout , run_code_until
    Example: 
        waitDisappear: 30 , //identifier , code to run if timeout
    """
    from prefect import task, flow, get_run_logger, context
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from core.core import dfObjList
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    import config
    logger = get_run_logger()
    identifier = element_identifier
    df = variables['optimusDF']
    codeValue = timeout
    if codeValue=="" or codeValue==None:    
        time_sec=1000
    else:
        time_sec=int(codeValue)
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser
        if identifier != None or identifier != '':                 
            logger.debug(f"{log_space}identifier = {identifier}")
            start_time = time.time()
            while True:
                Found = browser.p.wait(2000, selector=identifier)
                elapsed_time = int(time.time() - start_time)
                if not Found:
                    logger.info(log_space + 'Disappeared: ' + identifier)
                    return []       
                elif elapsed_time > time_sec: 
                    logger.warning(log_space+"Time out from waiting")                    
                    if run_code != None:                                           
                        run_code = dfObjList(df, run_code)
                        if run_code_until != None:
                            logger.debug(f"{log_space}Time out - run_code = {run_code}, run_code_until = {run_code_until}")
                            n = len(run_code)
                            return run_code
                        else:                                                           
                            logger.warning(f"{log_space}Time out - run_code = {run_code}")
                            n = len(run_code)
                            return run_code
                    else:                        
                        return []  
                else:
                    time.sleep(1)
            return []
    else:  
        logger.debug(f'{log_space}checking 1...')
        if identifier != None or identifier != '':                 
            logger.debug(f"{log_space}identifier = {identifier}")
            if not waitIdentifierDisappear(identifier, time_sec, 1, False):         
                logger.warning(f"   Time out from waiting', level = 'warning'")                    
                if run_code != None:                                           
                    run_code = dfObjList(df, run_code)
                    if run_code_until != None:
                        logger.debug(f"{log_space}Time out - run code: run_code = {run_code}, run_code_until = {run_code_until}, level = 'debug'")
                        n = len(run_code)
                        return run_code
                    else:                                                           
                        logger.warning(f"'      Time out - run code:', run_code = {run_code}, level = 'warning'")
                        n = len(run_code)
                        return run_code
            else:
                return []
        else:
            logger.debug(f"{log_space}wait time_sec = {time_sec}")
            time.sleep(time_sec)
            return []
@validate_args
@type_check
def count(element_identifier:str, **kwargs):
    """Return number of web elements as integer.  Applicable for TagUI.
    Argument: 
        element_identifier
    Example:
        count: {{element identifier}}
    """
    codeID = 'count'
    codeValue = element_identifier
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    import config
    config.variables[codeID] = r.count(codeValue)             
    print('      ',codeID,config.variables[codeID])
@validate_args
@type_check
def focus(app_to_focus:str):
    """Make application in focus.  Specific to tagui browser driver.
    Argument: 
        app_to_focus (full name of app)
    Example: 
        focus: app_to_focus
    """
    codeID = 'focus'
    codeValue = app_to_focus    
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    import config
    config.variables[codeID] = r.focus(codeValue)             
    print('      ',codeID,config.variables[codeID])
@validate_args
@type_check
def popup(codeValue:str, **kwargs):
    """Set context to web popup tab.  Specific to tagui browser driver.
    """
    codeID = 'popup'
    import config
    config.variables[codeID] = r.popup(codeValue)             
    print('      ',codeID,config.variables[codeID])
@validate_args
@type_check
def title():
    """Returns title of current page in the variable "title".
    Example:
        title:
    """
    codeID = 'title'
    import config
    config.variables[codeID] = r.title()             
    print('      ',codeID,config.variables[codeID])        
@validate_args
@type_check
def select(element_identifier:str, value:str, **kwargs):
    """Selects option or options in <select>.
    Example: 
        select: tag element for <select> , option value
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    import browser
    key = element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.select_option(key, value)
    else:
        r.select(key,value)             
@validate_args
@type_check
def snap(codeValue:str='page', saveFile:str='', **kwargs):  
    """Take screenshot of full web page to file.
    Example:  
        snap: page , image.png
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    import config
    import browser
    page = codeValue.split(',',1)[0]        
    if page=='':
        page = 'page'
    elif page =='log':
        snapImage()
        return
    if saveFile=='':saveFile = codeValue.split(',',1)[1].strip()
    from pathlib import Path
    if saveFile=='':
        saveFile = './Output/Images/' + saveFile
    else:
        if Path(saveFile).parent.exists():
            saveFile = Path(saveFile).resolve().__str__()
        else:
            saveFile = Path('./tmp.png').resolve().__str__()
    if RPABROWSER == 1 or RPABROWSER == 2: 
        browser.p.snap(path=saveFile, full_page=True)
    else:
        r.snap(page, saveFile)          
@validate_args
@type_check
def telegram(telegram_id:str , text_message:str):
    """Sends notification message via telegram.
    First, look up @rpapybot on your Telegram app to approve receiving messages.
    Message is send in the following format: {flow run name} - message string.
    Use @userinfobot to check telegram id
    Example: 
        telegram: telegram_id , message_string
    """
    from config import flow_run_name 
    r.telegram(int(telegram_id),f"{flow_run_name} -{text_message}")  
@validate_args
@type_check
def download(element_identifier:str, filename_to_save:str, **kwargs):
    """Download given url content using a selector to the download link.
    Example: 
        download: element_identifier , filename_to_save
    """
    download_url = element_identifier
    from config import RPABROWSER
    import config
    import browser
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.download(download_url, filename_to_save)
    else:
        r.download(download_url, filename_to_save)
@validate_args
@type_check
def upload(element_identifier:str, file_to_load:str, **kwargs):
    """Upload given specific web locator and file path.
    Example: 
        upload: upload_selector , file_to_load
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    import browser
    upload_selector = element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.upload(upload_selector, file_to_load)
    else:
        pass
@validate_args
@type_check
def setView(element_identifier:str):
    """Sets the target scope for playwright browser action to either existing "frame" or "page" or frame identified by given "identifer".
    Example: 
        setView: page
        setView: frame
        setView: 
    """
    from config import RPABROWSER
    import config
    import browser
    identifier = element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        if identifier.lower() == 'page':
            browser.p.setView(viewType = 'page')            
        elif identifier.lower() == 'frame':
            browser.p.setView(viewType = 'frame')            
        else:
            browser.p.setView(viewType = 'frame', selector = identifier)
    else:
        pass
@validate_args
@type_check
def recordVideo(True_False:bool=True, record_video_dir:str='.\\output\\'):
    """Activate recording of video for browser automation session.  Only for playwright browser driver.
    Default directory is the script working directory.
    Example: 
        recordVideo: True , D:/test/Video/
        recordVideo: True , ./Video/
        recordVideo: True
        recordVideo: False
    """
    from config import RPABROWSER
    import config
    if RPABROWSER == 1 or RPABROWSER == 2:
        if True_False:
            config.variables['record_video_dir']=record_video_dir
        else:
            config.variables['record_video_dir']="None"
    else:
        pass
@validate_args
@type_check
def chromeZoom(factor:int):
    """Zoom in or out in Chrome browser. Playwright: Zoom factor 50=50%, 110=110%
    Tagui: Zoom factor -1 = -90%, -2 = -80%, -3 = -75%, 0 = reset to 100%.
    Example: 
        chromeZoom: 30
    """
    from config import RPABROWSER
    import browser
    if RPABROWSER == 1 or RPABROWSER == 2:
        jscript= f"document.body.style.zoom={str(factor/100)}"
        browser.p.evaluate( jscript )
    else:
        import rpa as r
        if factor < 0:      zoom_key = '-'  
        elif factor > 0:    zoom_key = '+'  
        elif factor == 0:   zoom_key = '0'  
        else:               return
        r.keyboard('[ctrl]0')
        for i in range(int(abs(factor))):
            r.keyboard('[ctrl]' + zoom_key) 
@validate_args
@type_check
def expect(element_identifier:str, frame_locator:str=None, action:str=None, value:str=None, timeout:int=30, debug:bool=False):
    """Ensures that Locator points to an attached and visible DOM node. 
    To check that at least one element from the list is visible, use locator.first.
    Example: 
        locate: //div[@class='section'] , iframe , wait , hidden , 30
    """
    import traceback
    from config import RPABROWSER
    from prefect import get_run_logger
    logger = get_run_logger()
    from browser import p
    expect(p.page.get_by_text(element_identifier)).to_be_visible()
    expect(p.page.get_by_test_id("todo-item").first).to_be_visible()
    expect(
        page.get_by_role("button", name="Sign in")
        .or_(page.get_by_role("button", name="Sign up"))
        .first
    ).to_be_visible()    
    return True
@validate_args
@type_check
def locate(element_identifier:str, frame_locator:str=None, action:str=None, value:str=None, timeout:int=30, debug:bool=False):
    """Locate and highlight element identifier / selector.  And perform action.
    element_identifier = selector.  Can be xpath e.g. //div[@class='section']
    frame_locator = page | frame | frame_selector e.g. iframe
    action = None, click, check, uncheck, select, fill, type, input, press, keyboard, count, isvisible, ishidden, isexist, wait
    value = attached|detached|visible|hidden for wait action
    timeout = integer value in seconds
    debug = True|False
    Example: 
        locate: //div[@class='section'] , iframe , wait , hidden , 30
    """
    import traceback
    from config import RPABROWSER
    from prefect import get_run_logger
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
    logger = get_run_logger()
    i=0
    try:
        if RPABROWSER == 1 or RPABROWSER == 2:
            while i <= timeout:    
                from browser import p
                if frame_locator=="" or frame_locator==None: pass
                elif frame_locator.lower()=="page": p.setView(viewType="page", debug=debug)
                elif frame_locator.lower()=="frame": p.setView(viewType="frame", debug=debug)
                else: p.setView(viewType="frame", selector=frame_locator, debug=debug)
                if element_identifier=='': return False 
                locator = p.findElement(element_identifier, highlight=True, debug=debug)
                if action==None:
                    if locator==None:
                        print('Locator: FALSE:',locator)
                        return False
                    else:
                        print('Locator: TRUE:',locator)
                        return True
                if locator == None:
                    pass
                else:
                    if action.lower()=='click':
                        locator.click()
                    elif action.lower()=='check':
                        locator.check()
                    elif action.lower()=='uncheck':
                        locator.uncheck()
                    elif action.lower()=='select' and not value==None:
                        locator.select_option(value)
                    elif action.lower() in ['fill','type','input'] and not value==None:
                        locator.fill(value)
                    elif action.lower() in ['press','keyboard'] and not value==None:
                        locator.fill(value) 
                    elif action.lower() in ['count']:
                        return locator.count() > 0 
                    elif action.lower() in ['isvisible', 'isexist']:
                        return locator.is_visible() 
                    elif action.lower() in ['ishidden']:
                        return locator.is_hidden()
                    elif action.lower() in ['expect']:
                        from playwright.sync_api import expect
                        if value.lower() == 'visible': expect(locator.first).to_be_visible(timeout=timeout*1000)
                        elif value.lower() == 'notvisible': expect(locator.first).not_to_be_visible(timeout=timeout*1000)
                        elif value.lower() == 'hidden': expect(locator.first).to_be_hidden(timeout=timeout*1000)
                        elif value.lower() == 'enabled': expect(locator.first).to_be_enabled(timeout=timeout*1000)
                    elif action.lower() in ['wait']:
                        if value == None:
                            locator.wait_for()
                        elif value.lower() in ["attached","detached","visible","hidden"]:
                            locator.wait_for(state=value, timeout=timeout*1000)  
                        return True
                    else:                    
                        pass
                    return True
                if i%30==0:
                    logger.debug(f'{log_space}waiting ... {str(int(i))} sec ...')
                p.page.wait_for_timeout(1000) 
                i=i+1
            logger.error('ERROR: Timeout')
            return False
    except Exception as e:
        logger.error(e)
        return False
@validate_args
@type_check
def page(property:str=None, variable_name:str=None, timeout:int=30):
    """Return page url | title
    Example: 
        page: url | title , variable
    """
    from config import RPABROWSER
    from prefect import get_run_logger
    logger = get_run_logger()
    i=0
    if RPABROWSER == 1 or RPABROWSER == 2:
        while i <= timeout:
            try:
                from browser import p
                if property.lower()=='url':
                    import config
                    config.variables[variable_name]=p.page.url
                    return config.variables[variable_name]
                elif property.lower()=='title':
                    if not p.page.title()=="":
                        import config
                        config.variables[variable_name]=p.page.title()
                        return config.variables[variable_name]
                elif property.lower()=='is_url' and variable_name!= None:
                    return p.page.url == variable_name
                elif property.lower()=='is_title' and variable_name!= None:
                    return p.page.title() == variable_name
                elif property.lower()=='wait':
                    if variable_name==None:
                        p.page.wait_for_load_state()
                    elif variable_name.lower() in ["load","domcontentloaded","networkidle"]:
                        logger.info(f"Wait for load state {variable_name}")
                        p.page.wait_for_load_state(state=variable_name.lower(), timeout=30000)
                    return True
                p.page.wait_for_timeout(1000) 
                i=i+1
            except Exception as e:
                logger.error(e)  
                if "Execution context was destroyed, most likely because of a navigation" in str(e):
                    i=i+1
                    pass 
                else:
                    return 'ERROR'
