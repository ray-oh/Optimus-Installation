#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

Github is Optimus's standard library that provides functions for github and internet operations.

github_repo_folder_content_files(owner:str = "<owner>", repo:str = "<repository>", path:str = "<folder_path") -> list
github_repo_latest_release(owner:str = "<owner>", repo:str = "<repository>") -> str
github_repo_release(owner:str = "<owner>", repo:str = "<repository>", release_vers:str = "<release tag>") -> list
is_internet_available() -> bool
checkOptimusReleases(version="")
"""
from core.lexicon import validate_args, type_check
import requests

@validate_args
@type_check
def github_repo_folder_content_files(owner:str = "<owner>", repo:str = "<repository>", path:str = "<folder_path") -> list:
    """Files from a github folder content.
    E.g. https://github.com/ray-oh/Optimus-Installation/tree/main/installation/packages
    path = installation/packages

    Example: 
        github_repo_folder_files: ray-oh , Optimus-Installation , installation/packages
    """
    #from prefect import task, flow, get_run_logger, context
    #logger = get_run_logger()    
    #log_space = "          "

    #https://github.com/ray-oh/Optimus-Installation/tree/main/installation/packages
    #url = "https://api.github.com/repos/{owner}/{repo}/contents/{path}"
    #owner = "ray-oh" #"<owner>"
    #repo = "Optimus-Installation" #"<repository>"
    #path = "installation/packages" #"<folder_path>"
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"
    #logger.debug(f'{log_space}{url}')

    response = requests.get(url.format(owner=owner, repo=repo, path=path))
    if response.status_code == 200:
        files = response.json()
        for file in files:
            print(file["name"])
        return files
    else:
        print("Error: Could not retrieve files.")
        return "Error: Could not retrieve files."

def github_repo_latest_release(owner:str = "<owner>", repo:str = "<repository>") -> str:
    """Return latest release name / version.

    Example: 
        github_repo_latest_release: tebelorg , rpa-python
    """
    url = "https://api.github.com/repos/{owner}/{repo}/releases/latest"
    response = requests.get(url.format(owner=owner, repo=repo))
    if response.status_code == 200:
        release = response.json()
        print(f"The latest release of {repo} is {release['tag_name']} {release['name']}.")
        return release['tag_name'] #release['name']
    else:
        print("Error: Could not retrieve release information.")
        return "Error: Could not retrieve release information."

@validate_args
@type_check
def github_repo_release(owner:str = "<owner>", repo:str = "<repository>", release_vers:str = "<release tag>") -> list:
    """Return list of files for specific release version.
    E.g. https://github.com/ray-oh/tutorialGitHub/releases

    Example: 
        github_repo_release: ray-oh , tutorialGithub , 0.1.2
    """
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()    
    log_space = "          "

    url = "https://api.github.com/repos/{owner}/{repo}/releases/tags/{version}" #latest"  0.1.2
    response = requests.get(url.format(owner=owner, repo=repo))
    if response.status_code == 200:
        release = response.json()
        assets_url = release["assets_url"]
        assets_response = requests.get(assets_url)
        if assets_response.status_code == 200:
            assets = assets_response.json()
            for asset in assets:
                print(asset["name"])
            return assets
        else:
            print("Error: Could not retrieve assets.")
            return "Error: Could not retrieve assets."
    else:
        print("Error: Could not retrieve release information.")
        return "Error: Could not retrieve release information."
    return [], [], []


def is_internet_available() -> bool:
    """Return True/False if internet is available.  If calling from Jupyter/in python - give string "" as argument e.g. is_internet_available("").

    Example: 
        is_internet_available:
    """
    try:
        requests.get('https://www.google.com')
        return True
    except:
        return False

    if is_internet_available():
        print("Internet is available.")
    else:
        print("Internet is not available.")


def checkOptimusReleases(version=""):
    """ Checks available releases and returns information on releases available
    Used by launcher upgrade.
    """
    # print default starting text
    #from libraries.Github import github_repo_latest_release, is_internet_available
    if is_internet_available():
        latest_version = github_repo_latest_release("ray-oh", "Optimus-Installation")
    else:
        latest_version = "Internet or package is not available. Check again later."

    def returnVers(text):
        import re
        #text = '10.2.4-test org'
        match = re.search(r'\d+\.\d+\.\d+', text)
        if match:
            #print(match.group())
            return match.group()
        else:
            #print('No match')
            return None

    try:
        from packaging.version import parse
        v2 = parse(returnVers(version))
        v1 = parse(returnVers(latest_version))

        if v1 > v2:
            #print(f'{v1} is greater than {v2}')
            upgrade_available = "Upgrade available"
        elif v1 < v2:
            #print(f'{v1} is less than {v2}')
            upgrade_available = "OPTIMUS newer than available upgrade"
        else:
            #print(f'{v1} is equal to {v2}')
            upgrade_available = "OPTIMUS up to date"
        return f"{upgrade_available} .... \nCurrent OPTIMUS is {version} ... \nLatest release is {latest_version} ..."
    except:
        return ""
