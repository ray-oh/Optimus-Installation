"""
An always available standard library with often needed keywords.
Dataframe manipulation and processing
dropNRowsExcel(row_number:str , dataframe:str)
DFpromoteHeader(dataframe:str)
DFsaveToExcel(filename:str , dataframe:str , mode:str = 'w' , sheet:str = 'Sheet1')
DFreadExcel(table_name:str, filename:str, sheet_name=0)
DFreadFile(table_name:str, filename:str, sheet_name=0)
DFsort(sort_column:str , ascending:bool , dataframe:str)
DFdropDuplicates(unique_column:str , keep:bool , dataframe:str)
DFconcatenate(list_of_dataframes:str , name_of_merged_dataframe:str)
DFcreate(dataframe:str , columns:str)
    elif codeID.lower() == 'dropNRowsExcel'.lower():   _dropNRowsExcel(codeValue)                                
    elif codeID.lower() == 'DFpromoteHeader'.lower(): _DFpromoteHeader(codeValue) 
    elif codeID.lower() == 'DFsaveToExcel'.lower():   _DFsaveToExcel(codeValue)  
    elif codeID.lower() == 'DFreadExcel'.lower():     _DFreadExcel(codeValue) 
    elif codeID.lower() == 'DFsort'.lower():      _DFsort(codeValue) 
    elif codeID.lower() == 'DFdropDuplicates'.lower():    _DFdropDuplicates(codeValue) 
    elif codeID.lower() == 'DFconcatenate'.lower():    _DFconcatenate(codeValue)    
    elif codeID.lower() == 'DFcreate'.lower(): _DFcreate(codeValue)
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def dropNRowsExcel(row_number:str , dataframe:str):
    """Drop first N rows from dataframe.  Selecting all rows from N+1 row onwards.
    Example:
        dropNRowsExcel: {{row number}} , {{data frame}}
    """
    from config import variables
    N = int(row_number)
    variables[dataframe] = variables[dataframe].iloc[N: , :]
@validate_args
@type_check
def DFpromoteHeader(dataframe:str):
    """Promote first row of dataframe as header.
    Example:
        DFpromoteHeader: {{data frame}}
    """
    from config import variables
    new_header = variables[dataframe].iloc[0] 
    variables[dataframe] = variables[dataframe][1:] 
    variables[dataframe].columns = new_header 
@validate_args
@type_check
def DFsaveToExcel(filename:str , dataframe:str , mode:str = 'w' , sheet:str = 'Sheet1'):
    """Save dataframe to Excel file.  mode = write (w) or append (a). 
    Example:
        DFsaveToExcel: {{filename}} , {{dataframe}} , {{mode}} , {{sheet}}
    """
    from config import variables
    from pathlib import Path
    from copy import copy
    from typing import Union, Optional
    import numpy as np
    import pandas as pd
    import openpyxl
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    def copy_excel_cell_range(
            src_ws: openpyxl.worksheet.worksheet.Worksheet,
            min_row: int = None,
            max_row: int = None,
            min_col: int = None,
            max_col: int = None,
            tgt_ws: openpyxl.worksheet.worksheet.Worksheet = None,
            tgt_min_row: int = 1,
            tgt_min_col: int = 1,
            with_style: bool = True
    ) -> openpyxl.worksheet.worksheet.Worksheet:
        """
        copies all cells from the source worksheet [src_ws] starting from [min_row] row
        and [min_col] column up to [max_row] row and [max_col] column
        to target worksheet [tgt_ws] starting from [tgt_min_row] row
        and [tgt_min_col] column.
        @param src_ws:  source worksheet
        @param min_row: smallest row index in the source worksheet (1-based index)
        @param max_row: largest row index in the source worksheet (1-based index)
        @param min_col: smallest column index in the source worksheet (1-based index)
        @param max_col: largest column index in the source worksheet (1-based index)
        @param tgt_ws:  target worksheet.
                        If None, then the copy will be done to the same (source) worksheet.
        @param tgt_min_row: target row index (1-based index)
        @param tgt_min_col: target column index (1-based index)
        @param with_style:  whether to copy cell style. Default: True
        @return: target worksheet object
        """
        if tgt_ws is None:
            tgt_ws = src_ws
        for row in src_ws.iter_rows(min_row=min_row, max_row=max_row,
                                    min_col=min_col, max_col=max_col):
            for cell in row:
                tgt_cell = tgt_ws.cell(
                    row=cell.row + tgt_min_row - 1,
                    column=cell.col_idx + tgt_min_col - 1,
                    value=cell.value
                )
                if with_style and cell.has_style:
                    tgt_cell.font = copy(cell.font)
                    tgt_cell.border = copy(cell.border)
                    tgt_cell.fill = copy(cell.fill)
                    tgt_cell.number_format = copy(cell.number_format)
                    tgt_cell.protection = copy(cell.protection)
                    tgt_cell.alignment = copy(cell.alignment)
        return tgt_ws
    def append_df_to_excel_old(
        filename: Union[str, Path],
        df: pd.DataFrame,
        sheet_name: str = 'Sheet1',
        startrow: Optional[int] = None,
        max_col_width: int = 30,
        autofilter: bool = False,
        fmt_int: str = "
        fmt_float: str = "
        fmt_date: str = "yyyy-mm-dd",
        fmt_datetime: str = "yyyy-mm-dd hh:mm",
        truncate_sheet: bool = False,
        storage_options: Optional[dict] = None,
        **to_excel_kwargs
    ) -> None:
        import pandas
        from openpyxl import load_workbook
        book = load_workbook(filename)
        writer = pandas.ExcelWriter(filename, engine='openpyxl')
        writer.book = book
        writer.sheets = {ws.title: ws for ws in book.worksheets}
        for sheetname in writer.sheets:
            df.to_excel(writer,sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row, index = False,header= False)
        writer.save()
    def append_df_to_excel(
            filename: Union[str, Path],
            df: pd.DataFrame,
            sheet_name: str = 'Sheet1',
            startrow: Optional[int] = None,
            max_col_width: int = 30,
            autofilter: bool = False,
            fmt_int: str = "
            fmt_float: str = "
            fmt_date: str = "yyyy-mm-dd",
            fmt_datetime: str = "yyyy-mm-dd hh:mm",
            truncate_sheet: bool = False,
            storage_options: Optional[dict] = None,
            **to_excel_kwargs
    ) -> None:
        """
        Append a DataFrame [df] to existing Excel file [filename]
        into [sheet_name] Sheet.
        If [filename] doesn't exist, then this function will create it.
        @param filename: File path or existing ExcelWriter
                        (Example: '/path/to/file.xlsx')
        @param df: DataFrame to save to workbook
        @param sheet_name: Name of sheet which will contain DataFrame.
                        (default: 'Sheet1')
        @param startrow: upper left cell row to dump data frame.
                        Per default (startrow=None) calculate the last row
                        in the existing DF and write to the next row...
        @param max_col_width: maximum column width in Excel. Default: 40
        @param autofilter: boolean - whether add Excel autofilter or not. Default: False
        @param fmt_int: Excel format for integer numbers
        @param fmt_float: Excel format for float numbers
        @param fmt_date: Excel format for dates
        @param fmt_datetime: Excel format for datetime's
        @param truncate_sheet: truncate (remove and recreate) [sheet_name]
                            before writing DataFrame to Excel file
        @param storage_options: dict, optional
            Extra options that make sense for a particular storage connection, e.g. host, port,
            username, password, etc., if using a URL that will be parsed by fsspec, e.g.,
            starting “s3://”, “gcs://”.
        @param to_excel_kwargs: arguments which will be passed to `DataFrame.to_excel()`
                                [can be a dictionary]
        @return: None
        Usage examples:
        >>> append_df_to_excel('/tmp/test.xlsx', df, autofilter=True,
                            freeze_panes=(1,0))
        >>> append_df_to_excel('/tmp/test.xlsx', df, header=None, index=False)
        >>> append_df_to_excel('/tmp/test.xlsx', df, sheet_name='Sheet2',
                            index=False)
        >>> append_df_to_excel('/tmp/test.xlsx', df, sheet_name='Sheet2',
                            index=False, startrow=25)
        >>> append_df_to_excel('/tmp/test.xlsx', df, index=False,
                            fmt_datetime="dd.mm.yyyy hh:mm")
        (c) [MaxU](https://stackoverflow.com/users/5741205/maxu?tab=profile)
        """
        def set_column_format(ws, column_letter, fmt):
            for cell in ws[column_letter]:
                cell.number_format = fmt
        filename = Path(filename)
        file_exists = filename.is_file()
        first_col = int(to_excel_kwargs.get("index", True)) + 1
        if 'engine' in to_excel_kwargs:
            to_excel_kwargs.pop('engine')
        if file_exists:
            wb = load_workbook(filename)
            sheet_names = wb.sheetnames
            sheet_exists = sheet_name in sheet_names
            sheets = {ws.title: ws for ws in wb.worksheets}
        with pd.ExcelWriter(
            filename.with_suffix(".xlsx"),
            engine="openpyxl",
            mode="a" if file_exists else "w",
            if_sheet_exists="new" if file_exists else None,
            date_format=fmt_date,
            datetime_format=fmt_datetime,
            storage_options=storage_options
        ) as writer:
            if file_exists:
                writer.book = wb
                if startrow is None and sheet_name in writer.book.sheetnames:
                    startrow = writer.book[sheet_name].max_row
                if truncate_sheet and sheet_name in writer.book.sheetnames:
                    idx = writer.book.sheetnames.index(sheet_name)
                    writer.book.remove(writer.book.worksheets[idx])
                    writer.book.create_sheet(sheet_name, idx)
                writer.sheets = sheets
            else:
                startrow = 0
            df.to_excel(writer, sheet_name=sheet_name, **to_excel_kwargs)
            worksheet = writer.sheets[sheet_name]
            if autofilter:
                worksheet.auto_filter.ref = worksheet.dimensions
            for xl_col_no, dtyp in enumerate(df.dtypes, first_col):
                col_no = xl_col_no - first_col
                width = max(df.iloc[:, col_no].astype(str).str.len().max(),
                            len(df.columns[col_no]) + 6)
                width = min(max_col_width, width)
                column_letter = get_column_letter(xl_col_no)
                worksheet.column_dimensions[column_letter].width = width
                if np.issubdtype(dtyp, np.integer):
                    set_column_format(worksheet, column_letter, fmt_int)
                if np.issubdtype(dtyp, np.floating):
                    set_column_format(worksheet, column_letter, fmt_float)
        if file_exists and sheet_exists:
            wb = load_workbook(filename)
            new_sheet_name = set(wb.sheetnames) - set(sheet_names)
            if new_sheet_name:
                new_sheet_name = list(new_sheet_name)[0]
            copy_excel_cell_range(
                src_ws=wb[new_sheet_name],
                tgt_ws=wb[sheet_name],
                tgt_min_row=startrow + 1,
                with_style=True
            )
            del wb[new_sheet_name]
            wb.save(filename)
            wb.close()
    _ifsheetexist = None
    if mode.lower() == 'a':
        _ifsheetexist = 'overlay'
        append_df_to_excel(filename, variables[dataframe], sheet_name=sheet,
                    index=False)
    else:
        mode = 'w'  
        with pd.ExcelWriter(filename, if_sheet_exists=_ifsheetexist, engine="openpyxl",
                            mode=mode) as writer:  
            variables[dataframe].to_excel(writer, sheet_name= sheet, index=False)
        print(_ifsheetexist, sheet, mode)
@validate_args
@type_check
def DFreadExcel(table_name:str, filename:str, sheet_name=0):
    """Create a table from given Excel.  
    Table content accessed by {{table_name:field_name}} and iterate.
    Example:
        DFreadExcel: {{table_name}}, {{file name}} , {{sheet_name}}
    """
    import pandas as pd
    import config
    dataframe = table_name
    config.variables[dataframe] = pd.read_excel(filename, sheet_name=sheet_name)
@validate_args
@type_check
def DFreadFile(table_name:str, filename:str, sheet_name=0):
    """Create a table from given Excel or csv.  
    Table content accessed by {{table_name:field_name}} and iterate.
    Example:
        DFreadExcel: {{table_name}}, {{file name}} , {{sheet_name}}
    """
    import pandas as pd
    import config
    from prefect import get_run_logger
    logger = get_run_logger()
    dataframe = table_name
    if '.xlsx' in filename or '.xls' in filename or '.xlsm' in filename:
        config.variables[dataframe] = pd.read_excel(filename, sheet_name=sheet_name)
    elif '.csv' in filename:
        config.variables[dataframe] = pd.read_csv(filename)
    logger.debug(f"Table Columns: {config.variables[dataframe].columns.tolist()}")
@validate_args
@type_check
def DFsort(sort_column:str , ascending:bool , dataframe:str):
    """Sort a dataframe.  ascending=True or False.
    Example:
        DFsort: {{sort column}} , {{ascending}} , {{data frame}}
    """
    from config import variables
    columnList = sort_column 
    boolAscending = bool(ascending) 
    variables[dataframe].sort_values(by=columnList, ascending = boolAscending, inplace = True)
@validate_args
@type_check
def DFdropDuplicates(unique_column:str , keep:bool , dataframe:str):
    """Sort a dataframe.  ascending=True or False.
    Example:
        DFsort: {{sort column}} , {{ascending}} , {{data frame}}
    """
    from config import variables
    uniqueColumnList = unique_column 
    variables[dataframe] = variables[dataframe].drop_duplicates(uniqueColumnList, keep=keep)
@validate_args
@type_check
def DFconcatenate(list_of_dataframes:str , name_of_merged_dataframe:str):
    """Concatenate a list of dataframes.
    Example:
        DFconcatenate: {{list of dataframes}} , {{name of merged dataframe}}
    """
    from config import variables
    import pandas as pd
    dataFrameList = list_of_dataframes 
    variables[name_of_merged_dataframe] = pd.concat(map(lambda x: variables[x], dataFrameList), ignore_index=True)
@validate_args
@type_check
def DFcreate(dataframe:str , columns:str):
    """Create a dataframe from a column of values.
    Example:
        DFcreate: {{dataframe}} , {{column of values}}
    """
    from config import variables
    import pandas as pd
    dataFrameName = dataframe 
    columnslist = columns 
    elementlist = list(map(lambda x: x.strip(), columnslist.split(',')))
    dictionary = variables
    print('1', dataFrameName, elementlist, dictionary)
    dictresult = dict((k, dictionary[k]) for k in elementlist
            if k in dictionary)
    print('2', dictresult)
    if not dataFrameName in variables:
        variables[dataFrameName] = pd.DataFrame(dictresult, index=[0])
    else:
        n = variables[dataFrameName].__len__()
        variables[dataFrameName] = pd.concat([variables[dataFrameName], pd.DataFrame(dictresult, index=[n])])
    print('3', variables[dataFrameName])
