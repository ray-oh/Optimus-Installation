#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'dropNRowsExcel'.lower():   _dropNRowsExcel(codeValue)                                # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFpromoteHeader'.lower(): _DFpromoteHeader(codeValue) # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFsaveToExcel'.lower():   _DFsaveToExcel(codeValue)  # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFreadExcel'.lower():     _DFreadExcel(codeValue) # read Excel to dataframe.  DFreadExcel:filename, variableDataFrameName
    elif codeID.lower() == 'DFsort'.lower():      _DFsort(codeValue) # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFdropDuplicates'.lower():    _DFdropDuplicates(codeValue) # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFconcatenate'.lower():    _DFconcatenate(codeValue)    # merge files.  merge:newFile,oldFile,olderFile
    elif codeID.lower() == 'DFcreate'.lower(): _DFcreate(codeValue)


"""

from core.lexicon import validate_args, type_check
#import pandas as pd

@validate_args
@type_check
def dropNRowsExcel(row_number:str , dataframe:str):
    """Drop first N rows from dataframe.  Selecting all rows from N+1 row onwards.

    Example:
        dropNRowsExcel: {{row number}} , {{data frame}}
    """
    #tmpDict = parseArguments('Nrows, variableDataFrameName',codeValue)
    # Drop first N rows
    # by selecting all rows from 4th row onwards
    from config import variables

    #N = variables['tmpDict['Nrows']']
    #variables[tmpDict['variableDataFrameName']] = variables[tmpDict['variableDataFrameName']].iloc[N: , :]

    N = int(row_number)
    variables[dataframe] = variables[dataframe].iloc[N: , :]

@validate_args
@type_check
def DFpromoteHeader(dataframe:str):
    """Promote first row of dataframe as header.

    Example:
        DFpromoteHeader: {{data frame}}
    """
    from config import variables

    #tmpDict = parseArguments('variableDataFrameName',codeValue)
    new_header = variables[dataframe].iloc[0] #grab the first row for the header
    variables[dataframe] = variables[dataframe][1:] #take the data less the header row
    variables[dataframe].columns = new_header #set the header row as the df header

@validate_args
@type_check
def DFsaveToExcel(filename:str , dataframe:str , mode:str = 'w' , sheet:str = 'Sheet1'):
    """Save dataframe to Excel file.  mode = write (w) or append (a). 

    Example:
        DFsaveToExcel: {{filename}} , {{dataframe}} , {{mode}} , {{sheet}}
    """
    from config import variables

    from pathlib import Path
    from copy import copy
    from typing import Union, Optional
    import numpy as np
    import pandas as pd
    import openpyxl
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter


    def copy_excel_cell_range(
            src_ws: openpyxl.worksheet.worksheet.Worksheet,
            min_row: int = None,
            max_row: int = None,
            min_col: int = None,
            max_col: int = None,
            tgt_ws: openpyxl.worksheet.worksheet.Worksheet = None,
            tgt_min_row: int = 1,
            tgt_min_col: int = 1,
            with_style: bool = True
    ) -> openpyxl.worksheet.worksheet.Worksheet:
        """
        copies all cells from the source worksheet [src_ws] starting from [min_row] row
        and [min_col] column up to [max_row] row and [max_col] column
        to target worksheet [tgt_ws] starting from [tgt_min_row] row
        and [tgt_min_col] column.

        @param src_ws:  source worksheet
        @param min_row: smallest row index in the source worksheet (1-based index)
        @param max_row: largest row index in the source worksheet (1-based index)
        @param min_col: smallest column index in the source worksheet (1-based index)
        @param max_col: largest column index in the source worksheet (1-based index)
        @param tgt_ws:  target worksheet.
                        If None, then the copy will be done to the same (source) worksheet.
        @param tgt_min_row: target row index (1-based index)
        @param tgt_min_col: target column index (1-based index)
        @param with_style:  whether to copy cell style. Default: True

        @return: target worksheet object
        """
        if tgt_ws is None:
            tgt_ws = src_ws

        # https://stackoverflow.com/a/34838233/5741205
        for row in src_ws.iter_rows(min_row=min_row, max_row=max_row,
                                    min_col=min_col, max_col=max_col):
            for cell in row:
                tgt_cell = tgt_ws.cell(
                    row=cell.row + tgt_min_row - 1,
                    column=cell.col_idx + tgt_min_col - 1,
                    value=cell.value
                )
                if with_style and cell.has_style:
                    # tgt_cell._style = copy(cell._style)
                    tgt_cell.font = copy(cell.font)
                    tgt_cell.border = copy(cell.border)
                    tgt_cell.fill = copy(cell.fill)
                    tgt_cell.number_format = copy(cell.number_format)
                    tgt_cell.protection = copy(cell.protection)
                    tgt_cell.alignment = copy(cell.alignment)
        return tgt_ws

    #   append_df_to_excel(filename, variables[dataFrameName], sheet_name=_sheet, index=False)
    def append_df_to_excel_old(
        filename: Union[str, Path],
        df: pd.DataFrame,
        sheet_name: str = 'Sheet1',
        startrow: Optional[int] = None,
        max_col_width: int = 30,
        autofilter: bool = False,
        fmt_int: str = "#,##0",
        fmt_float: str = "#,##0.00",
        fmt_date: str = "yyyy-mm-dd",
        fmt_datetime: str = "yyyy-mm-dd hh:mm",
        truncate_sheet: bool = False,
        storage_options: Optional[dict] = None,
        **to_excel_kwargs
    ) -> None:
        import pandas
        from openpyxl import load_workbook

        book = load_workbook(filename)
        writer = pandas.ExcelWriter(filename, engine='openpyxl')
        writer.book = book
        writer.sheets = {ws.title: ws for ws in book.worksheets}

        for sheetname in writer.sheets:
            df.to_excel(writer,sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row, index = False,header= False)

        writer.save()


    def append_df_to_excel(
            filename: Union[str, Path],
            df: pd.DataFrame,
            sheet_name: str = 'Sheet1',
            startrow: Optional[int] = None,
            max_col_width: int = 30,
            autofilter: bool = False,
            fmt_int: str = "#,##0",
            fmt_float: str = "#,##0.00",
            fmt_date: str = "yyyy-mm-dd",
            fmt_datetime: str = "yyyy-mm-dd hh:mm",
            truncate_sheet: bool = False,
            storage_options: Optional[dict] = None,
            **to_excel_kwargs
    ) -> None:
        """
        Append a DataFrame [df] to existing Excel file [filename]
        into [sheet_name] Sheet.
        If [filename] doesn't exist, then this function will create it.

        @param filename: File path or existing ExcelWriter
                        (Example: '/path/to/file.xlsx')
        @param df: DataFrame to save to workbook
        @param sheet_name: Name of sheet which will contain DataFrame.
                        (default: 'Sheet1')
        @param startrow: upper left cell row to dump data frame.
                        Per default (startrow=None) calculate the last row
                        in the existing DF and write to the next row...
        @param max_col_width: maximum column width in Excel. Default: 40
        @param autofilter: boolean - whether add Excel autofilter or not. Default: False
        @param fmt_int: Excel format for integer numbers
        @param fmt_float: Excel format for float numbers
        @param fmt_date: Excel format for dates
        @param fmt_datetime: Excel format for datetime's
        @param truncate_sheet: truncate (remove and recreate) [sheet_name]
                            before writing DataFrame to Excel file
        @param storage_options: dict, optional
            Extra options that make sense for a particular storage connection, e.g. host, port,
            username, password, etc., if using a URL that will be parsed by fsspec, e.g.,
            starting “s3://”, “gcs://”.
        @param to_excel_kwargs: arguments which will be passed to `DataFrame.to_excel()`
                                [can be a dictionary]
        @return: None

        Usage examples:

        >>> append_df_to_excel('/tmp/test.xlsx', df, autofilter=True,
                            freeze_panes=(1,0))

        >>> append_df_to_excel('/tmp/test.xlsx', df, header=None, index=False)

        >>> append_df_to_excel('/tmp/test.xlsx', df, sheet_name='Sheet2',
                            index=False)

        >>> append_df_to_excel('/tmp/test.xlsx', df, sheet_name='Sheet2',
                            index=False, startrow=25)

        >>> append_df_to_excel('/tmp/test.xlsx', df, index=False,
                            fmt_datetime="dd.mm.yyyy hh:mm")

        (c) [MaxU](https://stackoverflow.com/users/5741205/maxu?tab=profile)
        """
        def set_column_format(ws, column_letter, fmt):
            for cell in ws[column_letter]:
                cell.number_format = fmt
        filename = Path(filename)
        file_exists = filename.is_file()
        # process parameters
        # calculate first column number
        # if the DF will be written using `index=True`, then `first_col = 2`, else `first_col = 1`
        first_col = int(to_excel_kwargs.get("index", True)) + 1
        # ignore [engine] parameter if it was passed
        if 'engine' in to_excel_kwargs:
            to_excel_kwargs.pop('engine')
        # save content of existing sheets
        if file_exists:
            wb = load_workbook(filename)
            sheet_names = wb.sheetnames
            sheet_exists = sheet_name in sheet_names
            sheets = {ws.title: ws for ws in wb.worksheets}

        with pd.ExcelWriter(
            filename.with_suffix(".xlsx"),
            engine="openpyxl",
            mode="a" if file_exists else "w",
            if_sheet_exists="new" if file_exists else None,
            date_format=fmt_date,
            datetime_format=fmt_datetime,
            storage_options=storage_options
        ) as writer:
            if file_exists:
                # try to open an existing workbook
                writer.book = wb
                # get the last row in the existing Excel sheet
                # if it was not specified explicitly
                if startrow is None and sheet_name in writer.book.sheetnames:
                    startrow = writer.book[sheet_name].max_row
                # truncate sheet
                if truncate_sheet and sheet_name in writer.book.sheetnames:
                    # index of [sheet_name] sheet
                    idx = writer.book.sheetnames.index(sheet_name)
                    # remove [sheet_name]
                    writer.book.remove(writer.book.worksheets[idx])
                    # create an empty sheet [sheet_name] using old index
                    writer.book.create_sheet(sheet_name, idx)
                # copy existing sheets
                writer.sheets = sheets
            else:
                # file doesn't exist, we are creating a new one
                startrow = 0

            # write out the DataFrame to an ExcelWriter
            df.to_excel(writer, sheet_name=sheet_name, **to_excel_kwargs)
            worksheet = writer.sheets[sheet_name]

            if autofilter:
                worksheet.auto_filter.ref = worksheet.dimensions

            for xl_col_no, dtyp in enumerate(df.dtypes, first_col):
                col_no = xl_col_no - first_col
                width = max(df.iloc[:, col_no].astype(str).str.len().max(),
                            len(df.columns[col_no]) + 6)
                width = min(max_col_width, width)
                column_letter = get_column_letter(xl_col_no)
                worksheet.column_dimensions[column_letter].width = width
                if np.issubdtype(dtyp, np.integer):
                    set_column_format(worksheet, column_letter, fmt_int)
                if np.issubdtype(dtyp, np.floating):
                    set_column_format(worksheet, column_letter, fmt_float)

        if file_exists and sheet_exists:
            # move (append) rows from new worksheet to the `sheet_name` worksheet
            wb = load_workbook(filename)
            # retrieve generated worksheet name
            new_sheet_name = set(wb.sheetnames) - set(sheet_names)
            if new_sheet_name:
                new_sheet_name = list(new_sheet_name)[0]
            # copy rows written by `df.to_excel(...)` to
            copy_excel_cell_range(
                src_ws=wb[new_sheet_name],
                tgt_ws=wb[sheet_name],
                tgt_min_row=startrow + 1,
                with_style=True
            )
            # remove new (generated by Pandas) worksheet
            del wb[new_sheet_name]
            wb.save(filename)
            wb.close()

    #tmpDict = parseArguments('filename, variableDataFrameName, mode, sheet',codeValue)
    #filename = tmpDict['filename']
    #dataFrameName = tmpDict['variableDataFrameName']
    #if 'sheet' in tmpDict: 
    #    _sheet = tmpDict['sheet']
    #else:
    #    _sheet = 'Sheet1'
    _ifsheetexist = None

    if mode.lower() == 'a':
        #_mode = tmpDict['mode'] # write w or append a
        #if mode.lower() == 'a': 
        _ifsheetexist = 'overlay'
        append_df_to_excel(filename, variables[dataframe], sheet_name=sheet,
                    index=False)
    else:
        mode = 'w'  # write
        #variables[tmpDict['variableDataFrameName']].to_excel(tmpDict['filename'], index=False)
        with pd.ExcelWriter(filename, if_sheet_exists=_ifsheetexist, engine="openpyxl",
                            mode=mode) as writer:  
            variables[dataframe].to_excel(writer, sheet_name= sheet, index=False)
        #    #variables[dataFrameName].to_excel(writer, index=False)
        print(_ifsheetexist, sheet, mode)


@validate_args
@type_check
def DFreadExcel(filename:str , dataframe:str):
    """Create a dataframe from given Excel.

    Example:
        DFreadExcel: {{file name}} , {{data frame}}
    """
    import pandas as pd
    #tmpDict = parseArguments('filename, variableDataFrameName',codeValue)
    variables[dataframe] = pd.read_excel(filename)


@validate_args
@type_check
def DFsort(sort_column:str , ascending:bool , dataframe:str):
    """Sort a dataframe.  ascending=True or False.

    Example:
        DFsort: {{sort column}} , {{ascending}} , {{data frame}}
    """
    from config import variables
    #tmpDict = parseArguments('sortFieldList, boolAscending, variableDataFrameName',codeValue)

    columnList = sort_column #tmpDict['sortFieldList']
    boolAscending = bool(ascending) #tmpDict['boolAscending']
    variables[dataframe].sort_values(by=columnList, ascending = boolAscending, inplace = True)

@validate_args
@type_check
def DFdropDuplicates(unique_column:str , keep:bool , dataframe:str):
    """Sort a dataframe.  ascending=True or False.

    Example:
        DFsort: {{sort column}} , {{ascending}} , {{data frame}}
    """
    from config import variables
    #tmpDict = parseArguments('uniqueColumnList, keep, variableDataFrameName',codeValue)

    uniqueColumnList = unique_column #tmpDict['uniqueColumnList']
    #keep = bool(keep) #tmpDict['keep']
    variables[dataframe] = variables[dataframe].drop_duplicates(uniqueColumnList, keep=keep)

@validate_args
@type_check
def DFconcatenate(list_of_dataframes:str , name_of_merged_dataframe:str):
    """Concatenate a list of dataframes.

    Example:
        DFconcatenate: {{list of dataframes}} , {{name of merged dataframe}}
    """
    from config import variables
    import pandas as pd
    #tmpDict = parseArguments('dataFrameList, mergedDataFrameName',codeValue)
    dataFrameList = list_of_dataframes #tmpDict['dataFrameList']
    variables[name_of_merged_dataframe] = pd.concat(map(lambda x: variables[x], dataFrameList), ignore_index=True)

@validate_args
@type_check
def DFcreate(dataframe:str , columns:str):
    """Create a dataframe from a column of values.

    Example:
        DFcreate: {{dataframe}} , {{column of values}}
    """
    from config import variables
    import pandas as pd

    #tmpDict = parseArguments('dataFrameName, columnslist',codeValue)
    dataFrameName = dataframe #tmpDict['dataFrameName']
    columnslist = columns #tmpDict['columnslist'].strip('\"')
    elementlist = list(map(lambda x: x.strip(), columnslist.split(',')))
    dictionary = variables
    print('1', dataFrameName, elementlist, dictionary)
    dictresult = dict((k, dictionary[k]) for k in elementlist
            if k in dictionary)
    print('2', dictresult)
    if not dataFrameName in variables:
        #n == 0:
        variables[dataFrameName] = pd.DataFrame(dictresult, index=[0])
    else:
        n = variables[dataFrameName].__len__()
        variables[dataFrameName] = pd.concat([variables[dataFrameName], pd.DataFrame(dictresult, index=[n])])
    print('3', variables[dataFrameName])
