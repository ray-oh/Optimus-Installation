"""
An always available standard library with often needed keywords.
Python functions
runJupyterNb(nb_file:str, jsonString:str)
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def runJupyterNb(nb_file:str, jsonString:str):
    """Run Jupyter Notebook.
    Example: 
        runJupyterNb: {{notebook file}} , {{parameters in json format}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "
    logger.debug(f"{log_space}Run Jupyter Notebook = {nb_file}, Parameters = {jsonString}")
    from core.files import checkWorkDirectory
    from pathlib import Path, PureWindowsPath
    CWD_DIR = checkWorkDirectory('.')
    import papermill as pm
    import json
    paramDict = json.loads(jsonString)
    from datetime import datetime
    currentDateAndTime = datetime.now()
    res = pm.execute_notebook(
        nb_file, nb_file.replace('.ipynb', '_output_'+ currentDateAndTime.strftime("%Y%m%d_%H%M%S") +'.ipynb'),
        parameters = paramDict
    )
