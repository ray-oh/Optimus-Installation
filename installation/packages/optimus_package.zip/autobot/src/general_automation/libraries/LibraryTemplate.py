"""
An always available standard library with often needed keywords.
Template library.  Copy and modify this to add new functions.
"""
from core.lexicon import validate_args, type_check
@validate_args
@type_check
def function_template(arg: str, **kwargs) -> None:
    """Template for creating custom optimus functions
    Args:
        None
    Example:
        rem: {{text or action to comment}}
    Raises:
        None
    Returns:
        None
    """
    print(arg)
    return None
