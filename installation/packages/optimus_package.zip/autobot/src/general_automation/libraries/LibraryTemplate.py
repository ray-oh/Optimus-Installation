#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).
"""

from core.lexicon import validate_args, type_check

@validate_args
@type_check
def function_template(arg: str, **kwargs) -> None:
    """Template for creating custom optimus functions

    Args:
        None

    Example:
        rem: {{text or action to comment}}
        
    Raises:
        None

    Returns:
        None
    """
    print(arg)
    return None
