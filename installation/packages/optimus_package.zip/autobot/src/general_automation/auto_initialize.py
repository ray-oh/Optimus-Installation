_B='/scripts'
_A='OPTIMUS_DIR'
from pathlib import Path,PureWindowsPath
from core.files import renameFile
import configparser
from auto_utility_parsers import parseArg
import sys,os
def checkWorkDirectory(strpath):A=Path(strpath).resolve().absolute().__str__();return A
def changeWorkingDirectory(NEW_DIR):import os;os.chdir(NEW_DIR);A=Path('.').absolute().__str__();return A
def checkSettingsPath(SETTINGS_PATH):
	if not Path(SETTINGS_PATH).is_file():print('Missing file: settings.ini');from config import EX_CONFIG as A;sys.exit(A)
def initializeFromSettings(SETTINGS_PATH,deploymentRun=False):A=configparser.ConfigParser();A.read(SETTINGS_PATH);B=parseArg(A,deploymentRun);return A,B
def runBatchCommand(commandStr):C='Results of batch run *********************************************************';A=commandStr;import subprocess as D,sys;print('Run command string:',A);B=D.run(A,capture_output=True,text=True);print('Batch command working directory',Path('.').absolute().__str__());print('      ','Run batch command: ',A,'Return code:',B.returncode);print(C);print(B.stdout);print(C);return B
def setEnvVar(env_var=_A,env_val=Path('.').resolve().parents[0].absolute().__str__()):import os;os.system('SETX {0} {1}'.format(env_var,env_val))
def updateDependentFolders(field,PROGRAM_DIR,configObj,section):
	C=field;B=section;A=configObj;D=Path(PROGRAM_DIR+_B).absolute().__str__()
	if not A.has_section(B):A.add_section(B)
	A[B][C]=str(C);return D
def configValidation(configObj,PROGRAM_DIR,AUTOBOT_DIR,SCRIPTS_DIR,PREFECT_DIR,SETTINGS_PATH,INITIALIZATION,FLOWRUN=0,DEPLOYMENTNAME=''):
	J='PREFECT_DIR';I='SCRIPTS_DIR';H='AUTOBOT_DIR';G=PREFECT_DIR;F=SCRIPTS_DIR;E=AUTOBOT_DIR;D=PROGRAM_DIR;C='settings';B=DEPLOYMENTNAME;A=configObj;F=Path(D+_B).absolute().__str__();G=Path(D+'/prefect').absolute().__str__();E=Path(D+'/autobot').absolute().__str__()
	if INITIALIZATION==1:
		if not A.has_section(C):A.add_section(C)
		A[C][H]=str(E);A[C][I]=str(F);A[C][J]=str(G);setEnvVar(_A,D)
	if FLOWRUN==2:
		if A.has_section(B):A.remove_section(B)
		A.add_section(B);A[B]=A[C]
		if not A.has_section(B):A.add_section(B)
		A[B][H]=str(E);A[B][I]=str(F);A[B][J]=str(G)
	print('update: AUTOBOT_DIR, PROGRAM_DIR, SCRIPTS_DIR, PREFECT_DIR',E,D,F,G);A[C]['INITIALIZATION']=str(0);A[C]['FLOWRUN']=str(0);save_settings(SETTINGS_PATH,A);return A,D,E,F,G
def checkStartFile(STARTFILE,SCRIPTS_DIR):
	B='.xlsm';A=STARTFILE
	if not A.endswith(('.xls',B)):A=A+B
	import os
	if len(os.path.dirname(A))==0:A=Path(SCRIPTS_DIR,A)
	else:A=Path(A)
	return A.absolute().__str__()
def checkFileValid(file):
	if not file.is_file():print('Warning - Invalid file or path: ',file.absolute());return False
	return True
def checkSaveSettings(SETTINGS,SETTINGS_PATH,configObj):
	A=SETTINGS
	if A==2:0
	elif A==1 or A==0:
		if A==1:save_settings(SETTINGS_PATH,configObj)
def setup_assetDirectories(STARTFILE,SCRIPTS_DIR,OUTPUT_PATH,IMAGE_PATH,LOG_PATH,ADDON_PATH,SRCLOGFILE):
	G=STARTFILE;D='/';H=Path(G).name.__str__();I=Path(G).stem.__str__();A=(Path(G).parents[0]/I).resolve().absolute().__str__();B=Path(A+D+OUTPUT_PATH).absolute().__str__();E=Path(A+D+IMAGE_PATH).absolute().__str__();C=Path(A+D+LOG_PATH).absolute().__str__();F=Path(A+D+ADDON_PATH).absolute().__str__();J=Path(C+D+SRCLOGFILE).absolute().__str__()
	if not(Path(A).exists()and Path(B).exists()and Path(E).exists()and Path(C).exists()and Path(F).exists()):
		if not Path(A).exists():os.mkdir(A)
		if not Path(B).exists():os.mkdir(B)
		if not Path(B).exists():os.mkdir(B)
		if not Path(E).exists():os.mkdir(E)
		if not Path(C).exists():os.mkdir(C)
		if not Path(F).exists():os.mkdir(F)
		print('Script Directories created ...')
	return H,A,B,E,C,F,J
def save_settings(SETTINGS_PATH,configObj):
	A=SETTINGS_PATH;from config import constants as C;B=A+'_'+C['todayYYYYMMDD']+'_'+C['now_hhmmss']+'.bak';print(B);renameFile(A,B)
	with open(A,'w')as D:configObj.write(D)
	print('Settings updated and saved:',A,' Backup:',B)