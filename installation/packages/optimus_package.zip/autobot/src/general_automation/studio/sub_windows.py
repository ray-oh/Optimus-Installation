_A3='Realtime Shell Command Output'
_A2='DEBUG LEVEL'
_A1='Prefect Deployments'
_A0='Deployments'
_z='period'
_y='period_num'
_x='Period'
_w='multiple'
_v='-STATUS LIST-'
_u='Status'
_t='months'
_s='Delete'
_r='Scheduled'
_q='Pending'
_p='Running'
_o='Task Scheduler Query'
_n='CREATE'
_m='Optimus\\Scripts\\'
_l='Default'
_k='ONSTART'
_j='Optimus Orion'
_i='/ri 180 /du 0010:00'
_h='Optimus\\'
_g='utf-8'
_f='white'
_e='black'
_d='Save'
_c='action'
_b='Action'
_a='SCRIPT LIST_'
_Z='DAILY'
_Y='Optimus Agent'
_X='_IN_'
_W='INFO LEVEL'
_V='days'
_U='Crashed'
_T='Failed'
_S='Completed'
_R='Task Scheduler'
_Q='task'
_P='program'
_O='-OUTPUT-'
_N='Prog'
_M='Query'
_L='task_path'
_K='start_time'
_J='modifier'
_I='freq_mod'
_H='freq'
_G='Run'
_F='description'
_E='Exit'
_D='top'
_C=None
_B=False
_A=True
from pathlib import Path
import os,FreeSimpleGUI as sg
from core.dates import localTime
from studio.launcher import sub_window,prog_path
tasks={}
tasks[_Y]={_P:f"powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}",_K:'06:30',_H:_Z,_I:'1',_L:_h,_Q:_Y,_J:_i,_F:'Agent responsible for checking for flow runs that are ready to run and starting their execution.  Lightweight polling service that gets scheduled work from a work pool and deploy corresponding flow runs.'}
tasks[_j]={_P:Path(f"{prog_path}\\autobot\\startOrion.bat").absolute().__str__(),_K:'',_H:_k,_I:'',_L:_h,_Q:_j,_J:f' /ru "{os.environ.get("USERNAME")}" /delay 0015:00',_F:'Enables flow run monitoring dashboard.  Track and manage your flows, runs, and deployments and additionally filter by names, tags, and other metadata.  Check out the dashboard at http://127.0.0.1:4200'}
tasks[_l]={_P:f"runRPA.bat -f {''} -sh main -sc main",_K:'09:00',_H:_Z,_I:'1',_L:_m,_Q:'',_J:_i,_F:'Schedule Optimus automation scripts.'}
def sub_window_task_scheduler(prog_path,runrpa_script,window,values,task_path=_m,script_list=_C,action_list=[_n,'DELETE','RUN','QUERY','QUERY ALL']):
	H=values;G=prog_path;C=task_path;B=script_list;from core.files import list_of_files as N
	if B==_C:
		A=_l;D=tasks[A][_K];I=tasks[A][_H];E=tasks[A][_I];C=tasks[A][_L];J=tasks[A][_J];K=tasks[A][_F];B=N(f"{G}\\scripts",'*.xlsm')
		if _a in H:F=os.path.splitext(H[_a][0])[0]
		else:F=B[0]
		L=f"{G}\\{runrpa_script}";M=_n
	else:A=_Y;L=tasks[A][_P];D=tasks[A][_K];I=tasks[A][_H];E=tasks[A][_I];C=tasks[A][_L];F=tasks[A][_Q];J=tasks[A][_J];K=tasks[A][_F];M='RUN'
	O=D[:2];P=D[-2:];Q=[[sg.Text('Task')],[sg.Text(_b)],[sg.Text('Start Time')],[sg.Text('Frequency')]];R=[f"{A:02d}"for A in range(0,24)];S=[f"{A:02d}"for A in range(0,60)];E=[f"{A:02d}"for A in range(1,61)];T=['MINUTE','HOURLY',_Z,'WEEKLY','MONTHLY','ONCE',_k];U=[[sg.Combo(B,size=(37,1),default_value=F,key='Task Scheduler tasklist',readonly=_A,enable_events=_A)],[sg.Combo(action_list,size=(37,1),default_value=M,key=_c,readonly=_A,enable_events=_A)],[sg.Spin([A for A in R],initial_value=O,readonly=_A,key='start_hr',enable_events=_A),sg.Text(':'),sg.Spin([A for A in S],initial_value=P,readonly=_A,key='start_min',enable_events=_A)],[sg.Combo(T,size=(25,1),default_value=I,key=_H,readonly=_A,enable_events=_A),sg.Spin([A for A in E],initial_value='01',readonly=_A,key=_I,enable_events=_A)],[sg.Input(J,size=(37,1),key=_J,enable_events=_A)]];V=[[sg.Text(K,size=(20,8),key=_F)]];W=[sg.Column(Q,vertical_alignment=_D),sg.Column(U,vertical_alignment=_D),sg.Column(V,vertical_alignment=_D)];X=[sg.Button(_G,key='Task Scheduler Run'),sg.Button(_E),sg.VSeparator(),sg.Button('Query All',key=_o),sg.Button(_R,key='Windows Task Scheduler')];Y=window.current_location();sub_window(program=L,title=_R,run=_B,location=Y,disabled=_B,insertWindow=W,window_buttons=[X],replace_window_buttons=_A,task_path=C)
def sub_windows_prefect(window):A=[_S,_T,_U,_p,_q,_r,'Late'];B=[_M,_s];C=[f"{A:03d}"for A in range(0,365)];K=[f"{A:02d}"for A in range(0,24)];D=['hours',_V,'weeks',_t];E=_N;F=[[sg.Text(_u)],[sg.Listbox(A,size=(22,5),expand_y=_A,enable_events=_A,key=_v,select_mode=_w,default_values=(_S,_T,_U))]];G=[[sg.Text(_b)],[sg.Combo(B,size=(10,1),default_value=_M,key=_c,readonly=_A)],[sg.Text('')],[sg.Text(_x)],[sg.Text('Past'),sg.Spin([A for A in C],initial_value='001',readonly=_A,size=(3,1),key=_y),sg.Combo(D,size=(8,1),default_value=_V,key=_z,readonly=_A)]];H=[sg.Column(F,vertical_alignment=_D),sg.Column(G,vertical_alignment=_D)];I=[sg.Button(_G,key='Prefect Run'),sg.Button(_E),sg.VSeparator(),sg.Text('Dashboard: '),sg.Button('Monitor Flows',key='Prefect Monitor'),sg.Button(_A0,key=_A1)];J=window.current_location();sub_window(program=E,title='Workflow Management',run=_B,location=J,insertWindow=H,window_buttons=[I],replace_window_buttons=_A,visible=_B);return
def sub_windows_run_script(prog_path,label_str,version,window):
	G='Prefect';F='main';E='Debug';B=label_str;A=prog_path;from core.files import list_of_files as H;I=H(f"{A}\\scripts",'*.xls*');J=[[sg.Text('Select your script')],[sg.Listbox(I,size=(22,5),expand_y=_A,enable_events=_A,key=_a)]];K=[[sg.Button('Refresh',size=(8,1),key='SCRIPT LIST Refresh')],[sg.Button('Edit',size=(8,1),key='SCRIPT LIST Edit')],[sg.Button('Deploy',size=(8,1),key='SCRIPT LIST Deploy')],[sg.Button(E,size=(8,1),key='SCRIPT LIST Debug')]];L=f"{A}\\autobot\\_cache\\log_settings.pickle";from pathlib import Path;from core.files import pickleWrite,pickleRead as M
	if Path(L).exists():C=M(filename_pickle=f"{A}\\autobot\\_cache\\log_settings.pickle");print(C);D=C['beta']
	else:D=_B
	N=[[sg.Text('Starting Worksheet')],[sg.Input(F,size=(37,1),enable_events=_A,key='SCRIPT LIST_worksheet')],[sg.Text('Starting Step / Object')],[sg.Input(F,size=(37,1),enable_events=_A,key='SCRIPT LIST_objectStep')],[sg.Checkbox(E,default=_B,enable_events=_A,key='SCRIPT LIST Debug activate'),sg.Checkbox('Log',default=D,enable_events=_A,key='SCRIPT LIST beta logging'),sg.Text('Break'),sg.Input('',size=(11,1),key='-BREAK POINT-')]];O=[sg.Column(J,vertical_alignment=_D),sg.Column(K,vertical_alignment=_D),sg.VSeparator(),sg.Column(N,vertical_alignment=_D)];P=[sg.VSeparator(),sg.Button(_R,key=_R),sg.Button(_M,key=_o),sg.VSeparator(),sg.Button(G,key=G),sg.Button(_A0,key=_A1)];Q=window.current_location();sub_window(program=f"{B}",version=version,title=B,run=_B,location=Q,insertWindow=O,window_buttons=[P])
def sub_window_notifications(window):
	D='Notifications Management';E='Enable telegram notifications for RPA runs.  Setup default telegram ID. Check your telegram ID from @userinfobot.';F=_N;A=_A;id='';B=f"{prog_path}\\autobot\\_cache\\notifications.pickle";from pathlib import Path
	if Path(B).exists():from core.files import pickleRead as G;C=G(filename_pickle=B);id=C['id'];A=C['activate']
	H=[[sg.Text('Activate',size=(12,1)),sg.Checkbox('',default=A,enable_events=_A,key='Notifications activate')],[sg.Text('Telegram ID',size=(12,1)),sg.Input(id,size=(12,1),key='Notifications ID')]];I=[[sg.Text(E,size=(40,3),key=_F)]];J=[sg.Column(H,vertical_alignment=_D),sg.VSeparator(),sg.Column(I,vertical_alignment=_D)];K=[sg.Button(_d,key='Notifications Save'),sg.Button(_E)];L=window.current_location();sub_window(program=F,title=D,run=_B,location=L,insertWindow=J,window_buttons=[K],replace_window_buttons=_A,visible=_B);return
def sub_window_screen_recording(window):
	E='Recording folder';D='Recording file';F='Screen recording';G='Enable recording of RPA run.';H=_N;A=_A;id='recording.mp4';I=prog_path;B=f"{prog_path}\\autobot\\_cache\\recording.pickle";from pathlib import Path
	if Path(B).exists():from core.files import pickleRead as J;C=J(filename_pickle=B);id=C['file'];A=C['activate']
	K=[[sg.Text('Activate',size=(12,1)),sg.Checkbox('',default=A,enable_events=_A,key='Recording activate')],[sg.Text(D,size=(12,1)),sg.Input(id,size=(20,1),key=D)],[sg.Text('Folder',size=(12,1)),sg.Input(prog_path,size=(20,1),key=E),sg.FolderBrowse(target=E,initial_folder=I)]];L=[[sg.Text(G,size=(25,3),key=_F)]];M=[sg.Column(K,vertical_alignment=_D),sg.VSeparator(),sg.Column(L,vertical_alignment=_D)];N=[sg.Button(_d,key='Recording Save'),sg.Button(_E)];O=window.current_location();sub_window(program=H,title=F,run=_B,location=O,insertWindow=M,window_buttons=[N],replace_window_buttons=_A,visible=_B);return
def sub_window_log_level(window):
	E='Logging Management';F='Enable various level of logging for RPA runs.';G=_N;H=[_A2,_W];A=_W;B=_A;C=f"{prog_path}\\autobot\\_cache\\log_settings.pickle";from pathlib import Path
	if Path(C).exists():from core.files import pickleRead as I;D=I(filename_pickle=C);A=D['log_level'];B=D['beta']
	J=[[sg.Combo(H,size=(20,1),default_value=A,key='Log Settings log_level',readonly=_A,enable_events=_A)],[sg.Text('Activate beta logging',size=(15,1)),sg.Checkbox('',default=B,enable_events=_A,key='Log Settings beta')]];K=[[sg.Text(F,size=(40,3),key=_F)]];L=[sg.Column(J,vertical_alignment=_D),sg.VSeparator(),sg.Column(K,vertical_alignment=_D)];M=[sg.Button(_d,key='Log Settings Save'),sg.Button(_E)];N=window.current_location();sub_window(program=G,title=E,run=_B,location=N,insertWindow=L,window_buttons=[M],replace_window_buttons=_A,visible=_B);return
def sub_windows_agents(window):A=[_S,_T,_U,_p,_q,_r,'Late'];B=[_M,_s];C=[f"{A:03d}"for A in range(0,365)];K=[f"{A:02d}"for A in range(0,24)];D=['hours',_V,'weeks',_t];E=_N;F=[[sg.Text(_u)],[sg.Listbox(A,size=(22,5),expand_y=_A,enable_events=_A,key=_v,select_mode=_w,default_values=(_S,_T,_U))]];G=[[sg.Text(_b)],[sg.Combo(B,size=(10,1),default_value=_M,key=_c,readonly=_A)],[sg.Text('')],[sg.Text(_x)],[sg.Text('Past'),sg.Spin([A for A in C],initial_value='001',readonly=_A,size=(3,1),key=_y),sg.Combo(D,size=(8,1),default_value=_V,key=_z,readonly=_A)]];H=[sg.Column(F,vertical_alignment=_D),sg.Column(G,vertical_alignment=_D)];I=[sg.Button(_G,key='Agent Run'),sg.Button('Register',key='Agent Register'),sg.Button(_E)];J=window.current_location();sub_window(program=E,title='Optimus Services',run=_B,location=J,insertWindow=H,window_buttons=[I],replace_window_buttons=_A,visible=_B);return
def ___upgrade_sub_window(program='',version=''):
	R='Process completed: ';Q='[\\r\\n]+';P='[^\\x00-\\x7F]+';O='-IN-';J=version;import subprocess as F,FreeSimpleGUI as C;S=[[C.Text('Enter a command to execute:')],[C.Input(key=O,size=(80,5),default_text=program)],[C.Button(_G),C.Button(_E)],[C.Output(size=(80,15),key=_O,background_color=_e,text_color=_f)]];D=C.Window('Upgrade OPTIMUS Packages',S,finalize=_A);from libraries.Github import github_repo_latest_release as T,is_internet_available as U
	if U():G=T('ray-oh','Optimus-Installation')
	else:G='Internet or package is not available. Check again later.'
	def K(text):
		import re;A=re.search('\\d+\\.\\d+\\.\\d+',text)
		if A:return A.group()
		else:return _C
	try:
		from packaging.version import parse as L;M=L(K(J));N=L(K(G))
		if N>M:H='Upgrade available'
		elif N<M:H='OPTIMUS newer than available upgrade'
		else:H='OPTIMUS up to date'
		print(f"{H} .... Current OPTIMUS is {J} ... Latest release is {G} ...")
	except:pass
	while _A:
		I,V=D.read()
		if I==C.WIN_CLOSED or I==_E:break
		if I==_G:
			print('RUNNING ....');W=V[O].split(' ');A=F.Popen(W,shell=_A,stdout=F.PIPE,stderr=F.PIPE)
			for E in A.stdout:E=E.decode(_g);import re;E=re.sub(P,'',E);E=re.sub(Q,'',E.rstrip());print(E);D.Refresh()if D else _C
			A.wait();print(R,not A.poll()==_C)
		if _B:
			while _A:
				import re;B=re.sub(P,'',A.stdout.readline().decode(_g));B=re.sub(Q,'',B.strip())
				if A.poll()is not _C:break
				else:print(B)
				D.Refresh()if D else _C
			A.wait();print(R,not A.poll()==_C)
		if _B:
			B=''
			while _A:
				B=B+A.stdout.readline()
				if B==b''and A.poll()is not _C:break
				if B:D[_O].update(B.decode())
			A.poll()
	D.close()
def ____dsupgrade_sub_window(program=''):
	import subprocess as B,sys,FreeSimpleGUI as A;E=[[A.Text('Enter or modify command to execute')],[A.Input(key=_X,size=(80,5),default_text=program)],[A.Output(size=(80,15),background_color=_e,text_color=_f)],[A.Button(_G),A.Button(_E)]];C=A.Window(_A3,E,finalize=_A);print('Default text to display in the output area')
	while _A:
		D,F=C.Read()
		if D in(_C,_E):break
		if D==_G:G(cmd=F[_X],window=C)
	C.Close()
	def G(cmd,timeout=_C,window=_C):
		C=B.Popen(cmd,shell=_A,stdout=B.PIPE,stderr=B.STDOUT);D=''
		for A in C.stdout:A=A.decode(_g);D+=A+'\n';print('test')
		E=C.wait(timeout);return E,D
def temp_from_launch_window():
	N='A custom progress meter';M='Complete';L='./assets/studio/help.xlsx';K='all , ./assets/studio/help.xlsx';J='1DEBUG LEVEL';F='h';C='progressbar';B='Cancel'
	if _B:
		if _A:
			if _A:
				if _A:0
				elif J in label_str or _W in label_str:
					def D(window):
						import FreeSimpleGUI as A;from libraries.BuiltIn import help
						if help(K):from pathlib import Path;B=Path(L).resolve().absolute().__str__()
						else:0
						window.write_event_value(M,'')
					def O(function,title,size,animated_gif,msg):
						H='-IMAGE-';F=animated_gif;E='-OK-';import threading as I,FreeSimpleGUI as A;J=[[A.Text(msg,key=_O)],[A.Image(F,key=H)],[A.Button('Ok',key=E,disabled=_A),A.Button(B,visible=_B)]];C=A.Window(title,J,size=size,disable_minimize=_A,disable_close=_A);G=_A;I.Thread(target=function,args=(C,),daemon=_A).start()
						while _A:
							D,K=C.read(timeout=100)
							if D==A.WIN_CLOSED or D==B or D==E:break
							if D==M:C[_O].update('Help generated');C[E].update(disabled=_B);G=_B
							if G:C[H].update_animation(F,time_between_frames=100)
						C.close()
					O(D,'Generate Help Documentation',(200,100),'./assets/shortcuts/progressbar2.gif',N)
				elif J in label_str or'1INFO LEVEL'in label_str:
					def P():
						import FreeSimpleGUI as A;G=[[A.Text(N)],[A.ProgressBar(1000,orientation=F,size=(20,20),key=C)],[A.Button('Ok'),A.Button(B)]];D=A.Window('Custom Progress Meter',G);H=D[C]
						for I in range(1000):
							E,J=D.read(timeout=10)
							if E==B or E==A.WIN_CLOSED:break
							H.UpdateBar(I+1)
						D.close()
					P()
				elif _A2 in label_str or _W in label_str:
					def Q():
						H='update_';G='progress_1';import threading as I;J=[[sg.Text('Testing progress bar:')],[sg.ProgressBar(max_value=10,orientation=F,size=(20,20),key=G)],[sg.Output(size=(80,15),key=_O,background_color=_e,text_color=_f)]];C=sg.Window('Test',J,finalize=_A);K=1;C[G].update(K);I.Thread(target=R,args=(C,),daemon=_A).start()
						while _A:
							B,A,D=sg.read_all_windows()
							if A==_E:break
							if A.startswith(H):print(f"event: {A}, value: {D[A]}");E=A[len(H):];print('key to update',E);B[E].update(D[A]);B.refresh();continue
						B.close()
					def D():
						import FreeSimpleGUI as A;from libraries.BuiltIn import help
						if help(K):from pathlib import Path;B=Path(L).resolve().absolute().__str__()
						else:0
					def R(window):import time,random;D();print('Done!!!');window.write_event_value(_E,'')
					Q()
				elif'2DEBUG LEVEL'in label_str or'2INFO LEVEL'in label_str:
					def S():
						I='Start';import FreeSimpleGUI as A,time as G,threading as H
						def J():
							for A in range(100):D[C].update(A+1);G.sleep(0.1)
							return _A
						K=[[A.Text('Progress of the task:')],[A.ProgressBar(100,orientation=F,size=(20,20),key=C)],[A.Button(I),A.Button(B)]];D=A.Window('Progress Bar Example',K);L=''
						while _A:
							E,P=D.read()
							if E==A.WIN_CLOSED or E==B or'success'in L:break
							if E==I:
								import queue
								def M():
									for A in range(50):print('other run ',str(A));G.sleep(0.1)
								Q=queue.Queue();N=H.Thread(target=J);N.start();O=H.Thread(target=M);O.start()
						D.close()
					S()
				elif label_str=='UPGRADE3':
					def T(cmd,timeout=_C,window=_C):
						C=window;D=A.Popen(cmd,shell=_A,stdout=A.PIPE,stderr=A.STDOUT);E=''
						for B in D.stdout:B=B.decode(errors='replace'if sys.version_info<(3,5)else'backslashreplace').rstrip();E+=B;print(B);C.Refresh()if C else _C
						F=D.wait(timeout);return F,E
					U=[[sg.Text('Enter a command to execute (e.g. dir or ls)')],[sg.Input(key=_X)],[sg.Output(size=(60,15))],[sg.Button(_G),sg.Button(_E)]];E=sg.Window(_A3,U)
					while _A:
						G,V=E.Read()
						if G in(_C,_E):exit;break
						if G==_G:T(cmd=V[_X],window=E)
					E.Close()
				elif label_str=='UPGRADE2':H=program.split(' ');I=_A;print(program,'|',I,'|',H);Y=f"============= UPGRADE =============\nUpgrading in progress ...\n";import subprocess as A;W=A.Popen(H,shell=I,stdout=A.PIPE,stderr=A.PIPE);X,Z=W.communicate();sg.popup(X.decode(),title='Upgrade Package')