
from pathlib import Path
import os
import FreeSimpleGUI as sg
from core.dates import localTime
from studio.launcher import sub_window, prog_path
tasks = {}
tasks['Optimus Agent'] = {
    'program':f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}',
    'start_time':'06:30',
    'freq':'DAILY',
    'freq_mod':'1',
    'task_path':'Optimus\\',
    'task':'Optimus Agent',
    'modifier':'/ri 180 /du 0010:00',
    'description':'Agent responsible for checking for flow runs that are ready to run and starting their execution.  Lightweight polling service that gets scheduled work from a work pool and deploy corresponding flow runs.'
} 
tasks['Optimus Orion'] = {
    'program':Path(f'{prog_path}\\autobot\\startOrion.bat').absolute().__str__(),
    'start_time':'',
    'freq':'ONSTART',
    'freq_mod':'',
    'task_path':'Optimus\\',
    'task':'Optimus Orion',
    'modifier':f' /ru "{os.environ.get("USERNAME")}" /delay 0015:00',
    'description':'Enables flow run monitoring dashboard.  Track and manage your flows, runs, and deployments and additionally filter by names, tags, and other metadata.  Check out the dashboard at http://127.0.0.1:4200'
}
tasks['Default'] = {
    'program':f'runRPA.bat -f {""} -sh main -sc main',
    'start_time':'09:00',
    'freq':'DAILY',
    'freq_mod':'1',
    'task_path':'Optimus\\Scripts\\',
    'task':'',
    'modifier':'/ri 180 /du 0010:00',
    'description':'Schedule Optimus automation scripts.'    
}
def sub_window_task_scheduler(prog_path, runrpa_script, window, values,
    task_path = 'Optimus\\Scripts\\', script_list = None, action_list = ['CREATE', 'DELETE', 'RUN', 'QUERY', 'QUERY ALL']):
    
    from core.files import list_of_files
    if script_list == None: 
        item = 'Default'
        start_time = tasks[item]['start_time']
        freq = tasks[item]['freq']
        freq_mod = tasks[item]['freq_mod']
        task_path = tasks[item]['task_path']
        modifier = tasks[item]['modifier']
        description = tasks[item]['description']
        script_list = list_of_files(f'{prog_path}\scripts', '*.xlsm')
        if "SCRIPT LIST_" in values:
            task = os.path.splitext(values["SCRIPT LIST_"][0])[0]
        else:
            task = script_list[0]
        program = f'{prog_path}\\{runrpa_script}'
        action = 'CREATE'
    else: 
        item = 'Optimus Agent'
        program = tasks[item]['program']
        start_time = tasks[item]['start_time']
        freq = tasks[item]['freq']
        freq_mod = tasks[item]['freq_mod']
        task_path = tasks[item]['task_path']
        task = tasks[item]['task']
        modifier = tasks[item]['modifier']
        description = tasks[item]['description']
        action='RUN' 
    initial_hrs = start_time[:2]
    initial_mins= start_time[-2:]
    left_part = [
        [sg.Text("Task")],
        [sg.Text("Action")],                        
        [sg.Text("Start Time")],
        [sg.Text("Frequency")],
    ]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    mins = [f'{i:02d}' for i in range(0, 60)]
    freq_mod = [f'{i:02d}' for i in range(1, 61)]                    
    freq_list = ['MINUTE', 'HOURLY', 'DAILY', 'WEEKLY', 'MONTHLY', 'ONCE', 'ONSTART']
    middle_part = [
        [sg.Combo(script_list, size=(37, 1), default_value=task, key='Task Scheduler tasklist', readonly=True, enable_events=True)],        
        [sg.Combo(action_list, size=(37, 1), default_value=action, key='action', readonly=True, enable_events=True)],
        [sg.Spin([i for i in hrs], initial_value=initial_hrs, readonly=True, key='start_hr', enable_events=True), sg.Text(':'), sg.Spin([i for i in mins], initial_value=initial_mins, readonly=True, key='start_min', enable_events=True)],
        [sg.Combo(freq_list, size=(25, 1), default_value=freq, key='freq', readonly=True, enable_events=True), sg.Spin([i for i in freq_mod], initial_value='01', readonly=True, key='freq_mod', enable_events=True)],
        [sg.Input(modifier, size=(37, 1), key="modifier", enable_events=True)],
    ]
    right_part = [
        [sg.Text(description, size=(20, 8), key='description')],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(middle_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Run', key='Task Scheduler Run'), sg.Button('Exit'), sg.VSeparator(), sg.Button('Query All', key='Task Scheduler Query'), sg.Button('Task Scheduler', key='Windows Task Scheduler')]
    current_location = window.current_location()
    sub_window(program=program, title='Task Scheduler', run=False, location=current_location, disabled=False,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, task_path=task_path)
    
def sub_windows_prefect(window):
    
    status_list = ['Completed', 'Failed', 'Crashed', 'Running', 'Pending', 'Scheduled', 'Late']
    action_list = ['Query', 'Delete']
    days = [f'{i:03d}' for i in range(0, 365)]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    period = ['hours', 'days', 'weeks', 'months']
    program = 'Prog'
    left_part = [
        [sg.Text("Status")],
        [sg.Listbox(status_list, size=(22, 5), expand_y=True, enable_events=True, key='-STATUS LIST-', select_mode='multiple', default_values=('Completed', 'Failed', 'Crashed'))], 
    ]
    right_part = [
        [sg.Text("Action")],        
        [sg.Combo(action_list, size=(10, 1), default_value='Query', key='action', readonly=True)],
        [sg.Text("")],
        [sg.Text("Period")],
        [sg.Text("Past"), sg.Spin([i for i in days], initial_value='001', readonly=True, size=(3, 1), key='period_num'), sg.Combo(period, size=(8, 1), default_value='days', key='period', readonly=True)],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Run', key='Prefect Run'), sg.Button('Exit'), sg.VSeparator(), 
                      sg.Text("Dashboard: "), sg.Button('Monitor Flows', key='Prefect Monitor'), sg.Button('Deployments', key='Prefect Deployments')]
    current_location = window.current_location()
    sub_window(program=program, title='Workflow Management', run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)
    return
def sub_windows_run_script(prog_path, label_str, version, window):                   
    from core.files import list_of_files
    script_list = list_of_files(f'{prog_path}\scripts', '*.xls*')
    left_part = [
        [sg.Text("Select your script")],
        [sg.Listbox(script_list, size=(22, 5), expand_y=True, enable_events=True, key='SCRIPT LIST_')] 
    ]
        
    middle_part = [
        [sg.Button('Refresh', size=(8, 1), key = 'SCRIPT LIST Refresh')],
        [sg.Button('Edit', size=(8, 1), key = 'SCRIPT LIST Edit')],
        [sg.Button('Deploy', size=(8, 1), key = 'SCRIPT LIST Deploy')],
        [sg.Button('Debug', size=(8, 1), key = 'SCRIPT LIST Debug')],
    ]
    filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle"
    from pathlib import Path
    from core.files import pickleWrite, pickleRead
    if Path(filename_pickle).exists():
        obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
        print(obj)
        beta_logging = obj['beta']
    else:
        beta_logging = False
    right_part = [
        [sg.Text("Starting Worksheet")],
        [sg.Input('main', size=(37, 1), enable_events=True, key="SCRIPT LIST_worksheet")],
        [sg.Text("Starting Step / Object")],
        [sg.Input('main', size=(37, 1), enable_events=True, key="SCRIPT LIST_objectStep")],
        [sg.Checkbox("Debug", default=False, enable_events=True, key='SCRIPT LIST Debug activate'), 
         sg.Checkbox("Log", default=beta_logging, enable_events=True, key='SCRIPT LIST beta logging'),
         sg.Text("Break"), sg.Input('', size=(11, 1), key="-BREAK POINT-")],                        
    ] 
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(middle_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.VSeparator(), sg.Button('Task Scheduler', key='Task Scheduler'), sg.Button('Query', key='Task Scheduler Query'), sg.VSeparator(),
                        sg.Button('Prefect', key='Prefect'), sg.Button('Deployments', key='Prefect Deployments')]
    current_location = window.current_location()
    sub_window(program=f'{label_str}', version=version, title=label_str, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons]) 
def sub_window_notifications(window):
    
    title = 'Notifications Management'
    description = 'Enable telegram notifications for RPA runs.  Setup default telegram ID. Check your telegram ID from @userinfobot.'
    program = 'Prog'
    activate = True
    id = ''
    file = f"{prog_path}\\autobot\\_cache\\notifications.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        notifications = pickleRead(filename_pickle=file)
        id = notifications['id']
        activate = notifications['activate']
    left_part = [
        [sg.Text("Activate", size=(12, 1)), sg.Checkbox("", default=activate, enable_events=True, key='Notifications activate')],
        [sg.Text("Telegram ID", size=(12, 1)), sg.Input(id, size=(12, 1), key="Notifications ID")],                        
    ]
    right_part = [
        [sg.Text(description, size=(40, 3), key='description')],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Save', key='Notifications Save'), sg.Button('Exit')]
    current_location = window.current_location()
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)
    return
def sub_window_screen_recording(window):
    
    title = 'Screen recording'
    description = 'Enable recording of RPA run.'
    program = 'Prog'
    activate = True
    id = 'recording.mp4'
    folder = prog_path
    file = f"{prog_path}\\autobot\\_cache\\recording.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        recording = pickleRead(filename_pickle=file)
        id = recording['file']
        activate = recording['activate']
    left_part = [
        [sg.Text("Activate", size=(12, 1)), sg.Checkbox("", default=activate, enable_events=True, key='Recording activate')],
        [sg.Text("Recording file", size=(12, 1)), sg.Input(id, size=(20, 1), key="Recording file")],
        [sg.Text("Folder", size=(12, 1)), sg.Input(prog_path, size=(20, 1), key='Recording folder'), sg.FolderBrowse(target='Recording folder', initial_folder=folder)],
    ]
    right_part = [
        [sg.Text(description, size=(25, 3), key='description')],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Save', key='Recording Save'), sg.Button('Exit')]
    current_location = window.current_location()
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)
    return
def sub_window_log_level(window):
    
    title = 'Logging Management'
    description = 'Enable various level of logging for RPA runs.'
    program = 'Prog'
    log_level_options = ['DEBUG LEVEL', 'INFO LEVEL']
    log_level = 'INFO LEVEL'
    beta = True
    file = f"{prog_path}\\autobot\\_cache\\log_settings.pickle"
    from pathlib import Path
    if Path(file).exists():
        from core.files import pickleRead
        log_settings = pickleRead(filename_pickle=file)
        log_level = log_settings['log_level']
        beta = log_settings['beta']
    left_part = [
        [sg.Combo(log_level_options, size=(20, 1), default_value=log_level, key='Log Settings log_level', readonly=True, enable_events=True)],
        [sg.Text("Activate beta logging", size=(15, 1)), sg.Checkbox("", default=beta, enable_events=True, key='Log Settings beta')],
    ]
    right_part = [
        [sg.Text(description, size=(40, 3), key='description')],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.VSeparator(),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Save', key='Log Settings Save'), sg.Button('Exit')]
    current_location = window.current_location()
    sub_window(program=program, title=title, run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)
    return
def sub_windows_agents(window):
    
    status_list = ['Completed', 'Failed', 'Crashed', 'Running', 'Pending', 'Scheduled', 'Late']
    action_list = ['Query', 'Delete']
    days = [f'{i:03d}' for i in range(0, 365)]
    hrs = [f'{i:02d}' for i in range(0, 24)]
    period = ['hours', 'days', 'weeks', 'months']
    program = 'Prog'
    left_part = [
        [sg.Text("Status")],
        [sg.Listbox(status_list, size=(22, 5), expand_y=True, enable_events=True, key='-STATUS LIST-', select_mode='multiple', default_values=('Completed', 'Failed', 'Crashed'))], 
    ]
    right_part = [
        [sg.Text("Action")],        
        [sg.Combo(action_list, size=(10, 1), default_value='Query', key='action', readonly=True)],
        [sg.Text("")],
        [sg.Text("Period")],
        [sg.Text("Past"), sg.Spin([i for i in days], initial_value='001', readonly=True, size=(3, 1), key='period_num'), sg.Combo(period, size=(8, 1), default_value='days', key='period', readonly=True)],
    ]
    script_Window = [
        sg.Column(left_part, vertical_alignment="top"),
        sg.Column(right_part, vertical_alignment="top")
        ]
    script_buttons = [sg.Button('Run', key='Agent Run'), sg.Button('Register', key='Agent Register'), sg.Button('Exit')]
    current_location = window.current_location()
    sub_window(program=program, title='Optimus Services', run=False, location=current_location,
                insertWindow=script_Window, window_buttons=[script_buttons], replace_window_buttons=True, visible=False)
    return
def ___upgrade_sub_window(program:str = "", version:str = ""):
    import subprocess
    import FreeSimpleGUI as sg
    layout = [[sg.Text('Enter a command to execute:')],
            [sg.Input(key='-IN-', size=(80,5), default_text=program)],
            [sg.Button('Run'), sg.Button('Exit')],
            [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')]]
    window = sg.Window('Upgrade OPTIMUS Packages', layout, finalize=True)  
    from libraries.Github import github_repo_latest_release, is_internet_available
    if is_internet_available():
        latest_version = github_repo_latest_release("ray-oh", "Optimus-Installation")
    else:
        latest_version = "Internet or package is not available. Check again later."
    def returnVers(text):
        import re
        match = re.search(r'\d+\.\d+\.\d+', text)
        if match:
            return match.group()
        else:
            return None
    try:
        from packaging.version import parse
        v2 = parse(returnVers(version))
        v1 = parse(returnVers(latest_version))
        if v1 > v2:
            upgrade_available = "Upgrade available"
        elif v1 < v2:
            upgrade_available = "OPTIMUS newer than available upgrade"
        else:
            upgrade_available = "OPTIMUS up to date"
        print(f"{upgrade_available} .... Current OPTIMUS is {version} ... Latest release is {latest_version} ...")
    except:
        pass
    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit':
            break
        if event == 'Run':
            print('RUNNING ....')
            command = values['-IN-'].split(" ")
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            for line in process.stdout:
                line = line.decode('utf-8')
                import re
                line = re.sub(r"[^\x00-\x7F]+", "", line)
                line = re.sub(r"[\r\n]+", "", line.rstrip())                
                print(line)
                window.Refresh() if window else None  
            process.wait()
            print('Process completed: ', not process.poll()==None)
        if False:
            while True:
                import re
                output = re.sub(r"[^\x00-\x7F]+", "", process.stdout.readline().decode('utf-8'))
                output = re.sub(r"[\r\n]+", "", output.strip())                
                if  process.poll() is not None:
                    break
                else:
                    print(output)
                window.Refresh() if window else None  
            process.wait()
            print('Process completed: ', not process.poll()==None)
        if False:
            output = ""            
            while True:
                output = output + process.stdout.readline()
                if output == b'' and process.poll() is not None:
                    break
                if output:
                    window['-OUTPUT-'].update(output.decode())
            process.poll()
    window.close()
def ____dsupgrade_sub_window(program:str = ""):
    import subprocess
    import sys
    import FreeSimpleGUI as sg
    layout = [
        [sg.Text('Enter or modify command to execute')],
        [sg.Input(key='_IN_', size=(80,5), default_text=program)],  
        [sg.Output(size=(80,15), background_color='black', text_color='white')],  
        [sg.Button('Run'), sg.Button('Exit')]  
    ]
    window = sg.Window('Realtime Shell Command Output', layout, finalize=True)
    print('Default text to display in the output area')
    while True:  
        event, values = window.Read()
        if event in (None, 'Exit'):  
            break
        if event == 'Run':  
            runCommand(cmd=values['_IN_'], window=window)
    window.Close()
    def runCommand(cmd, timeout=None, window=None):
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output = ''
        for line in p.stdout:
            line = line.decode("utf-8")
            output += line + '\n'
            print("test")
        retval = p.wait(timeout)
        return (retval, output)  
def temp_from_launch_window():
    if False: 
        if True:
            if True:                
                if True: pass                
                elif '1DEBUG LEVEL' in label_str or 'INFO LEVEL' in label_str:
                    def generateHelp(window):
                        import FreeSimpleGUI as sg
                        from libraries.BuiltIn import help
                        if help("all , ./assets/studio/help.xlsx"): 
                            from pathlib import Path
                            helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                        else:
                            pass
                        window.write_event_value('Complete', '')
                    def animation(function, title, size, animated_gif, msg):
                        import threading
                        import FreeSimpleGUI as sg
                        layout = [[sg.Text(msg, key='-OUTPUT-')],
                                [sg.Image(animated_gif, key="-IMAGE-")],
                                [sg.Button("Ok", key="-OK-", disabled=True), sg.Button('Cancel', visible=False)]]
                        window = sg.Window(title, layout, size=size, disable_minimize=True, disable_close=True)
                        animate = True
                        threading.Thread(target=function, args=(window, ),
                                        daemon=True).start()
                        while True:
                            event, values = window.read(timeout=100)
                            if event == sg.WIN_CLOSED or event == 'Cancel' or event == '-OK-':
                                break
                            if event == 'Complete':
                                window["-OUTPUT-"].update('Help generated')
                                window["-OK-"].update(disabled=False)
                                animate = False
                            if animate:
                                window["-IMAGE-"].update_animation(animated_gif, time_between_frames=100)
                        window.close()
                    animation(generateHelp, 'Generate Help Documentation', (200,100), r"./assets/shortcuts/progressbar2.gif", 'A custom progress meter')
                elif '1DEBUG LEVEL' in label_str or '1INFO LEVEL' in label_str:
                    def progressBar():
                        import FreeSimpleGUI as sg
                        layout = [[sg.Text('A custom progress meter')],
                                [sg.ProgressBar(1000, orientation='h', size=(20, 20), key='progressbar')],
                                [sg.Button('Ok'), sg.Button('Cancel')]]
                        window = sg.Window('Custom Progress Meter', layout)
                        progress_bar = window['progressbar']
                        for i in range(1000):
                            event, values = window.read(timeout=10)
                            if event == 'Cancel'  or event == sg.WIN_CLOSED:
                                break
                            progress_bar.UpdateBar(i + 1)
                        window.close()                
                    progressBar()
                elif 'DEBUG LEVEL' in label_str or 'INFO LEVEL' in label_str:
                    def test():
                        import threading
                        layout = [[sg.Text('Testing progress bar:')],
                                [sg.ProgressBar(max_value=10, orientation='h', size=(20, 20), key='progress_1')],
                                [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')]]
                        main_window = sg.Window('Test', layout, finalize=True)
                        current_value = 1
                        main_window['progress_1'].update(current_value)
                        threading.Thread(target=another_function,
                                        args=(main_window, ),
                                        daemon=True).start()
                        while True:
                            window, event, values = sg.read_all_windows()
                            if event == 'Exit':
                                break
                            if event.startswith('update_'):
                                print(f'event: {event}, value: {values[event]}')
                                key_to_update = event[len('update_'):]
                                print('key to update' , key_to_update)
                                window[key_to_update].update(values[event])
                                window.refresh()
                                continue
                        window.close()
                    def generateHelp():
                        import FreeSimpleGUI as sg
                        from libraries.BuiltIn import help
                        if help("all , ./assets/studio/help.xlsx"):
                            from pathlib import Path
                            helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                        else:
                            pass
                    def another_function(window):
                        import time
                        import random
                        generateHelp()
                        print('Done!!!')
                        window.write_event_value('Exit', '')
                    test()
                elif '2DEBUG LEVEL' in label_str or '2INFO LEVEL' in label_str:
                    def progressWindow():
                        import FreeSimpleGUI as sg
                        import time
                        import threading
                        def run_progress_bar():
                            for i in range(100):
                                window['progressbar'].update(i + 1)
                                time.sleep(0.1)
                            return True
                        layout2 = [[sg.Text('Progress of the task:')],
                                [sg.ProgressBar(100, orientation='h', size=(20, 20), key='progressbar')],
                                [sg.Button('Start'), sg.Button('Cancel')]]
                        window = sg.Window('Progress Bar Example', layout2)
                        result = ''
                        while True:
                            event, values = window.read()
                            if event == sg.WIN_CLOSED or event == 'Cancel' or 'success' in result:
                                break
                            if event == 'Start':
                                import queue
                                def run_other_function():
                                    for i in range(50):
                                        print('other run ', str(i))
                                        time.sleep(0.1)
                                q = queue.Queue()
                                progress_thread = threading.Thread(target=run_progress_bar)
                                progress_thread.start()
                                other_thread = threading.Thread(target=run_other_function)
                                other_thread.start()
                        window.close()
                    progressWindow()
                elif label_str=='UPGRADE3':
                    def runCommand(cmd, timeout=None, window=None):
                        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                        output = ''
                        for line in p.stdout:
                            line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                            output += line
                            print(line)
                            window.Refresh() if window else None        
                        retval = p.wait(timeout)
                        return (retval, output)                         
                    layout = [  [sg.Text('Enter a command to execute (e.g. dir or ls)')],
                            [sg.Input(key='_IN_')],             
                            [sg.Output(size=(60,15))],          
                            [sg.Button('Run'), sg.Button('Exit')] ]     
                    window = sg.Window('Realtime Shell Command Output', layout)
                    while True:             
                        event, values = window.Read()
                        if event in (None, 'Exit'):         
                            exit
                            break
                        if event == 'Run':                  
                            runCommand(cmd=values['_IN_'], window=window)
                    window.Close()
                elif label_str=='UPGRADE2':
                    command = program.split(" ")
                    shell=True
                    print(program, "|", shell, "|", command)
                    markdown_text = \
f               
                    import subprocess
                    proc = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   
                    output, error = proc.communicate()
                    sg.popup(output.decode(), title='Upgrade Package')
