_N='DEBUG LEVEL'
_M='INFO LEVEL'
_L='<Escape>'
_K='Optimus Orion'
_J='Optimus Agent'
_I='RUN SCRIPT'
_H='_Escape'
_G='utf-8'
_F='Exit'
_E='std'
_D='white'
_C=None
_B=False
_A=True
from pathlib import Path
import FreeSimpleGUI as sg
from core.dates import localTime
from core.files import _getProgPath
from libraries.Image import resize
help_text='\nOptimus runRPA.bat utility to process RPA scripts with steps defined from an\nExcel input.\nusage: runRPA [-h] [-f STARTFILE] [-sc STARTCODE] [-sh STARTSHEET]\n                   [-pl LOGPRINTLEVEL] [-ll DEFAULTLOGLEVEL]\n                   [-b BACKGROUND] [-o FLOWRUN] [-r RETRIES] [-t TAG]\n                   [-u UPDATE] [-a ARGUMENTS]\noptions:\n  -h, --help            show this help message and exit\nRequired arguments:\n  -f STARTFILE, --startfile STARTFILE\n                        Path to Excel file with RPA steps (default: )\nOptional arguments:\n  -sc STARTCODE, --startcode STARTCODE\n                        Name of first block of RPA steps to run (default:\n                        main)\n  -sh STARTSHEET, --startsheet STARTSHEET\n                        Name of first sheet or module to run (default: main)\n  -pl LOGPRINTLEVEL, --logprintlevel LOGPRINTLEVEL\n                        Prints alerts to console - 10 Debug, 20 Info, 30\n                        Warning (default: 30)\n  -ll DEFAULTLOGLEVEL, --defaultloglevel DEFAULTLOGLEVEL\n                        Log alert level - DEBUG, INFO, WARNING etc (default:\n                        DEBUG)\n  -b BACKGROUND, --background BACKGROUND\n                        Mode: 0 = Normal, 1 = Background, 2 = Deactivate clean\n                        up (default kill Outlook, Excel, Chrome, RPA\n                        processes), 3 = headless (default: 0)\n  -o FLOWRUN, --flowrun FLOWRUN\n                        0 = Normal run, 1 = Run Prefect Flow, 2 = Deploy\n                        Prefect Flow (default: 0)\n  -r RETRIES, --retries RETRIES\n                        Retry upon failure (default: 0)\n  -t TAG, --tag TAG     Label for automation run e.g. test or production\n                        (default: production)\n  -u UPDATE, --update UPDATE\n                        Update / refresh Excel script on loading: 0 = No\n                        update, 1 = Update (default: 0)\n  -a ARGUMENTS, --arguments ARGUMENTS\n                        Arguments for script - accessed by constant arg.\n                        Delimited by " , " (default: )\n'
prog_path=_getProgPath().__str__()
def get_asset_file(scriptKeywordsDefn=f"{prog_path}/autobot/assets/studio/studio.xlsx"):
	A='Apps';import pandas as pd;from core.files import isFileNewer,get_filename_without_extension,readfile;scriptKeywordsDefnCache=get_filename_without_extension(scriptKeywordsDefn)+'.pickle'
	if Path(scriptKeywordsDefnCache).exists():
		if isFileNewer(scriptKeywordsDefnCache,scriptKeywordsDefn):df=pd.read_pickle(scriptKeywordsDefnCache)
		else:df=readfile(filepath=scriptKeywordsDefn,sheet_name=A);pd.to_pickle(df,scriptKeywordsDefnCache)
	else:df=readfile(filepath=scriptKeywordsDefn,sheet_name=A);pd.to_pickle(df,scriptKeywordsDefnCache)
	return df
def launcher_window(version='x.x.x',description='',date='',updated='',author='',asset_file=f"{prog_path}/autobot/assets/studio/studio.xlsx"):
	J='optimus\\';I='CREATE';H='ORION SERVER';G='AGENT';F='bold';E='OPTIMUS RPA';D='Tab';C='-TASKBAR-';B='Helvetica';A='Label';import numpy as np;markdown_text=f"============= OPTIMUS =============\nVersion {version} | {date}\n{author}\n{description}\n";markdown_text=f"""Version: {version}
Release: {date}
Path:    {prog_path}
Contact: {author}
Desciption:{description}
""";df=get_asset_file(asset_file);df[A].replace('',np.nan,inplace=_A);df[A].replace('nan',np.nan,inplace=_A);df=df.dropna(subset=[A]);menu_def=[['&Application',['E&xit']],['&Help',['&About']]];right_click_menu_def=[[],['Edit Me','Versions','Nothing','More Nothing',_F]];fcolor='dark slate gray';menu_bar=[[sg.Menu(menu_def,key='-MENU-',tearoff=_B)]];banner_textblock=[[sg.Text(E,background_color=_D,text_color=fcolor,font=(B,12,F))],[sg.Text('Select required action ...',background_color=_D,text_color=fcolor,font=(B,11))]];top_bar_banner=[[sg.Column(banner_textblock,background_color=_D),sg.Push(background_color=_D),sg.Image(data=resize('./assets/studio/program_icon.png',(150,60)),background_color=_D)]];top_bar=[[sg.Frame('',top_bar_banner,background_color=_D,size=(480,70))]];bottom_bar=[[sg.Text('Select command ...',key=C)]];button_bar={};tabs=df[D].unique();tab_group=[]
	for (idx_bar,tab) in enumerate(tabs):
		button_bar[idx_bar]=[[]]
		for (idx,i) in enumerate(df[df[D]==tab][A].tolist()):button_bar[idx_bar]+=[[sg.Button(f"{i}",size=(16,1),font=(B,12,F),k=f"-BUTTON{i}",enable_events=_A),sg.Text(f"{df[df[D]==tab]['Description'].tolist()[idx]}",size=(30,1),justification='center',font=(B,10),k=f"-BUTTON DESC{idx}-",enable_events=_A)]]
		tab_group+=[sg.Tab(tab.split(' , ')[1],button_bar[idx_bar])]
	layout=menu_bar+top_bar;layout+=[[sg.TabGroup([tab_group],key='-TAB GROUP-',expand_x=_A,expand_y=_A)]];layout+=bottom_bar;layout[-1].append(sg.Sizegrip());win_title=f"OPTIMUS - Do more with less";window=sg.Window(win_title,layout,right_click_menu=right_click_menu_def,right_click_menu_tearoff=_A,grab_anywhere=_A,resizable=_B,margins=(0,0),finalize=_A,icon='./assets/shortcuts/rocket.ico');window.set_min_size(window.size);window.bind(_L,_H)
	while _A:
		event,values=window.read()
		if event in('-EXIT-',sg.WIN_CLOSED,_H,_F):break
		if event in'About':sg.popup(markdown_text,title=E)
		if'-BUTTON'in event:
			print(event,str(event)[7:])
			try:
				label_str=str(event)[7:];program=df[df[A]==label_str]['Launcher'].tolist()[0];type=df[df[A]==label_str]['Type'].tolist()[0];window[C].update(f"{label_str} : {program}")
				if label_str=='CLOSE':break
				elif label_str==_I:from studio.sub_windows import sub_windows_run_script;sub_windows_run_script(prog_path,label_str,version,window)
				elif label_str=='STUDIO':from studio.studio import search_rpa_commands_window;search_rpa_commands_window(location=window.current_location())
				elif label_str=='INSPECT':from studio.py_inspect import main;main()
				elif label_str=='HELP':from libraries.BuiltIn import help;from pathlib import Path;helpFile=Path('./assets/studio/help.xlsx').resolve().absolute().__str__();popup(help('all , ./assets/studio/help.xlsx'),'Help Documentation',f"""Help documentation refreshed for new libraries.

File:
{helpFile}

Access from Studio.""",'Help documentation refresh failed.')
				elif label_str=='SHORTCUT':from libraries.FileSystem import _setup_shortcuts;popup(_setup_shortcuts(),'Setup','Shortcuts created on desktop','Shortcuts creation failed')
				elif label_str=='UPGRADE':from libraries.Github import checkOptimusReleases;sub_window(program=f"{prog_path}\\{program}",version=version,title=program,run=_B,starting_msg=checkOptimusReleases(version))
				elif label_str in('PACKAGE','CLEAN'):sub_window(program=f"{prog_path}\\{program}",title=program,run=_B)
				elif label_str in'LOGGING':from studio.sub_windows import sub_window_log_level;sub_window_log_level(window=window)
				elif label_str in(_M,_N):sub_window(program=f"{prog_path}\\{program}",title=program,run=_A)
				elif label_str in'NOTIFICATIONS':from studio.sub_windows import sub_window_notifications;sub_window_notifications(window=window)
				elif label_str in'RECORDING':from studio.sub_windows import sub_window_screen_recording;sub_window_screen_recording(window=window)
				elif label_str in'WORKFLOW':from studio.sub_windows import sub_windows_prefect;sub_windows_prefect(window)
				elif label_str in(G,H,'SERVICES'):
					from studio.sub_windows import sub_window_task_scheduler;sub_window_task_scheduler(prog_path=prog_path,runrpa_script='',window=window,values=values,task_path='Optimus\\',script_list=[_J,_K]);continue
					if label_str==G:action=I;program=f"powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}";start_time='06:00';freq='DAILY /mo 1';task_path=J;task='Optimus_Agent_test'
					elif label_str==H:action=I;from pathlib import Path;program=Path(f"{prog_path}\\autobot\\startOrion.bat").absolute().__str__();start_time='';import os;freq=f'ONSTART /ru "{os.environ.get("USERNAME")}" ';task_path=J;task='Optimus_Orion_test'
					from libraries.Windows import _schedule;result=_schedule(action=action,program=program,start_time=start_time,freq=freq,task_path=task_path,task=task);window[C].update(f"{label_str} : {program}");sub_window(program=f"{prog_path}\\{program}",title=program,run=_B)
				elif _A:runProgram(type,program,prog_path)
			except Exception as e:print(e);window[C].update(f"{label_str} : ERROR {e}")
	window.close()
def sub_window(program='',title='',version='',disabled=_A,run=_B,starting_msg='',variable=_C,insertWindow=[],window_buttons=[[]],replace_window_buttons=_B,location=(0,0),message='',visible=_A,task_path=_C):
	y='SCRIPT LIST Debug activate';x='window position';w='SCRIPT LIST Deploy';v='task';u='program';t='start_min';s='start_hr';r='runRPA.bat';q='Task Scheduler';p='action';o='Running ...';n='Prefect';m='Log Settings';l='beta';k='SCRIPT LIST beta logging';j='Recording';i='Notifications';h='Optimus locals';g='Optimus globals';f='Key';d='INTERACTIVE - Variablelist';c='INTERACTIVE -Variables';b='Edit';a='codeID';Z='INTERACTIVE - Record';Y='INTERACTIVE';X='-MESSAGE-';W='SCRIPT LIST Debug';V='[\\r\\n]+';U='[^\\x00-\\x7F]+';T='Save';S='Please select a script first';R='script file';Q='_Enter';P='description';O='start_time';N='Task Scheduler tasklist';M='activate';L=':';K='break point';J='-ALERT-';I='Run';H='freq_mod';G='modifier';F='record';E='freq';D='SCRIPT LIST_';C='INTERACTIVE - VariableType';B='Ready';A='-IN-';import subprocess,FreeSimpleGUI as sg
	if run:default_buttons=[[sg.Button(_F,disabled=_A)]]
	else:default_buttons=[[sg.Button(I),sg.Button(_F)]]
	if replace_window_buttons:window_buttons=window_buttons
	else:window_buttons=[default_buttons[0]+window_buttons[0]]
	layout=[insertWindow,[sg.Text('Enter or modify command to execute',key=X,visible=visible)],[sg.Input(key=A,size=(80,5),default_text=program,disabled=disabled,visible=visible)]]+window_buttons;layout=layout+[[sg.Output(size=(80,15),key='-OUTPUT-',background_color='black',text_color=_D)],[sg.Text('STATUS: Running ...',key=J,visible=_A)]]
	if not location==(0,0):window=sg.Window(title,layout,finalize=_A,location=location)
	else:window=sg.Window(title,layout,finalize=_A)
	window.TKroot.focus_force()
	if run:run=_A;print(f"{starting_msg}");window.write_event_value(I,'')
	elif starting_msg!='':print(starting_msg)
	firstRun=_A;runrpa_script='';alert=B;sub_window_result='';import config
	if not F in config.variables:config.variables[F]=_B
	if config.variables[F]:prev_input=program;window[A].update('');window.Refresh()if window else _C
	if program==_I and firstRun==_A:window.Refresh()if window else _C;print(help_text);command=f"{prog_path}\\runrpa -h";window[A].update(disabled=_B);firstRun=_B
	window.bind(_L,_H);window[f"-IN-"].bind('<Return>',Q);window[A].set_focus()
	while _A:
		window[J].update(f"STATUS: {alert}")
		if not message=='':window[X].update(message)
		window.Refresh();event,values=window.read()
		if event==sg.WIN_CLOSED or event==_F or _H in event:break
		if Y in event or Y in title and Q in event:
			if'Continue'in event:
				import config;config.variables[K]=values['INTERACTIVE -BREAK POINT']
				if config.variables[K]=='':config.variables[K]='CONTINUE TO END AS THIS WILL NOT MATCH'
				sub_window_result=values[A];break
			elif'Step'in event or Q in event:import config;config.variables[K]='';sub_window_result=values[A];break
			elif'Terminate'in event:raise ValueError('Terminate Run')
			elif'Record'in event:
				if config.variables[F]:window[Z].update(button_color=(_D,'#283b5b'));config.variables[F]=_B;window[A].update(prev_input)
				else:window[Z].update(button_color=(_D,'red'));prev_input=values[A];window[A].update('');config.variables[F]=_A
			elif'- Save'in event:from studio.xpath import saveToExcel;print(config.variables[R]);from pathlib import Path;saveToExcel(dataframe=config.variables['recorded_df_list'],excel=config.variables[R],worksheet='Recorded',mode='w')
			elif'Auto Save'in event:config.variables['Auto save activate']=values['INTERACTIVE - Auto Save']
			if'Studio'in event:
				from studio.studio import search_rpa_commands_window,formula_window
				if L in values[A]:codeID=values[A].split(L,1)[0].strip();codeParameterList=values[A].split(L,1)[1].strip().split(' , ');print(a,codeID,'codeParameterList',codeParameterList)
				current_location=window.current_location()
				if a in locals()and len(values[A].strip())>0:inputText=formula_window(codeID,codeParameterList,location=current_location)
				else:inputText=search_rpa_commands_window(location=current_location)
				if not inputText=='':window[A].update(inputText)
				window.Refresh()
			elif b in event:from pathlib import Path;script_file=str(Path(config.variables[R]).name);runProgram(_E,f'start excel.exe "{prog_path}/scripts/{script_file}"',prog_path)
			if'Variablelist'in event:window[c].update(values[d])
			if'VariableType'in event:
				from config import variables,constants;df=variable[1]
				if'Script constants'==values[C]:variableList=df[df.Object=='constants'][f].values.tolist()
				elif'Script variables'==values[C]:variableList=df[df.Object=='variables'][f].values.tolist()
				elif'Optimus constants'==values[C]:variableList=list(constants.keys())
				elif'Optimus variables'==values[C]:variableList=list(variables.keys())
				elif g==values[C]:variableList=list(globals().keys())
				elif h==values[C]:variableList=list(locals().keys())
				window[d].update(value='',values=variableList)
			if'Resolve'in event:
				from auto_helper_lib import updateConstants;checkcode=values[c];from config import variables
				try:
					if g==values[C]:result=globals()[checkcode]
					elif h==values[C]:result=locals()[checkcode]
					else:result=updateConstants(df=variables['optimusDF'],code='{{'+checkcode+'}}')
					print('Variable value:',result)
				except Exception as e:print('Error',e)
		if'SCRIPT LIST'in event:
			if'_'in event:
				if len(values[D])!=0:runrpa_script=f"runRPA.bat -f {values[D][0]} -sh {values['SCRIPT LIST_worksheet']} -sc {values['SCRIPT LIST_objectStep']}";window[A].update(runrpa_script);alert=B
			elif'Refresh'in event:from core.files import list_of_files;script_list=list_of_files(f"{prog_path}\\scripts",'*.xlsm');window[D].update(script_list);alert='Refreshed'
			elif b in event:
				if len(values[D])!=0:script_file=values[D][0];runProgram(_E,f'cd ..\\scripts && start excel.exe "{script_file}"',prog_path);alert=B
				else:alert=S
			elif'Debug activate'in event:0
		if i in event:
			if T in event:activate=values['Notifications activate'];id=values['Notifications ID'];print(i,activate,id);from core.files import pickleWrite,pickleRead;pickleWrite(obj={M:activate,'id':id},filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle");obj=pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle");print(obj)
			if M in event:0
		if j in event:
			if T in event:activate=values['Recording activate'];file=values['Recording file'];folder=values['Recording folder'];print(j,activate,folder,file);from core.files import pickleWrite,pickleRead;pickleWrite(obj={M:activate,'file':file,'folder':folder},filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle");obj=pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle");print(obj)
			if M in event:0
		if event==k:
			beta=values[k];filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle";from pathlib import Path;from core.files import pickleWrite,pickleRead
			if Path(filename_pickle).exists():obj=pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle");print(obj)
			else:obj={}
			obj[l]=beta;pickleWrite(obj=obj,filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle")
		if m in event:
			if T in event:
				beta=values['Log Settings beta'];log_level=values['Log Settings log_level'];print(m,log_level,beta);from core.files import pickleWrite,pickleRead;pickleWrite(obj={l:beta,'log_level':log_level},filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle");obj=pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\log_settings.pickle");print(obj);print(prog_path)
				if log_level==_N:cmd=f"{prog_path}\\autobot\\setLogLevelDEBUG.bat"
				elif log_level==_M:cmd=f"{prog_path}\\autobot\\setLogLevelINFO.bat"
				import subprocess;process=subprocess.Popen(cmd,shell=_A,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
				for line in process.stdout:line=line.decode(_G);import re;line=re.sub(U,'',line);line=re.sub(V,'',line.rstrip());print(line);window.Refresh()if window else _C
				process.wait()
		if n in event:
			if event==n:from studio.sub_windows import sub_windows_prefect;sub_windows_prefect(window);alert=B
			elif I in event:
				alert=o;window[J].update(f"STATUS: {alert}");window.Refresh()if window else _C;action=values[p];status_list=values['-STATUS LIST-'];period_num=values['period_num'];period=values['period']
				if period.lower()=='hours':factor=1
				elif period.lower()=='days':factor=24
				elif period.lower()=='weeks':factor=24*7
				elif period.lower()=='months':factor=24*30
				hours=int(period_num)*factor;import asyncio;from libraries.Prefect import bulk_delete_flow_runs,query_flow_runs
				try:
					if action.lower()=='query':msg=asyncio.run(query_flow_runs(state=status_list,hours=hours));print(msg);alert=B
					elif action.lower()=='delete':asyncio.run(bulk_delete_flow_runs(state=status_list,hours=hours,prompt=_B));alert=B
				except Exception as e:alert=str(e)
			elif'Monitor'in event:runProgram(_E,f"start http://127.0.0.1:4200/flow-runs",prog_path);alert=B
			elif'Deployments'in event:runProgram(_E,f"start http://127.0.0.1:4200/deployments",prog_path);alert=B
		if q in event:
			try:
				if event==q:
					if len(values[D])==0:alert=S;continue
					else:
						if r in runrpa_script:from studio.sub_windows import sub_window_task_scheduler;sub_window_task_scheduler(prog_path,runrpa_script,window,values)
						alert=B
				elif event=='Task Scheduler Run':
					action=values[p];program=values[A]
					if values[E]=='ONSTART':start_time='';freq=values[E]+' '+values[G]
					else:start_time=values[s]+L+values[t];freq=values[E]+' '+values[G]+' /mo '+values[H]
					task=values[N];from libraries.Windows import _schedule;result=_schedule(action=action,program=program,start_time=start_time,freq=freq,task_path=task_path,task=task);alert=B
				elif'Windows'in event:runProgram(_E,f"start taskschd.msc",prog_path);alert=B
				elif'Query'in event:
					cmd='schtasks /query /tn \\Optimus\\ /nh';import subprocess;process=subprocess.Popen(cmd,shell=_A,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
					for line in process.stdout:line=line.decode(_G);import re;line=re.sub(U,'',line);line=re.sub(V,'',line.rstrip());print(line);window.Refresh()if window else _C
					process.wait();alert=B
					if _B:
						result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=_A)
						if result.returncode==0:output=result.stdout.decode(_G);print(output)
						else:error=result.stderr.decode(_G);print(f"Error: {error}")
				elif'tasklist'in event:
					from studio.sub_windows import tasks
					if _J in values[N]:item=_J;program=tasks[item][u];start_time=tasks[item][O];freq=tasks[item][E];freq_mod=tasks[item][H];task=tasks[item][v];modifier=tasks[item][G];description=tasks[item][P]
					elif _K in values[N]:item=_K;program=tasks[item][u];start_time=tasks[item][O];freq=tasks[item][E];freq_mod=tasks[item][H];task=tasks[item][v];modifier=tasks[item][G];description=tasks[item][P]
					else:program=f"runRPA.bat -f {values[N]} -sh main -sc main"
					window[A].update(program)
					if G in locals():window[G].update(modifier)
					if P in locals():window[P].update(description)
					if E in locals():window[E].update(freq)
					if H in locals():window[H].update(freq_mod)
					if O in locals():window[s].update(start_time[:2])
					if O in locals():window[t].update(start_time[-2:])
					alert=B
			except Exception as e:print('ERROR: Tasklist',str(e))
		if event in(I,W,w):
			run=_B;command=values[A].split(' ')
			if _I in program:
				additional_args='';import config;config.variables[x]=window.current_location()
				if len(values[D])==0:alert=S;continue
				if y in values.keys()or event==W:
					if values[y]or event==W:additional_args=' -o 3';additional_args=additional_args+' -a '+f'"{config.variables[x]} , {values["-BREAK POINT-"]}"'
				elif event==w:additional_args=' -o 2'
				if r in runrpa_script:print(runrpa_script,prog_path);runProgram(_E,f"cd .. && start {runrpa_script}{additional_args}",prog_path);alert=B
				continue
			alert=o;window[J].update(f"STATUS: {alert}");window.Refresh()if window else _C;process=subprocess.Popen(command,shell=_A,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			for line in process.stdout:line=line.decode(_G);import re;line=re.sub(U,'',line);line=re.sub(V,'',line.rstrip());print(line);window.Refresh()if window else _C
			process.wait();print('Process completed: ',not process.poll()==_C);window[_F].update(disabled=_B);alert=B
	window.close();return sub_window_result
def popup(function=_A,title='',ifTrue='True result',ifFalse='False',location=(0,0)):
	import FreeSimpleGUI as sg
	if function:text=ifTrue
	else:text=ifFalse
	if location==(0,0):sg.popup(text,title=title)
	else:sg.popup(text,title=title,location=location)
def runProgram(type,program,prog_path):
	print(type,program,prog_path)
	try:
		if type in'win':command=program.split(' ');shell=_A
		elif type in _E:command=program;shell=_A
		else:command=f"{prog_path}\\{program}".split(' ');shell=_B
		print(program);import subprocess;process=subprocess.Popen(command,shell=shell,stdout=subprocess.PIPE,stderr=subprocess.PIPE);result=process.stdout.decode(_G);return result
	except Exception as e:return''
if __name__=='__main__':launcher_window()