#!/usr/bin/env python
"""
    Application launcher for Optimus.
    Allows following actions:
        Run RPA scripts
        Settings
        And more!

    Copyright 2021, 2022, 2023 Optimus
"""
from pathlib import Path
import PySimpleGUI as sg

# Optimus keyword command definition library and other utility
from core.dates import localTime
from core.files import _getProgPath
from libraries.Image import resize

help_text = """
Optimus runRPA.bat utility to process RPA scripts with steps defined from an
Excel input.

usage: runRPA [-h] [-f STARTFILE] [-sc STARTCODE] [-sh STARTSHEET]
                   [-pl LOGPRINTLEVEL] [-ll DEFAULTLOGLEVEL]
                   [-b BACKGROUND] [-o FLOWRUN] [-r RETRIES] [-t TAG]
                   [-u UPDATE] [-a ARGUMENTS]

options:
  -h, --help            show this help message and exit

Required arguments:
  -f STARTFILE, --startfile STARTFILE
                        Path to Excel file with RPA steps (default: )

Optional arguments:
  -sc STARTCODE, --startcode STARTCODE
                        Name of first block of RPA steps to run (default:
                        main)
  -sh STARTSHEET, --startsheet STARTSHEET
                        Name of first sheet or module to run (default: main)
  -pl LOGPRINTLEVEL, --logprintlevel LOGPRINTLEVEL
                        Prints alerts to console - 10 Debug, 20 Info, 30
                        Warning (default: 30)
  -ll DEFAULTLOGLEVEL, --defaultloglevel DEFAULTLOGLEVEL
                        Log alert level - DEBUG, INFO, WARNING etc (default:
                        DEBUG)
  -b BACKGROUND, --background BACKGROUND
                        Mode: 0 = Normal, 1 = Background, 2 = Deactivate clean
                        up (default kill Outlook, Excel, Chrome, RPA
                        processes), 3 = headless (default: 0)
  -o FLOWRUN, --flowrun FLOWRUN
                        0 = Normal run, 1 = Run Prefect Flow, 2 = Deploy
                        Prefect Flow (default: 0)
  -r RETRIES, --retries RETRIES
                        Retry upon failure (default: 0)
  -t TAG, --tag TAG     Label for automation run e.g. test or production
                        (default: production)
  -u UPDATE, --update UPDATE
                        Update / refresh Excel script on loading: 0 = No
                        update, 1 = Update (default: 0)
  -a ARGUMENTS, --arguments ARGUMENTS
                        Arguments for script - accessed by constant arg.
                        Delimited by " , " (default: )
"""

# default program path
prog_path = _getProgPath().__str__() # d:\optimus

def get_asset_file(scriptKeywordsDefn:str = f"{prog_path}/autobot/assets/studio/studio.xlsx"):
    """ Read asset file
    """
    import pandas as pd
    from core.files import isFileNewer, get_filename_without_extension, readfile
    # enhance to read from cache if cache file exist
    # else read file from excel source and generate a cache
    #scriptKeywordsDefn = f"{prog_path}/autobot/assets/studio/studio.xlsx" #f'D:\Optimus\docs\scriptKeywordsDefn.xlsx'
    scriptKeywordsDefnCache = get_filename_without_extension(scriptKeywordsDefn)+".pickle"

    if Path(scriptKeywordsDefnCache).exists():
        if isFileNewer(scriptKeywordsDefnCache, scriptKeywordsDefn): # Is file1 newer, return True or False
            df = pd.read_pickle(scriptKeywordsDefnCache)
        else:
            df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
            pd.to_pickle(df, scriptKeywordsDefnCache) # generate cache
    else:
        df = readfile(filepath = scriptKeywordsDefn, sheet_name="Apps")
        pd.to_pickle(df, scriptKeywordsDefnCache) # generate cache
    return df


#__version__, __description__, __date__, __updated__
def launcher_window(version="x.x.x", description="", date="", updated="", author="", asset_file=f"{prog_path}/autobot/assets/studio/studio.xlsx"):
    import numpy as np
    markdown_text = \
f"""============= OPTIMUS =============
Version {version} | {date}
{author}

{description}
"""
    markdown_text = \
f"""Version: {version}
Release: {date}
Contact: {author}

Desciption:{description}
"""
    df = get_asset_file(asset_file)
    df['Label'].replace('', np.NaN, inplace=True)
    df['Label'].replace('nan', np.NaN, inplace=True)    
    #df.dropna(subset=['Label'], inplace=True)
    df = df.dropna(subset=['Label'])    
    # PARAMETERS    
    menu_def = [['&Application', ['E&xit']],
                ['&Help', ['&About']] ]
    right_click_menu_def = [[], ['Edit Me', 'Versions', 'Nothing','More Nothing','Exit']]
    fcolor = 'dark slate gray'

    # LAYOUT COMPONENTS
    #menu_bar = [ [sg.MenubarCustom(menu_def, key='-MENU-', menu_color=("white", "blue"), tearoff=False)] ] #font='Courier 15',tearoff=True
    menu_bar = [ [sg.Menu(menu_def, key='-MENU-', tearoff=False)] ] #font='Courier 15',tearoff=True    
    #menu_bar = [ [sg.Menu(menu_def, key='-MENU-', menu_color=("white", "blue"), tearoff=False)] ] #font='Courier 15',tearoff=True    
    #background_color = 'blue'
    #menu_bar = [ [sg.Menu(menu_def, key='-MENU-', text_color='black', background_color=background_color)] ]


    banner_textblock = [ [sg.Text('OPTIMUS RPA',background_color='white', text_color=fcolor, font=("Helvetica", 12, "bold"))],
            [sg.Text('Select required action ...',background_color='white', text_color=fcolor, font=("Helvetica", 11))] ]
    top_bar_banner = [[sg.Column(banner_textblock, background_color='white'), sg.Push(background_color='white'), 
                  sg.Image(data=resize('./assets/studio/program_icon.png', (150,60)), background_color='white')]]
    top_bar = [[sg.Frame('', top_bar_banner, background_color='white', size=(480,70) )]]
    bottom_bar = [[sg.Text('Select command ...', key='-TASKBAR-')]]


    button_bar = {}
    tabs = df['Tab'].unique()
    tab_group = []
    for idx_bar, tab in enumerate(tabs):
        button_bar[idx_bar] = [[]]
        for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
            #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
            button_bar[idx_bar] +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                                k=f"-BUTTON{i}", enable_events=True),
                    sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                                justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                    ]] 
        tab_group += [sg.Tab(tab.split(' , ')[1], button_bar[idx_bar])]
        #print(f'{idx_bar} BAR:',button_bar[idx_bar])

    """
    # tab1 layout
    button_bar = [[]]
    tab = 'tab1'
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab1_layout =  button_bar
    
    # tab2 layout
    button2_bar = [[]]
    tab = 'tab2'    
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button2_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab2_layout =  button2_bar

    # tab3 layout
    button3_bar = [[]]
    tab = 'tab3'    
    for idx, i in enumerate(df[df['Tab']==tab]["Label"].tolist()):
        #print(df["Label"][idx], df["Row"][idx], df["Col"][idx], df["Description"][idx], df["Launcher"][idx])
        button3_bar +=  [[sg.Button(f"{i}", size=(16, 1), font=("Helvetica", 12, "bold"), 
                             k=f"-BUTTON{i}", enable_events=True),
                   sg.Text(f"{df[df['Tab']==tab]['Description'].tolist()[idx]}", size=(30, 1), 
                            justification='center', font=("Helvetica", 10), k=f"-BUTTON DESC{idx}-", enable_events=True)
                  ]] 
    tab3_layout =  button3_bar
    """
    #logging_layout = [[sg.Text("Anything printed will display here!")],
    #                  [sg.Multiline(size=(60,15), font='Courier 8', expand_x=True, expand_y=True, write_only=True,
    #                                reroute_stdout=True, reroute_stderr=True, echo_stdout_stderr=True, autoscroll=True, auto_refresh=True)]
    #                  ]

    # LAYOUT
    layout = menu_bar + top_bar
    #layout +=[[sg.TabGroup([[  sg.Tab('OPTIMUS CORE', tab1_layout),
    #                           sg.Tab('SETTINGS', tab2_layout),
    #                           sg.Tab('AGENTS', tab3_layout),
    #                        ]], key='-TAB GROUP-', expand_x=True, expand_y=True),
    #           ]]

    layout +=[[sg.TabGroup([tab_group], key='-TAB GROUP-', expand_x=True, expand_y=True),
               ]]


    layout += bottom_bar
    layout[-1].append(sg.Sizegrip())
    
    # WINDOW CREATE / BINDINGS    
    win_title = f'OPTIMUS - Do more with less'
    window = sg.Window(win_title, layout, right_click_menu=right_click_menu_def, right_click_menu_tearoff=True, grab_anywhere=True, 
                       resizable=False, margins=(0,0), finalize=True, icon = r"./assets/shortcuts/rocket.ico")
                       # , keep_on_top=True)right_click_menu_tearoff=True, use_custom_titlebar=True, no_titlebar=True,  
    window.set_min_size(window.size)
    window.bind("<Escape>", "_Escape")    
    #return window

    # window = make_window() # sg.theme() 
    
    # EVENT ACTIONS    
    while True: # Event Loop
        event, values = window.read()

        if event in ("-EXIT-", sg.WIN_CLOSED, "_Escape", "Exit"):
            break

        if event in ("About"):#event == 'About':
            sg.popup(markdown_text, title='OPTIMUS RPA')                        
            #sg.popup_scrolled(markdown_text, title='My Popup')
            #gui(window, key)
            #print("MENU Clicked", event)

        if '-BUTTON' in event:
            print(event, str(event)[7:]) #, df[df['Label']==str(event)[7:]]['Description'][0])
            # depending on label_str event, choose action - either call python function directly or indirectly via windows command batch
            try:
                label_str = str(event)[7:]            
                program = df[df['Label']==label_str]['Launcher'].tolist()[0]            
                type = df[df['Label']==label_str]['Type'].tolist()[0]

                window['-TASKBAR-'].update(f"{label_str} : {program}")

                if label_str=='CLOSE':
                    break

                elif label_str=='RUN SCRIPT':
                    from studio.sub_windows import sub_windows_run_script
                    sub_windows_run_script(prog_path, label_str, version, window)

                elif label_str=='STUDIO':
                    from studio.studio import search_rpa_commands_window
                    #studio.
                    search_rpa_commands_window()

                elif label_str=='HELP':
                    from libraries.BuiltIn import help
                    from pathlib import Path
                    helpFile = Path("./assets/studio/help.xlsx").resolve().absolute().__str__()
                    popup(help("all , ./assets/studio/help.xlsx"), 'Help Documentation', 
                        f"Help documentation refreshed for new libraries.\n\nFile:\n{helpFile}\n\nAccess from Studio.", 
                        "Help documentation refresh failed.")

                elif label_str=='SHORTCUT':
                    from libraries.FileSystem import _setup_shortcuts
                    popup(_setup_shortcuts(), 'Setup', 'Shortcuts created on desktop', 'Shortcuts creation failed')

                elif label_str=='UPGRADE':
                    from libraries.Github import checkOptimusReleases
                    sub_window(program=f'{prog_path}\{program}', version=version, title=program, run=False, starting_msg=checkOptimusReleases(version))
                    #upgrade_sub_window(f'{prog_path}\{program}', version)

                elif label_str in ("PACKAGE", "CLEAN"):
                    sub_window(program=f'{prog_path}\{program}', title=program, run=False)

                elif label_str in ("INFO LEVEL", "DEBUG LEVEL"):
                    sub_window(program=f'{prog_path}\{program}', title=program, run=True)
                    """
                    result = runProgram(type, program, prog_path)
                    print(result)
                    if result == "":
                        result_bool = True
                    else:
                        result_bool = False
                    popup(result_bool, program, f'Done\n{result}', 'Fail')
                    """

                elif label_str in ("NOTIFICATIONS"):
                    from studio.sub_windows import sub_window_notifications
                    #sub_windows_agents, sub_windows_agents(window)
                    sub_window_notifications(window=window)

                elif label_str in ("RECORDING"):
                    from studio.sub_windows import sub_window_screen_recording
                    #sub_windows_agents, sub_windows_agents(window)
                    sub_window_screen_recording(window=window)

                elif label_str in ("AGENT", "ORION SERVER", "SERVICES"):
                    from studio.sub_windows import sub_window_task_scheduler
                    #sub_windows_agents, sub_windows_agents(window)
                    sub_window_task_scheduler(prog_path=prog_path, runrpa_script="", window=window, values=values, 
                                            task_path = 'Optimus\\', script_list = ['Optimus Agent', 'Optimus Orion'])
                    continue
                    # Task scheduler submit
                    if label_str == "AGENT":
                        action='CREATE' #values["action"]
                        program=f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}' #values["-IN-"]
                        start_time='06:00' #values["start_hr"] + ':' + values["start_min"]
                        freq='DAILY /mo 1' #values["freq"] + ' /mo ' + values["freq_mod"] + ' ' + values["modifier"]
                        task_path='optimus\\'
                        task='Optimus_Agent_test' #values["task"]
                    elif label_str == "ORION SERVER":
                        action='CREATE' #values["action"]
                        from pathlib import Path
                        program= Path(f'{prog_path}\\autobot\\startOrion.bat').absolute().__str__() #values["-IN-"]
                        start_time='' #values["start_hr"] + ':' + values["start_min"]
                        import os
                        #print(os.environ.get("USERNAME"))
                        freq=f'ONSTART /ru "{os.environ.get("USERNAME")}" ' #values["freq"] + ' /mo ' + values["freq_mod"] + ' ' + values["modifier"]
                        #schtasks /create /tn \"My App\" /tr c:\\apps\\myapp.exe /sc onstart /ru SYSTEM
                        task_path='optimus\\'
                        task='Optimus_Orion_test' #values["task"]
                    from libraries.Windows import _schedule
                    result = _schedule(action=action, program=program, start_time=start_time, freq=freq, task_path = task_path, task=task)
                    window['-TASKBAR-'].update(f"{label_str} : {program}")
                    #popup(result, 'Agents', 'Successful', 'Failed')
                    sub_window(program=f'{prog_path}\{program}', title=program, run=False)

                elif True:
                    runProgram(type, program, prog_path)

            except Exception as e:
                print(e)
                window['-TASKBAR-'].update(f"{label_str} : ERROR {e}")
            
    window.close()


def sub_window(program:str = "", title:str = "", version:str = "", disabled:bool = True, run:bool = False, starting_msg:str = "", 
               insertWindow:list=[], window_buttons:list=[], replace_window_buttons:bool = False, location:tuple = (0,0), visible=True, task_path=None):
    import subprocess
    import PySimpleGUI as sg

    if run:
        default_buttons = [sg.Button('Exit', disabled=True)]
    else:
        default_buttons = [sg.Button('Run'), sg.Button('Exit')]

    if replace_window_buttons:
        window_buttons = window_buttons
    else:
        window_buttons = default_buttons + window_buttons

    layout = [insertWindow, 
            [sg.Text('Enter or modify command to execute', visible=visible)],
            [sg.Input(key='-IN-', size=(80,5), default_text=program, disabled=disabled, visible=visible)],
            window_buttons,
            [sg.Output(size=(80, 15), key='-OUTPUT-', background_color='black', text_color='white')],
            [sg.Text('STATUS: Running ...', key='-ALERT-', visible=True)],
            ]

    if not location == (0,0):
        window = sg.Window(title, layout, finalize=True, location=location)  #'Realtime Shell Command Output'
    else:
        window = sg.Window(title, layout, finalize=True)  #'Realtime Shell Command Output', enable_window_config_events=True

    # print default starting text
    if run:
        run = True
        print(f'{starting_msg}')
        window.write_event_value('Run', '')        
    elif starting_msg != "":
        print(starting_msg)

    firstRun = True
    runrpa_script = ""
    alert = "Ready"

    if program == 'RUN SCRIPT' and firstRun==True:
        window.Refresh() if window else None
        print(help_text)
        command = f'{prog_path}\\runrpa -h'
        window['-IN-'].update(disabled=False)
        #window["-OUTPUT-"].Widget.set_vscroll_position(0)
        #window["-OUTPUT-"].scroll_to(0)   #.Widget.set_vscroll_position(0)        
        #window.write_event_value('Run', '')
        firstRun = False

    while True:
        window['-ALERT-'].update(f'STATUS: {alert}')
        window.Refresh()

        event, values = window.read()
        #print('EVENT', event)
        if event == sg.WIN_CLOSED or event == 'Exit' or event == 'Continue' or event == 'Step':
            if event == 'Continue':
                import config
                if config.variables['break point'] == '': config.variables['break point'] = 'CONTINUE TO END AS THIS WILL NOT MATCH'
            elif event == 'Step':
                import config
                config.variables['break point'] = ''
            break

        if 'SCRIPT LIST' in event:
            if '_' in event:
                if len(values["SCRIPT LIST_"]) != 0:    
                    runrpa_script = f'runRPA.bat -f {values["SCRIPT LIST_"][0]} -sh {values["worksheet"]} -sc {values["objectStep"]}'
                    window['-IN-'].update(runrpa_script)  #f {values["-SCRIPT LIST-"][0]}
                    alert = 'Ready'
            elif 'Refresh' in event:
                from core.files import list_of_files
                script_list = list_of_files(f'{prog_path}\scripts', '*.xlsm')
                window['SCRIPT LIST_'].update(script_list)  #f {values["-SCRIPT LIST-"][0]}
                #print('Refresh')
                alert = 'Refreshed'
            elif 'Edit' in event:
                if len(values["SCRIPT LIST_"]) != 0:
                    script_file = values["SCRIPT LIST_"][0]
                    runProgram('std', f'cd ..\scripts && start excel.exe "{script_file}"', prog_path)
                    alert = 'Ready'
                else:
                    #window['-ALERT-'].update('Please select a script first')
                    alert = 'Please select a script first'
            elif 'Debug activate' in event:
                #window['SCRIPT LIST Debug activate'].update(not values[SCRIPT LIST Debug activate])
                #if debug is activated - flowrun = 3
                pass

        if event == 'Deployments':
            runProgram('std', f'start http://127.0.0.1:4200/deployments', prog_path)
            alert = 'Ready'

        if 'Notifications' in event:
            if 'Save' in event:
                activate = values['Notifications activate']
                id = values['Notifications ID']
                print('Notifications', activate, id)
                from core.files import pickleWrite, pickleRead
                pickleWrite(obj={'activate':activate, 'id':id}, filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle")
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\notifications.pickle")
                print(obj)
            if 'activate' in event:
                pass

        if 'Recording' in event:
            if 'Save' in event:
                activate = values['Recording activate']
                file = values['Recording file']
                folder = values['Recording folder']
                print('Recording', activate, folder, file)
                from core.files import pickleWrite, pickleRead
                pickleWrite(obj={'activate':activate, 'file':file, 'folder':folder}, filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle")
                obj = pickleRead(filename_pickle=f"{prog_path}\\autobot\\_cache\\recording.pickle")
                print(obj)
            if 'activate' in event:
                pass

        if 'Prefect' in event:
            if event == 'Prefect':
                from studio.sub_windows import sub_windows_prefect
                sub_windows_prefect(window)
                #sub_window_prefect(prog_path, runrpa_script, window, values)                        
                alert = 'Ready'
            elif 'Run' in event:
                # Prefect flow management
                alert = 'Running ...'
                window['-ALERT-'].update(f'STATUS: {alert}')
                window.Refresh() if window else None

                action = values['action']
                status_list = values["-STATUS LIST-"]
                period_num  = values["period_num"]
                period  = values["period"]
                if period.lower()=='hours': factor = 1
                elif period.lower()=='days': factor = 24
                elif period.lower()=='weeks': factor = 24*7
                elif period.lower()=='months': factor = 24*30
                hours = int(period_num) * factor

                import asyncio
                from libraries.Prefect import bulk_delete_flow_runs, query_flow_runs
                try:
                    if action.lower() == 'query':
                        msg = asyncio.run(query_flow_runs(state=status_list, hours=hours))
                        print(msg)
                        alert = 'Ready'
                    elif action.lower() == 'delete':
                        asyncio.run(bulk_delete_flow_runs(state=status_list, hours=hours, prompt=False))
                        alert = 'Ready'
                except Exception as e:
                    #print(str(e))
                    alert = str(e)


        if 'Task Scheduler' in event:
            try:
                if event == 'Task Scheduler': # open task scheduler sub window
                    if len(values["SCRIPT LIST_"]) == 0:
                        alert = 'Please select a script first'
                        #window['-ALERT-'].update('Please select a script first')
                        continue
                    else:
                        if 'runRPA.bat' in runrpa_script:
                            from studio.sub_windows import sub_window_task_scheduler
                            sub_window_task_scheduler(prog_path, runrpa_script, window, values)
                        alert = 'Ready'
                elif event == 'Task Scheduler Run': # Task scheduler Run
                    action=values["action"]
                    program=values["-IN-"]
                    if values["freq"] == "ONSTART":
                        start_time=""
                        freq=values["freq"] + ' ' + values["modifier"]
                    else:
                        start_time=values["start_hr"] + ':' + values["start_min"]
                        freq=values["freq"] + ' ' + values["modifier"] + ' /mo ' + values["freq_mod"]
                    #task_path='optimus\\scripts\\'
                    task=values["Task Scheduler tasklist"]
                    from libraries.Windows import _schedule
                    result = _schedule(action=action, program=program, start_time=start_time, freq=freq, task_path = task_path, task=task)
                    #print('Success') if result else print('Fail')              
                    alert = 'Ready'
                elif 'Windows' in event:
                    runProgram('std', f'start taskschd.msc', prog_path)
                    alert = 'Ready'
                elif 'Query' in event: # 'Query Tasks'
                    #cmd = 'schtasks /query /fo CSV /tn \Optimus\ | find "Optimus"'
                    cmd = 'schtasks /query /tn \Optimus\ /nh'
                    #runProgram('std', f'{cmd}', prog_path)

                    import subprocess
                    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    #output = subprocess.check_output(cmd, shell=True, universal_newlines=True)
                    #output, error = process.communicate()

                    for line in process.stdout:
                        line = line.decode('utf-8')
                        import re
                        # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                        #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                        line = re.sub(r"[^\x00-\x7F]+", "", line)
                        line = re.sub(r"[\r\n]+", "", line.rstrip())                
                        print(line)
                        window.Refresh() if window else None  # yes, a 1-line if, so shoot me
                        #output += line + '\n'
                    # Wait for the process to exit
                    process.wait()
                    alert = 'Ready'

                    if False:
                        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

                        if result.returncode == 0:
                            output = result.stdout.decode('utf-8')
                            print(output)
                        else:
                            error = result.stderr.decode('utf-8')
                            print(f'Error: {error}')
                elif 'tasklist' in event:  # and len(values["Task Scheduler task"]) != 0:
                    from studio.sub_windows import tasks
                    if "Optimus Agent" in values["Task Scheduler tasklist"]:
                        item = 'Optimus Agent'
                        program = tasks[item]['program']
                        start_time = tasks[item]['start_time']
                        freq = tasks[item]['freq']
                        freq_mod = tasks[item]['freq_mod']
                        task = tasks[item]['task']
                        modifier = tasks[item]['modifier']
                        description = tasks[item]['description']

                        #action='CREATE' #values["action"]
                        #program=f'powershell.exe -WindowStyle Hidden -nologo -file {prog_path}\\autobot\\addon\\launch_agent.ps1 -batchScript startAgent.bat -path {prog_path}' #values["-IN-"]
                        #start_time='06:30' #values["start_hr"] + ':' + values["start_min"]
                        #freq='DAILY' #values["freq"] + ' /mo ' + values["freq_mod"] + ' ' + values["modifier"]
                        #freq_mod = '1'
                        #task_path='optimus\\'
                        #task='Optimus_Agent_test' #values["task"]
                        #modifier = ''

                        #values["action"].update(action)
                        #values["-IN-"].update(program)
                        #values["start_hr"].update('06')
                        #values["start_min"].update('00')
                        #values["freq"].update('DAILY')
                        #values["freq_mod"].update('1')
                        #values["modifier"].update('')
                        #runrpa_script = program
                        #runrpa_script = f'runRPA.bat -f {values["Task Scheduler tasklist"]} -sh main -sc main'
                    elif "Optimus Orion" in values["Task Scheduler tasklist"]:
                        item = 'Optimus Orion'
                        program = tasks[item]['program']
                        start_time = tasks[item]['start_time']
                        freq = tasks[item]['freq']
                        freq_mod = tasks[item]['freq_mod']
                        task = tasks[item]['task']
                        modifier = tasks[item]['modifier']
                        description = tasks[item]['description']

                        #action='CREATE' #values["action"]
                        #from pathlib import Path
                        #program= Path(f'{prog_path}\\autobot\\startOrion.bat').absolute().__str__() #values["-IN-"]
                        #start_time='' #values["start_hr"] + ':' + values["start_min"]
                        #import os
                        #print(os.environ.get("USERNAME"))
                        #freq=f'ONSTART' #values["freq"] + ' /mo ' + values["freq_mod"] + ' ' + values["modifier"]
                        #freq_mod = '1'
                        #start_time='00:00' #values["start_hr"] + ':' + values["start_min"]
                        #schtasks /create /tn \"My App\" /tr c:\\apps\\myapp.exe /sc onstart /ru SYSTEM
                        #task_path='optimus\\'
                        #task='Optimus_Orion_test' #values["task"]
                        #modifier = f' /ru "{os.environ.get("USERNAME")}" '

                        #runrpa_script = program
                        #runrpa_script = f'runRPA.bat -f {values["Task Scheduler tasklist"]} -sh main -sc main'
                    else:
                        program = f'runRPA.bat -f {values["Task Scheduler tasklist"]} -sh main -sc main'
                    window['-IN-'].update(program)  #f {values["-SCRIPT LIST-"][0]}
                    if 'modifier' in locals(): window['modifier'].update(modifier)
                    if 'description' in locals(): window['description'].update(description)
                    if 'freq' in locals(): window['freq'].update(freq)                    
                    if 'freq_mod' in locals(): window['freq_mod'].update(freq_mod)                   
                    if 'start_time' in locals(): window["start_hr"].update(start_time[:2])
                    if 'start_time' in locals(): window["start_min"].update(start_time[-2:])

                    #window.Refresh() if window else None
                    alert = 'Ready'
            except Exception as e:
                print("ERROR: Tasklist", str(e))


        if event in ('Run', 'SCRIPT LIST Debug', 'SCRIPT LIST Deploy'):
            run = False
            command = values['-IN-'].split(" ")
            #print(program, "|", command)
            if 'RUN SCRIPT' in program:
                additional_args = ''
                if len(values["SCRIPT LIST_"])==0: # nothing selected
                    alert = 'Please select a script first'
                    #window['-ALERT-'].update('Please select a script first')
                    continue
                if 'SCRIPT LIST Debug activate' in values.keys() or event == 'SCRIPT LIST Debug':
                    if values['SCRIPT LIST Debug activate'] or event == 'SCRIPT LIST Debug':  # is True
                        additional_args = ' -o 3'
                        if len(values["-BREAK POINT-"])>0: additional_args = additional_args + ' -a ' + values["-BREAK POINT-"]                        
                elif event == 'SCRIPT LIST Deploy': 
                    additional_args = ' -o 2'
                if 'runRPA.bat' in runrpa_script:
                    #print(runrpa_script, prog_path)
                    runProgram('std', f'cd .. && start {runrpa_script}{additional_args}', prog_path)                    
                    alert = 'Ready'
                continue

            alert = 'Running ...'
            window['-ALERT-'].update(f'STATUS: {alert}')
            window.Refresh() if window else None

            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            #output = subprocess.check_output(cmd, shell=True, universal_newlines=True)
            #output, error = process.communicate()

            for line in process.stdout:
                line = line.decode('utf-8')
                import re
                # Remove non-printable characters and also carriage return or new lines.  convert byte string to string.
                #line = line.decode(errors='replace' if (sys.version_info) < (3, 5) else 'backslashreplace').rstrip()
                line = re.sub(r"[^\x00-\x7F]+", "", line)
                line = re.sub(r"[\r\n]+", "", line.rstrip())                
                print(line)
                window.Refresh() if window else None  # yes, a 1-line if, so shoot me
                #output += line + '\n'
            # Wait for the process to exit
            process.wait()
            print('Process completed: ', not process.poll()==None)
            window["Exit"].update(disabled=False)
            alert = 'Ready'

    window.close()


def popup(function:bool=True, title='', ifTrue:str='True result', ifFalse:str='False'):
    """ Pop up alerts
        popup(_setup_shortcuts(), 'Setup', 'Shortcuts created on desktop', 'Shortcuts creation failed')
    """
    import PySimpleGUI as sg                
    if function:
        from pathlib import Path
        sg.popup(ifTrue, title=title)
    else:
        sg.popup(ifFalse, title=title)

def runProgram(type, program, prog_path):
    """ run batch command
    """
    try:
        if type in ('win'): 
            command = program.split(" ")
            shell=True
        elif  type in ('std'):
            command = program #.split(" ")
            shell=True
        else: 
            command = f'{prog_path}\{program}'.split(" ")
            shell=False
        #print(program, "|", shell, "|", command)
        print(program)
        import subprocess
        #if len(program.split(" "))>1:
        #    #subprocess.call([program.split(" ")[0], program.split(" ")[1], program.split(" ")[2] ])
        #    subprocess.call(program.split(" "))                
        #elif len(program.split(" "))==1:
        #subprocess.call(["D:\\optimus\\" + program])
        process = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   # non blocking
        result = process.stdout.decode('utf-8')
        return result
    except Exception as e:
        return "" #False

if __name__ == '__main__':
    launcher_window()


