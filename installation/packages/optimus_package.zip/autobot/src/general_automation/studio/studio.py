
from pathlib import Path
import pandas as pd
def _getProgPath() -> str:
    
    from pathlib import Path
    curr_path = Path.cwd() 
    if (curr_path / "autobot/assets").exists():
        prog_path = curr_path
    elif (curr_path.parent / "autobot/assets").exists():
        prog_path = curr_path.parent
    elif (curr_path.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent
    elif (curr_path.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent
    elif (curr_path.parent.parent.parent.parent / "autobot/assets").exists():
        prog_path = curr_path.parent.parent.parent.parent
    else:
        raise ValueError('Studio.launcher: Cannot detect program path')
    return prog_path.as_posix()
prog_path = _getProgPath().__str__() 
MODULE_PATH_src = Path(f"{prog_path}/autobot/src/general_automation").resolve().absolute().__str__()
import sys
sys.path.append(MODULE_PATH_src)
scriptKeywordsDefn = f"{prog_path}/autobot/assets/studio/help.xlsx" 
def get_asset_file(scriptKeywordsDefn:str = f"{prog_path}/autobot/assets/studio/studio.xlsx", sheet_name:str='Apps'):
    
    import pandas as pd
    from core.files import isFileNewer, get_filename_without_extension, readfile
    scriptKeywordsDefnCache = get_filename_without_extension(scriptKeywordsDefn)+".pickle"
    if Path(scriptKeywordsDefnCache).exists():
        if isFileNewer(scriptKeywordsDefnCache, scriptKeywordsDefn): 
            df = pd.read_pickle(scriptKeywordsDefnCache)
        else:
            df = readfile(filepath = scriptKeywordsDefn, sheet_name=sheet_name)
            pd.to_pickle(df, scriptKeywordsDefnCache) 
    else:
        df = readfile(filepath = scriptKeywordsDefn, sheet_name=sheet_name)
        pd.to_pickle(df, scriptKeywordsDefnCache) 
    return df
def temp():
    import pandas as pd
    def readfile(filepath = scriptKeywordsDefn):
        df = pd.read_excel(filepath, sheet_name=0) 
        df['Type']=df['Type'].fillna(method="ffill")
        df['Description']=df['Description'].astype(str)
        df['Command']=df['Command'].astype(str)    
        return df
    from pathlib import Path
    def get_filename_without_extension(file_path:str) -> str:
        path = Path(file_path)
        filename_without_extension = path.stem
        full_path = path.parent
        return str (full_path / filename_without_extension)
        return filename_without_extension
    from core.files import isFileNewer
    scriptKeywordsDefnCache = get_filename_without_extension(scriptKeywordsDefn)+".pickle"
    if Path(scriptKeywordsDefnCache).exists():
        if isFileNewer(scriptKeywordsDefnCache, scriptKeywordsDefn):
            df = pd.read_pickle(scriptKeywordsDefnCache)
            print("read cache")
        else:
            df = readfile(filepath = scriptKeywordsDefn)
            pd.to_pickle(df, scriptKeywordsDefnCache) 
    else:
        df = readfile(filepath = scriptKeywordsDefn)
        pd.to_pickle(df, scriptKeywordsDefnCache) 
    def arg(values, x, df=pd.DataFrame):    
        argstr = data_desc(key=values['listbox'][0], field='Arguments', df=df)    
        import json
        y = json.loads(x)
        return
def formula_exist(command:str='rem', df=pd.DataFrame):
    if command == '': return False
    else: return command.lower() in df['Command'].str.lower().to_list()       
import pandas as pd
def data_desc(key='rem:', field='Description', token="", df=pd.DataFrame):
    x = df[df.Command.str.lower()==key.lower()][field]
    if len(x)==0: return ""
    result = str(x.iloc[0])
    if result =="nan": 
        result=""
    else:
        result=token+result
    return result
def readJSON(json_str):
    import json
    try:
        return json.loads(json_str)
    except:
        return None
import FreeSimpleGUI as sg
_width_win = 50 
_width_txt = _width_win - 5 
_font_header = ("Helvetica", 12, "bold")
_font_txt = ("Helvetica", 12, "bold") 
def formula_window(command:str, codeParameterList:list=[], location:tuple = (0,0), df=get_asset_file(scriptKeywordsDefn=scriptKeywordsDefn, sheet_name='help')):
    
    if not formula_exist(command, df=df): 
        sg.popup('Command does not exist', title='Formula Builder', location=location)
        return ''
    _width_win = 70 
    _width_txt = _width_win - 50 
    _font_header = ("Helvetica", 12, "bold")
    _font_txt = ("Helvetica", 12, "bold") 
    bar_command = [[sg.Text(f"{command}", font=_font_header)]] 
    def _bar_parameters():
        arguments_str = data_desc(key=command, field='Arguments',token="", df=df)
        args = readJSON(arguments_str)
        if args == None:
            bar_parameters = [[sg.Text(f"No parameters", size=(_width_txt, 1))]] 
        else:
            bar_parameters = [[]]
            for idx, arg in enumerate(args): 
                if idx < len(codeParameterList): 
                    inputValue = codeParameterList[idx]
                else:
                    inputValue = ''
                bar_parameters+=[[sg.Text(arg, size=(_width_txt, 1)), sg.Input(inputValue, enable_events=True, key=f"-INPUT{idx}-")]]
        return bar_parameters, args
    bar_parameters, args = _bar_parameters()
    bar_description = [[sg.MLine(size=(_width_win, 10), key='-DESCRIPTION-', disabled=True)]]
    
    description_content = data_desc(key=command, field='Description',token="⏰DESCRIPTION\n ", df=df)+"\n"+ \
                             data_desc(key=command, field='Example',token="✅EXAMPLE\n ", df=df)+"\n"+ \
                             data_desc(key=command, field='Arguments',token="⬛ARGUMENTS\n ", df=df)+"\n"+ \
                             data_desc(key=command, field='Documentation',token="⚠️DOCUMENTATION\n ", df=df)    
    bar_result = [[sg.Multiline(f"Input parameters and click COPY to generate formula ...\n{command}"\
                               , size=(_width_win, 3), key='-RESULT-')]]
    selector_attrib_list = ['None']
    if 'element_identifier' in args:
        bar_bottom = [[sg.Push(), sg.Button(' Copy ', key='-COPY-'),sg.Button(' Cancel ', key='-CANCEL-'), sg.VSeparator(), 
                    sg.Button('Selector', key='-SELECTOR-'), 
                    sg.Combo(selector_attrib_list, size=(25, 1), default_value='None', key='-ATTRIB-', enable_events=True), 
                    sg.Button('Locate', key='-LOCATE-')]]
    else:
        bar_bottom = [[sg.Push(), sg.Button(' Copy ', key='-COPY-'),sg.Button(' Cancel ', key='-CANCEL-')]]
    bg_color = '
    bar_status = [[sg.Multiline(f"Status: Ready", size=(_width_win, 3), autoscroll = False, background_color = bg_color, key='-ALERT-')]]
    layout = [[]] + bar_command + [[sg.Text("Parameters", font=_font_header)]] + bar_parameters + \
                [[sg.Text("Description", font=_font_header)]] + bar_description + \
                [[sg.Text("Result", font=_font_header)]] + bar_result + bar_bottom + bar_status
    if not location == (0,0):
        window = sg.Window("Functional Arguments", layout, modal=True, finalize=True, keep_on_top=True, location=location)
    else:
        window = sg.Window("Functional Arguments", layout, modal=True, finalize=True, keep_on_top=True)        
    try:
        for idx, arg in enumerate(args):
            window[f"-INPUT{idx}-"].bind("<Return>", "_Enter")    
    except:
        pass
    window.bind("<Escape>", "_Escape")    
    window['-DESCRIPTION-'].update(description_content)                        
    result_rpa = ''
    old_jscript = 
    old_jscript =     
    jscript =     
    alert_msg = "STATUS: Ready"
    bg_color = '
    while True:
        event, values = window.read()
        if False: 
            print('alertmsg')
        if event == "-CANCEL-" or event == sg.WIN_CLOSED or "_Escape" in event:
            break
        if event == '-SELECTOR-':
            from browser import p        
            element = p.evaluate(jscript) 
            from studio.xpath import xpathBuild, xpathObj
            selectorObj = xpathObj(element)  
            print('element:', selectorObj)
            try:
                attrib, selector = xpathBuild(selectorObj)
                print('attrib:',attrib, 'selector:', selector)
                attrib_selection_combo = list(selectorObj.keys())
                if 'node_name' in attrib_selection_combo: attrib_selection_combo.remove('node_name')
                window[f"-ATTRIB-"].update(values = attrib_selection_combo)
                window[f"-ATTRIB-"].update(value = attrib)
                locator = p.findElement(selector, highlight=True)
                keys = list(args.keys())
                window[f"-INPUT{keys.index('element_identifier')}-"].update(selector)
                window[f"-ALERT-"].update(f"Element: {element}")
                import pyclip
                pyclip.copy(selector) 
                pass
            except Exception as e:
                print(e)
        if event == '-ATTRIB-':
            if 'selectorObj' in locals():
                attrib, selector = xpathBuild(selectorObj, key=values['-ATTRIB-'])
                keys = list(args.keys())
                window[f"-INPUT{keys.index('element_identifier')}-"].update(selector)
            else:
                print('No web element')
        if event == '-LOCATE-':
            from browser import p            
            if 'element_identifier' in args:
                keys = list(args.keys())
                idx = keys.index('element_identifier')
            selector = values[f"-INPUT{idx}-"]
            if not selector=='' or p.selector_exists(selector): locator = p.findElement(selector, highlight=True)
        if event == "-COPY-" or "_Enter" in event: 
            result_rpa=f"{command}: "
            separator=""            
            try:
                for idx, arg in enumerate(args):
                    if idx > 0: separator=" , "  
                    result_rpa += separator+values[f"-INPUT{idx}-"]
            except:
                pass
            result_rpa=f"{result_rpa}".strip() + ' '
            import re
            result_rpa = re.sub('(\s+,\s*)+$', '', result_rpa) 
            window['-RESULT-'].update(result_rpa)
            import pyclip
            pyclip.copy(result_rpa) 
            from config import variables
            if variables['record'] or variables['debug']: break
    window.close()
    return result_rpa
def search_rpa_commands_window(location:tuple = (0,0), df = get_asset_file(scriptKeywordsDefn=scriptKeywordsDefn, sheet_name='help')):
    def strDiffs(oldstr, newstr):
        import difflib
        difflist = [li[2] for li in difflib.ndiff(oldstr, newstr) if li[0] == '+']
        return ''.join(difflist)
    initialMsg = 'Type a brief description and click Go to search'
    bar_search = [[sg.Input(initialMsg, enable_events=True, key='-SEARCH-'), sg.Button(' Go ', key='-GO-')]]
    cmd_combolist = [''] + ['(Show All)'] + df['Type'].dropna().unique().tolist()
    bar_categorySelection = [[sg.Text('Or select a category:'), sg.Push(), \
                      sg.Combo(tuple(cmd_combolist), enable_events=True, key='-COMBO-')]] 
    command=""
    cmd_list = df[df['Command']!='nan']['Command'].tolist()
    cmd_list_str = tuple([k for k in cmd_list if isinstance(k,str)])
    bar_commandlist = [[sg.Listbox(values=cmd_list_str, size=(_width_win, 7), enable_events=True, key='-LISTBOX-')]]
    def cmd_description(command):
        return   data_desc(key=command, field='Description',token="⏰DESCRIPTION\n ", df=df)+"\n"+ \
                 data_desc(key=command, field='Example',token="✅EXAMPLE\n ", df=df)+"\n"+ \
                 data_desc(key=command, field='Arguments',token="⬛ARGUMENTS\n ", df=df)+"\n"+ \
                 data_desc(key=command, field='Documentation',token="⚠️DOCUMENTATION\n ", df=df)
    
    bar_description = [[sg.MLine(size=(50, 10), key='-DESCRIPTION-', disabled=True)]]  
    bar_bottom = [[sg.Push(), sg.Button(" Ok ", key="-OPEN-"), sg.Button(" Exit ", key="-EXIT-")]]
    layout = [[sg.Text('Search for a function:')]] + bar_search + \
                bar_categorySelection + [[sg.Text('Select a function:')]] + bar_commandlist + \
                [[sg.Text('Description:')]] + bar_description + bar_bottom
    if not location == (0,0):
        window = sg.Window("Insert Function", layout, finalize=True, keep_on_top=True, location=location)  
    else:
        window = sg.Window("Insert Function", layout, finalize=True, keep_on_top=True)  
    window[f"-SEARCH-"].bind("<Return>", "_Enter")    
    window[f"-LISTBOX-"].bind("<Return>", "_Enter")
    window[f"-SEARCH-"].bind("<Escape>", "_Escape")
    window.bind("<Escape>", "_Escape2")
    prev_input = initialMsg
    prev_event = ''
    while True:        
        event, values = window.read()
        if event == "-EXIT-" or event == sg.WIN_CLOSED  or "_Escape2" in event:
            break
        if event == '-SEARCH-' or event == '-SEARCH-_Escape': 
            if prev_input == initialMsg or values['-SEARCH-'] == initialMsg: 
                incrementalStr = strDiffs(initialMsg, values['-SEARCH-'])
                window['-SEARCH-'].update(incrementalStr)                
            elif event == '-SEARCH-_Escape':                  
                window['-SEARCH-'].update("")
            prev_input = values['-SEARCH-']
        if event in ['-GO-','-SEARCH-_Enter','-COMBO-']:  
            if event in ['-GO-', '-SEARCH-_Enter']:
                searchStr = values['-SEARCH-']
                df2=df[['Command', 'Type','Description']].dropna()           
                mylist = df2[(df2['Command'].str.contains(searchStr, case=False)| \
                            df2['Type'].str.contains(searchStr, case=False)| \
                            df2['Description'].str.contains(searchStr, case=False))]['Command'].tolist()
                cmd_list_str = tuple([k for k in mylist if isinstance(k,str)])        
            elif event in ['-COMBO-']:
                searchStr = values['-COMBO-']
                if 'Show All' in searchStr or searchStr=="": searchStr = ''
                df2=df[['Command', 'Type','Description']].dropna()  
                mylist = df2[(df2['Type'].str.contains(searchStr, case=False))]['Command'].tolist()
                cmd_list_str = tuple([k for k in mylist if isinstance(k,str)])        
            window['-LISTBOX-'].update(cmd_list_str)            
        if event == "-OPEN-" or event=="-LISTBOX-_Enter":    
            if len(values['-LISTBOX-']):
                command = values['-LISTBOX-'][0]
                print('form win')
                inputText=formula_window(command, location=window.current_location(), df=df)
                from config import variables
                if variables['debug'] and not inputText=='':
                    window.close()
                    return inputText
        if event == '-LISTBOX-' and not '
            command = values['-LISTBOX-'][0]
            window['-DESCRIPTION-'].update(cmd_description(command))     
        if prev_event != event:                             
            print(window.size, prev_event, event, values['-SEARCH-'])            
            prev_event = event
        if not event == '-SEARCH-' and values['-SEARCH-']=='':  
            window['-SEARCH-'].update(initialMsg)
            prev_input = initialMsg
    window.close()
    return None
if __name__ == "__main__":
    search_rpa_commands_window()
