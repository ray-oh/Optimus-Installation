_U='⚠️DOCUMENTATION\n '
_T='Documentation'
_S='⬛ARGUMENTS\n '
_R='✅EXAMPLE\n '
_Q='Example'
_P='⏰DESCRIPTION\n '
_O='.pickle'
_N='_Escape'
_M='<Escape>'
_L='<Return>'
_K='_Enter'
_J='-DESCRIPTION-'
_I='bold'
_H='Helvetica'
_G='Arguments'
_F='\n'
_E=False
_D='Type'
_C='Description'
_B='Command'
_A=True
from pathlib import Path
import pandas as pd
def _getProgPath():
	A='autobot/assets';from pathlib import Path;curr_path=Path.cwd()
	if (curr_path/A).exists():prog_path=curr_path
	elif (curr_path.parent/A).exists():prog_path=curr_path.parent
	elif (curr_path.parent.parent/A).exists():prog_path=curr_path.parent.parent
	elif (curr_path.parent.parent.parent/A).exists():prog_path=curr_path.parent.parent.parent
	elif (curr_path.parent.parent.parent.parent/A).exists():prog_path=curr_path.parent.parent.parent.parent
	else:raise ValueError('Studio.launcher: Cannot detect program path')
	return prog_path.as_posix()
prog_path=_getProgPath().__str__()
MODULE_PATH_src=Path(f"{prog_path}/autobot/src/general_automation").resolve().absolute().__str__()
import sys
sys.path.append(MODULE_PATH_src)
scriptKeywordsDefn=f"{prog_path}/autobot/assets/studio/help.xlsx"
def get_asset_file(scriptKeywordsDefn=f"{prog_path}/autobot/assets/studio/studio.xlsx",sheet_name='Apps'):
	import pandas as pd;from core.files import isFileNewer,get_filename_without_extension,readfile;scriptKeywordsDefnCache=get_filename_without_extension(scriptKeywordsDefn)+_O
	if Path(scriptKeywordsDefnCache).exists():
		if isFileNewer(scriptKeywordsDefnCache,scriptKeywordsDefn):df=pd.read_pickle(scriptKeywordsDefnCache)
		else:df=readfile(filepath=scriptKeywordsDefn,sheet_name=sheet_name);pd.to_pickle(df,scriptKeywordsDefnCache)
	else:df=readfile(filepath=scriptKeywordsDefn,sheet_name=sheet_name);pd.to_pickle(df,scriptKeywordsDefnCache)
	return df
def temp():
	import pandas as pd
	def readfile(filepath=scriptKeywordsDefn):df=pd.read_excel(filepath,sheet_name=0);df[_D]=df[_D].fillna(method='ffill');df[_C]=df[_C].astype(str);df[_B]=df[_B].astype(str);return df
	from pathlib import Path
	def get_filename_without_extension(file_path):path=Path(file_path);filename_without_extension=path.stem;full_path=path.parent;return str(full_path/filename_without_extension);return filename_without_extension
	from core.files import isFileNewer;scriptKeywordsDefnCache=get_filename_without_extension(scriptKeywordsDefn)+_O
	if Path(scriptKeywordsDefnCache).exists():
		if isFileNewer(scriptKeywordsDefnCache,scriptKeywordsDefn):df=pd.read_pickle(scriptKeywordsDefnCache);print('read cache')
		else:df=readfile(filepath=scriptKeywordsDefn);pd.to_pickle(df,scriptKeywordsDefnCache)
	else:df=readfile(filepath=scriptKeywordsDefn);pd.to_pickle(df,scriptKeywordsDefnCache)
	def arg(values,x,df=pd.DataFrame):argstr=data_desc(key=values['listbox'][0],field=_G,df=df);import json;y=json.loads(x);return
def formula_exist(command='rem',df=pd.DataFrame):
	if command=='':return _E
	else:return command.lower()in df[_B].str.lower().to_list()
import pandas as pd
def data_desc(key='rem:',field=_C,token='',df=pd.DataFrame):
	x=df[df.Command.str.lower()==key.lower()][field]
	if len(x)==0:return''
	result=str(x.iloc[0])
	if result=='nan':result=''
	else:result=token+result
	return result
def readJSON(json_str):
	import json
	try:return json.loads(json_str)
	except:return None
import FreeSimpleGUI as sg
_width_win=50
_width_txt=_width_win-5
_font_header=_H,12,_I
_font_txt=_H,12,_I
def formula_window(command,codeParameterList=[],location=(0,0),df=get_asset_file(scriptKeywordsDefn=scriptKeywordsDefn,sheet_name='help')):
	M='node_name';L='Functional Arguments';K='#64778d';J='-LOCATE-';I='-SELECTOR-';H=' Cancel ';G=' Copy ';F='None';E='-RESULT-';D='-ATTRIB-';C='-CANCEL-';B='-COPY-';A='element_identifier'
	if not formula_exist(command,df=df):sg.popup('Command does not exist',title='Formula Builder',location=location);return''
	_width_win=70;_width_txt=_width_win-50;_font_header=_H,12,_I;_font_txt=_H,12,_I;bar_command=[[sg.Text(f"{command}",font=_font_header)]]
	def _bar_parameters():
		arguments_str=data_desc(key=command,field=_G,token='',df=df);args=readJSON(arguments_str)
		if args==None:bar_parameters=[[sg.Text(f"No parameters",size=(_width_txt,1))]]
		else:
			bar_parameters=[[]]
			for (idx,arg) in enumerate(args):
				if idx<len(codeParameterList):inputValue=codeParameterList[idx]
				else:inputValue=''
				bar_parameters+=[[sg.Text(arg,size=(_width_txt,1)),sg.Input(inputValue,enable_events=_A,key=f"-INPUT{idx}-")]]
		return bar_parameters,args
	bar_parameters,args=_bar_parameters();bar_description=[[sg.MLine(size=(_width_win,10),key=_J,disabled=_A)]];description_content=data_desc(key=command,field=_C,token=_P,df=df)+_F+data_desc(key=command,field=_Q,token=_R,df=df)+_F+data_desc(key=command,field=_G,token=_S,df=df)+_F+data_desc(key=command,field=_T,token=_U,df=df);bar_result=[[sg.Multiline(f"Input parameters and click COPY to generate formula ...\n{command}",size=(_width_win,3),key=E)]];selector_attrib_list=[F]
	if A in args:bar_bottom=[[sg.Push(),sg.Button(G,key=B),sg.Button(H,key=C),sg.VSeparator(),sg.Button('Selector',key=I),sg.Combo(selector_attrib_list,size=(25,1),default_value=F,key=D,enable_events=_A),sg.Button('Locate',key=J)]]
	else:bar_bottom=[[sg.Push(),sg.Button(G,key=B),sg.Button(H,key=C)]]
	bg_color=K;bar_status=[[sg.Multiline(f"Status: Ready",size=(_width_win,3),autoscroll=_E,background_color=bg_color,key='-ALERT-')]];layout=[[]]+bar_command+[[sg.Text('Parameters',font=_font_header)]]+bar_parameters+[[sg.Text(_C,font=_font_header)]]+bar_description+[[sg.Text('Result',font=_font_header)]]+bar_result+bar_bottom+bar_status
	if not location==(0,0):window=sg.Window(L,layout,modal=_A,finalize=_A,keep_on_top=_A,location=location)
	else:window=sg.Window(L,layout,modal=_A,finalize=_A,keep_on_top=_A)
	try:
		for (idx,arg) in enumerate(args):window[f"-INPUT{idx}-"].bind(_L,_K)
	except:pass
	window.bind(_M,_N);window[_J].update(description_content);result_rpa='';old_jscript='\n// Your CSS as text\nvar styles = `\n*:hover {\n    //background-color: #205081 !important;\n    //use outline instead of border\n    outline:1px solid red !important;\n    //cursor:default;\n    //box-sizing:border-box;\n}\n`\nvar styleSheet = document.createElement("style")\nstyleSheet.innerText = styles\ndocument.head.appendChild(styleSheet)\nasync function getMousePos() {\n    let mousePos = { x: undefined, y: undefined };\n    let element = \'\'\n    let promise = new Promise((resolve, reject) => {\n        function printMousePos(event) {\n            event.preventDefault(); // Prevents the default action\n            mousePos = { x: event.clientX, y: event.clientY };              \n            resolve(mousePos);\n            element = document.elementFromPoint(mousePos.x, mousePos.y) \n            console.log(element.outerHTML)\n        }\n        window.addEventListener(\'click\', () => {printMousePos(event);});    \n        window.addEventListener("contextmenu", () => {printMousePos(event);});    \n        //"contextmenu", (e) => {e.preventDefault()});                                 \n      });\n      await promise\n      return element.outerHTML\n}\ngetMousePos()\n    ';old_jscript='\n// create a style sheet and add rule\nvar borderStyleSheet = document.createElement("style");\ndocument.head.appendChild(borderStyleSheet);\nborderStyleSheet.sheet.insertRule("*:hover { outline: 1px solid red;}", 0);\n// enable rule\nborderStyleSheet.disabled = false;\n// see existing stylesheets\nconsole.log(document.styleSheets);                                 \nasync function getMousePos() {\n    let mousePos = { x: undefined, y: undefined };\n    let element = \'\'\n    let promise = new Promise((resolve, reject) => {\n        function printMousePos(event) {\n            event.preventDefault(); // Prevents the default action\n            mousePos = { x: event.clientX, y: event.clientY };              \n            resolve(mousePos);\n            element = document.elementFromPoint(mousePos.x, mousePos.y) \n            console.log(element.outerHTML)\n        }\n        //window.addEventListener(\'click\', () => {printMousePos(event);});    \n        window.addEventListener("contextmenu", () => {printMousePos(event);});    \n        //"contextmenu", (e) => {e.preventDefault()});                                 \n      });\n    await promise\n    // disable rule\n    borderStyleSheet.disabled = true;\n    return element.outerHTML\n}\ngetMousePos()\n    ';jscript='\nvar iframe = document.getElementById(\'myFrame\');\nvar iframeDoc = iframe.contentWindow || iframe.contentDocument;\n// create a style sheet and add rule\nvar borderStyleSheet = document.createElement("style");\ndocument.head.appendChild(borderStyleSheet);\nborderStyleSheet.sheet.insertRule("*:hover { outline: 1px solid red;}", 0);\n// enable rule\nborderStyleSheet.disabled = false;\n// see existing stylesheets\nconsole.log(document.styleSheets);                                 \nasync function getMousePos() {\n    let mousePos = { x: undefined, y: undefined };\n    let element = \'\'\n    let promise = new Promise((resolve, reject) => {\n        function printMousePos(event) {\n            event.preventDefault(); // Prevents the default action\n            mousePos = { x: event.clientX, y: event.clientY };              \n            resolve(mousePos);\n            element = document.elementFromPoint(mousePos.x, mousePos.y) \n            console.log(element.outerHTML)\n        }\n        //window.addEventListener(\'click\', () => {printMousePos(event);});    \n        window.addEventListener("contextmenu", () => {printMousePos(event);});    \n        //"contextmenu", (e) => {e.preventDefault()});                                 \n      });\n    await promise\n    // disable rule\n    borderStyleSheet.disabled = true;\n    return element.outerHTML\n}\ngetMousePos()\n    ';alert_msg='STATUS: Ready';bg_color=K
	while _A:
		event,values=window.read()
		if _E:print('alertmsg')
		if event==C or event==sg.WIN_CLOSED or _N in event:break
		if event==I:
			from browser import p;element=p.evaluate(jscript);from studio.xpath import xpathBuild,xpathObj;selectorObj=xpathObj(element);print('element:',selectorObj)
			try:
				attrib,selector=xpathBuild(selectorObj);print('attrib:',attrib,'selector:',selector);attrib_selection_combo=list(selectorObj.keys())
				if M in attrib_selection_combo:attrib_selection_combo.remove(M)
				window[f"-ATTRIB-"].update(values=attrib_selection_combo);window[f"-ATTRIB-"].update(value=attrib);locator=p.findElement(selector,highlight=_A);keys=list(args.keys());window[f"-INPUT{keys.index(A)}-"].update(selector);window[f"-ALERT-"].update(f"Element: {element}");import pyclip;pyclip.copy(selector)
			except Exception as e:print(e)
		if event==D:
			if'selectorObj'in locals():attrib,selector=xpathBuild(selectorObj,key=values[D]);keys=list(args.keys());window[f"-INPUT{keys.index(A)}-"].update(selector)
			else:print('No web element')
		if event==J:
			from browser import p
			if A in args:keys=list(args.keys());idx=keys.index(A)
			selector=values[f"-INPUT{idx}-"]
			if not selector==''or p.selector_exists(selector):locator=p.findElement(selector,highlight=_A)
		if event==B or _K in event:
			result_rpa=f"{command}: ";separator=''
			try:
				for (idx,arg) in enumerate(args):
					if idx>0:separator=' , '
					result_rpa+=separator+values[f"-INPUT{idx}-"]
			except:pass
			result_rpa=f"{result_rpa}".strip()+' ';import re;result_rpa=re.sub('(\\s+,\\s*)+$','',result_rpa);window[E].update(result_rpa);import pyclip;pyclip.copy(result_rpa);from config import variables
			if variables['record']or variables['debug']:break
	window.close();return result_rpa
def search_rpa_commands_window(location=(0,0),df=get_asset_file(scriptKeywordsDefn=scriptKeywordsDefn,sheet_name='help')):
	J='-SEARCH-_Enter';I='-SEARCH-_Escape';H='_Escape2';G='Insert Function';F='-EXIT-';E='-OPEN-';D='-GO-';C='-COMBO-';B='-LISTBOX-';A='-SEARCH-'
	def strDiffs(oldstr,newstr):import difflib;difflist=[li[2]for li in difflib.ndiff(oldstr,newstr)if li[0]=='+'];return ''.join(difflist)
	initialMsg='Type a brief description and click Go to search';bar_search=[[sg.Input(initialMsg,enable_events=_A,key=A),sg.Button(' Go ',key=D)]];cmd_combolist=['']+['(Show All)']+df[_D].dropna().unique().tolist();bar_categorySelection=[[sg.Text('Or select a category:'),sg.Push(),sg.Combo(tuple(cmd_combolist),enable_events=_A,key=C)]];command='';cmd_list=df[df[_B]!='nan'][_B].tolist();cmd_list_str=tuple([k for k in cmd_list if isinstance(k,str)]);bar_commandlist=[[sg.Listbox(values=cmd_list_str,size=(_width_win,7),enable_events=_A,key=B)]]
	def cmd_description(command):return data_desc(key=command,field=_C,token=_P,df=df)+_F+data_desc(key=command,field=_Q,token=_R,df=df)+_F+data_desc(key=command,field=_G,token=_S,df=df)+_F+data_desc(key=command,field=_T,token=_U,df=df)
	bar_description=[[sg.MLine(size=(50,10),key=_J,disabled=_A)]];bar_bottom=[[sg.Push(),sg.Button(' Ok ',key=E),sg.Button(' Exit ',key=F)]];layout=[[sg.Text('Search for a function:')]]+bar_search+bar_categorySelection+[[sg.Text('Select a function:')]]+bar_commandlist+[[sg.Text('Description:')]]+bar_description+bar_bottom
	if not location==(0,0):window=sg.Window(G,layout,finalize=_A,keep_on_top=_A,location=location)
	else:window=sg.Window(G,layout,finalize=_A,keep_on_top=_A)
	window[f"-SEARCH-"].bind(_L,_K);window[f"-LISTBOX-"].bind(_L,_K);window[f"-SEARCH-"].bind(_M,_N);window.bind(_M,H);prev_input=initialMsg;prev_event=''
	while _A:
		event,values=window.read()
		if event==F or event==sg.WIN_CLOSED or H in event:break
		if event==A or event==I:
			if prev_input==initialMsg or values[A]==initialMsg:incrementalStr=strDiffs(initialMsg,values[A]);window[A].update(incrementalStr)
			elif event==I:window[A].update('')
			prev_input=values[A]
		if event in[D,J,C]:
			if event in[D,J]:searchStr=values[A];df2=df[[_B,_D,_C]].dropna();mylist=df2[df2[_B].str.contains(searchStr,case=_E)|df2[_D].str.contains(searchStr,case=_E)|df2[_C].str.contains(searchStr,case=_E)][_B].tolist();cmd_list_str=tuple([k for k in mylist if isinstance(k,str)])
			elif event in[C]:
				searchStr=values[C]
				if'Show All'in searchStr or searchStr=='':searchStr=''
				df2=df[[_B,_D,_C]].dropna();mylist=df2[df2[_D].str.contains(searchStr,case=_E)][_B].tolist();cmd_list_str=tuple([k for k in mylist if isinstance(k,str)])
			window[B].update(cmd_list_str)
		if event==E or event=='-LISTBOX-_Enter':
			if len(values[B]):
				command=values[B][0];print('form win');inputText=formula_window(command,location=window.current_location(),df=df);from config import variables
				if variables['debug']and not inputText=='':window.close();return inputText
		if event==B and not'# ---'in values[B][0]:command=values[B][0];window[_J].update(cmd_description(command))
		if prev_event!=event:print(window.size,prev_event,event,values[A]);prev_event=event
		if not event==A and values[A]=='':window[A].update(initialMsg);prev_input=initialMsg
	window.close();return None
if __name__=='__main__':search_rpa_commands_window()