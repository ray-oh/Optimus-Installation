_E='Controls'
_D='Geometry'
_C='atspi'
_B=False
_A='uia'
from PyQt5.QtCore import QLocale,QCoreApplication,QSettings,Qt,QAbstractTableModel,QVariant
from PyQt5.QtGui import QStandardItemModel
from PyQt5.QtGui import QStandardItem
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QGridLayout
from PyQt5.QtWidgets import QLabel
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QTreeView
from PyQt5.QtWidgets import QTableView
import sys,warnings
warnings.simplefilter('ignore',UserWarning)
sys.coinit_flags=2
from pywinauto import backend
def main():A=QApplication(sys.argv);A.setStyle('Fusion');B=MyWindow();B.show();A.exec_();A.quit()
class MyWindow(QWidget):
	def __init__(A):
		B='MainWindow';super(MyWindow,A).__init__();A.setMinimumSize(1000,1000);A.setLocale(QLocale(QLocale.English,QLocale.UnitedStates));A.setWindowTitle(QCoreApplication.translate(B,'PyInspect'));A.settings=QSettings('py_inspect',B);A.mainLayout=QGridLayout();A.backendLabel=QLabel('Backend Type');A.comboBox=QComboBox();A.comboBox.setMouseTracking(_B);A.comboBox.setMaxVisibleItems(5);A.comboBox.setObjectName('comboBox')
		for C in backend.registry.backends.keys():A.comboBox.addItem(C)
		A.mainLayout.addWidget(A.backendLabel,0,0,1,1);A.mainLayout.addWidget(A.comboBox,0,1,1,1);A.tree_view=QTreeView();A.tree_view.setColumnWidth(0,150);A.comboBox.setCurrentText(_A);A.__initialize_calc();A.table_view=QTableView();A.comboBox.activated[str].connect(A.__show_tree);A.mainLayout.addWidget(A.tree_view,1,0,1,1);A.mainLayout.addWidget(A.table_view,1,1,1,1);A.setLayout(A.mainLayout);D=A.settings.value(_D,bytes('','utf-8'));A.restoreGeometry(D)
	if sys.platform.startswith('linux'):
		def __initialize_calc(A,_backend=_C):B=_backend;A.element_info=backend.registry.backends[B].element_info_class();A.tree_model=MyTreeModel(A.element_info,B);A.tree_model.setHeaderData(0,Qt.Horizontal,_E);A.tree_view.setModel(A.tree_model);A.tree_view.clicked.connect(A.__show_property)
	else:
		def __initialize_calc(A,_backend=_A):B=_backend;A.element_info=backend.registry.backends[B].element_info_class();A.tree_model=MyTreeModel(A.element_info,B);A.tree_model.setHeaderData(0,Qt.Horizontal,_E);A.tree_view.setModel(A.tree_model);A.tree_view.clicked.connect(A.__show_property)
	def __show_tree(A,text):B=text;A.__initialize_calc(B)
	def __show_property(A,index=None):B=index.data();A.table_model=MyTableModel(A.tree_model.props_dict.get(B),A);A.table_view.wordWrap();A.table_view.setModel(A.table_model);A.table_view.setColumnWidth(1,320)
	def closeEvent(A,event):B=A.saveGeometry();A.settings.setValue(_D,B);super(MyWindow,A).closeEvent(event)
class MyTreeModel(QStandardItemModel):
	def __init__(A,element_info,backend):B=element_info;QStandardItemModel.__init__(A);C=A.invisibleRootItem();A.props_dict={};A.backend=backend;A.branch=QStandardItem(A.__node_name(B));A.branch.setEditable(_B);C.appendRow(A.branch);A.__generate_props_dict(B);A.__get_next(B,A.branch)
	def __get_next(A,element_info,parent):
		for B in element_info.children():A.__generate_props_dict(B);C=QStandardItem(A.__node_name(B));C.setEditable(_B);parent.appendRow(C);A.__get_next(B,C)
	def __node_name(B,element_info):
		C='%s "%s" (%s)';A=element_info
		if _A==B.backend:return C%(str(A.control_type),str(A.name),id(A))
		elif _C==B.backend:return C%(str(A.control_type),str(A.name),id(A))
		return'"%s" (%s)'%(str(A.name),id(A))
	def __generate_props_dict(B,element_info):E='runtime_id';D='control_type';A=element_info;C=[['control_id',str(A.control_id)],['class_name',str(A.class_name)],['enabled',str(A.enabled)],['handle',str(A.handle)],['name',str(A.name)],['process_id',str(A.process_id)],['rectangle',str(A.rectangle)],['rich_text',str(A.rich_text)],['visible',str(A.visible)]];F=[]if B.backend=='win32'else[];G=[['automation_id',str(A.automation_id)],[D,str(A.control_type)],['element',str(A.element)],['framework_id',str(A.framework_id)],[E,str(A.runtime_id)]]if B.backend==_A else[];H=[[D,str(A.control_type)],[E,str(A.runtime_id)]]if B.backend==_C else[];C.extend(G);C.extend(F);C.extend(H);I={B.__node_name(A):C};B.props_dict.update(I)
class MyTableModel(QAbstractTableModel):
	def __init__(A,datain,parent=None,*B):QAbstractTableModel.__init__(A,parent,*(B));A.arraydata=datain;A.header_labels=['Property','Value']
	def rowCount(A,parent):return len(A.arraydata)
	def columnCount(A,parent):return len(A.arraydata[0])
	def data(B,index,role):
		A=index
		if not A.isValid():return QVariant()
		elif role!=Qt.DisplayRole:return QVariant()
		return QVariant(B.arraydata[A.row()][A.column()])
	def headerData(A,section,orientation,role=Qt.DisplayRole):
		C=orientation;B=section
		if role==Qt.DisplayRole and C==Qt.Horizontal:return A.header_labels[B]
		return QAbstractTableModel.headerData(A,B,C,role)
if __name__=='__main__':main()