#!/usr/bin/env python
_F='https://github.com/ray-oh/Optimus'
_E='menuTitle'
_D='version'
_C='settings'
_B='type'
_A=True
from argparse import ArgumentParser,ArgumentDefaultsHelpFormatter,RawDescriptionHelpFormatter
from gooey import Gooey,GooeyParser
from pathlib import Path
@Gooey(program_name='Optimus RPA - do more with less',optional_cols=3,program_description=f"Input RPA script name and other parameters below",image_dir=f"{Path.cwd().__str__()}",menu=[{'name':'Help','items':[{_B:'MessageDialog',_E:'About','caption':'Inform','message':'RPA solution with Excel front end for creating flows.\nDesigned with the typical data analyst who is not technical savy but comfortable using Excel in mind.\nThe solution makes it really easy for beginners to develop your own flows, especially with templates.\nUsers can easily share and reuse modular Excel based scripts to speed up flow creation or create sophisticated automation flows.\n\nOPTIMUS differentiates itself from other RPA solutions including market leading commercial packages like UiPath in terms of its ease of use and extensibility.\nBut at the sametime, it does not compromise on features and capabilities.'},{_B:'Link',_E:'Documentation','url':_F},{_B:'AboutDialog',_E:'Version / License','name':'Optimus RPA','description':'Program for running Optimus Automation Scripts',_D:'1.2.1','copyright':'2023','website':_F,'developer':'Raymond Oh (https://github.com/ray-oh)','license':'BSD-3-Clause license'}]}])
def parseArgGUI(configObj):version=configObj[_C][_D];parserGUI=GooeyParser(description=f"Automate more with less!");return parserGUI
def parseArg(configObj,deploymentRun):
	C='help';B='startfile';A='flag';version=configObj[_C][_D];import sys
	if len(sys.argv)>1 or deploymentRun:activateGooey=False;parser=ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter,description='Optimus '+version+'\n'+'Utility to process RPA scripts with steps defined from an Excel input.')
	else:activateGooey=_A;parser=parseArgGUI(configObj)
	required=parser.add_argument_group('Required arguments');optional=parser.add_argument_group('Optional arguments')
	def addArg(op,widget_action,activateGooey,defaultValue,typeValue,key):
		A='./scripts/*.xlsm'
		def filelistcheck(value):
			from pathlib import Path;scripts=[f.stem for f in Path.cwd().parents[0].glob(A)]
			if value in scripts:return value
			else:raise TypeError('Incorrect file')
		if not activateGooey:op.add_argument(flag,flagLong,default=defaultValue,type=typeValue,help=help)
		elif key==B:scripts=[f.stem for f in Path.cwd().parents[0].glob(A)];op.add_argument(flag,flagLong,help=help,choices=scripts,widget='FilterableDropdown',type=filelistcheck,gooey_options={'full_width':_A},required=_A)
		elif'choices['in widget_action:op.add_argument(flag,flagLong,help=help,default=defaultValue,choices=eval(widget_action[7:]))
		elif str(widget_action).lower()in['dirchooser','filechooser','integerfield']:op.add_argument(flag,flagLong,help=help,default=defaultValue,widget=widget_action,required=_A)
		elif str(widget_action).lower()in['store','count']:op.add_argument(flag,flagLong,help=help,action=widget_action,default=defaultValue)
		elif typeValue==bool:defaultValue=eval(defaultValue);op.add_argument(flag,flagLong,help=help,widget='CheckBox',default=defaultValue)
		else:op.add_argument(flag,flagLong,default=defaultValue,type=typeValue,help=help)
		return op
	config_keys=configObj.options(A);flags_items=configObj.items(A);help_items=configObj.items(C)
	for key in config_keys:
		flag='-'+configObj[A][key];flagLong='--'+key;typeValue=eval(configObj[_B][key]);defaultValue=configObj[_C][key];widget_action=configObj['widget'][key];help=configObj[C][key]
		if key in[B,'program_dir']:required=addArg(required,widget_action,activateGooey,defaultValue,typeValue,key)
		else:optional=addArg(optional,widget_action,activateGooey,defaultValue,typeValue,key)
	args=vars(parser.parse_args());return args
def mainparseArguments():A='main';parser=ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter);parser.add_argument('-f','--startfile',default='.\\main.xlsm',type=str,help='Path to Excel file with RPA steps');parser.add_argument('-c','--startcode',default=A,type=str,help='Name of first block of RPA steps to run');parser.add_argument('-m','--startsheet',default=A,help='Name of first sheet or module to run');parser.add_argument('-b','--background',default=0,help='0 = Normal mode, 1 = Background mode');parser.add_argument('-p','--logPrint',default=_A,type=bool,help='Print logs to console.');parser.add_argument('-a','--logPrintLevel',default=30,type=int,help='Prints alerts to console - 10 Debug, 20 Info, 30 Warning.');parser.add_argument('-d','--defaultLogLevel',default='DEBUG',type=str,help='Log alert level - DEBUG, INFO, WARNING etc.');parser.add_argument('-l','--srcLog',default='generalAutomation.log',type=str,help='Log file name');parser.add_argument('-r','--srcLogPath',default='.\\log',type=str,help='Log Path');parser.add_argument('-g','--config',default='',type=str,help='Path to config file with default run settings. Default config.json');parser.add_argument('-s','--settings',default=2,type=int,help='Settings: 0 = ignore, 1 = save config, 2 = load config');args=vars(parser.parse_args());return args
from pyparsing import printables,originalTextFor,OneOrMore,quotedString,Word,delimitedList
def parseWithQuotes(stringToParse,delimiter=','):stringToParse=searchReplacePattern('(,[\\s]*,)',stringToParse,',[space],');printables_less_delimiter=printables.replace(delimiter,'');content=originalTextFor(OneOrMore(quotedString|Word(printables_less_delimiter)));result=delimitedList(content,delimiter).parseString(stringToParse);result=searchReplaceList(result,'[space]','');return result
import re
def regexSearch(strPattern,strSearch):
	try:print('regexSearch .....',strPattern,strSearch);found=re.search(strPattern,strSearch).group(1);return found
	except AttributeError:pass
	return None
def searchReplacePattern(pattern,searchStr,replace):return re.sub(pattern,replace,searchStr)
def searchReplaceList(objList,search,replace=''):result=[replace if x==search else x for x in objList];return result
def parseArguments(labels,argumentStr,delimiter=',',validate=1):
	labelsList=[s.strip()for s in labels.split(delimiter)];argumentsList=[s.strip()for s in parseWithQuotes(argumentStr)]
	if validate==2:
		if len(argumentsList)!=len(labelsList):return{}
	elif validate==1:
		if len(argumentsList)>len(labelsList):return{}
	elif validate==0:0
	i=0;tmpDict={}
	for argument in argumentsList:tmpDict[labelsList[i]]=argument;i=i+1
	return tmpDict