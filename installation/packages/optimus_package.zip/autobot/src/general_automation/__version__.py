__version__ = '2.1.7'
__annotations__ = """
2.1.7 PySimpleGUI (which changed to closed source licensing) replace with FreeSimpleGUI.
Updates to requirements.txt, studio and launcher files.
2.1.7.1 Bug fix builtin/regexSearch
2.7.1.2 Print debug for browser/findElement
2.7.1.3 REFACTOR auto_helper_lib to core.core
2.7.1.4 Add runOptimus launch script
2.7.1.5 Flow name add sheet and code details
2.7.1.6 Library and core file documentations
2.7.1.7 killOptimus, runbat title, killprocess
2.7.1.8 core updateconstants formula substitutions
2.7.1.9 Playwright locate expect ishidden
2.7.1.10 Expect download timeout.
"""
__date__ = '2023-12-27'
__updated__ = '2024-08-05'
__author__ = 'GitHub: ray-oh'
__description__ = """
RPA solution with Excel front end
designed to make automation easy for beginners.
Automate more with less, using
Excel automation script templates.
"""