_A='2023-12-27'
__version__='2.1.0'
__date__=_A
__updated__=_A
__author__='GitHub: ray-oh'
__description__='\nRPA solution with Excel front end\ndesigned to make automation easy for beginners.\nAutomate more with less, using\nExcel automation script templates.\n'