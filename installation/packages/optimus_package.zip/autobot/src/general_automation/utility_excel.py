_A='example.pickle'
import os.path,datetime,time
def isFileNewer(file1,file2,type='m'):
	B=file2;A=file1
	if type=='m':return os.path.getmtime(A)>os.path.getmtime(B)
	elif type=='c':return os.path.getctime(A)>os.path.getctime(B)
	else:return
import pickle
def pickle_storeData(db={},dbfilename=_A):
	if db=={}:return
	A=open(dbfilename,'ab');pickle.dump(db,A);A.close();return
def pickle_loadData(dbfilename=_A):A=open(dbfilename,'rb');B=pickle.load(A);A.close();return B
import pandas as pd
from pathlib import Path
from auto_helper_lib import try_catch,readExcelConfig
from config import log_space
def cacheScripts(script='OptimusLib.xlsm',df=pd.DataFrame(),program_dir='D:/optimus/',startsheet='main',refresh=False,msgStr=''):
	J='scripts';I=refresh;H=program_dir;G=script;B=df;A=msgStr;E=Path(G).stem;F=Path(H).joinpath(J,G);C=Path(H).joinpath(J,'_cache',E+'.pickle')
	if F.exists():
		if C.exists()and isFileNewer(C.__str__(),F.__str__())and not I:
			D=pd.read_pickle(C.__str__())
			if not A=='':A=A+'\n'
			A=A+f"     {log_space}{E} ---- from Cache"
		else:
			D=try_catch(readExcelConfig(sheet=startsheet,excel=str(F),refresh=I))
			if not A=='':A=A+'\n'
			A=A+f"     {log_space}{E} ---- from Excel";pd.to_pickle(D,C.__str__())
		if B.empty:B=D
		else:B=pd.concat([B,D],ignore_index=True,sort=False)
	return B,A