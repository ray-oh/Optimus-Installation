if __name__ == "__main__":    
    from prefect import tags
    import config 
    import core.initialize
    if 'arguments' in config.program_args:
        config.constants['arg'] = config.program_args['arguments']
    if config.program_args['flowrun']==3: 
        config.variables['break point'] = config.program_args['arguments'].split(' , ')[1]
        config.variables['window position'] = eval(config.program_args['arguments'].split(' , ')[0])
    if '4' in str(config.program_args['background']):
        deploymentname = config.program_args['startfile'] + "_TRIGGER"
    else:
        deploymentname = config.program_args['startfile']
    retries = int(config.program_args['retries'])
    tag = config.program_args['tag']
    print(deploymentname, config.program_args['startsheet'], config.program_args['startcode'])
    if config.program_args['startsheet']!="main": deploymentname=deploymentname+'_'+config.program_args['startsheet']
    if config.program_args['startcode']!="main": deploymentname=deploymentname+'_'+config.program_args['startcode']
    with tags(tag):   
        from run import run
        result = run.with_options(name=deploymentname, description=deploymentname, retries=retries)(flowrun=config.program_args['flowrun']) 
