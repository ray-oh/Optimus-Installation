#!/usr/bin/env python
_A='startfile'
if __name__=='__main__':
	from prefect import tags;import config,initialize
	if'4'in str(config.program_args['background']):deploymentname=config.program_args[_A]+'_TRIGGER'
	else:deploymentname=config.program_args[_A]
	retries=int(config.program_args['retries']);tag=config.program_args['tag']
	with tags(tag):from run import run;result=run.with_options(name=deploymentname,description=deploymentname,retries=retries)(flowrun=config.program_args['flowrun'])