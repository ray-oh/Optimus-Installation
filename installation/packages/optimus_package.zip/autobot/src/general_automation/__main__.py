_E='startfile'
_D='flowrun'
_C='startcode'
_B='startsheet'
_A='arguments'
if __name__=='__main__':
	from prefect import tags;import config,core.initialize
	if _A in config.program_args:config.constants['arg']=config.program_args[_A]
	if config.program_args[_D]==3:config.variables['break point']=config.program_args[_A].split(' , ')[1];config.variables['window position']=eval(config.program_args[_A].split(' , ')[0])
	if'4'in str(config.program_args['background']):deploymentname=config.program_args[_E]+'_TRIGGER'
	else:deploymentname=config.program_args[_E]
	retries=int(config.program_args['retries']);tag=config.program_args['tag'];print(deploymentname,config.program_args[_B],config.program_args[_C])
	if config.program_args[_B]!='main':deploymentname=deploymentname+'_'+config.program_args[_B]
	if config.program_args[_C]!='main':deploymentname=deploymentname+'_'+config.program_args[_C]
	with tags(tag):from run import run;result=run.with_options(name=deploymentname,description=deploymentname,retries=retries)(flowrun=config.program_args[_D])