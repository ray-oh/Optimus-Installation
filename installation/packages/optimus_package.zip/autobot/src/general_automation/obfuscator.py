import re
def remove_comments(file_path):
    with open(file_path, mode='r', encoding="utf8") as file:
        code = file.read()
    code = re.sub(r'
    with open(file_path, mode='w', encoding="utf8") as file:
        file.write(code)
def remove_docstrings(file_path):
    with open(file_path, mode='r', encoding="utf8") as file:
        code = file.read()
    code = re.sub(r'', '', code, flags=re.DOTALL)
    code = re.sub(r"", '', code, flags=re.DOTALL)
    with open(file_path, mode='w', encoding="utf8") as file:
        file.write(code)
def remove_empty_lines(file_path):
    with open(file_path, mode='r', encoding="utf8") as file:
        lines = file.readlines()
    with open(file_path, mode='w', encoding="utf8") as file:
        for line in lines:
            if line.strip():  
                file.write(line)
import os
def xxxlist_files(directory):
    file_list = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_list.append(os.path.join(root, file))
    return file_list
import fnmatch
import os
def filter_files(file_list, include_patterns, exclude_patterns):
    included_files = []
    for pattern in include_patterns:
        included_files.extend(fnmatch.filter(file_list, pattern))
    excluded_files = set()
    for pattern in exclude_patterns:
        excluded_files.update(fnmatch.filter(file_list, pattern))
    filtered_files = [file for file in included_files if file not in excluded_files]
    return filtered_files
def list_files(directory):
    if not os.path.isdir(directory):
        raise FileNotFoundError(f"The directory '{directory}' does not exist.")
    file_list = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_list.append(os.path.join(root, file))
    return file_list
def xxxprocess(directory, mode="D", exclude="None"):
    from pathlib import Path
    if Path(directory).is_dir():
        print(f"The directory '{directory}' exists.")
        all_files = list_files(directory)
        for file in all_files:
            if mode == "D":
                print(file)
            elif mode == "W":
                remove_comments(file)
                remove_empty_lines(file)
    else:
        print(f"The directory '{directory}' does not exist.")
def process(directory, mode="D", include_patterns=[], exclude_patterns=[]):
    try:
        all_files = list_files(directory)
        for file in all_files:
            if mode == "W" and ".py" in file.lower():
                remove_comments(file)
                remove_empty_lines(file)
        filtered_files = filter_files(all_files, include_patterns, exclude_patterns)
        for file in filtered_files:
            if mode == "D":
                print(file)
            elif mode == "W":
                remove_docstrings(file)
    except FileNotFoundError as e:
        print(e)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Obfuscate files in directory.")
    parser.add_argument('-d', dest='directory', type=str, default='None', help='Directory')
    parser.add_argument('-m', dest='mode', type=str, default='D', help='Mode: D=display or W=write')
    parser.add_argument('-x', dest='exclude', type=str, default='', help='Exclude: patterns. E.g. *version*.py,*libraries*.py')
    parser.add_argument('-i', dest='include', type=str, default='*.py', help='Include: patterns. Default *.py')            
    args = parser.parse_args()
    process(args.directory, args.mode.upper(), args.include.split(','), args.exclude.split(','))
