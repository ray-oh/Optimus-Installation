#!/usr/bin/env python
_C='gen_py'
_B='outlook.application'
_A='MAPI'
import datetime,os,shutil
from pathlib import Path
import pandas as pd,win32com.client as win32
from prefect import task,flow,get_run_logger,context
from prefect.task_runners import SequentialTaskRunner
from config import log_space
today_string=datetime.datetime.today().strftime('%m%d%Y_%I%p')
today_string2=datetime.datetime.today().strftime('%b %d, %Y')
attachment_path=Path.cwd()/'data'/'attachments'
archive_dir=Path.cwd()/'archive'
src_file=Path.cwd()/'mail.xlsx'
class EmailsSender:
	def __init__(A):
		B=get_run_logger();from pathlib import Path;import tempfile as C;D=Path(C.gettempdir(),_C)
		try:import pythoncom as E;E.CoInitialize();A.outlook=win32.gencache.EnsureDispatch(_B)
		except AttributeError:B.error('AttributeError - relaunch COM object');F=D;import shutil as G;G.rmtree(F);A.outlook=win32.gencache.EnsureDispatch(_B)
		A.olOutbox=A.outlook.GetNamespace(_A).GetDefaultFolder(4)
	def getSentEmailSubjectList(B,sentEmailSubjectList=[],cutOffDateTme=datetime.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)):
		A=sentEmailSubjectList
		if len(A)==0:A=B.folderItemsList(ofolder=5,dateRange_StartOn=cutOffDateTme)
		return A
	def refreshMail(C):D=get_run_logger();A=C.outlook.GetNamespace(_A);E=A.SyncObjects;B=E.AppFolders;from win32com.client import constants as F;G=A.GetDefaultFolder(F.olFolderInbox);D.debug(f"{log_space}-----------------------------------refreshMail");B.Start;B.Stop;H=G.Items;I=H.GetLast().ReceivedTime;print(I)
	def temp2():
		import pythoncom as B;B.CoInitialize();from pathlib import Path as A
		try:logger.debug(f"{log_space}Try 1 ,,,23");import win32com.client as C;self.outlook=C.Dispatch(_B,B.CoInitialize());self.olOutbox=self.outlook.GetNamespace(_A).GetDefaultFolder(4)
		except AttributeError:
			logger.debug(f"{log_space}Try 2");D='C:\\Users\\svc_supplychain\\AppData\\Local\\Temp\\gen_py'
			for E in A(D):A.unlink(E)
			A.rmdir(D);self.outlook=C.gencache.EnsureDispatch(_B);self.olOutbox=self.outlook.GetNamespace(_A).GetDefaultFolder(4)
	def temp():
		B=get_run_logger()
		try:B.debug(f"{log_space}Try 1");from win32com import client as A;self.outlook=A.Dispatch(_B);self.olOutbox=self.outlook.GetNamespace(_A).GetDefaultFolder(4)
		except AttributeError:
			B.debug(f"{log_space}Try 2");import os;import re;import sys;import shutil as D;E=[A.__name__ for A in sys.modules.values()]
			for C in E:
				if re.match('win32com\\.gen_py\\..+',C):del sys.modules[C]
			D.rmtree(os.path.join(os.environ.get('LOCALAPPDATA'),'Temp',_C));from win32com import client as A;self.outlook=A.gencache.EnsureDispatch(_B);self.olOutbox=self.outlook.GetNamespace(_A).GetDefaultFolder(4)
	def send_email(N,boolDisplay=False,boolRun=True,**O):
		M='Attachment';L='HTMLBody';K='Body';J='Subject';H=boolRun;D=None;P=get_run_logger();C=N.outlook.CreateItem(0)
		if not H:P.debug(f"{log_space}Skip run:{not H}");return
		for (E,A) in O.items():
			if E=='EmailObj':
				for B in A:
					if B=='To'and A[B]is not D:C.To=A[B]
					elif B=='CC'and A[B]is not D:C.CC=A[B]
					elif B==J and A[B]is not D:C.Subject=A[B]
					elif B==K and A[B]is not D:C.Body=A[B]
					elif B==L and A[B]is not D:C.HTMLBody=A[B]
					elif B==M and A[B]is not D:
						G=A[B].split(',')
						for B in G:
							from pathlib import Path;F=Path(B.strip())
							if F.is_file():C.Attachments.Add(F.resolve().absolute().__str__())
			else:
				if E=='To'and A is not D:C.To=A
				if E=='CC'and A is not D:C.CC=A
				if E==J and A is not D:C.Subject=A
				if E==K and A is not D:C.Body=A
				if E==L and A is not D:C.HTMLBody=A
				if E==M and A is not D:
					G=A.split(',')
					for B in G:
						from pathlib import Path;F=Path(B.strip())
						if F.is_file():C.Attachments.Add(F.resolve().absolute().__str__())
		from auto_initialize import checkFileValid as Q;from pathlib import Path,PureWindowsPath
		if Q(Path(C.HTMLBody)):
			R=Path(C.HTMLBody).resolve().absolute().__str__()
			with open(R,'r')as I:C.HTMLBody=I.read();I.close()
		if boolDisplay:C.Display(True)
		else:C.Send()
	def wait_send_complete(C,timeOut=900):
		D=timeOut;A=get_run_logger();A.debug(f"{log_space}Outbox sending in progress - outbox item count: {C.outlook.GetNamespace(_A).GetDefaultFolder(4).Items.Count}");import time
		for E in range(D):
			B=C.outlook.GetNamespace(_A).GetDefaultFolder(4).Items.Count
			if B==0:return True
			time.sleep(1);A.debug(f"{log_space}Timeout countdown {E} to {D}.  Outbox item count: {B}")
		A.debug(f"{log_space}Timeout:"+str(B));return False
	def sentFolderList(E):
		F=get_run_logger();F.debug(f"{log_space}Sentbox item count: {E.outlook.GetNamespace(_A).GetDefaultFolder(5).Items.Count}");import win32com.client as N,datetime as B;K=B.datetime(2022,11,27,0,1);O=B.datetime(2022,11,27,8,0);G=E.outlook.GetNamespace(_A).GetDefaultFolder(5)
		def L(in_dtObj):A=in_dtObj;return B.datetime(A.year,A.month,A.day,A.hour,A.minute)
		print(type(G.Items));format='%d/%m/%Y %H:%M %p';M=B.datetime.strftime(K,format);H="[LastModificationTime] > '"+M+"'";print(H);I=G.Items.Restrict(H);F.debug(f"{log_space}Folder item count: {I.Count}");A=[]
		for J in I:
			C=J;D=J.ReceivedTime;D=L(D)
			if not str(C.Subject)in A:print('%s :: %s'%(str(D),C.Subject));A=A+[str(C.Subject)]
		return A
	def folderItemsList(J,ofolder=5,dateRange_StartOn=datetime.datetime(2022,11,27,0,1)):
		K=get_run_logger();import datetime as E;L=J.outlook.GetNamespace(_A).GetDefaultFolder(ofolder)
		def F(in_dtObj):A=in_dtObj;return E.datetime(A.year,A.month,A.day,A.hour,A.minute)
		format='%m/%d/%Y %H:%M %p';G=E.datetime.strftime(dateRange_StartOn,format);M="[ReceivedTime] > '"+G+"'";C=L.Items.Restrict(M);A=[];D=''
		if C.Count>0:
			for H in C:
				B=H;I=H.ReceivedTime;I=F(I)
				if not str(B.Subject)in A:D=D+f"{log_space}{F(B.ReceivedTime)}::{B.Subject}\n";A=A+[str(B.Subject)]
			K.debug(f"{log_space}Sent item count: {C.Count} since {G},\n{D}")
		return A