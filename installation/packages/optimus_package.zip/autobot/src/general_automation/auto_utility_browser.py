#!/usr/bin/env python
_F='%Y%m%d_%H%M%S'
_E='.jpeg'
_D='.jpg'
_C='.png'
_B=False
_A=True
import config
from auto_utility_file import GetRecentCreatedFile
import rpa as r
from pathlib import Path,PureWindowsPath
def chromeZoom(factor):
	A=factor
	try:int(A)
	except ValueError:return
	A=int(A)
	if A<0:B='-'
	elif A>0:B='+'
	elif A==0:B='0'
	else:return
	r.keyboard('[ctrl]0')
	for C in range(int(abs(A))):r.keyboard('[ctrl]'+B)
	return
import sys
def exitProg():r.close();sys.exit(config.EX_OK)
def exitProgWError(errorCode):r.close();sys.exit(errorCode)
from datetime import date
from datetime import datetime
def snapImage(msg='Snap picture at '+datetime.now().strftime(_F),file_suffix='_Check.PNG',time_snap=datetime.now().strftime(_F)):A=time_snap;print(msg+' '+A+'.PNG');r.snap('(0,0)-(1920,1080)',config.LOG_DIR+'/'+A+file_suffix)
import time
def waitIdentifierExist(identifier,time_seconds=10,interval=5,snapPic=_A):
	U='RPA ERROR';T='FILE=';S=snapPic;R=interval;Q=time_seconds;K='s ';J='elapsed time';E='|';B=identifier;D=time.time();A=int(time.time()-D);print('waitIdentifierExist',time.ctime(D),E,A,E,type(B))
	if type(B)==list:
		H=list(map(lambda x:Path(config.IMAGE_DIR+'/'+x).absolute().__str__()if x.lower().endswith((_C,_D,_E))else x,B));A=int(time.time()-D)
		while _A:
			print('..... true ..... ',list(H),len(list(H)),type(list(H)))
			for (F,G) in enumerate(H):
				print('loop',G,F,J,str(A),K)
				if G.startswith(T):
					C=G.split('=');C=C[1].split(E);L=C[0].strip();M=C[1].strip();N=float(C[2].strip());O=GetRecentCreatedFile(L,M,min(N,A+10))
					if O is not None:return _A,F
				else:
					try:
						if not r.timeout():raise ValueError(U)
					except Exception as I:raise ValueError(str(I));exit
					P=r.exist(G);r.timeout()
					if P:A=int(time.time()-D);print('SUCCESS',G,F,J,str(A),K);return _A,F
			A=int(time.time()-D)
			if A>Q:
				print('FAIL',J,str(A),K)
				if S:snapImage()
				return _B,F
			else:print('loop wait',J,str(A),K);r.wait(R)
	else:
		if B.lower().endswith((_C,_D,_E)):B=Path(config.IMAGE_DIR+'/'+B).absolute().__str__()
		print('Not list',time.ctime(D),E,A,E,type(B),'identifer=',B)
		while _A:
			if B.startswith(T):
				C=B.split('=');C=C[1].split(E);L=C[0].strip();M=C[1].strip();N=float(C[2].strip());O=GetRecentCreatedFile(L,M,min(N,A+10))
				if O is not None:return _A
			else:
				try:
					if not r.timeout():raise ValueError(U)
				except Exception as I:print(I);raise ValueError(str(I));exit
				P=r.exist(B);r.timeout()
				if P:A=int(time.time()-D);return _A
			A=int(time.time()-D)
			if A>Q:
				if S:snapImage()
				return _B
			else:r.wait(R)
	return _B
def waitIdentifierDisappear(identifier,time_seconds=10,interval=5,snapPic=_A):
	A=identifier;B=time.time()
	if A.lower().endswith((_C,_D,_E)):A=Path(config.IMAGE_DIR+'/'+A).absolute().__str__()
	while _A:
		C=r.present(A);D=int(time.time()-B)
		if not C:return _A
		elif D>time_seconds:
			if snapPic:snapImage()
			return _B
		else:r.wait(interval)
	return _B