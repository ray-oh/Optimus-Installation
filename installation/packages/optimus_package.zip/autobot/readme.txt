https://www.freecodecamp.org/news/how-to-setup-virtual-environments-in-python/
pip install virtualenv
python<version> -m venv <virtual-environment-name>

mkdir projectA
cd projectA
python3.8 -m venv env

cd d:\
python -m venv DClick

env/Scripts/activate.bat
deactivate

pip list

pip freeze > requirements.txt

pip install -r requirements.txt


Setup windows taskscheduler
D:\PowershellScript\to_Console.bat
D:\QRes\1920-res.bat
powershell.exe
-WindowStyle Hidden -nologo -file D:\DClick\GeneralAutomationScript.ps1
-WindowStyle Hidden -nologo -file D:\DClick\runVBA_Email.ps1

 