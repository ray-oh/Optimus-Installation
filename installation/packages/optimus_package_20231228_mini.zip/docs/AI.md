Voice to text
open ai whisper ai install windows without GPU
https://github.com/openai/whisper/discussions/1463

penAI Whisper - lablab.ai
https://lablab.ai/tech/whisper

openai/whisper-large · Hugging Face
https://huggingface.co/openai/whisper-large

OpenAI Whisper — Your speech-to-text AI: History and usage
https://www.superannotate.com/blog/openai-whisper-automatic-speech-recognition-system

Introducing Whisper - openai.com
https://openai.com/research/whisper


OpenAI Whisper is a general-purpose speech recognition model that can perform multilingual speech recognition, speech translation, and language identification1234. It is trained on a large dataset of diverse audio and is a pre-trained model for automatic speech recognition and speech translation2. The model is open source and can be used to build useful applications and for further research on robust speech processing4.


Voice ai
text to speech generator with clone voice

https://robotwealth.com/how-to-connect-google-colab-to-a-local-jupyter-runtime/

https://research.google.com/colaboratory/faq.html#usage-limits

My vocal ai
voice cloning, text to speech
free
1 Custom voice quota
2 Monthly clone training quota
2,000 Monthly TTS characters
500 Characters per TTS request


https://play.ht/studio/files
TTS (text to speech), voice cloning


This AI Makes you a PRO Singer !
https://www.youtube.com/watch?v=Sj8hXeMcoUg

